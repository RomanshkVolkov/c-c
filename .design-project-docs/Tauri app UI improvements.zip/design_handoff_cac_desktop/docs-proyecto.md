# Handoff: documentación por proyecto

## Por dónde empezar

Empieza por los **PRs 1, 2 y 3** (pestañas y lectura, metadatos y frescura,
edición y plantillas). Con esos tres la documentación ya es utilizable y no
depende de nada externo.

**No implementes el PR 7 (GitHub) todavía.** Necesita una GitHub App creada en
la organización, su clave privada en el backend y un receptor de webhook con
secreto — nada de eso existe aún. Si se intenta antes, lo que sale es un token
inventado y un flujo que no se puede probar. Cuando llegue el momento, la
sección "Cómo se lee el archivo (backend)" tiene la secuencia exacta.

Para validar la idea del reflejo del repositorio **sin** integración, hay un
atajo en el estado vacío: pegar un README una vez. Cero backend.

Los PRs 4, 5 y 6 (decisiones, compartir, índice) son independientes entre sí y
se pueden hacer en cualquier orden después de los tres primeros.

## Qué es esto

La documentación de una lista, convertida en la cuarta vista del proyecto —
junto a List, Board y Calendar. Sustituye a `DocView` como superficie: el
markdown único por nodo se vuelve un documento con cuatro pestañas fijas, y
gana tres cosas que un markdown suelto no tiene: procedencia (de dónde salió
cada decisión), frescura (quién la revisó y cuándo) y origen en el repositorio
(una pestaña puede ser el reflejo de un `.md` de GitHub).

Referencia: **`Cac Project Docs.dc.html`** (en este paquete). Prototipo
navegable, no código para copiar. La barra "Prototype" de arriba conmuta las
nueve pantallas; la segunda barra cambia el estado del origen y de cada flujo.

## Fidelidad

**Alta** en estructura, medidas, iconografía y copy del chrome. El contenido es
el proyecto real (Portento · Dashboard, sus tareas y sus variables) para que se
lea como algo verdadero, pero los valores son de ejemplo. Ningún color nuevo:
todo sale de `index.css`.

## Lo que no cambia

- **Un documento por nodo.** Sigue siendo space / folder / list, como hoy en
  `DocView`. Las pestañas son secciones de ese documento, no documentos nuevos.
- **Notes se queda como está.** Comparte editor y gana el mismo botón de
  compartir, nada más. No hay "mover a proyecto" ni árbol compartido.
- **Los invitados no ven documentación.** Siguen limitados a Dev tools; al
  compartir en un canal ven la tarjeta, nunca el documento.

---

## Las cuatro pestañas

Fijas, siempre presentes, en este orden:

| Pestaña | Qué lleva |
| --- | --- |
| **Overview** | Qué es el proyecto, estructura del repo, tabla de variables de entorno |
| **Runbook** | Pasos numerados con comandos, y la vuelta atrás |
| **Decisions** | Registro append-only: fecha, autor, etiqueta, y de dónde salió |
| **Links** | Credenciales (referencias), código e infra, diseño y cliente |

Una pestaña vacía se muestra en gris y sin ruido — **no** se oculta, porque su
ausencia es información ("este proyecto no tiene runbook"). Solo Overview se
crea con contenido al usar una plantilla.

**La tabla de variables es la pieza central.** Cuatro columnas: clave, dónde se
define, quién la tiene, y un enlace a la bóveda. **Nunca guarda valores** — así
no caduca, no es un riesgo, y responde la pregunta que hace alguien nuevo.

## Lo que se quitó por el camino, y por qué

Está aquí para que no se reintroduzca sin discutirlo:

- **Bloque de tareas abiertas embebido.** El tablero está a un clic y ya está
  abierto. Duplicarlo cargaba el documento sin añadir nada.
- **"Mencionado en" (backlinks).** Describe algo que ya pasó y nadie lo lee. Se
  sustituyó por compartir, que es la acción del momento en que el documento
  sirve. Si el equipo crece, volverá a hacer falta en la otra dirección: saber
  qué tareas dependen de un runbook **antes** de cambiarlo.

---

## Orden de PRs sugerido

1. **Pestañas y lectura.** Cuarta vista en la lista, cuatro pestañas, TOC
   lateral, tipografía de lectura. Con el markdown que ya existe repartido en
   Overview. Entregable por sí solo.
2. **Metadatos y frescura.** Owner, `reviewed_at`, aviso a los 90 días con
   Mark reviewed / Reassign owner, y el banner de una línea sobre el tablero.
3. **Edición y plantillas.** Autoguardado con historial, editor de bloques,
   menú `/`, cuatro plantillas, estado vacío.
4. **Decisiones.** Pestaña Decisions, `/decision` en la tarea, decisión en la
   descripción, procedencia.
5. **Compartir e insertar.** Share a canal/DM, `/doc` en el composer, "guardar
   mensaje en la documentación".
6. **Índice de la organización.** Tabla ordenada por revisión, filtros,
   documentación en ⌘K.
7. **GitHub.** App de organización, vínculo por pestaña, webhook, edición del
   archivo con commit o PR.

Los PRs 1–3 son la base y son los que hay que hacer primero. El 7 es el más
grande y el único que necesita trabajo de infraestructura: **no se empieza hasta
que exista la GitHub App y el receptor de webhook** (ver "Por dónde empezar").

---

## Archivos

**Nuevos**

| Archivo | Qué es |
| --- | --- |
| `src/components/docs/DocTabs.tsx` | Las cuatro pestañas + cabecera del documento |
| `src/components/docs/DocHeader.tsx` | Owner, frescura, Share, History, estado de guardado |
| `src/components/docs/DocEditor.tsx` | Editor de bloques (reusa el de Notes) |
| `src/components/docs/blocks/EnvTable.tsx` | Bloque de tabla de variables |
| `src/components/docs/blocks/CredentialRef.tsx` | Referencia a bóveda, sin valor |
| `src/components/docs/DecisionList.tsx` | Entradas con fecha, autor, etiqueta, procedencia |
| `src/components/docs/DecisionForm.tsx` | `/decision` desde la tarea y desde el documento |
| `src/components/docs/ShareDoc.tsx` | Popover de compartir a canal o DM |
| `src/components/docs/DocIndex.tsx` | Índice de la organización |
| `src/components/docs/TemplatePicker.tsx` | Estado vacío con las cuatro plantillas |
| `src/components/docs/SourceBar.tsx` | Barra de origen: sincronizado, sin conexión, roto |
| `src/components/docs/github/FilePicker.tsx` | Repo, rama, árbol y previsualización |
| `src/components/docs/github/FileEditor.tsx` | Markdown crudo, diff, commit o PR |
| `src/components/docs/github/InstallFlow.tsx` | Instalación de la App a nivel de org |
| `src/pages/DocIndexPage.tsx` | Ruta del índice |

**Que cambian**

| Archivo | Cambio |
| --- | --- |
| `src/components/DocView.tsx` | Se reemplaza por `DocTabs`; el markdown actual pasa a Overview |
| `src/pages/MyWork.tsx` | Cuarto icono de vista tras un divisor; banner del doc cuando el scope es una lista |
| `src/pages/Tasks.tsx` | Igual, en la cabecera de la lista |
| `src/components/tasks/TaskDetail.tsx` | Bloque de decisión en descripción y comentarios; `/decision` en el composer |
| `src/components/chat/MessageActions.tsx` | "Guardar en la documentación" |
| `src/components/chat/Composer.tsx` | `/doc` para insertar una sección |
| `src/components/AppSidebar.tsx` | Marca de documentación en folders y listas; "All docs" |
| `src/components/CommandPalette.tsx` | Documentación como categoría en ⌘K |
| `src/pages/Organization.tsx` | Integración de GitHub y tabla de documentos conectados |

---

## Modelo de datos

```ts
// Un documento por nodo, con secciones por pestaña
Doc {
  id, kind: "space" | "folder" | "list", nodeId,
  ownerId: string | null,
  reviewedAt: Date | null, reviewedBy: string | null,
  pinnedLine: string | null,          // el banner sobre el tablero
}

DocTab {
  docId, key: "overview" | "runbook" | "decisions" | "links",
  body: string,                        // markdown, vacío si está conectada
  source: DocTabSource | null,         // si no es null, la pestaña es read-only
  updatedAt, updatedBy,
}

DocTabSource {                         // el vínculo es POR PESTAÑA, no por doc
  repo: string, branch: string, path: string,
  blobSha: string, etag: string,
  syncedAt: Date, state: "synced" | "unreachable" | "missing",
  cachedBody: string,                  // ← siempre hay copia guardada
}

Decision {
  docId, title, body, tag, authorId, decidedAt,
  origin: { kind: "task", taskId } | { kind: "message", messageId, channelId } | { kind: "doc" },
}

DocVersion { docId, tabKey, body, authorId, savedAt }
```

Cuatro reglas del diseño que van en el modelo, no en la pantalla:

- **Siempre hay copia guardada.** `cachedBody` no es opcional. Si GitHub no
  responde, el documento se lee igual y solo dice de cuándo es. Un documento que
  necesita red para existir no sirve en una app de escritorio.
- **El vínculo es por pestaña.** Así conviven el reflejo del repo (Overview) y
  lo escrito a mano (Decisions) en el mismo documento.
- **Decisions es append-only.** Se corrige añadiendo, no editando: un registro
  que se puede reescribir no es un registro.
- **`origin` es obligatorio.** Toda decisión sabe de dónde salió, y ese es el
  enlace de vuelta a la tarea o al mensaje.

## Endpoints

**Documentación**

| Endpoint | Para qué |
| --- | --- |
| `GET /api/v1/docs/:kind/:id` | El documento con sus cuatro pestañas resueltas |
| `PUT /api/v1/docs/:kind/:id/tabs/:tab` | Guardar una pestaña (autoguardado; 409 si está conectada) |
| `GET /api/v1/docs/:kind/:id/versions?tab=` | Historial |
| `POST /api/v1/docs/:kind/:id/versions/:v/restore` | Restaurar |
| `PATCH /api/v1/docs/:kind/:id` | Owner, `reviewedAt`, línea fijada |
| `POST /api/v1/docs/:kind/:id/decisions` | Registrar decisión (con `origin`) |
| `POST /api/v1/docs/:kind/:id/from-template` | Crear desde plantilla |
| `GET /api/v1/docs` | Índice de la organización (filtros: owner, stale, sin dueño) |
| `GET /api/v1/search?kinds=docs` | Documentación en ⌘K |
| `POST /api/v1/docs/:kind/:id/share` | Publicar la tarjeta en un canal o DM |

**GitHub**

| Endpoint | Para qué |
| --- | --- |
| `GET /api/v1/integrations/github` | Estado: instalada, pendiente de owner, repos compartidos |
| `GET /api/v1/integrations/github/install-url` | URL de instalación de la App |
| `GET /api/v1/integrations/github/callback` | Callback: guarda `installation_id` |
| `GET /api/v1/integrations/github/repos` | Repos con acceso |
| `GET /api/v1/integrations/github/tree?repo=&branch=` | Árbol para el selector |
| `GET /api/v1/integrations/github/file?repo=&branch=&path=` | Contenido crudo + sha |
| `PUT /api/v1/docs/:kind/:id/tabs/:tab/source` | Atar la pestaña a un archivo |
| `DELETE /api/v1/docs/:kind/:id/tabs/:tab/source` | Desatar |
| `POST /api/v1/integrations/github/commit` | Commit directo desde la app |
| `POST /api/v1/integrations/github/pull-request` | PR cuando la rama está protegida |
| `POST /api/v1/webhooks/github` | Receptor de `push` |

### Cómo se lee el archivo (backend)

1. **Token de instalación.** JWT firmado con la clave privada de la App (RS256,
   10 min) → `POST /app/installations/:id/access_tokens`. El token dura 1 hora;
   se cachea y se renueva. **Nunca sale del backend** — el webview de Tauri no
   lo ve.
2. **Contenido.** `GET /repos/{owner}/{repo}/contents/{path}?ref={branch}` con
   `Accept: application/vnd.github.raw`. Se guarda el `sha` del blob y el
   `etag`; la siguiente lectura manda `If-None-Match` y un 304 no gasta cuota.
3. **Árbol del selector.** `GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1`
   en una sola llamada, filtrando `.md`.
4. **Refresco.** Webhook `push`: `commits[].modified/added/removed` contra las
   rutas atadas; si coincide, se invalida y se relee. Firma verificada con
   `X-Hub-Signature-256`.
5. **Escritura.** `PUT /repos/.../contents/{path}` con el `sha` actual — si el
   sha no coincide, alguien más cambió el archivo: hay que releer y avisar, no
   sobrescribir. Para PR: crear rama con `POST /git/refs`, commit, y
   `POST /pulls`.

**Detalle que muerde:** los enlaces relativos e imágenes del README
(`./docs/img/x.png`) se rompen al renderizar fuera de GitHub. Hay que
reescribirlos a `raw.githubusercontent.com` en el backend antes de servir el
markdown.

**Permisos de la App:** `contents: read` (leer), `contents: write` (solo para
los commits que se hacen desde cac), `metadata: read` (listar repos y ramas).
Nada más. Si quien instala es miembro y no owner de la organización de GitHub,
la instalación queda como solicitud pendiente: es un estado de la pantalla, no
un error.

---

## Reglas visuales

Medidas exactas del prototipo. Tokens de `tokens.css`; ningún color nuevo.

**Documento**

- Cabecera 52 px: ruta en `--muted-foreground` + nombre de la lista en 14/600,
  los cuatro iconos de vista a la derecha (26 px, el de docs tras un divisor de
  1×16 px), chip de guardado, Share, History, `⋯`.
- Fila de metadatos: Owner (píldora con avatar 20 px), Reviewed (chip de
  frescura), y a la derecha "Pinned above the board".
- Pestañas: 34 px de alto, subrayado de 2 px en `--primary` cuando está activa,
  pista en 12 px a la derecha del nombre. Candado de 12 px si está conectada.
- Cuerpo: `max-width: 720px`, texto 16 px / `line-height: 1.7`, H2 17/600.
  Medida de línea corta a propósito: es un documento, no un panel.
- TOC lateral de 216 px con barra de 2 px en `--primary` sobre la sección
  visible. Solo en Overview y Runbook; en Decisions y Links no aporta.

**Chips de frescura**

| Estado | Tratamiento |
| --- | --- |
| Al día | `--success` sobre `rgba(52,211,153,.09)` |
| 90+ días | `#F5C451` sobre `rgba(245,158,11,.09)`, con aviso completo al principio de la pestaña |
| Sin dueño | `--destructive`, solo en el índice |

El aviso de 90 días es una caja de 12/14 px con Mark reviewed y Reassign owner,
y dice **por qué** está sin revisar ("nadie lo ha confirmado desde el cambio de
host"), no solo cuántos días lleva.

**Barra de origen** (cuando la pestaña viene del repo)

Una fila de 9/12 px sobre el contenido: icono de GitHub, `repo@rama · ruta` en
monoespaciada 12,5 px, punto de estado, detalle, y las acciones a la derecha.

| Estado | Borde y fondo | Acciones |
| --- | --- | --- |
| Sincronizado | `--border` sobre `#131317` | Edit the file · On GitHub |
| Sin conexión | ámbar `.3` sobre `.07` | Retry · Edit the file |
| Archivo no existe | rojo `.32` sobre `.07` | Reconnect · Unlink |

Con la pestaña conectada, el chip de guardado dice "Read-only · from GitHub" en
`--muted-foreground`, no "Saved".

**Decisiones**

Tarjeta de radio 11, borde `--border` sobre `#131317`: fecha tabular, avatar
20 px, autor, etiqueta a la derecha; título 15/600, cuerpo 14 px en
`--muted-foreground`; y una fila de procedencia separada por una línea de 1 px:

- Desde una tarea: enlace con icono de check-square, "From #109 · título".
- Desde un mensaje: enlace con `#`, "From a message in #Portento".
- Escrita ahí: texto plano en `--muted-foreground`, "Written here".

El bloque de decisión dentro de una tarea (descripción o comentario) usa violeta
`#C4B5FD` sobre `rgba(155,135,245,.07)`, con la etiqueta DECISION en 11,5 px /
700 / mayúsculas. Es el único sitio donde aparece ese color: marca "esto no es
un comentario cualquiera".

**Compartir**

Popover de 340 px anclado al botón. Conmutador Whole doc / This section, con
**This section por defecto** — lo que se pega en un chat es una respuesta
concreta, y un enlace a un documento de cuatro pestañas obliga a buscarla.
Destinos mezclados (canales y DMs) en una sola lista. Previsualización de la
tarjeta tal como aterriza en el hilo, con ruta y frescura.

Al insertar desde el composer con `/doc`, tres formas: **Steps inline** (por
defecto — el texto pegado, gana en secciones cortas), Card + link, Link only.

**Editor**

Barra de formato visible de 42 px con 12 controles lucide de 15 px. Menú de
bloques con `/` de 330 px que incluye los bloques propios: fila de variable de
entorno, referencia a credencial, mención de tarea. Asa de arrastre a −30 px
del bloque. Autoguardado cada pocos segundos; el chip pasa por "Saving…" en
ámbar y vuelve a verde. Cada guardado es una versión.

**Índice de la organización**

Tabla de cinco columnas: Document (con la **ruta completa**, no el nombre — en
esta organización todas las listas se llaman `tasks` y el nombre solo no
identifica nada), Where, Owner, Last reviewed, Tasks. Ordenada por última
revisión, no alfabética: lo desactualizado sube. Al pie, las listas sin
documentación con enlace directo a las plantillas.

**Iconos** — lucide, 13–16 px en chrome, 20 px en cabeceras de tarjeta:
`FileText` (documento), `Gavel` (decisión), `Share`, `Link2`, `Github`,
`GitBranch`, `GitPullRequest`, `Lock`, `Pencil`, `Eye`, `RefreshCw`,
`ExternalLink`, `AlertCircle`, `Check`, `Save`.

---

## Estados y bordes

| Situación | Qué se ve |
| --- | --- |
| Lista sin documentación | Estado vacío con las cuatro plantillas, "Start blank" y "pega un README" |
| Pestaña vacía, documento con contenido | Nombre de pestaña en gris; dentro, una línea y el botón de editar |
| Pestaña conectada | Read-only, barra de origen, candado en la pestaña; editar abre el editor de **archivo** |
| GitHub caído | Copia guardada + edad + Retry. Nunca una pantalla vacía |
| Archivo renombrado o rama borrada | "File not found" con Reconnect / Unlink, y aviso en el índice de la org |
| Sha desactualizado al hacer commit | "Alguien cambió el archivo": releer y mostrar el diff nuevo, nunca sobrescribir |
| Rama protegida | El modo commit se desactiva; solo PR, explicando por qué |
| Instala un miembro sin permisos | "Needs an owner": solicitud pendiente, docs siguen a mano |
| Dos personas editando | Hoy solo se anuncia "Alexander is viewing". La escritura simultánea **no está resuelta** |
| Invitado | No ve documentación; en un canal ve la tarjeta compartida, no el documento |

## Accesibilidad

- El estado de la barra de origen no se comunica solo por color: cada estado
  cambia el texto ("Synced", "GitHub unreachable", "File not found").
- El candado de pestaña conectada lleva `title` y `aria-label`; el bloque de
  decisión lleva la palabra DECISION, no solo el color violeta.
- El chip de guardado es `aria-live="polite"`, para que un lector de pantalla
  anuncie el guardado sin interrumpir la escritura.
- `Esc` cierra el popover de compartir, el menú de bloques y el selector de
  archivo; nunca descarta cambios sin guardar.

## Lo que queda sin diseñar

Honesto, para que no se descubra a mitad de la implementación:

- **Escritura simultánea.** Solo se anuncia quién está mirando. Si dos personas
  escriben la misma pestaña, no hay resolución — hace falta decidir entre
  bloqueo suave, último gana con aviso, o CRDT (que es otro proyecto).
- **Editar la tabla de variables celda a celda.** Se diseñó como bloque, no la
  interacción de edición.
- **Permisos por documento.** Hoy hereda del space. Nadie ha pedido más.
- **Comentarios en línea sobre el documento.** Deliberadamente fuera: la
  discusión va al canal, y de ahí a Decisions.

## Checklist de aceptación

- [ ] Las cuatro pestañas existen siempre; una vacía se ve en gris y no se oculta.
- [ ] La tabla de variables nunca almacena un valor, solo referencias.
- [ ] Un documento no revisado en 90 días lo dice en la propia pestaña, con dueño.
- [ ] El banner de una línea aparece sobre el tablero solo si el scope es una lista.
- [ ] `/decision` en una tarea publica el comentario **y** añade la entrada, una sola vez.
- [ ] Toda decisión enlaza de vuelta a su origen, y la tarea enlaza a la decisión.
- [ ] Compartir por defecto manda la sección, no el documento entero.
- [ ] `/doc` en el composer inserta los pasos como texto por defecto.
- [ ] Una pestaña conectada es de solo lectura y se puede editar como archivo sin salir de la app.
- [ ] Con GitHub caído el documento se sigue leyendo y dice de cuándo es la copia.
- [ ] Un commit con sha desactualizado no sobrescribe: avisa y vuelve a mostrar el diff.
- [ ] El índice ordena por última revisión y muestra las listas sin documentación.
- [ ] Ningún emoji: todos los iconos son lucide.
