# Handoff: salas de voz en canales

## Qué es esto

La conversación hablada de un canal, con el modelo de Discord: entras a la sala
del canal, ves quién está dentro, y opcionalmente enciendes cámara o compartes
pantalla. Sustituye la pastilla `VoiceBar` de la cabecera como *única* superficie
de la llamada: la pastilla se queda para entrar y para el estado mínimo, pero la
llamada tiene ahora una pantalla propia.

Referencia: **`Cac Voice Rooms.dc.html`** (en este paquete). Es un prototipo
navegable, no código para copiar. Todo lo descrito abajo funciona ahí: entrar,
mute, sordera, cámara, compartir pantalla con selector, spotlight, chat en
overlay, ajustes de dispositivos, invitar, timbre y llamada entrante.

## Fidelidad

**Alta** en colores, medidas, iconografía y estructura. Los datos son de ejemplo
(Marta A., Luis R., Elena Ruiz). Los mosaicos de cámara y de pantalla compartida
son marcadores: el vídeo real va en su lugar, mismo radio y mismo borde.

## Lo que no cambia

- **Canal = espacio.** La sala sigue siendo la del `task-space`, como hoy en
  `voice.store.ts`. No se introduce un tipo "canal de voz" aparte.
- **El motor sigue en Rust.** El front no toca media: manda órdenes por `invoke`
  y pinta el estado que llega por el `Channel<VoiceEvent>`. El webview de Linux no
  tiene WebRTC (ver `docs/voz.md`), y eso no cambia con este diseño.
- **Una sala a la vez.** `entrar()` ya sale de la anterior; se mantiene.

---

## El cambio de modelo de estado (importante)

Hoy hay un solo booleano implícito: estás dentro o fuera. El diseño necesita
**dos**, porque *minimizar no es colgar*:

| Estado | Qué significa | Qué se ve |
| --- | --- | --- |
| `conectado` | El micrófono está abierto en esa sala | Barra verde al pie del sidebar, "Back to call" en la cabecera del canal |
| `escenario` | La pantalla de la sala está abierta | Mosaicos + barra de controles a pantalla completa |

- **Join voice** → `conectado: true`, `escenario: true`
- **Minimize** → `escenario: false` (sigues conectado; el audio no se corta)
- **Barra del sidebar / Back to call** → `escenario: true`
- **Leave** (o el botón rojo del sidebar) → los dos a `false`

Si esto se implementa con un solo estado, minimizar cuelga la llamada — que es
justo el error que el diseño evita.

---

## Orden de PRs sugerido

1. **Escenario y navegación.** `VoiceStage.tsx` nuevo + `conectado`/`escenario` en
   el store + Minimize / Back to call / barra del sidebar. Solo audio: mute,
   sordera y salir. Ya es un cambio completo y entregable.
2. **Presencia anidada.** Los presentes bajo el canal en la lista (`Channels.tsx`)
   y el aviso en el hilo ("Marta A. and Luis R. are talking in this channel ·
   Join"). Usa `ocupacion`, que ya existe.
3. **Cámara.** `voice_set_cam` + pista de vídeo en los mosaicos + selector de
   cámara en el popover de ajustes.
4. **Compartir pantalla.** `voice_share_screen` + diálogo de fuentes + layout
   spotlight con filmstrip.
5. **Timbre.** Señalización del ring, tarjeta de llamada entrante, tono WebAudio.

Cada uno es independiente. Si se para en el 1, la voz ya tiene pantalla propia.

---

## Archivos

**Nuevos**

| Archivo | Qué es |
| --- | --- |
| `src/components/voice/VoiceStage.tsx` | La pantalla de la sala: cabecera, mosaicos o spotlight, barra de controles |
| `src/components/voice/VoiceTile.tsx` | Un participante: avatar o vídeo, anillo de habla, nombre, mic-off |
| `src/components/voice/VoiceControls.tsx` | Los 6 botones + Leave |
| `src/components/voice/ScreenPicker.tsx` | Diálogo de fuentes (`Dialog` de shadcn) |
| `src/components/voice/DeviceSettings.tsx` | Popover de micrófono / salida / cámara / supresión de ruido |
| `src/components/voice/IncomingCall.tsx` | Tarjeta de llamada entrante |
| `src/components/voice/ringtone.ts` | Los dos tonos WebAudio |

**Que cambian**

| Archivo | Cambio |
| --- | --- |
| `src/store/voice.store.ts` | Campos y acciones de abajo |
| `src/components/chat/VoiceBar.tsx` | Entrar abre el escenario; dentro, la pastilla queda como "Back to call" |
| `src/components/chat/ChannelView.tsx` | Monta `VoiceStage` cuando `escenario && spaceId === este` |
| `src/pages/Channels.tsx` | Presentes anidados bajo el canal; icono `Volume2` + conteo (ya está) |
| `src/components/AppSidebar.tsx` | Barra de conexión al pie, encima de la fila de cuenta |

---

## Store: lo que se añade a `voice.store.ts`

```ts
// estado
escenario: boolean;            // la pantalla de la sala está abierta
cam: boolean;                  // tu cámara
compartiendo: boolean;         // tu pantalla
sordo: boolean;                // deafen: no oyes y no te oyen
video: Record<string, boolean>;      // identity -> tiene pista de vídeo
pantalla: string | null;             // identity de quien comparte, o null
dispositivos: { mic?: string; salida?: string; cam?: string };
llamando: { identity: string; name: string; desde: number } | null;  // saliente
entrante: { identity: string; name: string; spaceId: string } | null; // recibida

// acciones
abrirEscenario / cerrarEscenario
alternarCam / alternarCompartir(fuente) / alternarSordera
elegirDispositivo(tipo, id)
timbrar(identity) / cancelarTimbre()
aceptarEntrante() / rechazarEntrante()
```

Dos reglas del diseño que van en el store, no en la pantalla:

- **Sordera implica mute.** Ponerse sordo silencia el micrófono; quitarse la
  sordera no lo desilencia solo (en el mockup: `toggleDeaf`).
- **El timbre se corta solo a los 20 s** y deja "did not answer · Ring again".
  Sin ese tope, un timbre olvidado suena para siempre.

`VoiceEvent` necesita tres variantes más, que el motor ya puede reportar:
`{ kind: "video"; identity; enabled }`, `{ kind: "screen"; identity | null }`,
`{ kind: "ring"; identity; name; spaceId }`.

## Comandos Tauri (Rust)

| Comando | Args | Devuelve |
| --- | --- | --- |
| `voice_set_cam` | `{ enabled, deviceId? }` | `()` |
| `voice_share_screen` | `{ sourceId, withAudio }` | `()` |
| `voice_stop_share` | — | `()` |
| `voice_set_deaf` | `{ enabled }` | `()` |
| `voice_list_sources` | — | `[{ id, kind: "screen" \| "window", title, thumbnail }]` |
| `voice_list_devices` | — | `{ mics, outputs, cams }` |
| `voice_set_device` | `{ kind, deviceId }` | `()` |

Optimista igual que `alternarMic`: la UI cambia al pulsar y el comando confirma.
Si falla, se revierte y se muestra el error donde está el control, no en un toast
global.

## Endpoints que faltan

| Endpoint | Para qué | Notas |
| --- | --- | --- |
| `POST /api/v1/task-spaces/:id/voice/ring` | Timbrar a un miembro | Body `{ userId }`. Devuelve `{ ringId }` |
| `DELETE /api/v1/task-spaces/:id/voice/ring/:ringId` | Cancelar el timbre | También lo cancela el tope de 20 s del cliente |
| `WS voice.ring` | Recibir la llamada entrante | `{ ringId, spaceId, from: { id, name }, expiresAt }` |
| `WS voice.presence` | Sustituir el sondeo de 15 s | Opcional; el sondeo actual funciona y no bloquea nada |
| `GET /api/v1/chat/voice-presence` | Ya existe | Añadir `video: boolean` y `screen: boolean` por participante |

Sin `voice.ring` el timbre no se puede entregar: no se emula desde el cliente.
Todo lo demás del diseño funciona con lo que ya hay.

**Notificación del sistema.** Con la app en segundo plano, la llamada entrante es
una notificación nativa de Tauri con acciones Join / Decline, además de la tarjeta
dentro de la app.

---

## Reglas visuales

Medidas exactas del mockup. Tokens de `tokens.css`; ningún color nuevo.

**Escenario**

- Fondo `#0B0B0E` (un paso por debajo de `--background`: la llamada es una
  superficie más profunda que la app).
- Cabecera 52 px: icono `Volume2` verde, `#canal`, `3 in voice · 38 ms` en
  `--muted-foreground`, y a la derecha Invite / Chat / Minimize (32 px de alto,
  radio 7, borde `--border`).
- Padding del área de mosaicos: 20 px, `gap: 14px`.

**Mosaicos**

- Rejilla de 2 columnas, filas iguales, radio 14, fondo `#15151A`.
- Borde 2 px: `--success` (`#34D399`) mientras habla, `#1E1E24` cuando calla. El
  borde es el único indicador de habla; no se añaden ondas ni contadores.
- Avatar 84 px, iniciales 26 px/700. Con cámara, el vídeo llena el mosaico
  (`object-fit: cover`) y el avatar desaparece.
- Nombre: píldora `rgba(11,11,14,.72)`, radio 999, 13 px, abajo-izquierda a 12/11 px.
- Silenciado: `MicOff` 15 px en `--destructive` dentro de píldora igual,
  abajo-derecha. Icono, no la palabra.

**Barra de controles** (84 px, fondo `--sidebar`)

Seis botones circulares de 46 px, centrados, `gap: 10px`, y Leave separado por un
divisor de 1×28 px:

| Botón | Apagado | Encendido |
| --- | --- | --- |
| Mic | borde `--border`, fondo `#17171B` | mute: borde y texto `--destructive` sobre `rgba(251,113,133,.12)` |
| Deafen | igual | igual que mute |
| Camera | igual | `--primary` sobre `rgba(32,217,232,.14)` |
| Share | igual | igual que camera |
| Settings | siempre neutro | — |
| Leave | píldora `--destructive`, texto `#2A0A12`, 700 | — |

Iconos **lucide** a 20 px, `currentColor`: `Mic` / `MicOff`, `Headphones` /
`HeadphoneOff`, `Video` / `VideoOff`, `MonitorUp`, `SlidersHorizontal`,
`PhoneOff`. En la cabecera y el sidebar, 15–16 px.

**Compartir pantalla**

- El compartido ocupa el área principal con borde 2 px `--primary`; los
  participantes pasan a una columna de 200 px a la derecha, mosaicos de 120 px.
- Sobre el compartido: píldora "You are sharing · 1080p 30fps" abajo-izquierda y
  "Stop sharing" abajo-derecha. Salir de compartir no requiere ir a la barra.
- El selector es un `Dialog` de 620 px con pestañas Screens / Windows, rejilla de
  3 miniaturas 16:9, toggle "Share system audio", Cancel / Share.

**Chat de la sala**

Panel de 340 px dentro del escenario, radio 12, `rgba(19,19,23,.92)` con
`backdrop-filter: blur(8px)`. Es el mismo hilo del canal, no un chat aparte: los
mensajes enviados aquí salen en `#canal`.

**Barra del sidebar** (cuando estás conectado)

Caja de 8 px de margen, borde `rgba(52,211,153,.35)` sobre `rgba(52,211,153,.07)`:
punto verde, nombre del canal en `--success`, "Voice connected · 38 ms", y debajo
Mute (ancho completo) + `PhoneOff` rojo. Toda la fila del nombre es clicable y
vuelve al escenario.

**Timbre**

- Saliente: fila propia sobre la barra de controles (no flotante encima de los
  mosaicos), avatar con anillo `pulse` de 1,8 s, "Ringing Elena Ruiz", "Calling ·
  0:07", Cancel. A los 20 s pasa a "did not answer · Ring again · Dismiss".
- Entrante: overlay `rgba(8,8,10,.72)` con `blur(3px)` y tarjeta de 360 px:
  avatar 72 px con dos anillos `pulse` desfasados 0,7 s, nombre 17 px, "Calling
  you to #canal · 3 in voice", Decline (`--destructive`, suave) y Join
  (`--success`, sólido) al 50 % cada uno, y "Reply in chat instead" debajo.
- Tonos (`ringtone.ts`, WebAudio, sin archivos de audio):
  - Saliente: 440 + 480 Hz, 1,2 s on / 2,4 s off, ganancia 0,05.
  - Entrante: 880 Hz 260 ms + 1174 Hz 320 ms, cada 1,6 s, ganancia 0,045.
  - Ambos con rampa de 30 ms al entrar y al salir: sin la rampa se oye un clic.
  - El tono entrante respeta la sordera y el silencio del sistema operativo.

---

## Estados y bordes

| Situación | Qué se ve |
| --- | --- |
| Nadie en la sala, tú fuera | Cabecera del canal con "Join voice" sin avatares |
| Alguien dentro, tú fuera | Presentes anidados en la lista + aviso en el hilo con "Join" + avatares apilados en el botón |
| Entrando | Botón con spinner (`Loader2`), como hoy |
| Solo tú dentro | Bajo tu nombre, "nobody else yet" — el conteo a 1 no dice eso |
| Sin WebRTC en el webview | El error que ya devuelve `entrar()`, en el sitio del botón, con enlace a Dev tools › Webview lab |
| Te expulsan / se cae el SFU | Escenario se cierra, barra del sidebar desaparece, aviso en el hilo: "Disconnected · Rejoin" |
| Dos comparten a la vez | Solo una en spotlight; la otra queda en el filmstrip con borde `--primary` y se cambia pulsándola |

## Accesibilidad

- Cada control lleva `aria-label` y `aria-pressed`; el estado no se comunica solo
  por color (mute y sordera cambian el icono, no solo el tinte).
- El anillo de habla se acompaña de `aria-live` discreto al entrar y salir gente,
  no por cada palabra.
- `Esc` cierra el selector de fuentes, el popover de ajustes y el chat; **no**
  cuelga la llamada.
- Foco visible con `--ring` en los botones circulares.

## Checklist de aceptación

- [ ] Minimize mantiene el audio; solo Leave desconecta.
- [ ] La barra del sidebar aparece en cualquier pantalla de la app mientras estés
      conectado, y devuelve al escenario.
- [ ] El borde verde sigue a `hablando` y se apaga cuando alguien se va hablando.
- [ ] Sordera silencia el micrófono.
- [ ] Compartir se puede parar desde el propio compartido.
- [ ] El timbre se corta a los 20 s y se puede cancelar antes.
- [ ] La llamada entrante suena, muestra canal y ocupación, y Join entra a esa sala.
- [ ] Ningún emoji: todos los iconos son lucide.
