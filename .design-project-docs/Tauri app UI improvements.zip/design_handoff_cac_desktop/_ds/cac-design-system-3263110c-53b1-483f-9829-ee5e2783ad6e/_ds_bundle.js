/* @ds-bundle: {"namespace":"CacDS","components":[{"name":"Avatar","sourcePath":"components/general/Avatar/Avatar.jsx"},{"name":"AvatarBadge","sourcePath":"components/general/AvatarBadge/AvatarBadge.jsx"},{"name":"AvatarFallback","sourcePath":"components/general/AvatarFallback/AvatarFallback.jsx"},{"name":"AvatarGroup","sourcePath":"components/general/AvatarGroup/AvatarGroup.jsx"},{"name":"AvatarGroupCount","sourcePath":"components/general/AvatarGroupCount/AvatarGroupCount.jsx"},{"name":"AvatarImage","sourcePath":"components/general/AvatarImage/AvatarImage.jsx"},{"name":"Badge","sourcePath":"components/general/Badge/Badge.jsx"},{"name":"Button","sourcePath":"components/general/Button/Button.jsx"},{"name":"Card","sourcePath":"components/general/Card/Card.jsx"},{"name":"CardAction","sourcePath":"components/general/CardAction/CardAction.jsx"},{"name":"CardContent","sourcePath":"components/general/CardContent/CardContent.jsx"},{"name":"CardDescription","sourcePath":"components/general/CardDescription/CardDescription.jsx"},{"name":"CardFooter","sourcePath":"components/general/CardFooter/CardFooter.jsx"},{"name":"CardHeader","sourcePath":"components/general/CardHeader/CardHeader.jsx"},{"name":"CardTitle","sourcePath":"components/general/CardTitle/CardTitle.jsx"},{"name":"Dialog","sourcePath":"components/general/Dialog/Dialog.jsx"},{"name":"DialogClose","sourcePath":"components/general/DialogClose/DialogClose.jsx"},{"name":"DialogContent","sourcePath":"components/general/DialogContent/DialogContent.jsx"},{"name":"DialogDescription","sourcePath":"components/general/DialogDescription/DialogDescription.jsx"},{"name":"DialogFooter","sourcePath":"components/general/DialogFooter/DialogFooter.jsx"},{"name":"DialogHeader","sourcePath":"components/general/DialogHeader/DialogHeader.jsx"},{"name":"DialogOverlay","sourcePath":"components/general/DialogOverlay/DialogOverlay.jsx"},{"name":"DialogPortal","sourcePath":"components/general/DialogPortal/DialogPortal.jsx"},{"name":"DialogTitle","sourcePath":"components/general/DialogTitle/DialogTitle.jsx"},{"name":"DialogTrigger","sourcePath":"components/general/DialogTrigger/DialogTrigger.jsx"},{"name":"DropdownMenu","sourcePath":"components/general/DropdownMenu/DropdownMenu.jsx"},{"name":"DropdownMenuCheckboxItem","sourcePath":"components/general/DropdownMenuCheckboxItem/DropdownMenuCheckboxItem.jsx"},{"name":"DropdownMenuContent","sourcePath":"components/general/DropdownMenuContent/DropdownMenuContent.jsx"},{"name":"DropdownMenuGroup","sourcePath":"components/general/DropdownMenuGroup/DropdownMenuGroup.jsx"},{"name":"DropdownMenuItem","sourcePath":"components/general/DropdownMenuItem/DropdownMenuItem.jsx"},{"name":"DropdownMenuLabel","sourcePath":"components/general/DropdownMenuLabel/DropdownMenuLabel.jsx"},{"name":"DropdownMenuPortal","sourcePath":"components/general/DropdownMenuPortal/DropdownMenuPortal.jsx"},{"name":"DropdownMenuRadioGroup","sourcePath":"components/general/DropdownMenuRadioGroup/DropdownMenuRadioGroup.jsx"},{"name":"DropdownMenuRadioItem","sourcePath":"components/general/DropdownMenuRadioItem/DropdownMenuRadioItem.jsx"},{"name":"DropdownMenuSeparator","sourcePath":"components/general/DropdownMenuSeparator/DropdownMenuSeparator.jsx"},{"name":"DropdownMenuShortcut","sourcePath":"components/general/DropdownMenuShortcut/DropdownMenuShortcut.jsx"},{"name":"DropdownMenuSub","sourcePath":"components/general/DropdownMenuSub/DropdownMenuSub.jsx"},{"name":"DropdownMenuSubContent","sourcePath":"components/general/DropdownMenuSubContent/DropdownMenuSubContent.jsx"},{"name":"DropdownMenuSubTrigger","sourcePath":"components/general/DropdownMenuSubTrigger/DropdownMenuSubTrigger.jsx"},{"name":"DropdownMenuTrigger","sourcePath":"components/general/DropdownMenuTrigger/DropdownMenuTrigger.jsx"},{"name":"Input","sourcePath":"components/general/Input/Input.jsx"},{"name":"Label","sourcePath":"components/general/Label/Label.jsx"},{"name":"Select","sourcePath":"components/general/Select/Select.jsx"},{"name":"SelectContent","sourcePath":"components/general/SelectContent/SelectContent.jsx"},{"name":"SelectGroup","sourcePath":"components/general/SelectGroup/SelectGroup.jsx"},{"name":"SelectItem","sourcePath":"components/general/SelectItem/SelectItem.jsx"},{"name":"SelectLabel","sourcePath":"components/general/SelectLabel/SelectLabel.jsx"},{"name":"SelectScrollDownButton","sourcePath":"components/general/SelectScrollDownButton/SelectScrollDownButton.jsx"},{"name":"SelectScrollUpButton","sourcePath":"components/general/SelectScrollUpButton/SelectScrollUpButton.jsx"},{"name":"SelectSeparator","sourcePath":"components/general/SelectSeparator/SelectSeparator.jsx"},{"name":"SelectTrigger","sourcePath":"components/general/SelectTrigger/SelectTrigger.jsx"},{"name":"SelectValue","sourcePath":"components/general/SelectValue/SelectValue.jsx"},{"name":"Separator","sourcePath":"components/general/Separator/Separator.jsx"},{"name":"Sheet","sourcePath":"components/general/Sheet/Sheet.jsx"},{"name":"SheetClose","sourcePath":"components/general/SheetClose/SheetClose.jsx"},{"name":"SheetContent","sourcePath":"components/general/SheetContent/SheetContent.jsx"},{"name":"SheetDescription","sourcePath":"components/general/SheetDescription/SheetDescription.jsx"},{"name":"SheetFooter","sourcePath":"components/general/SheetFooter/SheetFooter.jsx"},{"name":"SheetHeader","sourcePath":"components/general/SheetHeader/SheetHeader.jsx"},{"name":"SheetTitle","sourcePath":"components/general/SheetTitle/SheetTitle.jsx"},{"name":"SheetTrigger","sourcePath":"components/general/SheetTrigger/SheetTrigger.jsx"},{"name":"Sidebar","sourcePath":"components/general/Sidebar/Sidebar.jsx"},{"name":"SidebarContent","sourcePath":"components/general/SidebarContent/SidebarContent.jsx"},{"name":"SidebarFooter","sourcePath":"components/general/SidebarFooter/SidebarFooter.jsx"},{"name":"SidebarGroup","sourcePath":"components/general/SidebarGroup/SidebarGroup.jsx"},{"name":"SidebarGroupAction","sourcePath":"components/general/SidebarGroupAction/SidebarGroupAction.jsx"},{"name":"SidebarGroupContent","sourcePath":"components/general/SidebarGroupContent/SidebarGroupContent.jsx"},{"name":"SidebarGroupLabel","sourcePath":"components/general/SidebarGroupLabel/SidebarGroupLabel.jsx"},{"name":"SidebarHeader","sourcePath":"components/general/SidebarHeader/SidebarHeader.jsx"},{"name":"SidebarInput","sourcePath":"components/general/SidebarInput/SidebarInput.jsx"},{"name":"SidebarInset","sourcePath":"components/general/SidebarInset/SidebarInset.jsx"},{"name":"SidebarMenu","sourcePath":"components/general/SidebarMenu/SidebarMenu.jsx"},{"name":"SidebarMenuAction","sourcePath":"components/general/SidebarMenuAction/SidebarMenuAction.jsx"},{"name":"SidebarMenuBadge","sourcePath":"components/general/SidebarMenuBadge/SidebarMenuBadge.jsx"},{"name":"SidebarMenuButton","sourcePath":"components/general/SidebarMenuButton/SidebarMenuButton.jsx"},{"name":"SidebarMenuItem","sourcePath":"components/general/SidebarMenuItem/SidebarMenuItem.jsx"},{"name":"SidebarMenuSkeleton","sourcePath":"components/general/SidebarMenuSkeleton/SidebarMenuSkeleton.jsx"},{"name":"SidebarMenuSub","sourcePath":"components/general/SidebarMenuSub/SidebarMenuSub.jsx"},{"name":"SidebarMenuSubButton","sourcePath":"components/general/SidebarMenuSubButton/SidebarMenuSubButton.jsx"},{"name":"SidebarMenuSubItem","sourcePath":"components/general/SidebarMenuSubItem/SidebarMenuSubItem.jsx"},{"name":"SidebarProvider","sourcePath":"components/general/SidebarProvider/SidebarProvider.jsx"},{"name":"SidebarRail","sourcePath":"components/general/SidebarRail/SidebarRail.jsx"},{"name":"SidebarSeparator","sourcePath":"components/general/SidebarSeparator/SidebarSeparator.jsx"},{"name":"SidebarTrigger","sourcePath":"components/general/SidebarTrigger/SidebarTrigger.jsx"},{"name":"Skeleton","sourcePath":"components/general/Skeleton/Skeleton.jsx"},{"name":"Table","sourcePath":"components/general/Table/Table.jsx"},{"name":"TableBody","sourcePath":"components/general/TableBody/TableBody.jsx"},{"name":"TableCaption","sourcePath":"components/general/TableCaption/TableCaption.jsx"},{"name":"TableCell","sourcePath":"components/general/TableCell/TableCell.jsx"},{"name":"TableFooter","sourcePath":"components/general/TableFooter/TableFooter.jsx"},{"name":"TableHead","sourcePath":"components/general/TableHead/TableHead.jsx"},{"name":"TableHeader","sourcePath":"components/general/TableHeader/TableHeader.jsx"},{"name":"TableRow","sourcePath":"components/general/TableRow/TableRow.jsx"},{"name":"Textarea","sourcePath":"components/general/Textarea/Textarea.jsx"},{"name":"Tooltip","sourcePath":"components/general/Tooltip/Tooltip.jsx"},{"name":"TooltipContent","sourcePath":"components/general/TooltipContent/TooltipContent.jsx"},{"name":"TooltipProvider","sourcePath":"components/general/TooltipProvider/TooltipProvider.jsx"},{"name":"TooltipTrigger","sourcePath":"components/general/TooltipTrigger/TooltipTrigger.jsx"}],"sourceHashes":{"components/general/Avatar/Avatar.jsx":"0588f0dde835","components/general/Avatar/Avatar.d.ts":"69df59a295b3","components/general/Avatar/Avatar.prompt.md":"918d94b2c9ca","components/general/AvatarBadge/AvatarBadge.jsx":"db71ebb7d7a6","components/general/AvatarBadge/AvatarBadge.d.ts":"6129271d24fc","components/general/AvatarBadge/AvatarBadge.prompt.md":"3f500b34b7ff","components/general/AvatarFallback/AvatarFallback.jsx":"9e87bb1b5a31","components/general/AvatarFallback/AvatarFallback.d.ts":"1f411c6ba0a3","components/general/AvatarFallback/AvatarFallback.prompt.md":"a05539d707a5","components/general/AvatarGroup/AvatarGroup.jsx":"5484a0f92450","components/general/AvatarGroup/AvatarGroup.d.ts":"2879acc62575","components/general/AvatarGroup/AvatarGroup.prompt.md":"bf6ab42071e0","components/general/AvatarGroupCount/AvatarGroupCount.jsx":"78d8b457a636","components/general/AvatarGroupCount/AvatarGroupCount.d.ts":"02b2dbee40eb","components/general/AvatarGroupCount/AvatarGroupCount.prompt.md":"c33ff0377269","components/general/AvatarImage/AvatarImage.jsx":"f8a127e27376","components/general/AvatarImage/AvatarImage.d.ts":"d4787fa22c0d","components/general/AvatarImage/AvatarImage.prompt.md":"ea172ec9198a","components/general/Badge/Badge.jsx":"c467d44d81bb","components/general/Badge/Badge.d.ts":"e2b36a9627b1","components/general/Badge/Badge.prompt.md":"a7bc648e5fe1","components/general/Button/Button.jsx":"ddfbe4987bfd","components/general/Button/Button.d.ts":"5e1213d84a85","components/general/Button/Button.prompt.md":"4f870c493f2e","components/general/Card/Card.jsx":"8d925f6cffe7","components/general/Card/Card.d.ts":"73c18caf1dc6","components/general/Card/Card.prompt.md":"f45b53663cf3","components/general/CardAction/CardAction.jsx":"39989ff6b0b1","components/general/CardAction/CardAction.d.ts":"6327f62ac4a6","components/general/CardAction/CardAction.prompt.md":"3cb848310f4a","components/general/CardContent/CardContent.jsx":"a87cc71f0df3","components/general/CardContent/CardContent.d.ts":"3e080e6414c6","components/general/CardContent/CardContent.prompt.md":"43aea979c674","components/general/CardDescription/CardDescription.jsx":"1ce429e34634","components/general/CardDescription/CardDescription.d.ts":"1a7406102d8e","components/general/CardDescription/CardDescription.prompt.md":"ba1393ce198a","components/general/CardFooter/CardFooter.jsx":"77b7f389bb02","components/general/CardFooter/CardFooter.d.ts":"59e76af41496","components/general/CardFooter/CardFooter.prompt.md":"d024626f567e","components/general/CardHeader/CardHeader.jsx":"e1ff67e12df5","components/general/CardHeader/CardHeader.d.ts":"523c1532b953","components/general/CardHeader/CardHeader.prompt.md":"707951ad5cd3","components/general/CardTitle/CardTitle.jsx":"130334f6ba08","components/general/CardTitle/CardTitle.d.ts":"cee3c4695896","components/general/CardTitle/CardTitle.prompt.md":"ad266f42d4c0","components/general/Dialog/Dialog.jsx":"b87f8b4dae78","components/general/Dialog/Dialog.d.ts":"2c876db5debb","components/general/Dialog/Dialog.prompt.md":"d34900e11f06","components/general/DialogClose/DialogClose.jsx":"6666bfb20f9d","components/general/DialogClose/DialogClose.d.ts":"21d72ab2361f","components/general/DialogClose/DialogClose.prompt.md":"00ec40404cc4","components/general/DialogContent/DialogContent.jsx":"403a14cae0d6","components/general/DialogContent/DialogContent.d.ts":"e68b949c1a83","components/general/DialogContent/DialogContent.prompt.md":"0e04d59b1ae9","components/general/DialogDescription/DialogDescription.jsx":"1ba25a995a55","components/general/DialogDescription/DialogDescription.d.ts":"237e39963c01","components/general/DialogDescription/DialogDescription.prompt.md":"806e09e9d74c","components/general/DialogFooter/DialogFooter.jsx":"3b0c96d75bdf","components/general/DialogFooter/DialogFooter.d.ts":"13794569541b","components/general/DialogFooter/DialogFooter.prompt.md":"b7ec45ad4227","components/general/DialogHeader/DialogHeader.jsx":"5512edfc13d6","components/general/DialogHeader/DialogHeader.d.ts":"9b0e94a18939","components/general/DialogHeader/DialogHeader.prompt.md":"6606d13f4352","components/general/DialogOverlay/DialogOverlay.jsx":"94ceb9f68d26","components/general/DialogOverlay/DialogOverlay.d.ts":"2fbb3e87b9e6","components/general/DialogOverlay/DialogOverlay.prompt.md":"3ca5a7276a82","components/general/DialogPortal/DialogPortal.jsx":"ddb27e889900","components/general/DialogPortal/DialogPortal.d.ts":"d7d8c938aa40","components/general/DialogPortal/DialogPortal.prompt.md":"54b96da51b78","components/general/DialogTitle/DialogTitle.jsx":"119d1cf4aaf7","components/general/DialogTitle/DialogTitle.d.ts":"d6414b6f3209","components/general/DialogTitle/DialogTitle.prompt.md":"3a5b90da1e81","components/general/DialogTrigger/DialogTrigger.jsx":"ac8f1d360bc0","components/general/DialogTrigger/DialogTrigger.d.ts":"b7628c6ae035","components/general/DialogTrigger/DialogTrigger.prompt.md":"a93d33080251","components/general/DropdownMenu/DropdownMenu.jsx":"1a14e28e020a","components/general/DropdownMenu/DropdownMenu.d.ts":"336ac3f81397","components/general/DropdownMenu/DropdownMenu.prompt.md":"860c5d3764fa","components/general/DropdownMenuCheckboxItem/DropdownMenuCheckboxItem.jsx":"3c1d35abab54","components/general/DropdownMenuCheckboxItem/DropdownMenuCheckboxItem.d.ts":"526f60441316","components/general/DropdownMenuCheckboxItem/DropdownMenuCheckboxItem.prompt.md":"ee6db322bc3c","components/general/DropdownMenuContent/DropdownMenuContent.jsx":"7fe0232aa01f","components/general/DropdownMenuContent/DropdownMenuContent.d.ts":"17a7d0d2899a","components/general/DropdownMenuContent/DropdownMenuContent.prompt.md":"0c2a8f03d232","components/general/DropdownMenuGroup/DropdownMenuGroup.jsx":"8a156c4bac73","components/general/DropdownMenuGroup/DropdownMenuGroup.d.ts":"4ec7d1cc2de2","components/general/DropdownMenuGroup/DropdownMenuGroup.prompt.md":"bd50d0171df1","components/general/DropdownMenuItem/DropdownMenuItem.jsx":"fc3a06594c66","components/general/DropdownMenuItem/DropdownMenuItem.d.ts":"2afae79c0141","components/general/DropdownMenuItem/DropdownMenuItem.prompt.md":"fca9046622f4","components/general/DropdownMenuLabel/DropdownMenuLabel.jsx":"733fe8803cd8","components/general/DropdownMenuLabel/DropdownMenuLabel.d.ts":"ad3cfa616f4c","components/general/DropdownMenuLabel/DropdownMenuLabel.prompt.md":"da3034407df0","components/general/DropdownMenuPortal/DropdownMenuPortal.jsx":"e8f96dcebdfe","components/general/DropdownMenuPortal/DropdownMenuPortal.d.ts":"1d840310f81f","components/general/DropdownMenuPortal/DropdownMenuPortal.prompt.md":"63929299d869","components/general/DropdownMenuRadioGroup/DropdownMenuRadioGroup.jsx":"c1ff5ec29ddd","components/general/DropdownMenuRadioGroup/DropdownMenuRadioGroup.d.ts":"737a94c90276","components/general/DropdownMenuRadioGroup/DropdownMenuRadioGroup.prompt.md":"ed7f294e19e9","components/general/DropdownMenuRadioItem/DropdownMenuRadioItem.jsx":"377fd3fc8a3a","components/general/DropdownMenuRadioItem/DropdownMenuRadioItem.d.ts":"f67ad3beed4f","components/general/DropdownMenuRadioItem/DropdownMenuRadioItem.prompt.md":"6680a39ede5d","components/general/DropdownMenuSeparator/DropdownMenuSeparator.jsx":"2fa7ea470d3a","components/general/DropdownMenuSeparator/DropdownMenuSeparator.d.ts":"f077057e6720","components/general/DropdownMenuSeparator/DropdownMenuSeparator.prompt.md":"d92c90aa9732","components/general/DropdownMenuShortcut/DropdownMenuShortcut.jsx":"3a6a5656476e","components/general/DropdownMenuShortcut/DropdownMenuShortcut.d.ts":"a598fdae71f7","components/general/DropdownMenuShortcut/DropdownMenuShortcut.prompt.md":"d57080c0ea2f","components/general/DropdownMenuSub/DropdownMenuSub.jsx":"3b05582036be","components/general/DropdownMenuSub/DropdownMenuSub.d.ts":"fea108cec36d","components/general/DropdownMenuSub/DropdownMenuSub.prompt.md":"571eaa77bdb1","components/general/DropdownMenuSubContent/DropdownMenuSubContent.jsx":"544667416c12","components/general/DropdownMenuSubContent/DropdownMenuSubContent.d.ts":"1c17cf1a93e7","components/general/DropdownMenuSubContent/DropdownMenuSubContent.prompt.md":"28696901dcd4","components/general/DropdownMenuSubTrigger/DropdownMenuSubTrigger.jsx":"2f5460308b4f","components/general/DropdownMenuSubTrigger/DropdownMenuSubTrigger.d.ts":"0fa2e2a1138e","components/general/DropdownMenuSubTrigger/DropdownMenuSubTrigger.prompt.md":"8ffae767c89a","components/general/DropdownMenuTrigger/DropdownMenuTrigger.jsx":"2a09cb3687ad","components/general/DropdownMenuTrigger/DropdownMenuTrigger.d.ts":"a2fab34b1879","components/general/DropdownMenuTrigger/DropdownMenuTrigger.prompt.md":"820003cb212c","components/general/Input/Input.jsx":"cf6408ce9357","components/general/Input/Input.d.ts":"fced8c2ba495","components/general/Input/Input.prompt.md":"bbb7ed45e6d0","components/general/Label/Label.jsx":"be7a54b7480e","components/general/Label/Label.d.ts":"c15e25c63874","components/general/Label/Label.prompt.md":"ceb3f4b51e3b","components/general/Select/Select.jsx":"91298c5c34b3","components/general/Select/Select.d.ts":"b8ec2180a102","components/general/Select/Select.prompt.md":"4ca5c46b975e","components/general/SelectContent/SelectContent.jsx":"e340851b6254","components/general/SelectContent/SelectContent.d.ts":"dc64ab5fab34","components/general/SelectContent/SelectContent.prompt.md":"f6086b0a5eda","components/general/SelectGroup/SelectGroup.jsx":"a1993daf2ada","components/general/SelectGroup/SelectGroup.d.ts":"934915216055","components/general/SelectGroup/SelectGroup.prompt.md":"a69f512c448d","components/general/SelectItem/SelectItem.jsx":"a56a48ffac58","components/general/SelectItem/SelectItem.d.ts":"6fb994d1d880","components/general/SelectItem/SelectItem.prompt.md":"80775a9f0ade","components/general/SelectLabel/SelectLabel.jsx":"221f59fecbbc","components/general/SelectLabel/SelectLabel.d.ts":"fac47a0ddfd6","components/general/SelectLabel/SelectLabel.prompt.md":"8bc7b7386713","components/general/SelectScrollDownButton/SelectScrollDownButton.jsx":"143a9b73e77b","components/general/SelectScrollDownButton/SelectScrollDownButton.d.ts":"21385d138d51","components/general/SelectScrollDownButton/SelectScrollDownButton.prompt.md":"254f409d0819","components/general/SelectScrollUpButton/SelectScrollUpButton.jsx":"8ac35f00b395","components/general/SelectScrollUpButton/SelectScrollUpButton.d.ts":"d56c5597f247","components/general/SelectScrollUpButton/SelectScrollUpButton.prompt.md":"25e4dc3bb40c","components/general/SelectSeparator/SelectSeparator.jsx":"ba7ab2d72bf8","components/general/SelectSeparator/SelectSeparator.d.ts":"6c57b2ff96f5","components/general/SelectSeparator/SelectSeparator.prompt.md":"c670b83a00b6","components/general/SelectTrigger/SelectTrigger.jsx":"e15aa870e1a7","components/general/SelectTrigger/SelectTrigger.d.ts":"d93e5e2c09c5","components/general/SelectTrigger/SelectTrigger.prompt.md":"3861055326f9","components/general/SelectValue/SelectValue.jsx":"9c23c67f37f0","components/general/SelectValue/SelectValue.d.ts":"6919670bd7b8","components/general/SelectValue/SelectValue.prompt.md":"daa301059f14","components/general/Separator/Separator.jsx":"6a7391dffad3","components/general/Separator/Separator.d.ts":"2bbff4bbeaec","components/general/Separator/Separator.prompt.md":"1099bbe38e08","components/general/Sheet/Sheet.jsx":"aec49c34932a","components/general/Sheet/Sheet.d.ts":"565512878479","components/general/Sheet/Sheet.prompt.md":"bf4147017aea","components/general/SheetClose/SheetClose.jsx":"60fcf1b33fe6","components/general/SheetClose/SheetClose.d.ts":"b680268f0f11","components/general/SheetClose/SheetClose.prompt.md":"8aff6de71401","components/general/SheetContent/SheetContent.jsx":"b6553d2ee0ec","components/general/SheetContent/SheetContent.d.ts":"6f1cd60ac9a3","components/general/SheetContent/SheetContent.prompt.md":"d825e5b86925","components/general/SheetDescription/SheetDescription.jsx":"f048be4211fd","components/general/SheetDescription/SheetDescription.d.ts":"d34be2503585","components/general/SheetDescription/SheetDescription.prompt.md":"6db778da58a2","components/general/SheetFooter/SheetFooter.jsx":"f2c923e06f08","components/general/SheetFooter/SheetFooter.d.ts":"affff16d84d2","components/general/SheetFooter/SheetFooter.prompt.md":"8b2355389d30","components/general/SheetHeader/SheetHeader.jsx":"82345b8f33b6","components/general/SheetHeader/SheetHeader.d.ts":"3527e7c2549f","components/general/SheetHeader/SheetHeader.prompt.md":"efbb8154a75f","components/general/SheetTitle/SheetTitle.jsx":"190ecee7be9a","components/general/SheetTitle/SheetTitle.d.ts":"5c666702476d","components/general/SheetTitle/SheetTitle.prompt.md":"c8f142046d22","components/general/SheetTrigger/SheetTrigger.jsx":"cdb475a0a51a","components/general/SheetTrigger/SheetTrigger.d.ts":"ec5b04f821ab","components/general/SheetTrigger/SheetTrigger.prompt.md":"c1bd15379047","components/general/Sidebar/Sidebar.jsx":"cac16a1c13e4","components/general/Sidebar/Sidebar.d.ts":"5b486a86a283","components/general/Sidebar/Sidebar.prompt.md":"c6c95752680d","components/general/SidebarContent/SidebarContent.jsx":"acb823a74697","components/general/SidebarContent/SidebarContent.d.ts":"8536801175d4","components/general/SidebarContent/SidebarContent.prompt.md":"bdb6c09eede1","components/general/SidebarFooter/SidebarFooter.jsx":"a16dc3b17a1c","components/general/SidebarFooter/SidebarFooter.d.ts":"4e66da49ea1b","components/general/SidebarFooter/SidebarFooter.prompt.md":"e0021995be16","components/general/SidebarGroup/SidebarGroup.jsx":"c1d92162c03b","components/general/SidebarGroup/SidebarGroup.d.ts":"f9ce61650340","components/general/SidebarGroup/SidebarGroup.prompt.md":"1dc46da70106","components/general/SidebarGroupAction/SidebarGroupAction.jsx":"edd03d9eebee","components/general/SidebarGroupAction/SidebarGroupAction.d.ts":"1e7c9276186d","components/general/SidebarGroupAction/SidebarGroupAction.prompt.md":"1071d291fb8c","components/general/SidebarGroupContent/SidebarGroupContent.jsx":"1330c787a012","components/general/SidebarGroupContent/SidebarGroupContent.d.ts":"377d927f275f","components/general/SidebarGroupContent/SidebarGroupContent.prompt.md":"bd62efff9418","components/general/SidebarGroupLabel/SidebarGroupLabel.jsx":"49a8dea77eaa","components/general/SidebarGroupLabel/SidebarGroupLabel.d.ts":"b230a4bf3b52","components/general/SidebarGroupLabel/SidebarGroupLabel.prompt.md":"45696fb1bf0e","components/general/SidebarHeader/SidebarHeader.jsx":"0b83b11d5f03","components/general/SidebarHeader/SidebarHeader.d.ts":"ed793c9d7d14","components/general/SidebarHeader/SidebarHeader.prompt.md":"52f744e708e4","components/general/SidebarInput/SidebarInput.jsx":"f696569807ed","components/general/SidebarInput/SidebarInput.d.ts":"0f2034bf7b17","components/general/SidebarInput/SidebarInput.prompt.md":"f50c15ba98ba","components/general/SidebarInset/SidebarInset.jsx":"d4e062c2868a","components/general/SidebarInset/SidebarInset.d.ts":"3c43c155770b","components/general/SidebarInset/SidebarInset.prompt.md":"9dba1fc0fe9f","components/general/SidebarMenu/SidebarMenu.jsx":"f203974b8259","components/general/SidebarMenu/SidebarMenu.d.ts":"2309d3048b8e","components/general/SidebarMenu/SidebarMenu.prompt.md":"7d504f4cddca","components/general/SidebarMenuAction/SidebarMenuAction.jsx":"971ed4f670ee","components/general/SidebarMenuAction/SidebarMenuAction.d.ts":"f01c1ab86208","components/general/SidebarMenuAction/SidebarMenuAction.prompt.md":"5454d7722990","components/general/SidebarMenuBadge/SidebarMenuBadge.jsx":"894d52736cfe","components/general/SidebarMenuBadge/SidebarMenuBadge.d.ts":"0222cb306fcf","components/general/SidebarMenuBadge/SidebarMenuBadge.prompt.md":"1356ca738848","components/general/SidebarMenuButton/SidebarMenuButton.jsx":"f44efa7516cb","components/general/SidebarMenuButton/SidebarMenuButton.d.ts":"7816c79a58e6","components/general/SidebarMenuButton/SidebarMenuButton.prompt.md":"c458aedb66b2","components/general/SidebarMenuItem/SidebarMenuItem.jsx":"46804ccaa670","components/general/SidebarMenuItem/SidebarMenuItem.d.ts":"8e5bf9b1a0cf","components/general/SidebarMenuItem/SidebarMenuItem.prompt.md":"4af576f95937","components/general/SidebarMenuSkeleton/SidebarMenuSkeleton.jsx":"9193c5bcd6ba","components/general/SidebarMenuSkeleton/SidebarMenuSkeleton.d.ts":"824f2cfa7410","components/general/SidebarMenuSkeleton/SidebarMenuSkeleton.prompt.md":"aa147323a2e0","components/general/SidebarMenuSub/SidebarMenuSub.jsx":"b98bc89053ec","components/general/SidebarMenuSub/SidebarMenuSub.d.ts":"b147ca0d9353","components/general/SidebarMenuSub/SidebarMenuSub.prompt.md":"890053d56c11","components/general/SidebarMenuSubButton/SidebarMenuSubButton.jsx":"72e450ed6499","components/general/SidebarMenuSubButton/SidebarMenuSubButton.d.ts":"e6009c550183","components/general/SidebarMenuSubButton/SidebarMenuSubButton.prompt.md":"5b52b695f054","components/general/SidebarMenuSubItem/SidebarMenuSubItem.jsx":"49afd09511ce","components/general/SidebarMenuSubItem/SidebarMenuSubItem.d.ts":"ff4f2255abed","components/general/SidebarMenuSubItem/SidebarMenuSubItem.prompt.md":"96ea9a9c8e23","components/general/SidebarProvider/SidebarProvider.jsx":"9c8e5e8efc5d","components/general/SidebarProvider/SidebarProvider.d.ts":"742f72405437","components/general/SidebarProvider/SidebarProvider.prompt.md":"c7d7b4eb39d2","components/general/SidebarRail/SidebarRail.jsx":"441d674a9e67","components/general/SidebarRail/SidebarRail.d.ts":"ca61508e2f9d","components/general/SidebarRail/SidebarRail.prompt.md":"1101c2278d60","components/general/SidebarSeparator/SidebarSeparator.jsx":"e0f098d23040","components/general/SidebarSeparator/SidebarSeparator.d.ts":"2dd243ac4103","components/general/SidebarSeparator/SidebarSeparator.prompt.md":"333716b7aa9d","components/general/SidebarTrigger/SidebarTrigger.jsx":"aaae2c6e624c","components/general/SidebarTrigger/SidebarTrigger.d.ts":"f9d59086dcd8","components/general/SidebarTrigger/SidebarTrigger.prompt.md":"0ccefb32c39f","components/general/Skeleton/Skeleton.jsx":"2d112266d130","components/general/Skeleton/Skeleton.d.ts":"597e1914b8ba","components/general/Skeleton/Skeleton.prompt.md":"76e17e600caa","components/general/Table/Table.jsx":"5c7f11ff7b2b","components/general/Table/Table.d.ts":"b91e7e60d33c","components/general/Table/Table.prompt.md":"a116bf4a0dad","components/general/TableBody/TableBody.jsx":"1f9be1a22079","components/general/TableBody/TableBody.d.ts":"0ea436437ce5","components/general/TableBody/TableBody.prompt.md":"707ffec7502e","components/general/TableCaption/TableCaption.jsx":"52809d0a0902","components/general/TableCaption/TableCaption.d.ts":"1ed0cb6872f6","components/general/TableCaption/TableCaption.prompt.md":"103b520e7720","components/general/TableCell/TableCell.jsx":"16b59172e030","components/general/TableCell/TableCell.d.ts":"a858f453e8f7","components/general/TableCell/TableCell.prompt.md":"5a0ffc8b10c8","components/general/TableFooter/TableFooter.jsx":"313204ad5d95","components/general/TableFooter/TableFooter.d.ts":"f5c23b67dfb6","components/general/TableFooter/TableFooter.prompt.md":"07bdba5bc4eb","components/general/TableHead/TableHead.jsx":"e033f5602f0b","components/general/TableHead/TableHead.d.ts":"004320f1d6e6","components/general/TableHead/TableHead.prompt.md":"5e6f2a552966","components/general/TableHeader/TableHeader.jsx":"7a2587244d9b","components/general/TableHeader/TableHeader.d.ts":"2358fa9b5601","components/general/TableHeader/TableHeader.prompt.md":"dfa3b68337f7","components/general/TableRow/TableRow.jsx":"183ae55f49b0","components/general/TableRow/TableRow.d.ts":"f62fa5a6c33e","components/general/TableRow/TableRow.prompt.md":"515bc1564922","components/general/Textarea/Textarea.jsx":"0fea068de9a8","components/general/Textarea/Textarea.d.ts":"dd34f81fdcbf","components/general/Textarea/Textarea.prompt.md":"dc710308f7cc","components/general/Tooltip/Tooltip.jsx":"6242325a72c3","components/general/Tooltip/Tooltip.d.ts":"fb5325f767f5","components/general/Tooltip/Tooltip.prompt.md":"f907fe42565d","components/general/TooltipContent/TooltipContent.jsx":"83936e1b1998","components/general/TooltipContent/TooltipContent.d.ts":"a642a67869d7","components/general/TooltipContent/TooltipContent.prompt.md":"6c7e31fd0687","components/general/TooltipProvider/TooltipProvider.jsx":"2ed6fe39a8c1","components/general/TooltipProvider/TooltipProvider.d.ts":"e16ecc17c598","components/general/TooltipProvider/TooltipProvider.prompt.md":"43d63c83c162","components/general/TooltipTrigger/TooltipTrigger.jsx":"2e7cb8cecbe3","components/general/TooltipTrigger/TooltipTrigger.d.ts":"c52336beeafe","components/general/TooltipTrigger/TooltipTrigger.prompt.md":"41206316c2cd"},"inlinedExternals":["@base-ui/react","@base-ui/utils","@floating-ui/core","@floating-ui/dom","@floating-ui/react-dom","@floating-ui/utils","class-variance-authority","clsx","lucide-react","reselect","tabbable","tailwind-merge","use-sync-external-store"],"builtBy":"cc-design-sync"} */
"use strict";
var CacDS = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx16(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs7(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx16;
      module.exports.jsxs = jsxs7;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs7 : jsx16)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // shim:react-dom-shim
  var require_react_dom_shim = __commonJS({
    "shim:react-dom-shim"(exports, module) {
      init_define_import_meta_env();
      var D = window.ReactDOM;
      var n = function() {
      };
      module.exports = Object.assign({ preload: n, preinit: n, preconnect: n, prefetchDNS: n, preloadModule: n, preinitModule: n }, D);
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
  var require_use_sync_external_store_shim_development = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js"(exports) {
      "use strict";
      init_define_import_meta_env();
      (function() {
        function is(x, y) {
          return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
        }
        function useSyncExternalStore$2(subscribe, getSnapshot) {
          didWarnOld18Alpha || void 0 === React164.startTransition || (didWarnOld18Alpha = true, console.error(
            "You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."
          ));
          var value = getSnapshot();
          if (!didWarnUncachedGetSnapshot) {
            var cachedValue = getSnapshot();
            objectIs(value, cachedValue) || (console.error(
              "The result of getSnapshot should be cached to avoid an infinite loop"
            ), didWarnUncachedGetSnapshot = true);
          }
          cachedValue = useState29({
            inst: { value, getSnapshot }
          });
          var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
          useLayoutEffect4(
            function() {
              inst.value = value;
              inst.getSnapshot = getSnapshot;
              checkIfSnapshotChanged(inst) && forceUpdate({ inst });
            },
            [subscribe, value, getSnapshot]
          );
          useEffect26(
            function() {
              checkIfSnapshotChanged(inst) && forceUpdate({ inst });
              return subscribe(function() {
                checkIfSnapshotChanged(inst) && forceUpdate({ inst });
              });
            },
            [subscribe]
          );
          useDebugValue2(value);
          return value;
        }
        function checkIfSnapshotChanged(inst) {
          var latestGetSnapshot = inst.getSnapshot;
          inst = inst.value;
          try {
            var nextValue = latestGetSnapshot();
            return !objectIs(inst, nextValue);
          } catch (error2) {
            return true;
          }
        }
        function useSyncExternalStore$1(subscribe, getSnapshot) {
          return getSnapshot();
        }
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
        var React164 = require_react_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useState29 = React164.useState, useEffect26 = React164.useEffect, useLayoutEffect4 = React164.useLayoutEffect, useDebugValue2 = React164.useDebugValue, didWarnOld18Alpha = false, didWarnUncachedGetSnapshot = false, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
        exports.useSyncExternalStore = void 0 !== React164.useSyncExternalStore ? React164.useSyncExternalStore : shim;
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
      })();
    }
  });

  // node_modules/use-sync-external-store/shim/index.js
  var require_shim = __commonJS({
    "node_modules/use-sync-external-store/shim/index.js"(exports, module) {
      "use strict";
      init_define_import_meta_env();
      if (false) {
        module.exports = null;
      } else {
        module.exports = require_use_sync_external_store_shim_development();
      }
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
  var require_with_selector_development = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js"(exports) {
      "use strict";
      init_define_import_meta_env();
      (function() {
        function is(x, y) {
          return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
        }
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
        var React164 = require_react_shim(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore2 = shim.useSyncExternalStore, useRef51 = React164.useRef, useEffect26 = React164.useEffect, useMemo53 = React164.useMemo, useDebugValue2 = React164.useDebugValue;
        exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
          var instRef = useRef51(null);
          if (null === instRef.current) {
            var inst = { hasValue: false, value: null };
            instRef.current = inst;
          } else inst = instRef.current;
          instRef = useMemo53(
            function() {
              function memoizedSelector(nextSnapshot) {
                if (!hasMemo) {
                  hasMemo = true;
                  memoizedSnapshot = nextSnapshot;
                  nextSnapshot = selector(nextSnapshot);
                  if (void 0 !== isEqual && inst.hasValue) {
                    var currentSelection = inst.value;
                    if (isEqual(currentSelection, nextSnapshot))
                      return memoizedSelection = currentSelection;
                  }
                  return memoizedSelection = nextSnapshot;
                }
                currentSelection = memoizedSelection;
                if (objectIs(memoizedSnapshot, nextSnapshot))
                  return currentSelection;
                var nextSelection = selector(nextSnapshot);
                if (void 0 !== isEqual && isEqual(currentSelection, nextSelection))
                  return memoizedSnapshot = nextSnapshot, currentSelection;
                memoizedSnapshot = nextSnapshot;
                return memoizedSelection = nextSelection;
              }
              var hasMemo = false, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
              return [
                function() {
                  return memoizedSelector(getSnapshot());
                },
                null === maybeGetServerSnapshot ? void 0 : function() {
                  return memoizedSelector(maybeGetServerSnapshot());
                }
              ];
            },
            [getSnapshot, getServerSnapshot, selector, isEqual]
          );
          var value = useSyncExternalStore2(subscribe, instRef[0], instRef[1]);
          useEffect26(
            function() {
              inst.hasValue = true;
              inst.value = value;
            },
            [value]
          );
          useDebugValue2(value);
          return value;
        };
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
      })();
    }
  });

  // node_modules/use-sync-external-store/shim/with-selector.js
  var require_with_selector = __commonJS({
    "node_modules/use-sync-external-store/shim/with-selector.js"(exports, module) {
      "use strict";
      init_define_import_meta_env();
      if (false) {
        module.exports = null;
      } else {
        module.exports = require_with_selector_development();
      }
    }
  });

  // .design-sync/ds-entry.ts
  var ds_entry_exports = {};
  __export(ds_entry_exports, {
    Avatar: () => Avatar,
    AvatarBadge: () => AvatarBadge,
    AvatarFallback: () => AvatarFallback3,
    AvatarGroup: () => AvatarGroup,
    AvatarGroupCount: () => AvatarGroupCount,
    AvatarImage: () => AvatarImage3,
    Badge: () => Badge,
    Button: () => Button3,
    Card: () => Card,
    CardAction: () => CardAction,
    CardContent: () => CardContent,
    CardDescription: () => CardDescription,
    CardFooter: () => CardFooter,
    CardHeader: () => CardHeader,
    CardTitle: () => CardTitle,
    Dialog: () => Dialog,
    DialogClose: () => DialogClose3,
    DialogContent: () => DialogContent,
    DialogDescription: () => DialogDescription3,
    DialogFooter: () => DialogFooter,
    DialogHeader: () => DialogHeader,
    DialogOverlay: () => DialogOverlay,
    DialogPortal: () => DialogPortal3,
    DialogTitle: () => DialogTitle3,
    DialogTrigger: () => DialogTrigger3,
    DropdownMenu: () => DropdownMenu,
    DropdownMenuCheckboxItem: () => DropdownMenuCheckboxItem,
    DropdownMenuContent: () => DropdownMenuContent,
    DropdownMenuGroup: () => DropdownMenuGroup,
    DropdownMenuItem: () => DropdownMenuItem,
    DropdownMenuLabel: () => DropdownMenuLabel,
    DropdownMenuPortal: () => DropdownMenuPortal,
    DropdownMenuRadioGroup: () => DropdownMenuRadioGroup,
    DropdownMenuRadioItem: () => DropdownMenuRadioItem,
    DropdownMenuSeparator: () => DropdownMenuSeparator,
    DropdownMenuShortcut: () => DropdownMenuShortcut,
    DropdownMenuSub: () => DropdownMenuSub,
    DropdownMenuSubContent: () => DropdownMenuSubContent,
    DropdownMenuSubTrigger: () => DropdownMenuSubTrigger,
    DropdownMenuTrigger: () => DropdownMenuTrigger,
    Input: () => Input3,
    Label: () => Label,
    Select: () => Select,
    SelectContent: () => SelectContent,
    SelectGroup: () => SelectGroup3,
    SelectItem: () => SelectItem3,
    SelectLabel: () => SelectLabel3,
    SelectScrollDownButton: () => SelectScrollDownButton,
    SelectScrollUpButton: () => SelectScrollUpButton,
    SelectSeparator: () => SelectSeparator,
    SelectTrigger: () => SelectTrigger3,
    SelectValue: () => SelectValue3,
    Separator: () => Separator2,
    Sheet: () => Sheet,
    SheetClose: () => SheetClose,
    SheetContent: () => SheetContent,
    SheetDescription: () => SheetDescription,
    SheetFooter: () => SheetFooter,
    SheetHeader: () => SheetHeader,
    SheetTitle: () => SheetTitle,
    SheetTrigger: () => SheetTrigger,
    Sidebar: () => Sidebar,
    SidebarContent: () => SidebarContent,
    SidebarFooter: () => SidebarFooter,
    SidebarGroup: () => SidebarGroup,
    SidebarGroupAction: () => SidebarGroupAction,
    SidebarGroupContent: () => SidebarGroupContent,
    SidebarGroupLabel: () => SidebarGroupLabel,
    SidebarHeader: () => SidebarHeader,
    SidebarInput: () => SidebarInput,
    SidebarInset: () => SidebarInset,
    SidebarMenu: () => SidebarMenu,
    SidebarMenuAction: () => SidebarMenuAction,
    SidebarMenuBadge: () => SidebarMenuBadge,
    SidebarMenuButton: () => SidebarMenuButton,
    SidebarMenuItem: () => SidebarMenuItem,
    SidebarMenuSkeleton: () => SidebarMenuSkeleton,
    SidebarMenuSub: () => SidebarMenuSub,
    SidebarMenuSubButton: () => SidebarMenuSubButton,
    SidebarMenuSubItem: () => SidebarMenuSubItem,
    SidebarProvider: () => SidebarProvider,
    SidebarRail: () => SidebarRail,
    SidebarSeparator: () => SidebarSeparator,
    SidebarTrigger: () => SidebarTrigger,
    Skeleton: () => Skeleton,
    Table: () => Table,
    TableBody: () => TableBody,
    TableCaption: () => TableCaption,
    TableCell: () => TableCell,
    TableFooter: () => TableFooter,
    TableHead: () => TableHead,
    TableHeader: () => TableHeader,
    TableRow: () => TableRow,
    Textarea: () => Textarea,
    Tooltip: () => Tooltip,
    TooltipContent: () => TooltipContent,
    TooltipProvider: () => TooltipProvider3,
    TooltipTrigger: () => TooltipTrigger3,
    badgeVariants: () => badgeVariants,
    buttonVariants: () => buttonVariants,
    useSidebar: () => useSidebar
  });
  init_define_import_meta_env();

  // src/components/ui/avatar.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/avatar/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/avatar/index.parts.js
  var index_parts_exports = {};
  __export(index_parts_exports, {
    Fallback: () => AvatarFallback,
    Image: () => AvatarImage,
    Root: () => AvatarRoot
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/avatar/root/AvatarRoot.js
  init_define_import_meta_env();
  var React6 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/useRenderElement.js
  init_define_import_meta_env();
  var React4 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useMergedRefs.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/useRefWithInit.js
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);
  var UNINITIALIZED = {};
  function useRefWithInit(init, initArg) {
    const ref = React.useRef(UNINITIALIZED);
    if (ref.current === UNINITIALIZED) {
      ref.current = init(initArg);
    }
    return ref;
  }

  // node_modules/@base-ui/utils/esm/useMergedRefs.js
  function useMergedRefs(a, b, c, d) {
    const forkRef = useRefWithInit(createForkRef).current;
    if (didChange(forkRef, a, b, c, d)) {
      update(forkRef, [a, b, c, d]);
    }
    return forkRef.callback;
  }
  function useMergedRefsN(refs) {
    const forkRef = useRefWithInit(createForkRef).current;
    if (didChangeN(forkRef, refs)) {
      update(forkRef, refs);
    }
    return forkRef.callback;
  }
  function createForkRef() {
    return {
      callback: null,
      cleanup: null,
      refs: []
    };
  }
  function didChange(forkRef, a, b, c, d) {
    return forkRef.refs[0] !== a || forkRef.refs[1] !== b || forkRef.refs[2] !== c || forkRef.refs[3] !== d;
  }
  function didChangeN(forkRef, newRefs) {
    return forkRef.refs.length !== newRefs.length || forkRef.refs.some((ref, index2) => ref !== newRefs[index2]);
  }
  function update(forkRef, refs) {
    forkRef.refs = refs;
    if (refs.every((ref) => ref == null)) {
      forkRef.callback = null;
      return;
    }
    forkRef.callback = (instance) => {
      if (forkRef.cleanup) {
        forkRef.cleanup();
        forkRef.cleanup = null;
      }
      if (instance != null) {
        const cleanupCallbacks = Array(refs.length).fill(null);
        for (let i = 0; i < refs.length; i += 1) {
          const ref = refs[i];
          if (ref == null) {
            continue;
          }
          switch (typeof ref) {
            case "function": {
              const refCleanup = ref(instance);
              if (typeof refCleanup === "function") {
                cleanupCallbacks[i] = refCleanup;
              }
              break;
            }
            case "object": {
              ref.current = instance;
              break;
            }
            default:
          }
        }
        forkRef.cleanup = () => {
          for (let i = 0; i < refs.length; i += 1) {
            const ref = refs[i];
            if (ref == null) {
              continue;
            }
            switch (typeof ref) {
              case "function": {
                const cleanupCallback = cleanupCallbacks[i];
                if (typeof cleanupCallback === "function") {
                  cleanupCallback();
                } else {
                  ref(null);
                }
                break;
              }
              case "object": {
                ref.current = null;
                break;
              }
              default:
            }
          }
        };
      }
    };
  }

  // node_modules/@base-ui/utils/esm/getReactElementRef.js
  init_define_import_meta_env();
  var React3 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/reactVersion.js
  init_define_import_meta_env();
  var React2 = __toESM(require_react_shim(), 1);
  var majorVersion = parseInt(React2.version, 10);
  function isReactVersionAtLeast(reactVersionToCheck) {
    return majorVersion >= reactVersionToCheck;
  }

  // node_modules/@base-ui/utils/esm/getReactElementRef.js
  function getReactElementRef(element) {
    if (!/* @__PURE__ */ React3.isValidElement(element)) {
      return null;
    }
    const reactElement = element;
    const propsWithRef = reactElement.props;
    return (isReactVersionAtLeast(19) ? propsWithRef?.ref : reactElement.ref) ?? null;
  }

  // node_modules/@base-ui/utils/esm/mergeObjects.js
  init_define_import_meta_env();
  function mergeObjects(a, b) {
    if (a && !b) {
      return a;
    }
    if (!a && b) {
      return b;
    }
    if (a || b) {
      return {
        ...a,
        ...b
      };
    }
    return void 0;
  }

  // node_modules/@base-ui/utils/esm/warn.js
  init_define_import_meta_env();
  var set;
  if (true) {
    set = /* @__PURE__ */ new Set();
  }
  function warn(...messages) {
    if (true) {
      const messageKey = messages.join(" ");
      if (!set.has(messageKey)) {
        set.add(messageKey);
        console.warn(`Base UI: ${messageKey}`);
      }
    }
  }

  // node_modules/@base-ui/react/esm/utils/getStateAttributesProps.js
  init_define_import_meta_env();
  function getStateAttributesProps(state, customMapping) {
    const props = {};
    for (const key in state) {
      const value = state[key];
      if (customMapping?.hasOwnProperty(key)) {
        const customProps = customMapping[key](value);
        if (customProps != null) {
          Object.assign(props, customProps);
        }
        continue;
      }
      if (value === true) {
        props[`data-${key.toLowerCase()}`] = "";
      } else if (value) {
        props[`data-${key.toLowerCase()}`] = value.toString();
      }
    }
    return props;
  }

  // node_modules/@base-ui/react/esm/utils/resolveClassName.js
  init_define_import_meta_env();
  function resolveClassName(className, state) {
    return typeof className === "function" ? className(state) : className;
  }

  // node_modules/@base-ui/react/esm/utils/resolveStyle.js
  init_define_import_meta_env();
  function resolveStyle(style, state) {
    return typeof style === "function" ? style(state) : style;
  }

  // node_modules/@base-ui/react/esm/merge-props/mergeProps.js
  init_define_import_meta_env();
  var EMPTY_PROPS = {};
  function mergeProps(a, b, c, d, e) {
    let merged = {
      ...resolvePropsGetter(a, EMPTY_PROPS)
    };
    if (b) {
      merged = mergeOne(merged, b);
    }
    if (c) {
      merged = mergeOne(merged, c);
    }
    if (d) {
      merged = mergeOne(merged, d);
    }
    if (e) {
      merged = mergeOne(merged, e);
    }
    return merged;
  }
  function mergePropsN(props) {
    if (props.length === 0) {
      return EMPTY_PROPS;
    }
    if (props.length === 1) {
      return resolvePropsGetter(props[0], EMPTY_PROPS);
    }
    let merged = {
      ...resolvePropsGetter(props[0], EMPTY_PROPS)
    };
    for (let i = 1; i < props.length; i += 1) {
      merged = mergeOne(merged, props[i]);
    }
    return merged;
  }
  function mergeOne(merged, inputProps) {
    if (isPropsGetter(inputProps)) {
      return inputProps(merged);
    }
    return mutablyMergeInto(merged, inputProps);
  }
  function mutablyMergeInto(mergedProps, externalProps) {
    if (!externalProps) {
      return mergedProps;
    }
    for (const propName in externalProps) {
      const externalPropValue = externalProps[propName];
      switch (propName) {
        case "style": {
          mergedProps[propName] = mergeObjects(mergedProps.style, externalPropValue);
          break;
        }
        case "className": {
          mergedProps[propName] = mergeClassNames(mergedProps.className, externalPropValue);
          break;
        }
        default: {
          if (isEventHandler(propName, externalPropValue)) {
            mergedProps[propName] = mergeEventHandlers(mergedProps[propName], externalPropValue);
          } else {
            mergedProps[propName] = externalPropValue;
          }
        }
      }
    }
    return mergedProps;
  }
  function isEventHandler(key, value) {
    const code0 = key.charCodeAt(0);
    const code1 = key.charCodeAt(1);
    const code2 = key.charCodeAt(2);
    return code0 === 111 && code1 === 110 && code2 >= 65 && code2 <= 90 && (typeof value === "function" || typeof value === "undefined");
  }
  function isPropsGetter(inputProps) {
    return typeof inputProps === "function";
  }
  function resolvePropsGetter(inputProps, previousProps) {
    if (isPropsGetter(inputProps)) {
      return inputProps(previousProps);
    }
    return inputProps ?? EMPTY_PROPS;
  }
  function mergeEventHandlers(ourHandler, theirHandler) {
    if (!theirHandler) {
      return ourHandler;
    }
    if (!ourHandler) {
      return theirHandler;
    }
    return (event) => {
      if (isSyntheticEvent(event)) {
        const baseUIEvent = event;
        makeEventPreventable(baseUIEvent);
        const result2 = theirHandler(baseUIEvent);
        if (!baseUIEvent.baseUIHandlerPrevented) {
          ourHandler?.(baseUIEvent);
        }
        return result2;
      }
      const result = theirHandler(event);
      ourHandler?.(event);
      return result;
    };
  }
  function makeEventPreventable(event) {
    event.preventBaseUIHandler = () => {
      event.baseUIHandlerPrevented = true;
    };
    return event;
  }
  function mergeClassNames(ourClassName, theirClassName) {
    if (theirClassName) {
      if (ourClassName) {
        return theirClassName + " " + ourClassName;
      }
      return theirClassName;
    }
    return ourClassName;
  }
  function isSyntheticEvent(event) {
    return event != null && typeof event === "object" && "nativeEvent" in event;
  }

  // node_modules/@base-ui/react/esm/utils/constants.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/empty.js
  init_define_import_meta_env();
  function NOOP() {
  }
  var EMPTY_ARRAY = Object.freeze([]);
  var EMPTY_OBJECT = Object.freeze({});

  // node_modules/@base-ui/react/esm/utils/constants.js
  var TYPEAHEAD_RESET_MS = 500;
  var PATIENT_CLICK_THRESHOLD = 500;
  var DISABLED_TRANSITIONS_STYLE = {
    style: {
      transition: "none"
    }
  };
  var CLICK_TRIGGER_IDENTIFIER = "data-base-ui-click-trigger";
  var BASE_UI_SWIPE_IGNORE_ATTRIBUTE = "data-base-ui-swipe-ignore";
  var LEGACY_SWIPE_IGNORE_ATTRIBUTE = "data-swipe-ignore";
  var BASE_UI_SWIPE_IGNORE_SELECTOR = `[${BASE_UI_SWIPE_IGNORE_ATTRIBUTE}]`;
  var LEGACY_SWIPE_IGNORE_SELECTOR = `[${LEGACY_SWIPE_IGNORE_ATTRIBUTE}]`;
  var DROPDOWN_COLLISION_AVOIDANCE = {
    fallbackAxisSide: "none"
  };
  var POPUP_COLLISION_AVOIDANCE = {
    fallbackAxisSide: "end"
  };
  var ownerVisuallyHidden = {
    clipPath: "inset(50%)",
    position: "fixed",
    top: 0,
    left: 0
  };

  // node_modules/@base-ui/react/esm/utils/useRenderElement.js
  var import_react = __toESM(require_react_shim(), 1);
  function useRenderElement(element, componentProps, params = {}) {
    const renderProp = componentProps.render;
    const outProps = useRenderElementProps(componentProps, params);
    if (params.enabled === false) {
      return null;
    }
    const state = params.state ?? EMPTY_OBJECT;
    return evaluateRenderProp(element, renderProp, outProps, state);
  }
  function useRenderElementProps(componentProps, params = {}) {
    const {
      className: classNameProp,
      style: styleProp,
      render: renderProp
    } = componentProps;
    const {
      state = EMPTY_OBJECT,
      ref,
      props,
      stateAttributesMapping: stateAttributesMapping16,
      enabled = true
    } = params;
    const className = enabled ? resolveClassName(classNameProp, state) : void 0;
    const style = enabled ? resolveStyle(styleProp, state) : void 0;
    const stateProps = enabled ? getStateAttributesProps(state, stateAttributesMapping16) : EMPTY_OBJECT;
    const outProps = enabled ? mergeObjects(stateProps, Array.isArray(props) ? mergePropsN(props) : props) ?? EMPTY_OBJECT : EMPTY_OBJECT;
    if (typeof document !== "undefined") {
      if (!enabled) {
        useMergedRefs(null, null);
      } else if (Array.isArray(ref)) {
        outProps.ref = useMergedRefsN([outProps.ref, getReactElementRef(renderProp), ...ref]);
      } else {
        outProps.ref = useMergedRefs(outProps.ref, getReactElementRef(renderProp), ref);
      }
    }
    if (!enabled) {
      return EMPTY_OBJECT;
    }
    if (className !== void 0) {
      outProps.className = mergeClassNames(outProps.className, className);
    }
    if (style !== void 0) {
      outProps.style = mergeObjects(outProps.style, style);
    }
    return outProps;
  }
  var REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy");
  function evaluateRenderProp(element, render, props, state) {
    if (render) {
      if (typeof render === "function") {
        if (true) {
          warnIfRenderPropLooksLikeComponent(render);
        }
        return render(props, state);
      }
      const mergedProps = mergeProps(props, render.props);
      mergedProps.ref = props.ref;
      let newElement = render;
      if (newElement?.$$typeof === REACT_LAZY_TYPE) {
        const children = React4.Children.toArray(render);
        newElement = children[0];
      }
      if (true) {
        if (!/* @__PURE__ */ React4.isValidElement(newElement)) {
          throw new Error(["Base UI: The `render` prop was provided an invalid React element as `React.isValidElement(render)` is `false`.", "A valid React element must be provided to the `render` prop because it is cloned with props to replace the default element.", "https://base-ui.com/r/invalid-render-prop"].join("\n"));
        }
      }
      return /* @__PURE__ */ React4.cloneElement(newElement, mergedProps);
    }
    if (element) {
      if (typeof element === "string") {
        return renderTag(element, props);
      }
    }
    throw new Error(true ? "Base UI: Render element or function are not defined." : formatErrorMessage_default(8));
  }
  function warnIfRenderPropLooksLikeComponent(renderFn) {
    const functionName = renderFn.name;
    if (functionName.length === 0) {
      return;
    }
    const firstCharacterCode = functionName.charCodeAt(0);
    if (firstCharacterCode < 65 || firstCharacterCode > 90) {
      return;
    }
    warn(`The \`render\` prop received a function named \`${functionName}\` that starts with an uppercase letter.`, "This usually means a React component was passed directly as `render={Component}`.", "Base UI calls `render` as a plain function, which can break the Rules of Hooks during reconciliation.", "If this is an intentional render callback, rename it to start with a lowercase letter.", "Use `render={<Component />}` or `render={(props) => <Component {...props} />}` instead.", "https://base-ui.com/r/invalid-render-prop");
  }
  function renderTag(Tag, props) {
    if (Tag === "button") {
      return /* @__PURE__ */ (0, import_react.createElement)("button", {
        type: "button",
        ...props,
        key: props.key
      });
    }
    if (Tag === "img") {
      return /* @__PURE__ */ (0, import_react.createElement)("img", {
        alt: "",
        ...props,
        key: props.key
      });
    }
    return /* @__PURE__ */ React4.createElement(Tag, props);
  }

  // node_modules/@base-ui/react/esm/avatar/root/AvatarRootContext.js
  init_define_import_meta_env();
  var React5 = __toESM(require_react_shim(), 1);
  var AvatarRootContext = /* @__PURE__ */ React5.createContext(void 0);
  if (true) AvatarRootContext.displayName = "AvatarRootContext";
  function useAvatarRootContext() {
    const context = React5.useContext(AvatarRootContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: AvatarRootContext is missing. Avatar parts must be placed within <Avatar.Root>." : formatErrorMessage_default(13));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/avatar/root/stateAttributesMapping.js
  init_define_import_meta_env();
  var avatarStateAttributesMapping = {
    imageLoadingStatus: () => null
  };

  // node_modules/@base-ui/react/esm/avatar/root/AvatarRoot.js
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var AvatarRoot = /* @__PURE__ */ React6.forwardRef(function AvatarRoot2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const [imageLoadingStatus, setImageLoadingStatus] = React6.useState("idle");
    const state = {
      imageLoadingStatus
    };
    const contextValue = React6.useMemo(() => ({
      imageLoadingStatus,
      setImageLoadingStatus
    }), [imageLoadingStatus, setImageLoadingStatus]);
    const element = useRenderElement("span", componentProps, {
      state,
      ref: forwardedRef,
      props: elementProps,
      stateAttributesMapping: avatarStateAttributesMapping
    });
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarRootContext.Provider, {
      value: contextValue,
      children: element
    });
  });
  if (true) AvatarRoot.displayName = "AvatarRoot";

  // node_modules/@base-ui/react/esm/avatar/image/AvatarImage.js
  init_define_import_meta_env();
  var React13 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useStableCallback.js
  init_define_import_meta_env();
  var React7 = __toESM(require_react_shim(), 1);
  var useInsertionEffect = React7[`useInsertionEffect${Math.random().toFixed(1)}`.slice(0, -3)];
  var useSafeInsertionEffect = (
    // React 17 doesn't have useInsertionEffect.
    useInsertionEffect && // Preact replaces useInsertionEffect with useLayoutEffect and fires too late.
    useInsertionEffect !== React7.useLayoutEffect ? useInsertionEffect : (fn) => fn()
  );
  function useStableCallback(callback) {
    const stable = useRefWithInit(createStableCallback).current;
    stable.next = callback;
    useSafeInsertionEffect(stable.effect);
    return stable.trampoline;
  }
  function createStableCallback() {
    const stable = {
      next: void 0,
      callback: assertNotCalled,
      trampoline: (...args) => stable.callback?.(...args),
      effect: () => {
        stable.callback = stable.next;
      }
    };
    return stable;
  }
  function assertNotCalled() {
    if (true) {
      throw (
        /* minify-error-disabled */
        new Error("Base UI: Cannot call an event handler while rendering.")
      );
    }
  }

  // node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js
  init_define_import_meta_env();
  var React8 = __toESM(require_react_shim(), 1);
  var noop = () => {
  };
  var useIsoLayoutEffect = typeof document !== "undefined" ? React8.useLayoutEffect : noop;

  // node_modules/@base-ui/react/esm/utils/useOpenChangeComplete.js
  init_define_import_meta_env();
  var React10 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/useAnimationsFinished.js
  init_define_import_meta_env();
  var ReactDOM = __toESM(require_react_dom_shim(), 1);

  // node_modules/@base-ui/utils/esm/useAnimationFrame.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/useOnMount.js
  init_define_import_meta_env();
  var React9 = __toESM(require_react_shim(), 1);
  var EMPTY = [];
  function useOnMount(fn) {
    React9.useEffect(fn, EMPTY);
  }

  // node_modules/@base-ui/utils/esm/useAnimationFrame.js
  var EMPTY2 = null;
  var LAST_RAF = globalThis.requestAnimationFrame;
  var Scheduler = class {
    constructor() {
      /* This implementation uses an array as a backing data-structure for frame callbacks.
       * It allows `O(1)` callback cancelling by inserting a `null` in the array, though it
       * never calls the native `cancelAnimationFrame` if there are no frames left. This can
       * be much more efficient if there is a call pattern that alterns as
       * "request-cancel-request-cancel-…".
       * But in the case of "request-request-…-cancel-cancel-…", it leaves the final animation
       * frame to run anyway. We turn that frame into a `O(1)` no-op via `callbacksCount`. */
      __publicField(this, "callbacks", []);
      __publicField(this, "callbacksCount", 0);
      __publicField(this, "nextId", 1);
      __publicField(this, "startId", 1);
      __publicField(this, "isScheduled", false);
      __publicField(this, "tick", (timestamp) => {
        this.isScheduled = false;
        const currentCallbacks = this.callbacks;
        const currentCallbacksCount = this.callbacksCount;
        this.callbacks = [];
        this.callbacksCount = 0;
        this.startId = this.nextId;
        if (currentCallbacksCount > 0) {
          for (let i = 0; i < currentCallbacks.length; i += 1) {
            currentCallbacks[i]?.(timestamp);
          }
        }
      });
    }
    request(fn) {
      const id = this.nextId;
      this.nextId += 1;
      this.callbacks.push(fn);
      this.callbacksCount += 1;
      const didRAFChange = LAST_RAF !== requestAnimationFrame && (LAST_RAF = requestAnimationFrame, true);
      if (!this.isScheduled || didRAFChange) {
        requestAnimationFrame(this.tick);
        this.isScheduled = true;
      }
      return id;
    }
    cancel(id) {
      const index2 = id - this.startId;
      if (index2 < 0 || index2 >= this.callbacks.length) {
        return;
      }
      this.callbacks[index2] = null;
      this.callbacksCount -= 1;
    }
  };
  var scheduler = new Scheduler();
  var AnimationFrame = class _AnimationFrame {
    constructor() {
      __publicField(this, "currentId", EMPTY2);
      __publicField(this, "cancel", () => {
        if (this.currentId !== EMPTY2) {
          scheduler.cancel(this.currentId);
          this.currentId = EMPTY2;
        }
      });
      __publicField(this, "disposeEffect", () => {
        return this.cancel;
      });
    }
    static create() {
      return new _AnimationFrame();
    }
    static request(fn) {
      return scheduler.request(fn);
    }
    static cancel(id) {
      return scheduler.cancel(id);
    }
    /**
     * Executes `fn` after `delay`, clearing any previously scheduled call.
     */
    request(fn) {
      this.cancel();
      this.currentId = scheduler.request(() => {
        this.currentId = EMPTY2;
        fn();
      });
    }
  };
  function useAnimationFrame() {
    const timeout = useRefWithInit(AnimationFrame.create).current;
    useOnMount(timeout.disposeEffect);
    return timeout;
  }

  // node_modules/@base-ui/react/esm/utils/resolveRef.js
  init_define_import_meta_env();
  function resolveRef(maybeRef) {
    if (maybeRef == null) {
      return maybeRef;
    }
    return "current" in maybeRef ? maybeRef.current : maybeRef;
  }

  // node_modules/@base-ui/react/esm/utils/stateAttributesMapping.js
  init_define_import_meta_env();
  var TransitionStatusDataAttributes = /* @__PURE__ */ (function(TransitionStatusDataAttributes2) {
    TransitionStatusDataAttributes2["startingStyle"] = "data-starting-style";
    TransitionStatusDataAttributes2["endingStyle"] = "data-ending-style";
    return TransitionStatusDataAttributes2;
  })({});
  var STARTING_HOOK = {
    [TransitionStatusDataAttributes.startingStyle]: ""
  };
  var ENDING_HOOK = {
    [TransitionStatusDataAttributes.endingStyle]: ""
  };
  var transitionStatusMapping = {
    transitionStatus(value) {
      if (value === "starting") {
        return STARTING_HOOK;
      }
      if (value === "ending") {
        return ENDING_HOOK;
      }
      return null;
    }
  };

  // node_modules/@base-ui/react/esm/utils/useAnimationsFinished.js
  function useAnimationsFinished(elementOrRef, waitForStartingStyleRemoved = false, treatAbortedAsFinished = true) {
    const frame = useAnimationFrame();
    return useStableCallback((fnToExecute, signal = null) => {
      frame.cancel();
      function done() {
        ReactDOM.flushSync(fnToExecute);
      }
      const element = resolveRef(elementOrRef);
      if (element == null) {
        return;
      }
      const resolvedElement = element;
      if (typeof resolvedElement.getAnimations !== "function" || globalThis.BASE_UI_ANIMATIONS_DISABLED) {
        fnToExecute();
      } else {
        let execWaitForStartingStyleRemoved = function() {
          const startingStyleAttribute = TransitionStatusDataAttributes.startingStyle;
          if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
            frame.request(exec);
            return;
          }
          const attributeObserver = new MutationObserver(() => {
            if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
              attributeObserver.disconnect();
              exec();
            }
          });
          attributeObserver.observe(resolvedElement, {
            attributes: true,
            attributeFilter: [startingStyleAttribute]
          });
          signal?.addEventListener("abort", () => attributeObserver.disconnect(), {
            once: true
          });
        }, exec = function() {
          Promise.all(resolvedElement.getAnimations().map((anim) => anim.finished)).then(() => {
            if (signal?.aborted) {
              return;
            }
            done();
          }).catch(() => {
            const currentAnimations = resolvedElement.getAnimations();
            if (treatAbortedAsFinished) {
              if (signal?.aborted) {
                return;
              }
              done();
            } else if (currentAnimations.length > 0 && currentAnimations.some((anim) => anim.pending || anim.playState !== "finished")) {
              exec();
            }
          });
        };
        if (waitForStartingStyleRemoved) {
          execWaitForStartingStyleRemoved();
          return;
        }
        frame.request(exec);
      }
    });
  }

  // node_modules/@base-ui/react/esm/utils/useOpenChangeComplete.js
  function useOpenChangeComplete(parameters) {
    const {
      enabled = true,
      open,
      ref,
      onComplete: onCompleteParam
    } = parameters;
    const onComplete = useStableCallback(onCompleteParam);
    const runOnceAnimationsFinish = useAnimationsFinished(ref, open, false);
    React10.useEffect(() => {
      if (!enabled) {
        return void 0;
      }
      const abortController = new AbortController();
      runOnceAnimationsFinish(onComplete, abortController.signal);
      return () => {
        abortController.abort();
      };
    }, [enabled, open, onComplete, runOnceAnimationsFinish]);
  }

  // node_modules/@base-ui/react/esm/utils/useTransitionStatus.js
  init_define_import_meta_env();
  var React11 = __toESM(require_react_shim(), 1);
  function useTransitionStatus(open, enableIdleState = false, deferEndingState = false) {
    const [transitionStatus, setTransitionStatus] = React11.useState(open && enableIdleState ? "idle" : void 0);
    const [mounted, setMounted] = React11.useState(open);
    if (open && !mounted) {
      setMounted(true);
      setTransitionStatus("starting");
    }
    if (!open && mounted && transitionStatus !== "ending" && !deferEndingState) {
      setTransitionStatus("ending");
    }
    if (!open && !mounted && transitionStatus === "ending") {
      setTransitionStatus(void 0);
    }
    useIsoLayoutEffect(() => {
      if (!open && mounted && transitionStatus !== "ending" && deferEndingState) {
        const frame = AnimationFrame.request(() => {
          setTransitionStatus("ending");
        });
        return () => {
          AnimationFrame.cancel(frame);
        };
      }
      return void 0;
    }, [open, mounted, transitionStatus, deferEndingState]);
    useIsoLayoutEffect(() => {
      if (!open || enableIdleState) {
        return void 0;
      }
      const frame = AnimationFrame.request(() => {
        setTransitionStatus(void 0);
      });
      return () => {
        AnimationFrame.cancel(frame);
      };
    }, [enableIdleState, open]);
    useIsoLayoutEffect(() => {
      if (!open || !enableIdleState) {
        return void 0;
      }
      if (open && mounted && transitionStatus !== "idle") {
        setTransitionStatus("starting");
      }
      const frame = AnimationFrame.request(() => {
        setTransitionStatus("idle");
      });
      return () => {
        AnimationFrame.cancel(frame);
      };
    }, [enableIdleState, open, mounted, setTransitionStatus, transitionStatus]);
    return React11.useMemo(() => ({
      mounted,
      setMounted,
      transitionStatus
    }), [mounted, transitionStatus]);
  }

  // node_modules/@base-ui/react/esm/avatar/image/useImageLoadingStatus.js
  init_define_import_meta_env();
  var React12 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/noop.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/avatar/image/useImageLoadingStatus.js
  function useImageLoadingStatus(src, {
    referrerPolicy,
    crossOrigin
  }) {
    const [loadingStatus, setLoadingStatus] = React12.useState("idle");
    useIsoLayoutEffect(() => {
      if (!src) {
        setLoadingStatus("error");
        return NOOP;
      }
      let isMounted = true;
      const image = new window.Image();
      const updateStatus = (status) => () => {
        if (!isMounted) {
          return;
        }
        setLoadingStatus(status);
      };
      setLoadingStatus("loading");
      image.onload = updateStatus("loaded");
      image.onerror = updateStatus("error");
      if (referrerPolicy) {
        image.referrerPolicy = referrerPolicy;
      }
      image.crossOrigin = crossOrigin ?? null;
      image.src = src;
      return () => {
        isMounted = false;
      };
    }, [src, crossOrigin, referrerPolicy]);
    return loadingStatus;
  }

  // node_modules/@base-ui/react/esm/avatar/image/AvatarImage.js
  var stateAttributesMapping = {
    ...avatarStateAttributesMapping,
    ...transitionStatusMapping
  };
  var AvatarImage = /* @__PURE__ */ React13.forwardRef(function AvatarImage2(componentProps, forwardedRef) {
    const {
      className,
      render,
      onLoadingStatusChange: onLoadingStatusChangeProp,
      referrerPolicy,
      crossOrigin,
      ...elementProps
    } = componentProps;
    const context = useAvatarRootContext();
    const imageLoadingStatus = useImageLoadingStatus(componentProps.src, {
      referrerPolicy,
      crossOrigin
    });
    const isVisible = imageLoadingStatus === "loaded";
    const {
      mounted,
      transitionStatus,
      setMounted
    } = useTransitionStatus(isVisible);
    const imageRef = React13.useRef(null);
    const handleLoadingStatusChange = useStableCallback((status) => {
      onLoadingStatusChangeProp?.(status);
      context.setImageLoadingStatus(status);
    });
    useIsoLayoutEffect(() => {
      if (imageLoadingStatus !== "idle") {
        handleLoadingStatusChange(imageLoadingStatus);
      }
    }, [imageLoadingStatus, handleLoadingStatusChange]);
    const state = {
      imageLoadingStatus,
      transitionStatus
    };
    useOpenChangeComplete({
      open: isVisible,
      ref: imageRef,
      onComplete() {
        if (!isVisible) {
          setMounted(false);
        }
      }
    });
    const element = useRenderElement("img", componentProps, {
      state,
      ref: [forwardedRef, imageRef],
      props: elementProps,
      stateAttributesMapping,
      enabled: mounted
    });
    if (!mounted) {
      return null;
    }
    return element;
  });
  if (true) AvatarImage.displayName = "AvatarImage";

  // node_modules/@base-ui/react/esm/avatar/fallback/AvatarFallback.js
  init_define_import_meta_env();
  var React14 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useTimeout.js
  init_define_import_meta_env();
  var EMPTY3 = 0;
  var Timeout = class _Timeout {
    constructor() {
      __publicField(this, "currentId", EMPTY3);
      __publicField(this, "clear", () => {
        if (this.currentId !== EMPTY3) {
          clearTimeout(this.currentId);
          this.currentId = EMPTY3;
        }
      });
      __publicField(this, "disposeEffect", () => {
        return this.clear;
      });
    }
    static create() {
      return new _Timeout();
    }
    /**
     * Executes `fn` after `delay`, clearing any previously scheduled call.
     */
    start(delay, fn) {
      this.clear();
      this.currentId = setTimeout(() => {
        this.currentId = EMPTY3;
        fn();
      }, delay);
    }
    isStarted() {
      return this.currentId !== EMPTY3;
    }
  };
  function useTimeout() {
    const timeout = useRefWithInit(Timeout.create).current;
    useOnMount(timeout.disposeEffect);
    return timeout;
  }

  // node_modules/@base-ui/react/esm/avatar/fallback/AvatarFallback.js
  var AvatarFallback = /* @__PURE__ */ React14.forwardRef(function AvatarFallback2(componentProps, forwardedRef) {
    const {
      className,
      render,
      delay,
      ...elementProps
    } = componentProps;
    const {
      imageLoadingStatus
    } = useAvatarRootContext();
    const [delayPassed, setDelayPassed] = React14.useState(delay === void 0);
    const timeout = useTimeout();
    React14.useEffect(() => {
      if (delay !== void 0) {
        timeout.start(delay, () => setDelayPassed(true));
      }
      return timeout.clear;
    }, [timeout, delay]);
    const state = {
      imageLoadingStatus
    };
    const element = useRenderElement("span", componentProps, {
      state,
      ref: forwardedRef,
      props: elementProps,
      stateAttributesMapping: avatarStateAttributesMapping,
      enabled: imageLoadingStatus !== "loaded" && delayPassed
    });
    return element;
  });
  if (true) AvatarFallback.displayName = "AvatarFallback";

  // src/lib/utils.ts
  init_define_import_meta_env();

  // node_modules/clsx/dist/clsx.mjs
  init_define_import_meta_env();
  function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
      var o = e.length;
      for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for (f in e) e[f] && (n && (n += " "), n += f);
    return n;
  }
  function clsx() {
    for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
  }

  // node_modules/tailwind-merge/dist/bundle-mjs.mjs
  init_define_import_meta_env();
  var concatArrays = (array1, array2) => {
    const combinedArray = new Array(array1.length + array2.length);
    for (let i = 0; i < array1.length; i++) {
      combinedArray[i] = array1[i];
    }
    for (let i = 0; i < array2.length; i++) {
      combinedArray[array1.length + i] = array2[i];
    }
    return combinedArray;
  };
  var createClassValidatorObject = (classGroupId, validator) => ({
    classGroupId,
    validator
  });
  var createClassPartObject = (nextPart = /* @__PURE__ */ new Map(), validators = null, classGroupId) => ({
    nextPart,
    validators,
    classGroupId
  });
  var CLASS_PART_SEPARATOR = "-";
  var EMPTY_CONFLICTS = [];
  var ARBITRARY_PROPERTY_PREFIX = "arbitrary..";
  var createClassGroupUtils = (config) => {
    const classMap = createClassMap(config);
    const {
      conflictingClassGroups,
      conflictingClassGroupModifiers
    } = config;
    const getClassGroupId = (className) => {
      if (className.startsWith("[") && className.endsWith("]")) {
        return getGroupIdForArbitraryProperty(className);
      }
      const classParts = className.split(CLASS_PART_SEPARATOR);
      const startIndex = classParts[0] === "" && classParts.length > 1 ? 1 : 0;
      return getGroupRecursive(classParts, startIndex, classMap);
    };
    const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
      if (hasPostfixModifier) {
        const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
        const baseConflicts = conflictingClassGroups[classGroupId];
        if (modifierConflicts) {
          if (baseConflicts) {
            return concatArrays(baseConflicts, modifierConflicts);
          }
          return modifierConflicts;
        }
        return baseConflicts || EMPTY_CONFLICTS;
      }
      return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
    };
    return {
      getClassGroupId,
      getConflictingClassGroupIds
    };
  };
  var getGroupRecursive = (classParts, startIndex, classPartObject) => {
    const classPathsLength = classParts.length - startIndex;
    if (classPathsLength === 0) {
      return classPartObject.classGroupId;
    }
    const currentClassPart = classParts[startIndex];
    const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
    if (nextClassPartObject) {
      const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
      if (result) return result;
    }
    const validators = classPartObject.validators;
    if (validators === null) {
      return void 0;
    }
    const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
    const validatorsLength = validators.length;
    for (let i = 0; i < validatorsLength; i++) {
      const validatorObj = validators[i];
      if (validatorObj.validator(classRest)) {
        return validatorObj.classGroupId;
      }
    }
    return void 0;
  };
  var getGroupIdForArbitraryProperty = (className) => className.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
    const content = className.slice(1, -1);
    const colonIndex = content.indexOf(":");
    const property = content.slice(0, colonIndex);
    return property ? ARBITRARY_PROPERTY_PREFIX + property : void 0;
  })();
  var createClassMap = (config) => {
    const {
      theme,
      classGroups
    } = config;
    return processClassGroups(classGroups, theme);
  };
  var processClassGroups = (classGroups, theme) => {
    const classMap = createClassPartObject();
    for (const classGroupId in classGroups) {
      const group = classGroups[classGroupId];
      processClassesRecursively(group, classMap, classGroupId, theme);
    }
    return classMap;
  };
  var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
    const len = classGroup.length;
    for (let i = 0; i < len; i++) {
      const classDefinition = classGroup[i];
      processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
    }
  };
  var processClassDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    if (typeof classDefinition === "string") {
      processStringDefinition(classDefinition, classPartObject, classGroupId);
      return;
    }
    if (typeof classDefinition === "function") {
      processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
      return;
    }
    processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
  };
  var processStringDefinition = (classDefinition, classPartObject, classGroupId) => {
    const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
    classPartObjectToEdit.classGroupId = classGroupId;
  };
  var processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    if (isThemeGetter(classDefinition)) {
      processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
      return;
    }
    if (classPartObject.validators === null) {
      classPartObject.validators = [];
    }
    classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
  };
  var processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
    const entries = Object.entries(classDefinition);
    const len = entries.length;
    for (let i = 0; i < len; i++) {
      const [key, value] = entries[i];
      processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
    }
  };
  var getPart = (classPartObject, path) => {
    let current = classPartObject;
    const parts = path.split(CLASS_PART_SEPARATOR);
    const len = parts.length;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      let next = current.nextPart.get(part);
      if (!next) {
        next = createClassPartObject();
        current.nextPart.set(part, next);
      }
      current = next;
    }
    return current;
  };
  var isThemeGetter = (func) => "isThemeGetter" in func && func.isThemeGetter === true;
  var createLruCache = (maxCacheSize) => {
    if (maxCacheSize < 1) {
      return {
        get: () => void 0,
        set: () => {
        }
      };
    }
    let cacheSize = 0;
    let cache = /* @__PURE__ */ Object.create(null);
    let previousCache = /* @__PURE__ */ Object.create(null);
    const update2 = (key, value) => {
      cache[key] = value;
      cacheSize++;
      if (cacheSize > maxCacheSize) {
        cacheSize = 0;
        previousCache = cache;
        cache = /* @__PURE__ */ Object.create(null);
      }
    };
    return {
      get(key) {
        let value = cache[key];
        if (value !== void 0) {
          return value;
        }
        if ((value = previousCache[key]) !== void 0) {
          update2(key, value);
          return value;
        }
      },
      set(key, value) {
        if (key in cache) {
          cache[key] = value;
        } else {
          update2(key, value);
        }
      }
    };
  };
  var IMPORTANT_MODIFIER = "!";
  var MODIFIER_SEPARATOR = ":";
  var EMPTY_MODIFIERS = [];
  var createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal) => ({
    modifiers,
    hasImportantModifier,
    baseClassName,
    maybePostfixModifierPosition,
    isExternal
  });
  var createParseClassName = (config) => {
    const {
      prefix,
      experimentalParseClassName
    } = config;
    let parseClassName = (className) => {
      const modifiers = [];
      let bracketDepth = 0;
      let parenDepth = 0;
      let modifierStart = 0;
      let postfixModifierPosition;
      const len = className.length;
      for (let index2 = 0; index2 < len; index2++) {
        const currentCharacter = className[index2];
        if (bracketDepth === 0 && parenDepth === 0) {
          if (currentCharacter === MODIFIER_SEPARATOR) {
            modifiers.push(className.slice(modifierStart, index2));
            modifierStart = index2 + 1;
            continue;
          }
          if (currentCharacter === "/") {
            postfixModifierPosition = index2;
            continue;
          }
        }
        if (currentCharacter === "[") bracketDepth++;
        else if (currentCharacter === "]") bracketDepth--;
        else if (currentCharacter === "(") parenDepth++;
        else if (currentCharacter === ")") parenDepth--;
      }
      const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
      let baseClassName = baseClassNameWithImportantModifier;
      let hasImportantModifier = false;
      if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
        baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
        hasImportantModifier = true;
      } else if (
        /**
         * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
         * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
         */
        baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)
      ) {
        baseClassName = baseClassNameWithImportantModifier.slice(1);
        hasImportantModifier = true;
      }
      const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
      return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
    };
    if (prefix) {
      const fullPrefix = prefix + MODIFIER_SEPARATOR;
      const parseClassNameOriginal = parseClassName;
      parseClassName = (className) => className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, void 0, true);
    }
    if (experimentalParseClassName) {
      const parseClassNameOriginal = parseClassName;
      parseClassName = (className) => experimentalParseClassName({
        className,
        parseClassName: parseClassNameOriginal
      });
    }
    return parseClassName;
  };
  var createSortModifiers = (config) => {
    const modifierWeights = /* @__PURE__ */ new Map();
    config.orderSensitiveModifiers.forEach((mod, index2) => {
      modifierWeights.set(mod, 1e6 + index2);
    });
    return (modifiers) => {
      const result = [];
      let currentSegment = [];
      for (let i = 0; i < modifiers.length; i++) {
        const modifier = modifiers[i];
        const isArbitrary = modifier[0] === "[";
        const isOrderSensitive = modifierWeights.has(modifier);
        if (isArbitrary || isOrderSensitive) {
          if (currentSegment.length > 0) {
            currentSegment.sort();
            result.push(...currentSegment);
            currentSegment = [];
          }
          result.push(modifier);
        } else {
          currentSegment.push(modifier);
        }
      }
      if (currentSegment.length > 0) {
        currentSegment.sort();
        result.push(...currentSegment);
      }
      return result;
    };
  };
  var createConfigUtils = (config) => ({
    cache: createLruCache(config.cacheSize),
    parseClassName: createParseClassName(config),
    sortModifiers: createSortModifiers(config),
    ...createClassGroupUtils(config)
  });
  var SPLIT_CLASSES_REGEX = /\s+/;
  var mergeClassList = (classList, configUtils) => {
    const {
      parseClassName,
      getClassGroupId,
      getConflictingClassGroupIds,
      sortModifiers
    } = configUtils;
    const classGroupsInConflict = [];
    const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
    let result = "";
    for (let index2 = classNames.length - 1; index2 >= 0; index2 -= 1) {
      const originalClassName = classNames[index2];
      const {
        isExternal,
        modifiers,
        hasImportantModifier,
        baseClassName,
        maybePostfixModifierPosition
      } = parseClassName(originalClassName);
      if (isExternal) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      let hasPostfixModifier = !!maybePostfixModifierPosition;
      let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
      if (!classGroupId) {
        if (!hasPostfixModifier) {
          result = originalClassName + (result.length > 0 ? " " + result : result);
          continue;
        }
        classGroupId = getClassGroupId(baseClassName);
        if (!classGroupId) {
          result = originalClassName + (result.length > 0 ? " " + result : result);
          continue;
        }
        hasPostfixModifier = false;
      }
      const variantModifier = modifiers.length === 0 ? "" : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(":");
      const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
      const classId = modifierId + classGroupId;
      if (classGroupsInConflict.indexOf(classId) > -1) {
        continue;
      }
      classGroupsInConflict.push(classId);
      const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
      for (let i = 0; i < conflictGroups.length; ++i) {
        const group = conflictGroups[i];
        classGroupsInConflict.push(modifierId + group);
      }
      result = originalClassName + (result.length > 0 ? " " + result : result);
    }
    return result;
  };
  var twJoin = (...classLists) => {
    let index2 = 0;
    let argument;
    let resolvedValue;
    let string = "";
    while (index2 < classLists.length) {
      if (argument = classLists[index2++]) {
        if (resolvedValue = toValue(argument)) {
          string && (string += " ");
          string += resolvedValue;
        }
      }
    }
    return string;
  };
  var toValue = (mix) => {
    if (typeof mix === "string") {
      return mix;
    }
    let resolvedValue;
    let string = "";
    for (let k = 0; k < mix.length; k++) {
      if (mix[k]) {
        if (resolvedValue = toValue(mix[k])) {
          string && (string += " ");
          string += resolvedValue;
        }
      }
    }
    return string;
  };
  var createTailwindMerge = (createConfigFirst, ...createConfigRest) => {
    let configUtils;
    let cacheGet;
    let cacheSet;
    let functionToCall;
    const initTailwindMerge = (classList) => {
      const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
      configUtils = createConfigUtils(config);
      cacheGet = configUtils.cache.get;
      cacheSet = configUtils.cache.set;
      functionToCall = tailwindMerge;
      return tailwindMerge(classList);
    };
    const tailwindMerge = (classList) => {
      const cachedResult = cacheGet(classList);
      if (cachedResult) {
        return cachedResult;
      }
      const result = mergeClassList(classList, configUtils);
      cacheSet(classList, result);
      return result;
    };
    functionToCall = initTailwindMerge;
    return (...args) => functionToCall(twJoin(...args));
  };
  var fallbackThemeArr = [];
  var fromTheme = (key) => {
    const themeGetter = (theme) => theme[key] || fallbackThemeArr;
    themeGetter.isThemeGetter = true;
    return themeGetter;
  };
  var arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
  var arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
  var fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
  var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
  var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
  var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
  var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
  var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
  var isFraction = (value) => fractionRegex.test(value);
  var isNumber = (value) => !!value && !Number.isNaN(Number(value));
  var isInteger = (value) => !!value && Number.isInteger(Number(value));
  var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
  var isTshirtSize = (value) => tshirtUnitRegex.test(value);
  var isAny = () => true;
  var isLengthOnly = (value) => (
    // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
    // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
    // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
    lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
  );
  var isNever = () => false;
  var isShadow = (value) => shadowRegex.test(value);
  var isImage = (value) => imageRegex.test(value);
  var isAnyNonArbitrary = (value) => !isArbitraryValue(value) && !isArbitraryVariable(value);
  var isArbitrarySize = (value) => getIsArbitraryValue(value, isLabelSize, isNever);
  var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
  var isArbitraryLength = (value) => getIsArbitraryValue(value, isLabelLength, isLengthOnly);
  var isArbitraryNumber = (value) => getIsArbitraryValue(value, isLabelNumber, isNumber);
  var isArbitraryWeight = (value) => getIsArbitraryValue(value, isLabelWeight, isAny);
  var isArbitraryFamilyName = (value) => getIsArbitraryValue(value, isLabelFamilyName, isNever);
  var isArbitraryPosition = (value) => getIsArbitraryValue(value, isLabelPosition, isNever);
  var isArbitraryImage = (value) => getIsArbitraryValue(value, isLabelImage, isImage);
  var isArbitraryShadow = (value) => getIsArbitraryValue(value, isLabelShadow, isShadow);
  var isArbitraryVariable = (value) => arbitraryVariableRegex.test(value);
  var isArbitraryVariableLength = (value) => getIsArbitraryVariable(value, isLabelLength);
  var isArbitraryVariableFamilyName = (value) => getIsArbitraryVariable(value, isLabelFamilyName);
  var isArbitraryVariablePosition = (value) => getIsArbitraryVariable(value, isLabelPosition);
  var isArbitraryVariableSize = (value) => getIsArbitraryVariable(value, isLabelSize);
  var isArbitraryVariableImage = (value) => getIsArbitraryVariable(value, isLabelImage);
  var isArbitraryVariableShadow = (value) => getIsArbitraryVariable(value, isLabelShadow, true);
  var isArbitraryVariableWeight = (value) => getIsArbitraryVariable(value, isLabelWeight, true);
  var getIsArbitraryValue = (value, testLabel, testValue) => {
    const result = arbitraryValueRegex.exec(value);
    if (result) {
      if (result[1]) {
        return testLabel(result[1]);
      }
      return testValue(result[2]);
    }
    return false;
  };
  var getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false) => {
    const result = arbitraryVariableRegex.exec(value);
    if (result) {
      if (result[1]) {
        return testLabel(result[1]);
      }
      return shouldMatchNoLabel;
    }
    return false;
  };
  var isLabelPosition = (label) => label === "position" || label === "percentage";
  var isLabelImage = (label) => label === "image" || label === "url";
  var isLabelSize = (label) => label === "length" || label === "size" || label === "bg-size";
  var isLabelLength = (label) => label === "length";
  var isLabelNumber = (label) => label === "number";
  var isLabelFamilyName = (label) => label === "family-name";
  var isLabelWeight = (label) => label === "number" || label === "weight";
  var isLabelShadow = (label) => label === "shadow";
  var getDefaultConfig = () => {
    const themeColor = fromTheme("color");
    const themeFont = fromTheme("font");
    const themeText = fromTheme("text");
    const themeFontWeight = fromTheme("font-weight");
    const themeTracking = fromTheme("tracking");
    const themeLeading = fromTheme("leading");
    const themeBreakpoint = fromTheme("breakpoint");
    const themeContainer = fromTheme("container");
    const themeSpacing = fromTheme("spacing");
    const themeRadius = fromTheme("radius");
    const themeShadow = fromTheme("shadow");
    const themeInsetShadow = fromTheme("inset-shadow");
    const themeTextShadow = fromTheme("text-shadow");
    const themeDropShadow = fromTheme("drop-shadow");
    const themeBlur = fromTheme("blur");
    const themePerspective = fromTheme("perspective");
    const themeAspect = fromTheme("aspect");
    const themeEase = fromTheme("ease");
    const themeAnimate = fromTheme("animate");
    const scaleBreak = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
    const scalePosition = () => [
      "center",
      "top",
      "bottom",
      "left",
      "right",
      "top-left",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "left-top",
      "top-right",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "right-top",
      "bottom-right",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "right-bottom",
      "bottom-left",
      // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
      "left-bottom"
    ];
    const scalePositionWithArbitrary = () => [...scalePosition(), isArbitraryVariable, isArbitraryValue];
    const scaleOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
    const scaleOverscroll = () => ["auto", "contain", "none"];
    const scaleUnambiguousSpacing = () => [isArbitraryVariable, isArbitraryValue, themeSpacing];
    const scaleInset = () => [isFraction, "full", "auto", ...scaleUnambiguousSpacing()];
    const scaleGridTemplateColsRows = () => [isInteger, "none", "subgrid", isArbitraryVariable, isArbitraryValue];
    const scaleGridColRowStartAndEnd = () => ["auto", {
      span: ["full", isInteger, isArbitraryVariable, isArbitraryValue]
    }, isInteger, isArbitraryVariable, isArbitraryValue];
    const scaleGridColRowStartOrEnd = () => [isInteger, "auto", isArbitraryVariable, isArbitraryValue];
    const scaleGridAutoColsRows = () => ["auto", "min", "max", "fr", isArbitraryVariable, isArbitraryValue];
    const scaleAlignPrimaryAxis = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"];
    const scaleAlignSecondaryAxis = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"];
    const scaleMargin = () => ["auto", ...scaleUnambiguousSpacing()];
    const scaleSizing = () => [isFraction, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleSizingInline = () => [isFraction, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleSizingBlock = () => [isFraction, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
    const scaleColor = () => [themeColor, isArbitraryVariable, isArbitraryValue];
    const scaleBgPosition = () => [...scalePosition(), isArbitraryVariablePosition, isArbitraryPosition, {
      position: [isArbitraryVariable, isArbitraryValue]
    }];
    const scaleBgRepeat = () => ["no-repeat", {
      repeat: ["", "x", "y", "space", "round"]
    }];
    const scaleBgSize = () => ["auto", "cover", "contain", isArbitraryVariableSize, isArbitrarySize, {
      size: [isArbitraryVariable, isArbitraryValue]
    }];
    const scaleGradientStopPosition = () => [isPercent, isArbitraryVariableLength, isArbitraryLength];
    const scaleRadius = () => [
      // Deprecated since Tailwind CSS v4.0.0
      "",
      "none",
      "full",
      themeRadius,
      isArbitraryVariable,
      isArbitraryValue
    ];
    const scaleBorderWidth = () => ["", isNumber, isArbitraryVariableLength, isArbitraryLength];
    const scaleLineStyle = () => ["solid", "dashed", "dotted", "double"];
    const scaleBlendMode = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
    const scaleMaskImagePosition = () => [isNumber, isPercent, isArbitraryVariablePosition, isArbitraryPosition];
    const scaleBlur = () => [
      // Deprecated since Tailwind CSS v4.0.0
      "",
      "none",
      themeBlur,
      isArbitraryVariable,
      isArbitraryValue
    ];
    const scaleRotate = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleScale = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleSkew = () => [isNumber, isArbitraryVariable, isArbitraryValue];
    const scaleTranslate = () => [isFraction, "full", ...scaleUnambiguousSpacing()];
    return {
      cacheSize: 500,
      theme: {
        animate: ["spin", "ping", "pulse", "bounce"],
        aspect: ["video"],
        blur: [isTshirtSize],
        breakpoint: [isTshirtSize],
        color: [isAny],
        container: [isTshirtSize],
        "drop-shadow": [isTshirtSize],
        ease: ["in", "out", "in-out"],
        font: [isAnyNonArbitrary],
        "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
        "inset-shadow": [isTshirtSize],
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
        perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
        radius: [isTshirtSize],
        shadow: [isTshirtSize],
        spacing: ["px", isNumber],
        text: [isTshirtSize],
        "text-shadow": [isTshirtSize],
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
      },
      classGroups: {
        // --------------
        // --- Layout ---
        // --------------
        /**
         * Aspect Ratio
         * @see https://tailwindcss.com/docs/aspect-ratio
         */
        aspect: [{
          aspect: ["auto", "square", isFraction, isArbitraryValue, isArbitraryVariable, themeAspect]
        }],
        /**
         * Container
         * @see https://tailwindcss.com/docs/container
         * @deprecated since Tailwind CSS v4.0.0
         */
        container: ["container"],
        /**
         * Columns
         * @see https://tailwindcss.com/docs/columns
         */
        columns: [{
          columns: [isNumber, isArbitraryValue, isArbitraryVariable, themeContainer]
        }],
        /**
         * Break After
         * @see https://tailwindcss.com/docs/break-after
         */
        "break-after": [{
          "break-after": scaleBreak()
        }],
        /**
         * Break Before
         * @see https://tailwindcss.com/docs/break-before
         */
        "break-before": [{
          "break-before": scaleBreak()
        }],
        /**
         * Break Inside
         * @see https://tailwindcss.com/docs/break-inside
         */
        "break-inside": [{
          "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
        }],
        /**
         * Box Decoration Break
         * @see https://tailwindcss.com/docs/box-decoration-break
         */
        "box-decoration": [{
          "box-decoration": ["slice", "clone"]
        }],
        /**
         * Box Sizing
         * @see https://tailwindcss.com/docs/box-sizing
         */
        box: [{
          box: ["border", "content"]
        }],
        /**
         * Display
         * @see https://tailwindcss.com/docs/display
         */
        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
        /**
         * Screen Reader Only
         * @see https://tailwindcss.com/docs/display#screen-reader-only
         */
        sr: ["sr-only", "not-sr-only"],
        /**
         * Floats
         * @see https://tailwindcss.com/docs/float
         */
        float: [{
          float: ["right", "left", "none", "start", "end"]
        }],
        /**
         * Clear
         * @see https://tailwindcss.com/docs/clear
         */
        clear: [{
          clear: ["left", "right", "both", "none", "start", "end"]
        }],
        /**
         * Isolation
         * @see https://tailwindcss.com/docs/isolation
         */
        isolation: ["isolate", "isolation-auto"],
        /**
         * Object Fit
         * @see https://tailwindcss.com/docs/object-fit
         */
        "object-fit": [{
          object: ["contain", "cover", "fill", "none", "scale-down"]
        }],
        /**
         * Object Position
         * @see https://tailwindcss.com/docs/object-position
         */
        "object-position": [{
          object: scalePositionWithArbitrary()
        }],
        /**
         * Overflow
         * @see https://tailwindcss.com/docs/overflow
         */
        overflow: [{
          overflow: scaleOverflow()
        }],
        /**
         * Overflow X
         * @see https://tailwindcss.com/docs/overflow
         */
        "overflow-x": [{
          "overflow-x": scaleOverflow()
        }],
        /**
         * Overflow Y
         * @see https://tailwindcss.com/docs/overflow
         */
        "overflow-y": [{
          "overflow-y": scaleOverflow()
        }],
        /**
         * Overscroll Behavior
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        overscroll: [{
          overscroll: scaleOverscroll()
        }],
        /**
         * Overscroll Behavior X
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        "overscroll-x": [{
          "overscroll-x": scaleOverscroll()
        }],
        /**
         * Overscroll Behavior Y
         * @see https://tailwindcss.com/docs/overscroll-behavior
         */
        "overscroll-y": [{
          "overscroll-y": scaleOverscroll()
        }],
        /**
         * Position
         * @see https://tailwindcss.com/docs/position
         */
        position: ["static", "fixed", "absolute", "relative", "sticky"],
        /**
         * Inset
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        inset: [{
          inset: scaleInset()
        }],
        /**
         * Inset Inline
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-x": [{
          "inset-x": scaleInset()
        }],
        /**
         * Inset Block
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-y": [{
          "inset-y": scaleInset()
        }],
        /**
         * Inset Inline Start
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         * @todo class group will be renamed to `inset-s` in next major release
         */
        start: [{
          "inset-s": scaleInset(),
          /**
           * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
           * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
           */
          start: scaleInset()
        }],
        /**
         * Inset Inline End
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         * @todo class group will be renamed to `inset-e` in next major release
         */
        end: [{
          "inset-e": scaleInset(),
          /**
           * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
           * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
           */
          end: scaleInset()
        }],
        /**
         * Inset Block Start
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-bs": [{
          "inset-bs": scaleInset()
        }],
        /**
         * Inset Block End
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        "inset-be": [{
          "inset-be": scaleInset()
        }],
        /**
         * Top
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        top: [{
          top: scaleInset()
        }],
        /**
         * Right
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        right: [{
          right: scaleInset()
        }],
        /**
         * Bottom
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        bottom: [{
          bottom: scaleInset()
        }],
        /**
         * Left
         * @see https://tailwindcss.com/docs/top-right-bottom-left
         */
        left: [{
          left: scaleInset()
        }],
        /**
         * Visibility
         * @see https://tailwindcss.com/docs/visibility
         */
        visibility: ["visible", "invisible", "collapse"],
        /**
         * Z-Index
         * @see https://tailwindcss.com/docs/z-index
         */
        z: [{
          z: [isInteger, "auto", isArbitraryVariable, isArbitraryValue]
        }],
        // ------------------------
        // --- Flexbox and Grid ---
        // ------------------------
        /**
         * Flex Basis
         * @see https://tailwindcss.com/docs/flex-basis
         */
        basis: [{
          basis: [isFraction, "full", "auto", themeContainer, ...scaleUnambiguousSpacing()]
        }],
        /**
         * Flex Direction
         * @see https://tailwindcss.com/docs/flex-direction
         */
        "flex-direction": [{
          flex: ["row", "row-reverse", "col", "col-reverse"]
        }],
        /**
         * Flex Wrap
         * @see https://tailwindcss.com/docs/flex-wrap
         */
        "flex-wrap": [{
          flex: ["nowrap", "wrap", "wrap-reverse"]
        }],
        /**
         * Flex
         * @see https://tailwindcss.com/docs/flex
         */
        flex: [{
          flex: [isNumber, isFraction, "auto", "initial", "none", isArbitraryValue]
        }],
        /**
         * Flex Grow
         * @see https://tailwindcss.com/docs/flex-grow
         */
        grow: [{
          grow: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Flex Shrink
         * @see https://tailwindcss.com/docs/flex-shrink
         */
        shrink: [{
          shrink: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Order
         * @see https://tailwindcss.com/docs/order
         */
        order: [{
          order: [isInteger, "first", "last", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Grid Template Columns
         * @see https://tailwindcss.com/docs/grid-template-columns
         */
        "grid-cols": [{
          "grid-cols": scaleGridTemplateColsRows()
        }],
        /**
         * Grid Column Start / End
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-start-end": [{
          col: scaleGridColRowStartAndEnd()
        }],
        /**
         * Grid Column Start
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-start": [{
          "col-start": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Column End
         * @see https://tailwindcss.com/docs/grid-column
         */
        "col-end": [{
          "col-end": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Template Rows
         * @see https://tailwindcss.com/docs/grid-template-rows
         */
        "grid-rows": [{
          "grid-rows": scaleGridTemplateColsRows()
        }],
        /**
         * Grid Row Start / End
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-start-end": [{
          row: scaleGridColRowStartAndEnd()
        }],
        /**
         * Grid Row Start
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-start": [{
          "row-start": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Row End
         * @see https://tailwindcss.com/docs/grid-row
         */
        "row-end": [{
          "row-end": scaleGridColRowStartOrEnd()
        }],
        /**
         * Grid Auto Flow
         * @see https://tailwindcss.com/docs/grid-auto-flow
         */
        "grid-flow": [{
          "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
        }],
        /**
         * Grid Auto Columns
         * @see https://tailwindcss.com/docs/grid-auto-columns
         */
        "auto-cols": [{
          "auto-cols": scaleGridAutoColsRows()
        }],
        /**
         * Grid Auto Rows
         * @see https://tailwindcss.com/docs/grid-auto-rows
         */
        "auto-rows": [{
          "auto-rows": scaleGridAutoColsRows()
        }],
        /**
         * Gap
         * @see https://tailwindcss.com/docs/gap
         */
        gap: [{
          gap: scaleUnambiguousSpacing()
        }],
        /**
         * Gap X
         * @see https://tailwindcss.com/docs/gap
         */
        "gap-x": [{
          "gap-x": scaleUnambiguousSpacing()
        }],
        /**
         * Gap Y
         * @see https://tailwindcss.com/docs/gap
         */
        "gap-y": [{
          "gap-y": scaleUnambiguousSpacing()
        }],
        /**
         * Justify Content
         * @see https://tailwindcss.com/docs/justify-content
         */
        "justify-content": [{
          justify: [...scaleAlignPrimaryAxis(), "normal"]
        }],
        /**
         * Justify Items
         * @see https://tailwindcss.com/docs/justify-items
         */
        "justify-items": [{
          "justify-items": [...scaleAlignSecondaryAxis(), "normal"]
        }],
        /**
         * Justify Self
         * @see https://tailwindcss.com/docs/justify-self
         */
        "justify-self": [{
          "justify-self": ["auto", ...scaleAlignSecondaryAxis()]
        }],
        /**
         * Align Content
         * @see https://tailwindcss.com/docs/align-content
         */
        "align-content": [{
          content: ["normal", ...scaleAlignPrimaryAxis()]
        }],
        /**
         * Align Items
         * @see https://tailwindcss.com/docs/align-items
         */
        "align-items": [{
          items: [...scaleAlignSecondaryAxis(), {
            baseline: ["", "last"]
          }]
        }],
        /**
         * Align Self
         * @see https://tailwindcss.com/docs/align-self
         */
        "align-self": [{
          self: ["auto", ...scaleAlignSecondaryAxis(), {
            baseline: ["", "last"]
          }]
        }],
        /**
         * Place Content
         * @see https://tailwindcss.com/docs/place-content
         */
        "place-content": [{
          "place-content": scaleAlignPrimaryAxis()
        }],
        /**
         * Place Items
         * @see https://tailwindcss.com/docs/place-items
         */
        "place-items": [{
          "place-items": [...scaleAlignSecondaryAxis(), "baseline"]
        }],
        /**
         * Place Self
         * @see https://tailwindcss.com/docs/place-self
         */
        "place-self": [{
          "place-self": ["auto", ...scaleAlignSecondaryAxis()]
        }],
        // Spacing
        /**
         * Padding
         * @see https://tailwindcss.com/docs/padding
         */
        p: [{
          p: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline
         * @see https://tailwindcss.com/docs/padding
         */
        px: [{
          px: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block
         * @see https://tailwindcss.com/docs/padding
         */
        py: [{
          py: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline Start
         * @see https://tailwindcss.com/docs/padding
         */
        ps: [{
          ps: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Inline End
         * @see https://tailwindcss.com/docs/padding
         */
        pe: [{
          pe: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block Start
         * @see https://tailwindcss.com/docs/padding
         */
        pbs: [{
          pbs: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Block End
         * @see https://tailwindcss.com/docs/padding
         */
        pbe: [{
          pbe: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Top
         * @see https://tailwindcss.com/docs/padding
         */
        pt: [{
          pt: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Right
         * @see https://tailwindcss.com/docs/padding
         */
        pr: [{
          pr: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Bottom
         * @see https://tailwindcss.com/docs/padding
         */
        pb: [{
          pb: scaleUnambiguousSpacing()
        }],
        /**
         * Padding Left
         * @see https://tailwindcss.com/docs/padding
         */
        pl: [{
          pl: scaleUnambiguousSpacing()
        }],
        /**
         * Margin
         * @see https://tailwindcss.com/docs/margin
         */
        m: [{
          m: scaleMargin()
        }],
        /**
         * Margin Inline
         * @see https://tailwindcss.com/docs/margin
         */
        mx: [{
          mx: scaleMargin()
        }],
        /**
         * Margin Block
         * @see https://tailwindcss.com/docs/margin
         */
        my: [{
          my: scaleMargin()
        }],
        /**
         * Margin Inline Start
         * @see https://tailwindcss.com/docs/margin
         */
        ms: [{
          ms: scaleMargin()
        }],
        /**
         * Margin Inline End
         * @see https://tailwindcss.com/docs/margin
         */
        me: [{
          me: scaleMargin()
        }],
        /**
         * Margin Block Start
         * @see https://tailwindcss.com/docs/margin
         */
        mbs: [{
          mbs: scaleMargin()
        }],
        /**
         * Margin Block End
         * @see https://tailwindcss.com/docs/margin
         */
        mbe: [{
          mbe: scaleMargin()
        }],
        /**
         * Margin Top
         * @see https://tailwindcss.com/docs/margin
         */
        mt: [{
          mt: scaleMargin()
        }],
        /**
         * Margin Right
         * @see https://tailwindcss.com/docs/margin
         */
        mr: [{
          mr: scaleMargin()
        }],
        /**
         * Margin Bottom
         * @see https://tailwindcss.com/docs/margin
         */
        mb: [{
          mb: scaleMargin()
        }],
        /**
         * Margin Left
         * @see https://tailwindcss.com/docs/margin
         */
        ml: [{
          ml: scaleMargin()
        }],
        /**
         * Space Between X
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-x": [{
          "space-x": scaleUnambiguousSpacing()
        }],
        /**
         * Space Between X Reverse
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-x-reverse": ["space-x-reverse"],
        /**
         * Space Between Y
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-y": [{
          "space-y": scaleUnambiguousSpacing()
        }],
        /**
         * Space Between Y Reverse
         * @see https://tailwindcss.com/docs/margin#adding-space-between-children
         */
        "space-y-reverse": ["space-y-reverse"],
        // --------------
        // --- Sizing ---
        // --------------
        /**
         * Size
         * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
         */
        size: [{
          size: scaleSizing()
        }],
        /**
         * Inline Size
         * @see https://tailwindcss.com/docs/width
         */
        "inline-size": [{
          inline: ["auto", ...scaleSizingInline()]
        }],
        /**
         * Min-Inline Size
         * @see https://tailwindcss.com/docs/min-width
         */
        "min-inline-size": [{
          "min-inline": ["auto", ...scaleSizingInline()]
        }],
        /**
         * Max-Inline Size
         * @see https://tailwindcss.com/docs/max-width
         */
        "max-inline-size": [{
          "max-inline": ["none", ...scaleSizingInline()]
        }],
        /**
         * Block Size
         * @see https://tailwindcss.com/docs/height
         */
        "block-size": [{
          block: ["auto", ...scaleSizingBlock()]
        }],
        /**
         * Min-Block Size
         * @see https://tailwindcss.com/docs/min-height
         */
        "min-block-size": [{
          "min-block": ["auto", ...scaleSizingBlock()]
        }],
        /**
         * Max-Block Size
         * @see https://tailwindcss.com/docs/max-height
         */
        "max-block-size": [{
          "max-block": ["none", ...scaleSizingBlock()]
        }],
        /**
         * Width
         * @see https://tailwindcss.com/docs/width
         */
        w: [{
          w: [themeContainer, "screen", ...scaleSizing()]
        }],
        /**
         * Min-Width
         * @see https://tailwindcss.com/docs/min-width
         */
        "min-w": [{
          "min-w": [
            themeContainer,
            "screen",
            /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            "none",
            ...scaleSizing()
          ]
        }],
        /**
         * Max-Width
         * @see https://tailwindcss.com/docs/max-width
         */
        "max-w": [{
          "max-w": [
            themeContainer,
            "screen",
            "none",
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            "prose",
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            {
              screen: [themeBreakpoint]
            },
            ...scaleSizing()
          ]
        }],
        /**
         * Height
         * @see https://tailwindcss.com/docs/height
         */
        h: [{
          h: ["screen", "lh", ...scaleSizing()]
        }],
        /**
         * Min-Height
         * @see https://tailwindcss.com/docs/min-height
         */
        "min-h": [{
          "min-h": ["screen", "lh", "none", ...scaleSizing()]
        }],
        /**
         * Max-Height
         * @see https://tailwindcss.com/docs/max-height
         */
        "max-h": [{
          "max-h": ["screen", "lh", ...scaleSizing()]
        }],
        // ------------------
        // --- Typography ---
        // ------------------
        /**
         * Font Size
         * @see https://tailwindcss.com/docs/font-size
         */
        "font-size": [{
          text: ["base", themeText, isArbitraryVariableLength, isArbitraryLength]
        }],
        /**
         * Font Smoothing
         * @see https://tailwindcss.com/docs/font-smoothing
         */
        "font-smoothing": ["antialiased", "subpixel-antialiased"],
        /**
         * Font Style
         * @see https://tailwindcss.com/docs/font-style
         */
        "font-style": ["italic", "not-italic"],
        /**
         * Font Weight
         * @see https://tailwindcss.com/docs/font-weight
         */
        "font-weight": [{
          font: [themeFontWeight, isArbitraryVariableWeight, isArbitraryWeight]
        }],
        /**
         * Font Stretch
         * @see https://tailwindcss.com/docs/font-stretch
         */
        "font-stretch": [{
          "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", isPercent, isArbitraryValue]
        }],
        /**
         * Font Family
         * @see https://tailwindcss.com/docs/font-family
         */
        "font-family": [{
          font: [isArbitraryVariableFamilyName, isArbitraryFamilyName, themeFont]
        }],
        /**
         * Font Feature Settings
         * @see https://tailwindcss.com/docs/font-feature-settings
         */
        "font-features": [{
          "font-features": [isArbitraryValue]
        }],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-normal": ["normal-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-ordinal": ["ordinal"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-slashed-zero": ["slashed-zero"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-figure": ["lining-nums", "oldstyle-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-spacing": ["proportional-nums", "tabular-nums"],
        /**
         * Font Variant Numeric
         * @see https://tailwindcss.com/docs/font-variant-numeric
         */
        "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
        /**
         * Letter Spacing
         * @see https://tailwindcss.com/docs/letter-spacing
         */
        tracking: [{
          tracking: [themeTracking, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Line Clamp
         * @see https://tailwindcss.com/docs/line-clamp
         */
        "line-clamp": [{
          "line-clamp": [isNumber, "none", isArbitraryVariable, isArbitraryNumber]
        }],
        /**
         * Line Height
         * @see https://tailwindcss.com/docs/line-height
         */
        leading: [{
          leading: [
            /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
            themeLeading,
            ...scaleUnambiguousSpacing()
          ]
        }],
        /**
         * List Style Image
         * @see https://tailwindcss.com/docs/list-style-image
         */
        "list-image": [{
          "list-image": ["none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * List Style Position
         * @see https://tailwindcss.com/docs/list-style-position
         */
        "list-style-position": [{
          list: ["inside", "outside"]
        }],
        /**
         * List Style Type
         * @see https://tailwindcss.com/docs/list-style-type
         */
        "list-style-type": [{
          list: ["disc", "decimal", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Text Alignment
         * @see https://tailwindcss.com/docs/text-align
         */
        "text-alignment": [{
          text: ["left", "center", "right", "justify", "start", "end"]
        }],
        /**
         * Placeholder Color
         * @deprecated since Tailwind CSS v3.0.0
         * @see https://v3.tailwindcss.com/docs/placeholder-color
         */
        "placeholder-color": [{
          placeholder: scaleColor()
        }],
        /**
         * Text Color
         * @see https://tailwindcss.com/docs/text-color
         */
        "text-color": [{
          text: scaleColor()
        }],
        /**
         * Text Decoration
         * @see https://tailwindcss.com/docs/text-decoration
         */
        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
        /**
         * Text Decoration Style
         * @see https://tailwindcss.com/docs/text-decoration-style
         */
        "text-decoration-style": [{
          decoration: [...scaleLineStyle(), "wavy"]
        }],
        /**
         * Text Decoration Thickness
         * @see https://tailwindcss.com/docs/text-decoration-thickness
         */
        "text-decoration-thickness": [{
          decoration: [isNumber, "from-font", "auto", isArbitraryVariable, isArbitraryLength]
        }],
        /**
         * Text Decoration Color
         * @see https://tailwindcss.com/docs/text-decoration-color
         */
        "text-decoration-color": [{
          decoration: scaleColor()
        }],
        /**
         * Text Underline Offset
         * @see https://tailwindcss.com/docs/text-underline-offset
         */
        "underline-offset": [{
          "underline-offset": [isNumber, "auto", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Text Transform
         * @see https://tailwindcss.com/docs/text-transform
         */
        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
        /**
         * Text Overflow
         * @see https://tailwindcss.com/docs/text-overflow
         */
        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
        /**
         * Text Wrap
         * @see https://tailwindcss.com/docs/text-wrap
         */
        "text-wrap": [{
          text: ["wrap", "nowrap", "balance", "pretty"]
        }],
        /**
         * Text Indent
         * @see https://tailwindcss.com/docs/text-indent
         */
        indent: [{
          indent: scaleUnambiguousSpacing()
        }],
        /**
         * Vertical Alignment
         * @see https://tailwindcss.com/docs/vertical-align
         */
        "vertical-align": [{
          align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Whitespace
         * @see https://tailwindcss.com/docs/whitespace
         */
        whitespace: [{
          whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
        }],
        /**
         * Word Break
         * @see https://tailwindcss.com/docs/word-break
         */
        break: [{
          break: ["normal", "words", "all", "keep"]
        }],
        /**
         * Overflow Wrap
         * @see https://tailwindcss.com/docs/overflow-wrap
         */
        wrap: [{
          wrap: ["break-word", "anywhere", "normal"]
        }],
        /**
         * Hyphens
         * @see https://tailwindcss.com/docs/hyphens
         */
        hyphens: [{
          hyphens: ["none", "manual", "auto"]
        }],
        /**
         * Content
         * @see https://tailwindcss.com/docs/content
         */
        content: [{
          content: ["none", isArbitraryVariable, isArbitraryValue]
        }],
        // -------------------
        // --- Backgrounds ---
        // -------------------
        /**
         * Background Attachment
         * @see https://tailwindcss.com/docs/background-attachment
         */
        "bg-attachment": [{
          bg: ["fixed", "local", "scroll"]
        }],
        /**
         * Background Clip
         * @see https://tailwindcss.com/docs/background-clip
         */
        "bg-clip": [{
          "bg-clip": ["border", "padding", "content", "text"]
        }],
        /**
         * Background Origin
         * @see https://tailwindcss.com/docs/background-origin
         */
        "bg-origin": [{
          "bg-origin": ["border", "padding", "content"]
        }],
        /**
         * Background Position
         * @see https://tailwindcss.com/docs/background-position
         */
        "bg-position": [{
          bg: scaleBgPosition()
        }],
        /**
         * Background Repeat
         * @see https://tailwindcss.com/docs/background-repeat
         */
        "bg-repeat": [{
          bg: scaleBgRepeat()
        }],
        /**
         * Background Size
         * @see https://tailwindcss.com/docs/background-size
         */
        "bg-size": [{
          bg: scaleBgSize()
        }],
        /**
         * Background Image
         * @see https://tailwindcss.com/docs/background-image
         */
        "bg-image": [{
          bg: ["none", {
            linear: [{
              to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
            }, isInteger, isArbitraryVariable, isArbitraryValue],
            radial: ["", isArbitraryVariable, isArbitraryValue],
            conic: [isInteger, isArbitraryVariable, isArbitraryValue]
          }, isArbitraryVariableImage, isArbitraryImage]
        }],
        /**
         * Background Color
         * @see https://tailwindcss.com/docs/background-color
         */
        "bg-color": [{
          bg: scaleColor()
        }],
        /**
         * Gradient Color Stops From Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-from-pos": [{
          from: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops Via Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-via-pos": [{
          via: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops To Position
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-to-pos": [{
          to: scaleGradientStopPosition()
        }],
        /**
         * Gradient Color Stops From
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-from": [{
          from: scaleColor()
        }],
        /**
         * Gradient Color Stops Via
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-via": [{
          via: scaleColor()
        }],
        /**
         * Gradient Color Stops To
         * @see https://tailwindcss.com/docs/gradient-color-stops
         */
        "gradient-to": [{
          to: scaleColor()
        }],
        // ---------------
        // --- Borders ---
        // ---------------
        /**
         * Border Radius
         * @see https://tailwindcss.com/docs/border-radius
         */
        rounded: [{
          rounded: scaleRadius()
        }],
        /**
         * Border Radius Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-s": [{
          "rounded-s": scaleRadius()
        }],
        /**
         * Border Radius End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-e": [{
          "rounded-e": scaleRadius()
        }],
        /**
         * Border Radius Top
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-t": [{
          "rounded-t": scaleRadius()
        }],
        /**
         * Border Radius Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-r": [{
          "rounded-r": scaleRadius()
        }],
        /**
         * Border Radius Bottom
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-b": [{
          "rounded-b": scaleRadius()
        }],
        /**
         * Border Radius Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-l": [{
          "rounded-l": scaleRadius()
        }],
        /**
         * Border Radius Start Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-ss": [{
          "rounded-ss": scaleRadius()
        }],
        /**
         * Border Radius Start End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-se": [{
          "rounded-se": scaleRadius()
        }],
        /**
         * Border Radius End End
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-ee": [{
          "rounded-ee": scaleRadius()
        }],
        /**
         * Border Radius End Start
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-es": [{
          "rounded-es": scaleRadius()
        }],
        /**
         * Border Radius Top Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-tl": [{
          "rounded-tl": scaleRadius()
        }],
        /**
         * Border Radius Top Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-tr": [{
          "rounded-tr": scaleRadius()
        }],
        /**
         * Border Radius Bottom Right
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-br": [{
          "rounded-br": scaleRadius()
        }],
        /**
         * Border Radius Bottom Left
         * @see https://tailwindcss.com/docs/border-radius
         */
        "rounded-bl": [{
          "rounded-bl": scaleRadius()
        }],
        /**
         * Border Width
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w": [{
          border: scaleBorderWidth()
        }],
        /**
         * Border Width Inline
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-x": [{
          "border-x": scaleBorderWidth()
        }],
        /**
         * Border Width Block
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-y": [{
          "border-y": scaleBorderWidth()
        }],
        /**
         * Border Width Inline Start
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-s": [{
          "border-s": scaleBorderWidth()
        }],
        /**
         * Border Width Inline End
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-e": [{
          "border-e": scaleBorderWidth()
        }],
        /**
         * Border Width Block Start
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-bs": [{
          "border-bs": scaleBorderWidth()
        }],
        /**
         * Border Width Block End
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-be": [{
          "border-be": scaleBorderWidth()
        }],
        /**
         * Border Width Top
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-t": [{
          "border-t": scaleBorderWidth()
        }],
        /**
         * Border Width Right
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-r": [{
          "border-r": scaleBorderWidth()
        }],
        /**
         * Border Width Bottom
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-b": [{
          "border-b": scaleBorderWidth()
        }],
        /**
         * Border Width Left
         * @see https://tailwindcss.com/docs/border-width
         */
        "border-w-l": [{
          "border-l": scaleBorderWidth()
        }],
        /**
         * Divide Width X
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-x": [{
          "divide-x": scaleBorderWidth()
        }],
        /**
         * Divide Width X Reverse
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-x-reverse": ["divide-x-reverse"],
        /**
         * Divide Width Y
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-y": [{
          "divide-y": scaleBorderWidth()
        }],
        /**
         * Divide Width Y Reverse
         * @see https://tailwindcss.com/docs/border-width#between-children
         */
        "divide-y-reverse": ["divide-y-reverse"],
        /**
         * Border Style
         * @see https://tailwindcss.com/docs/border-style
         */
        "border-style": [{
          border: [...scaleLineStyle(), "hidden", "none"]
        }],
        /**
         * Divide Style
         * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
         */
        "divide-style": [{
          divide: [...scaleLineStyle(), "hidden", "none"]
        }],
        /**
         * Border Color
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color": [{
          border: scaleColor()
        }],
        /**
         * Border Color Inline
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-x": [{
          "border-x": scaleColor()
        }],
        /**
         * Border Color Block
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-y": [{
          "border-y": scaleColor()
        }],
        /**
         * Border Color Inline Start
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-s": [{
          "border-s": scaleColor()
        }],
        /**
         * Border Color Inline End
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-e": [{
          "border-e": scaleColor()
        }],
        /**
         * Border Color Block Start
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-bs": [{
          "border-bs": scaleColor()
        }],
        /**
         * Border Color Block End
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-be": [{
          "border-be": scaleColor()
        }],
        /**
         * Border Color Top
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-t": [{
          "border-t": scaleColor()
        }],
        /**
         * Border Color Right
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-r": [{
          "border-r": scaleColor()
        }],
        /**
         * Border Color Bottom
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-b": [{
          "border-b": scaleColor()
        }],
        /**
         * Border Color Left
         * @see https://tailwindcss.com/docs/border-color
         */
        "border-color-l": [{
          "border-l": scaleColor()
        }],
        /**
         * Divide Color
         * @see https://tailwindcss.com/docs/divide-color
         */
        "divide-color": [{
          divide: scaleColor()
        }],
        /**
         * Outline Style
         * @see https://tailwindcss.com/docs/outline-style
         */
        "outline-style": [{
          outline: [...scaleLineStyle(), "none", "hidden"]
        }],
        /**
         * Outline Offset
         * @see https://tailwindcss.com/docs/outline-offset
         */
        "outline-offset": [{
          "outline-offset": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Outline Width
         * @see https://tailwindcss.com/docs/outline-width
         */
        "outline-w": [{
          outline: ["", isNumber, isArbitraryVariableLength, isArbitraryLength]
        }],
        /**
         * Outline Color
         * @see https://tailwindcss.com/docs/outline-color
         */
        "outline-color": [{
          outline: scaleColor()
        }],
        // ---------------
        // --- Effects ---
        // ---------------
        /**
         * Box Shadow
         * @see https://tailwindcss.com/docs/box-shadow
         */
        shadow: [{
          shadow: [
            // Deprecated since Tailwind CSS v4.0.0
            "",
            "none",
            themeShadow,
            isArbitraryVariableShadow,
            isArbitraryShadow
          ]
        }],
        /**
         * Box Shadow Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
         */
        "shadow-color": [{
          shadow: scaleColor()
        }],
        /**
         * Inset Box Shadow
         * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
         */
        "inset-shadow": [{
          "inset-shadow": ["none", themeInsetShadow, isArbitraryVariableShadow, isArbitraryShadow]
        }],
        /**
         * Inset Box Shadow Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
         */
        "inset-shadow-color": [{
          "inset-shadow": scaleColor()
        }],
        /**
         * Ring Width
         * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
         */
        "ring-w": [{
          ring: scaleBorderWidth()
        }],
        /**
         * Ring Width Inset
         * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-w-inset": ["ring-inset"],
        /**
         * Ring Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
         */
        "ring-color": [{
          ring: scaleColor()
        }],
        /**
         * Ring Offset Width
         * @see https://v3.tailwindcss.com/docs/ring-offset-width
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-offset-w": [{
          "ring-offset": [isNumber, isArbitraryLength]
        }],
        /**
         * Ring Offset Color
         * @see https://v3.tailwindcss.com/docs/ring-offset-color
         * @deprecated since Tailwind CSS v4.0.0
         * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
         */
        "ring-offset-color": [{
          "ring-offset": scaleColor()
        }],
        /**
         * Inset Ring Width
         * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
         */
        "inset-ring-w": [{
          "inset-ring": scaleBorderWidth()
        }],
        /**
         * Inset Ring Color
         * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
         */
        "inset-ring-color": [{
          "inset-ring": scaleColor()
        }],
        /**
         * Text Shadow
         * @see https://tailwindcss.com/docs/text-shadow
         */
        "text-shadow": [{
          "text-shadow": ["none", themeTextShadow, isArbitraryVariableShadow, isArbitraryShadow]
        }],
        /**
         * Text Shadow Color
         * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
         */
        "text-shadow-color": [{
          "text-shadow": scaleColor()
        }],
        /**
         * Opacity
         * @see https://tailwindcss.com/docs/opacity
         */
        opacity: [{
          opacity: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Mix Blend Mode
         * @see https://tailwindcss.com/docs/mix-blend-mode
         */
        "mix-blend": [{
          "mix-blend": [...scaleBlendMode(), "plus-darker", "plus-lighter"]
        }],
        /**
         * Background Blend Mode
         * @see https://tailwindcss.com/docs/background-blend-mode
         */
        "bg-blend": [{
          "bg-blend": scaleBlendMode()
        }],
        /**
         * Mask Clip
         * @see https://tailwindcss.com/docs/mask-clip
         */
        "mask-clip": [{
          "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
        }, "mask-no-clip"],
        /**
         * Mask Composite
         * @see https://tailwindcss.com/docs/mask-composite
         */
        "mask-composite": [{
          mask: ["add", "subtract", "intersect", "exclude"]
        }],
        /**
         * Mask Image
         * @see https://tailwindcss.com/docs/mask-image
         */
        "mask-image-linear-pos": [{
          "mask-linear": [isNumber]
        }],
        "mask-image-linear-from-pos": [{
          "mask-linear-from": scaleMaskImagePosition()
        }],
        "mask-image-linear-to-pos": [{
          "mask-linear-to": scaleMaskImagePosition()
        }],
        "mask-image-linear-from-color": [{
          "mask-linear-from": scaleColor()
        }],
        "mask-image-linear-to-color": [{
          "mask-linear-to": scaleColor()
        }],
        "mask-image-t-from-pos": [{
          "mask-t-from": scaleMaskImagePosition()
        }],
        "mask-image-t-to-pos": [{
          "mask-t-to": scaleMaskImagePosition()
        }],
        "mask-image-t-from-color": [{
          "mask-t-from": scaleColor()
        }],
        "mask-image-t-to-color": [{
          "mask-t-to": scaleColor()
        }],
        "mask-image-r-from-pos": [{
          "mask-r-from": scaleMaskImagePosition()
        }],
        "mask-image-r-to-pos": [{
          "mask-r-to": scaleMaskImagePosition()
        }],
        "mask-image-r-from-color": [{
          "mask-r-from": scaleColor()
        }],
        "mask-image-r-to-color": [{
          "mask-r-to": scaleColor()
        }],
        "mask-image-b-from-pos": [{
          "mask-b-from": scaleMaskImagePosition()
        }],
        "mask-image-b-to-pos": [{
          "mask-b-to": scaleMaskImagePosition()
        }],
        "mask-image-b-from-color": [{
          "mask-b-from": scaleColor()
        }],
        "mask-image-b-to-color": [{
          "mask-b-to": scaleColor()
        }],
        "mask-image-l-from-pos": [{
          "mask-l-from": scaleMaskImagePosition()
        }],
        "mask-image-l-to-pos": [{
          "mask-l-to": scaleMaskImagePosition()
        }],
        "mask-image-l-from-color": [{
          "mask-l-from": scaleColor()
        }],
        "mask-image-l-to-color": [{
          "mask-l-to": scaleColor()
        }],
        "mask-image-x-from-pos": [{
          "mask-x-from": scaleMaskImagePosition()
        }],
        "mask-image-x-to-pos": [{
          "mask-x-to": scaleMaskImagePosition()
        }],
        "mask-image-x-from-color": [{
          "mask-x-from": scaleColor()
        }],
        "mask-image-x-to-color": [{
          "mask-x-to": scaleColor()
        }],
        "mask-image-y-from-pos": [{
          "mask-y-from": scaleMaskImagePosition()
        }],
        "mask-image-y-to-pos": [{
          "mask-y-to": scaleMaskImagePosition()
        }],
        "mask-image-y-from-color": [{
          "mask-y-from": scaleColor()
        }],
        "mask-image-y-to-color": [{
          "mask-y-to": scaleColor()
        }],
        "mask-image-radial": [{
          "mask-radial": [isArbitraryVariable, isArbitraryValue]
        }],
        "mask-image-radial-from-pos": [{
          "mask-radial-from": scaleMaskImagePosition()
        }],
        "mask-image-radial-to-pos": [{
          "mask-radial-to": scaleMaskImagePosition()
        }],
        "mask-image-radial-from-color": [{
          "mask-radial-from": scaleColor()
        }],
        "mask-image-radial-to-color": [{
          "mask-radial-to": scaleColor()
        }],
        "mask-image-radial-shape": [{
          "mask-radial": ["circle", "ellipse"]
        }],
        "mask-image-radial-size": [{
          "mask-radial": [{
            closest: ["side", "corner"],
            farthest: ["side", "corner"]
          }]
        }],
        "mask-image-radial-pos": [{
          "mask-radial-at": scalePosition()
        }],
        "mask-image-conic-pos": [{
          "mask-conic": [isNumber]
        }],
        "mask-image-conic-from-pos": [{
          "mask-conic-from": scaleMaskImagePosition()
        }],
        "mask-image-conic-to-pos": [{
          "mask-conic-to": scaleMaskImagePosition()
        }],
        "mask-image-conic-from-color": [{
          "mask-conic-from": scaleColor()
        }],
        "mask-image-conic-to-color": [{
          "mask-conic-to": scaleColor()
        }],
        /**
         * Mask Mode
         * @see https://tailwindcss.com/docs/mask-mode
         */
        "mask-mode": [{
          mask: ["alpha", "luminance", "match"]
        }],
        /**
         * Mask Origin
         * @see https://tailwindcss.com/docs/mask-origin
         */
        "mask-origin": [{
          "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
        }],
        /**
         * Mask Position
         * @see https://tailwindcss.com/docs/mask-position
         */
        "mask-position": [{
          mask: scaleBgPosition()
        }],
        /**
         * Mask Repeat
         * @see https://tailwindcss.com/docs/mask-repeat
         */
        "mask-repeat": [{
          mask: scaleBgRepeat()
        }],
        /**
         * Mask Size
         * @see https://tailwindcss.com/docs/mask-size
         */
        "mask-size": [{
          mask: scaleBgSize()
        }],
        /**
         * Mask Type
         * @see https://tailwindcss.com/docs/mask-type
         */
        "mask-type": [{
          "mask-type": ["alpha", "luminance"]
        }],
        /**
         * Mask Image
         * @see https://tailwindcss.com/docs/mask-image
         */
        "mask-image": [{
          mask: ["none", isArbitraryVariable, isArbitraryValue]
        }],
        // ---------------
        // --- Filters ---
        // ---------------
        /**
         * Filter
         * @see https://tailwindcss.com/docs/filter
         */
        filter: [{
          filter: [
            // Deprecated since Tailwind CSS v3.0.0
            "",
            "none",
            isArbitraryVariable,
            isArbitraryValue
          ]
        }],
        /**
         * Blur
         * @see https://tailwindcss.com/docs/blur
         */
        blur: [{
          blur: scaleBlur()
        }],
        /**
         * Brightness
         * @see https://tailwindcss.com/docs/brightness
         */
        brightness: [{
          brightness: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Contrast
         * @see https://tailwindcss.com/docs/contrast
         */
        contrast: [{
          contrast: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Drop Shadow
         * @see https://tailwindcss.com/docs/drop-shadow
         */
        "drop-shadow": [{
          "drop-shadow": [
            // Deprecated since Tailwind CSS v4.0.0
            "",
            "none",
            themeDropShadow,
            isArbitraryVariableShadow,
            isArbitraryShadow
          ]
        }],
        /**
         * Drop Shadow Color
         * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
         */
        "drop-shadow-color": [{
          "drop-shadow": scaleColor()
        }],
        /**
         * Grayscale
         * @see https://tailwindcss.com/docs/grayscale
         */
        grayscale: [{
          grayscale: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Hue Rotate
         * @see https://tailwindcss.com/docs/hue-rotate
         */
        "hue-rotate": [{
          "hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Invert
         * @see https://tailwindcss.com/docs/invert
         */
        invert: [{
          invert: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Saturate
         * @see https://tailwindcss.com/docs/saturate
         */
        saturate: [{
          saturate: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Sepia
         * @see https://tailwindcss.com/docs/sepia
         */
        sepia: [{
          sepia: ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Filter
         * @see https://tailwindcss.com/docs/backdrop-filter
         */
        "backdrop-filter": [{
          "backdrop-filter": [
            // Deprecated since Tailwind CSS v3.0.0
            "",
            "none",
            isArbitraryVariable,
            isArbitraryValue
          ]
        }],
        /**
         * Backdrop Blur
         * @see https://tailwindcss.com/docs/backdrop-blur
         */
        "backdrop-blur": [{
          "backdrop-blur": scaleBlur()
        }],
        /**
         * Backdrop Brightness
         * @see https://tailwindcss.com/docs/backdrop-brightness
         */
        "backdrop-brightness": [{
          "backdrop-brightness": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Contrast
         * @see https://tailwindcss.com/docs/backdrop-contrast
         */
        "backdrop-contrast": [{
          "backdrop-contrast": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Grayscale
         * @see https://tailwindcss.com/docs/backdrop-grayscale
         */
        "backdrop-grayscale": [{
          "backdrop-grayscale": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Hue Rotate
         * @see https://tailwindcss.com/docs/backdrop-hue-rotate
         */
        "backdrop-hue-rotate": [{
          "backdrop-hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Invert
         * @see https://tailwindcss.com/docs/backdrop-invert
         */
        "backdrop-invert": [{
          "backdrop-invert": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Opacity
         * @see https://tailwindcss.com/docs/backdrop-opacity
         */
        "backdrop-opacity": [{
          "backdrop-opacity": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Saturate
         * @see https://tailwindcss.com/docs/backdrop-saturate
         */
        "backdrop-saturate": [{
          "backdrop-saturate": [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Backdrop Sepia
         * @see https://tailwindcss.com/docs/backdrop-sepia
         */
        "backdrop-sepia": [{
          "backdrop-sepia": ["", isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        // --------------
        // --- Tables ---
        // --------------
        /**
         * Border Collapse
         * @see https://tailwindcss.com/docs/border-collapse
         */
        "border-collapse": [{
          border: ["collapse", "separate"]
        }],
        /**
         * Border Spacing
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing": [{
          "border-spacing": scaleUnambiguousSpacing()
        }],
        /**
         * Border Spacing X
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing-x": [{
          "border-spacing-x": scaleUnambiguousSpacing()
        }],
        /**
         * Border Spacing Y
         * @see https://tailwindcss.com/docs/border-spacing
         */
        "border-spacing-y": [{
          "border-spacing-y": scaleUnambiguousSpacing()
        }],
        /**
         * Table Layout
         * @see https://tailwindcss.com/docs/table-layout
         */
        "table-layout": [{
          table: ["auto", "fixed"]
        }],
        /**
         * Caption Side
         * @see https://tailwindcss.com/docs/caption-side
         */
        caption: [{
          caption: ["top", "bottom"]
        }],
        // ---------------------------------
        // --- Transitions and Animation ---
        // ---------------------------------
        /**
         * Transition Property
         * @see https://tailwindcss.com/docs/transition-property
         */
        transition: [{
          transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Behavior
         * @see https://tailwindcss.com/docs/transition-behavior
         */
        "transition-behavior": [{
          transition: ["normal", "discrete"]
        }],
        /**
         * Transition Duration
         * @see https://tailwindcss.com/docs/transition-duration
         */
        duration: [{
          duration: [isNumber, "initial", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Timing Function
         * @see https://tailwindcss.com/docs/transition-timing-function
         */
        ease: [{
          ease: ["linear", "initial", themeEase, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Transition Delay
         * @see https://tailwindcss.com/docs/transition-delay
         */
        delay: [{
          delay: [isNumber, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Animation
         * @see https://tailwindcss.com/docs/animation
         */
        animate: [{
          animate: ["none", themeAnimate, isArbitraryVariable, isArbitraryValue]
        }],
        // ------------------
        // --- Transforms ---
        // ------------------
        /**
         * Backface Visibility
         * @see https://tailwindcss.com/docs/backface-visibility
         */
        backface: [{
          backface: ["hidden", "visible"]
        }],
        /**
         * Perspective
         * @see https://tailwindcss.com/docs/perspective
         */
        perspective: [{
          perspective: [themePerspective, isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Perspective Origin
         * @see https://tailwindcss.com/docs/perspective-origin
         */
        "perspective-origin": [{
          "perspective-origin": scalePositionWithArbitrary()
        }],
        /**
         * Rotate
         * @see https://tailwindcss.com/docs/rotate
         */
        rotate: [{
          rotate: scaleRotate()
        }],
        /**
         * Rotate X
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-x": [{
          "rotate-x": scaleRotate()
        }],
        /**
         * Rotate Y
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-y": [{
          "rotate-y": scaleRotate()
        }],
        /**
         * Rotate Z
         * @see https://tailwindcss.com/docs/rotate
         */
        "rotate-z": [{
          "rotate-z": scaleRotate()
        }],
        /**
         * Scale
         * @see https://tailwindcss.com/docs/scale
         */
        scale: [{
          scale: scaleScale()
        }],
        /**
         * Scale X
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-x": [{
          "scale-x": scaleScale()
        }],
        /**
         * Scale Y
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-y": [{
          "scale-y": scaleScale()
        }],
        /**
         * Scale Z
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-z": [{
          "scale-z": scaleScale()
        }],
        /**
         * Scale 3D
         * @see https://tailwindcss.com/docs/scale
         */
        "scale-3d": ["scale-3d"],
        /**
         * Skew
         * @see https://tailwindcss.com/docs/skew
         */
        skew: [{
          skew: scaleSkew()
        }],
        /**
         * Skew X
         * @see https://tailwindcss.com/docs/skew
         */
        "skew-x": [{
          "skew-x": scaleSkew()
        }],
        /**
         * Skew Y
         * @see https://tailwindcss.com/docs/skew
         */
        "skew-y": [{
          "skew-y": scaleSkew()
        }],
        /**
         * Transform
         * @see https://tailwindcss.com/docs/transform
         */
        transform: [{
          transform: [isArbitraryVariable, isArbitraryValue, "", "none", "gpu", "cpu"]
        }],
        /**
         * Transform Origin
         * @see https://tailwindcss.com/docs/transform-origin
         */
        "transform-origin": [{
          origin: scalePositionWithArbitrary()
        }],
        /**
         * Transform Style
         * @see https://tailwindcss.com/docs/transform-style
         */
        "transform-style": [{
          transform: ["3d", "flat"]
        }],
        /**
         * Translate
         * @see https://tailwindcss.com/docs/translate
         */
        translate: [{
          translate: scaleTranslate()
        }],
        /**
         * Translate X
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-x": [{
          "translate-x": scaleTranslate()
        }],
        /**
         * Translate Y
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-y": [{
          "translate-y": scaleTranslate()
        }],
        /**
         * Translate Z
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-z": [{
          "translate-z": scaleTranslate()
        }],
        /**
         * Translate None
         * @see https://tailwindcss.com/docs/translate
         */
        "translate-none": ["translate-none"],
        // ---------------------
        // --- Interactivity ---
        // ---------------------
        /**
         * Accent Color
         * @see https://tailwindcss.com/docs/accent-color
         */
        accent: [{
          accent: scaleColor()
        }],
        /**
         * Appearance
         * @see https://tailwindcss.com/docs/appearance
         */
        appearance: [{
          appearance: ["none", "auto"]
        }],
        /**
         * Caret Color
         * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
         */
        "caret-color": [{
          caret: scaleColor()
        }],
        /**
         * Color Scheme
         * @see https://tailwindcss.com/docs/color-scheme
         */
        "color-scheme": [{
          scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
        }],
        /**
         * Cursor
         * @see https://tailwindcss.com/docs/cursor
         */
        cursor: [{
          cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryVariable, isArbitraryValue]
        }],
        /**
         * Field Sizing
         * @see https://tailwindcss.com/docs/field-sizing
         */
        "field-sizing": [{
          "field-sizing": ["fixed", "content"]
        }],
        /**
         * Pointer Events
         * @see https://tailwindcss.com/docs/pointer-events
         */
        "pointer-events": [{
          "pointer-events": ["auto", "none"]
        }],
        /**
         * Resize
         * @see https://tailwindcss.com/docs/resize
         */
        resize: [{
          resize: ["none", "", "y", "x"]
        }],
        /**
         * Scroll Behavior
         * @see https://tailwindcss.com/docs/scroll-behavior
         */
        "scroll-behavior": [{
          scroll: ["auto", "smooth"]
        }],
        /**
         * Scroll Margin
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-m": [{
          "scroll-m": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mx": [{
          "scroll-mx": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-my": [{
          "scroll-my": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline Start
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-ms": [{
          "scroll-ms": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Inline End
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-me": [{
          "scroll-me": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block Start
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mbs": [{
          "scroll-mbs": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Block End
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mbe": [{
          "scroll-mbe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Top
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mt": [{
          "scroll-mt": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Right
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mr": [{
          "scroll-mr": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Bottom
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-mb": [{
          "scroll-mb": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Margin Left
         * @see https://tailwindcss.com/docs/scroll-margin
         */
        "scroll-ml": [{
          "scroll-ml": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-p": [{
          "scroll-p": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-px": [{
          "scroll-px": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-py": [{
          "scroll-py": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline Start
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-ps": [{
          "scroll-ps": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Inline End
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pe": [{
          "scroll-pe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block Start
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pbs": [{
          "scroll-pbs": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Block End
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pbe": [{
          "scroll-pbe": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Top
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pt": [{
          "scroll-pt": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Right
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pr": [{
          "scroll-pr": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Bottom
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pb": [{
          "scroll-pb": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Padding Left
         * @see https://tailwindcss.com/docs/scroll-padding
         */
        "scroll-pl": [{
          "scroll-pl": scaleUnambiguousSpacing()
        }],
        /**
         * Scroll Snap Align
         * @see https://tailwindcss.com/docs/scroll-snap-align
         */
        "snap-align": [{
          snap: ["start", "end", "center", "align-none"]
        }],
        /**
         * Scroll Snap Stop
         * @see https://tailwindcss.com/docs/scroll-snap-stop
         */
        "snap-stop": [{
          snap: ["normal", "always"]
        }],
        /**
         * Scroll Snap Type
         * @see https://tailwindcss.com/docs/scroll-snap-type
         */
        "snap-type": [{
          snap: ["none", "x", "y", "both"]
        }],
        /**
         * Scroll Snap Type Strictness
         * @see https://tailwindcss.com/docs/scroll-snap-type
         */
        "snap-strictness": [{
          snap: ["mandatory", "proximity"]
        }],
        /**
         * Touch Action
         * @see https://tailwindcss.com/docs/touch-action
         */
        touch: [{
          touch: ["auto", "none", "manipulation"]
        }],
        /**
         * Touch Action X
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-x": [{
          "touch-pan": ["x", "left", "right"]
        }],
        /**
         * Touch Action Y
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-y": [{
          "touch-pan": ["y", "up", "down"]
        }],
        /**
         * Touch Action Pinch Zoom
         * @see https://tailwindcss.com/docs/touch-action
         */
        "touch-pz": ["touch-pinch-zoom"],
        /**
         * User Select
         * @see https://tailwindcss.com/docs/user-select
         */
        select: [{
          select: ["none", "text", "all", "auto"]
        }],
        /**
         * Will Change
         * @see https://tailwindcss.com/docs/will-change
         */
        "will-change": [{
          "will-change": ["auto", "scroll", "contents", "transform", isArbitraryVariable, isArbitraryValue]
        }],
        // -----------
        // --- SVG ---
        // -----------
        /**
         * Fill
         * @see https://tailwindcss.com/docs/fill
         */
        fill: [{
          fill: ["none", ...scaleColor()]
        }],
        /**
         * Stroke Width
         * @see https://tailwindcss.com/docs/stroke-width
         */
        "stroke-w": [{
          stroke: [isNumber, isArbitraryVariableLength, isArbitraryLength, isArbitraryNumber]
        }],
        /**
         * Stroke
         * @see https://tailwindcss.com/docs/stroke
         */
        stroke: [{
          stroke: ["none", ...scaleColor()]
        }],
        // ---------------------
        // --- Accessibility ---
        // ---------------------
        /**
         * Forced Color Adjust
         * @see https://tailwindcss.com/docs/forced-color-adjust
         */
        "forced-color-adjust": [{
          "forced-color-adjust": ["auto", "none"]
        }]
      },
      conflictingClassGroups: {
        overflow: ["overflow-x", "overflow-y"],
        overscroll: ["overscroll-x", "overscroll-y"],
        inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
        "inset-x": ["right", "left"],
        "inset-y": ["top", "bottom"],
        flex: ["basis", "grow", "shrink"],
        gap: ["gap-x", "gap-y"],
        p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
        px: ["pr", "pl"],
        py: ["pt", "pb"],
        m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
        mx: ["mr", "ml"],
        my: ["mt", "mb"],
        size: ["w", "h"],
        "font-size": ["leading"],
        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
        "fvn-ordinal": ["fvn-normal"],
        "fvn-slashed-zero": ["fvn-normal"],
        "fvn-figure": ["fvn-normal"],
        "fvn-spacing": ["fvn-normal"],
        "fvn-fraction": ["fvn-normal"],
        "line-clamp": ["display", "overflow"],
        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
        "rounded-s": ["rounded-ss", "rounded-es"],
        "rounded-e": ["rounded-se", "rounded-ee"],
        "rounded-t": ["rounded-tl", "rounded-tr"],
        "rounded-r": ["rounded-tr", "rounded-br"],
        "rounded-b": ["rounded-br", "rounded-bl"],
        "rounded-l": ["rounded-tl", "rounded-bl"],
        "border-spacing": ["border-spacing-x", "border-spacing-y"],
        "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
        "border-w-x": ["border-w-r", "border-w-l"],
        "border-w-y": ["border-w-t", "border-w-b"],
        "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
        "border-color-x": ["border-color-r", "border-color-l"],
        "border-color-y": ["border-color-t", "border-color-b"],
        translate: ["translate-x", "translate-y", "translate-none"],
        "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
        "scroll-mx": ["scroll-mr", "scroll-ml"],
        "scroll-my": ["scroll-mt", "scroll-mb"],
        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
        "scroll-px": ["scroll-pr", "scroll-pl"],
        "scroll-py": ["scroll-pt", "scroll-pb"],
        touch: ["touch-x", "touch-y", "touch-pz"],
        "touch-x": ["touch"],
        "touch-y": ["touch"],
        "touch-pz": ["touch"]
      },
      conflictingClassGroupModifiers: {
        "font-size": ["leading"]
      },
      orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
    };
  };
  var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

  // src/lib/utils.ts
  function cn(...inputs) {
    return twMerge(clsx(inputs));
  }

  // src/components/ui/avatar.tsx
  var import_jsx_runtime2 = __toESM(require_react_shim(), 1);
  function Avatar({
    className,
    size: size4 = "default",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      index_parts_exports.Root,
      {
        "data-slot": "avatar",
        "data-size": size4,
        className: cn(
          "group/avatar relative flex size-8 shrink-0 rounded-full select-none after:absolute after:inset-0 after:rounded-full after:border after:border-border after:mix-blend-darken data-[size=lg]:size-10 data-[size=sm]:size-6 dark:after:mix-blend-lighten",
          className
        ),
        ...props
      }
    );
  }
  function AvatarImage3({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      index_parts_exports.Image,
      {
        "data-slot": "avatar-image",
        className: cn(
          "aspect-square size-full rounded-full object-cover",
          className
        ),
        ...props
      }
    );
  }
  function AvatarFallback3({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      index_parts_exports.Fallback,
      {
        "data-slot": "avatar-fallback",
        className: cn(
          "flex size-full items-center justify-center rounded-full bg-muted text-sm text-muted-foreground group-data-[size=sm]/avatar:text-xs",
          className
        ),
        ...props
      }
    );
  }
  function AvatarBadge({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "span",
      {
        "data-slot": "avatar-badge",
        className: cn(
          "absolute right-0 bottom-0 z-10 inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground bg-blend-color ring-2 ring-background select-none",
          "group-data-[size=sm]/avatar:size-2 group-data-[size=sm]/avatar:[&>svg]:hidden",
          "group-data-[size=default]/avatar:size-2.5 group-data-[size=default]/avatar:[&>svg]:size-2",
          "group-data-[size=lg]/avatar:size-3 group-data-[size=lg]/avatar:[&>svg]:size-2",
          className
        ),
        ...props
      }
    );
  }
  function AvatarGroup({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "div",
      {
        "data-slot": "avatar-group",
        className: cn(
          "group/avatar-group flex -space-x-2 *:data-[slot=avatar]:ring-2 *:data-[slot=avatar]:ring-background",
          className
        ),
        ...props
      }
    );
  }
  function AvatarGroupCount({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "div",
      {
        "data-slot": "avatar-group-count",
        className: cn(
          "relative flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm text-muted-foreground ring-2 ring-background group-has-data-[size=lg]/avatar-group:size-10 group-has-data-[size=sm]/avatar-group:size-6 [&>svg]:size-4 group-has-data-[size=lg]/avatar-group:[&>svg]:size-5 group-has-data-[size=sm]/avatar-group:[&>svg]:size-3",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/badge.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/use-render/useRender.js
  init_define_import_meta_env();
  function useRender(params) {
    return useRenderElement(params.defaultTagName ?? "div", params, params);
  }

  // node_modules/class-variance-authority/dist/index.mjs
  init_define_import_meta_env();
  var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
  var cx = clsx;
  var cva = (base, config) => (props) => {
    var _config_compoundVariants;
    if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
    const { variants, defaultVariants } = config;
    const getVariantClassNames = Object.keys(variants).map((variant) => {
      const variantProp = props === null || props === void 0 ? void 0 : props[variant];
      const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
      if (variantProp === null) return null;
      const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
      return variants[variant][variantKey];
    });
    const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
      let [key, value] = param;
      if (value === void 0) {
        return acc;
      }
      acc[key] = value;
      return acc;
    }, {});
    const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
      let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
      return Object.entries(compoundVariantOptions).every((param2) => {
        let [key, value] = param2;
        return Array.isArray(value) ? value.includes({
          ...defaultVariants,
          ...propsWithoutUndefined
        }[key]) : {
          ...defaultVariants,
          ...propsWithoutUndefined
        }[key] === value;
      }) ? [
        ...acc,
        cvClass,
        cvClassName
      ] : acc;
    }, []);
    return cx(base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
  };

  // src/components/ui/badge.tsx
  var badgeVariants = cva(
    "group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-4xl border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3!",
    {
      variants: {
        variant: {
          default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
          secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
          destructive: "bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",
          outline: "border-border text-foreground [a]:hover:bg-muted [a]:hover:text-muted-foreground",
          ghost: "hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",
          link: "text-primary underline-offset-4 hover:underline"
        }
      },
      defaultVariants: {
        variant: "default"
      }
    }
  );
  function Badge({
    className,
    variant = "default",
    render,
    ...props
  }) {
    return useRender({
      defaultTagName: "span",
      props: mergeProps(
        {
          className: cn(badgeVariants({ variant }), className)
        },
        props
      ),
      render,
      state: {
        slot: "badge",
        variant
      }
    });
  }

  // src/components/ui/button.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/button/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/button/Button.js
  init_define_import_meta_env();
  var React19 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/use-button/useButton.js
  init_define_import_meta_env();
  var React18 = __toESM(require_react_shim(), 1);

  // node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
  init_define_import_meta_env();
  function hasWindow() {
    return typeof window !== "undefined";
  }
  function getNodeName(node) {
    if (isNode(node)) {
      return (node.nodeName || "").toLowerCase();
    }
    return "#document";
  }
  function getWindow(node) {
    var _node$ownerDocument;
    return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
  }
  function getDocumentElement(node) {
    var _ref;
    return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
  }
  function isNode(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Node || value instanceof getWindow(value).Node;
  }
  function isElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Element || value instanceof getWindow(value).Element;
  }
  function isHTMLElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
  }
  function isShadowRoot(value) {
    if (!hasWindow() || typeof ShadowRoot === "undefined") {
      return false;
    }
    return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
  }
  function isOverflowElement(element) {
    const {
      overflow,
      overflowX,
      overflowY,
      display
    } = getComputedStyle2(element);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
  }
  function isTableElement(element) {
    return /^(table|td|th)$/.test(getNodeName(element));
  }
  function isTopLayer(element) {
    try {
      if (element.matches(":popover-open")) {
        return true;
      }
    } catch (_e) {
    }
    try {
      return element.matches(":modal");
    } catch (_e) {
      return false;
    }
  }
  var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
  var containRe = /paint|layout|strict|content/;
  var isNotNone = (value) => !!value && value !== "none";
  var isWebKitValue;
  function isContainingBlock(elementOrCss) {
    const css = isElement(elementOrCss) ? getComputedStyle2(elementOrCss) : elementOrCss;
    return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
  }
  function getContainingBlock(element) {
    let currentNode = getParentNode(element);
    while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
      if (isContainingBlock(currentNode)) {
        return currentNode;
      } else if (isTopLayer(currentNode)) {
        return null;
      }
      currentNode = getParentNode(currentNode);
    }
    return null;
  }
  function isWebKit() {
    if (isWebKitValue == null) {
      isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
    }
    return isWebKitValue;
  }
  function isLastTraversableNode(node) {
    return /^(html|body|#document)$/.test(getNodeName(node));
  }
  function getComputedStyle2(element) {
    return getWindow(element).getComputedStyle(element);
  }
  function getNodeScroll(element) {
    if (isElement(element)) {
      return {
        scrollLeft: element.scrollLeft,
        scrollTop: element.scrollTop
      };
    }
    return {
      scrollLeft: element.scrollX,
      scrollTop: element.scrollY
    };
  }
  function getParentNode(node) {
    if (getNodeName(node) === "html") {
      return node;
    }
    const result = (
      // Step into the shadow DOM of the parent of a slotted node.
      node.assignedSlot || // DOM Element detected.
      node.parentNode || // ShadowRoot detected.
      isShadowRoot(node) && node.host || // Fallback.
      getDocumentElement(node)
    );
    return isShadowRoot(result) ? result.host : result;
  }
  function getNearestOverflowAncestor(node) {
    const parentNode = getParentNode(node);
    if (isLastTraversableNode(parentNode)) {
      return node.ownerDocument ? node.ownerDocument.body : node.body;
    }
    if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
      return parentNode;
    }
    return getNearestOverflowAncestor(parentNode);
  }
  function getOverflowAncestors(node, list, traverseIframes) {
    var _node$ownerDocument2;
    if (list === void 0) {
      list = [];
    }
    if (traverseIframes === void 0) {
      traverseIframes = true;
    }
    const scrollableAncestor = getNearestOverflowAncestor(node);
    const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
    const win = getWindow(scrollableAncestor);
    if (isBody) {
      const frameElement = getFrameElement(win);
      return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
    } else {
      return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
    }
  }
  function getFrameElement(win) {
    return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
  }

  // node_modules/@base-ui/utils/esm/error.js
  init_define_import_meta_env();
  var set2;
  if (true) {
    set2 = /* @__PURE__ */ new Set();
  }
  function error(...messages) {
    if (true) {
      const messageKey = messages.join(" ");
      if (!set2.has(messageKey)) {
        set2.add(messageKey);
        console.error(`Base UI: ${messageKey}`);
      }
    }
  }

  // node_modules/@base-ui/utils/esm/safeReact.js
  init_define_import_meta_env();
  var React15 = __toESM(require_react_shim(), 1);
  var SafeReact = {
    ...React15
  };

  // node_modules/@base-ui/react/esm/composite/root/CompositeRootContext.js
  init_define_import_meta_env();
  var React16 = __toESM(require_react_shim(), 1);
  var CompositeRootContext = /* @__PURE__ */ React16.createContext(void 0);
  if (true) CompositeRootContext.displayName = "CompositeRootContext";
  function useCompositeRootContext(optional = false) {
    const context = React16.useContext(CompositeRootContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>." : formatErrorMessage_default(16));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/utils/useFocusableWhenDisabled.js
  init_define_import_meta_env();
  var React17 = __toESM(require_react_shim(), 1);
  function useFocusableWhenDisabled(parameters) {
    const {
      focusableWhenDisabled,
      disabled: disabled2,
      composite = false,
      tabIndex: tabIndexProp = 0,
      isNativeButton
    } = parameters;
    const isFocusableComposite = composite && focusableWhenDisabled !== false;
    const isNonFocusableComposite = composite && focusableWhenDisabled === false;
    const props = React17.useMemo(() => {
      const additionalProps = {
        // allow Tabbing away from focusableWhenDisabled elements
        onKeyDown(event) {
          if (disabled2 && focusableWhenDisabled && event.key !== "Tab") {
            event.preventDefault();
          }
        }
      };
      if (!composite) {
        additionalProps.tabIndex = tabIndexProp;
        if (!isNativeButton && disabled2) {
          additionalProps.tabIndex = focusableWhenDisabled ? tabIndexProp : -1;
        }
      }
      if (isNativeButton && (focusableWhenDisabled || isFocusableComposite) || !isNativeButton && disabled2) {
        additionalProps["aria-disabled"] = disabled2;
      }
      if (isNativeButton && (!focusableWhenDisabled || isNonFocusableComposite)) {
        additionalProps.disabled = disabled2;
      }
      return additionalProps;
    }, [composite, disabled2, focusableWhenDisabled, isFocusableComposite, isNonFocusableComposite, isNativeButton, tabIndexProp]);
    return {
      props
    };
  }

  // node_modules/@base-ui/react/esm/use-button/useButton.js
  function useButton(parameters = {}) {
    const {
      disabled: disabled2 = false,
      focusableWhenDisabled,
      tabIndex = 0,
      native: isNativeButton = true,
      composite: compositeProp
    } = parameters;
    const elementRef = React18.useRef(null);
    const compositeRootContext = useCompositeRootContext(true);
    const isCompositeItem = compositeProp ?? compositeRootContext !== void 0;
    const {
      props: focusableWhenDisabledProps
    } = useFocusableWhenDisabled({
      focusableWhenDisabled,
      disabled: disabled2,
      composite: isCompositeItem,
      tabIndex,
      isNativeButton
    });
    if (true) {
      React18.useEffect(() => {
        if (!elementRef.current) {
          return;
        }
        const isButtonTag = isButtonElement(elementRef.current);
        if (isNativeButton) {
          if (!isButtonTag) {
            const ownerStackMessage = SafeReact.captureOwnerStack?.() || "";
            const message = "A component that acts as a button expected a native <button> because the `nativeButton` prop is true. Rendering a non-<button> removes native button semantics, which can impact forms and accessibility. Use a real <button> in the `render` prop, or set `nativeButton` to `false`.";
            error(`${message}${ownerStackMessage}`);
          }
        } else if (isButtonTag) {
          const ownerStackMessage = SafeReact.captureOwnerStack?.() || "";
          const message = "A component that acts as a button expected a non-<button> because the `nativeButton` prop is false. Rendering a <button> keeps native behavior while Base UI applies non-native attributes and handlers, which can add unintended extra attributes (such as `role` or `aria-disabled`). Use a non-<button> in the `render` prop, or set `nativeButton` to `true`.";
          error(`${message}${ownerStackMessage}`);
        }
      }, [isNativeButton]);
    }
    const updateDisabled = React18.useCallback(() => {
      const element = elementRef.current;
      if (!isButtonElement(element)) {
        return;
      }
      if (isCompositeItem && disabled2 && focusableWhenDisabledProps.disabled === void 0 && element.disabled) {
        element.disabled = false;
      }
    }, [disabled2, focusableWhenDisabledProps.disabled, isCompositeItem]);
    useIsoLayoutEffect(updateDisabled, [updateDisabled]);
    const getButtonProps = React18.useCallback((externalProps = {}) => {
      const {
        onClick: externalOnClick,
        onMouseDown: externalOnMouseDown,
        onKeyUp: externalOnKeyUp,
        onKeyDown: externalOnKeyDown,
        onPointerDown: externalOnPointerDown,
        ...otherExternalProps
      } = externalProps;
      const type = isNativeButton ? "button" : void 0;
      return mergeProps({
        type,
        onClick(event) {
          if (disabled2) {
            event.preventDefault();
            return;
          }
          externalOnClick?.(event);
        },
        onMouseDown(event) {
          if (!disabled2) {
            externalOnMouseDown?.(event);
          }
        },
        onKeyDown(event) {
          if (disabled2) {
            return;
          }
          makeEventPreventable(event);
          externalOnKeyDown?.(event);
          if (event.baseUIHandlerPrevented) {
            return;
          }
          const isCurrentTarget = event.target === event.currentTarget;
          const currentTarget = event.currentTarget;
          const isButton = isButtonElement(currentTarget);
          const isLink = !isNativeButton && isValidLinkElement(currentTarget);
          const shouldClick = isCurrentTarget && (isNativeButton ? isButton : !isLink);
          const isEnterKey = event.key === "Enter";
          const isSpaceKey = event.key === " ";
          const role = currentTarget.getAttribute("role");
          const isTextNavigationRole = role?.startsWith("menuitem") || role === "option" || role === "gridcell";
          if (isCurrentTarget && isCompositeItem && isSpaceKey) {
            if (event.defaultPrevented && isTextNavigationRole) {
              return;
            }
            event.preventDefault();
            if (isLink || isNativeButton && isButton) {
              currentTarget.click();
              event.preventBaseUIHandler();
            } else if (shouldClick) {
              externalOnClick?.(event);
              event.preventBaseUIHandler();
            }
            return;
          }
          if (shouldClick) {
            if (!isNativeButton && (isSpaceKey || isEnterKey)) {
              event.preventDefault();
            }
            if (!isNativeButton && isEnterKey) {
              externalOnClick?.(event);
            }
          }
        },
        onKeyUp(event) {
          if (disabled2) {
            return;
          }
          makeEventPreventable(event);
          externalOnKeyUp?.(event);
          if (event.target === event.currentTarget && isNativeButton && isCompositeItem && isButtonElement(event.currentTarget) && event.key === " ") {
            event.preventDefault();
            return;
          }
          if (event.baseUIHandlerPrevented) {
            return;
          }
          if (event.target === event.currentTarget && !isNativeButton && !isCompositeItem && event.key === " ") {
            externalOnClick?.(event);
          }
        },
        onPointerDown(event) {
          if (disabled2) {
            event.preventDefault();
            return;
          }
          externalOnPointerDown?.(event);
        }
      }, !isNativeButton ? {
        role: "button"
      } : void 0, focusableWhenDisabledProps, otherExternalProps);
    }, [disabled2, focusableWhenDisabledProps, isCompositeItem, isNativeButton]);
    const buttonRef = useStableCallback((element) => {
      elementRef.current = element;
      updateDisabled();
    });
    return {
      getButtonProps,
      buttonRef
    };
  }
  function isButtonElement(elem) {
    return isHTMLElement(elem) && elem.tagName === "BUTTON";
  }
  function isValidLinkElement(elem) {
    return Boolean(elem?.tagName === "A" && elem?.href);
  }

  // node_modules/@base-ui/react/esm/button/Button.js
  var Button = /* @__PURE__ */ React19.forwardRef(function Button2(componentProps, forwardedRef) {
    const {
      render,
      className,
      disabled: disabled2 = false,
      focusableWhenDisabled = false,
      nativeButton = true,
      ...elementProps
    } = componentProps;
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      focusableWhenDisabled,
      native: nativeButton
    });
    const state = {
      disabled: disabled2
    };
    return useRenderElement("button", componentProps, {
      state,
      ref: [forwardedRef, buttonRef],
      props: [elementProps, getButtonProps]
    });
  });
  if (true) Button.displayName = "Button";

  // src/components/ui/button.tsx
  var import_jsx_runtime3 = __toESM(require_react_shim(), 1);
  var buttonVariants = cva(
    "group/button inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
    {
      variants: {
        variant: {
          default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
          outline: "border-border bg-background hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
          secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
          ghost: "hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:hover:bg-muted/50",
          destructive: "bg-destructive/10 text-destructive hover:bg-destructive/20 focus-visible:border-destructive/40 focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:hover:bg-destructive/30 dark:focus-visible:ring-destructive/40",
          link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
          default: "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
          xs: "h-6 gap-1 rounded-[min(var(--radius-md),10px)] px-2 text-xs in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
          sm: "h-7 gap-1 rounded-[min(var(--radius-md),12px)] px-2.5 text-[0.8rem] in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
          lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-3 has-data-[icon=inline-start]:pl-3",
          icon: "size-8",
          "icon-xs": "size-6 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3",
          "icon-sm": "size-7 rounded-[min(var(--radius-md),12px)] in-data-[slot=button-group]:rounded-lg",
          "icon-lg": "size-9"
        }
      },
      defaultVariants: {
        variant: "default",
        size: "default"
      }
    }
  );
  function Button3({
    className,
    variant = "default",
    size: size4 = "default",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      Button,
      {
        "data-slot": "button",
        className: cn(buttonVariants({ variant, size: size4, className })),
        ...props
      }
    );
  }

  // src/components/ui/card.tsx
  init_define_import_meta_env();
  var import_jsx_runtime4 = __toESM(require_react_shim(), 1);
  function Card({
    className,
    size: size4 = "default",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card",
        "data-size": size4,
        className: cn(
          "group/card flex flex-col gap-4 overflow-hidden rounded-xl bg-card py-4 text-sm text-card-foreground ring-1 ring-foreground/10 has-data-[slot=card-footer]:pb-0 has-[>img:first-child]:pt-0 data-[size=sm]:gap-3 data-[size=sm]:py-3 data-[size=sm]:has-data-[slot=card-footer]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl",
          className
        ),
        ...props
      }
    );
  }
  function CardHeader({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-header",
        className: cn(
          "group/card-header @container/card-header grid auto-rows-min items-start gap-1 rounded-t-xl px-4 group-data-[size=sm]/card:px-3 has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto] [.border-b]:pb-4 group-data-[size=sm]/card:[.border-b]:pb-3",
          className
        ),
        ...props
      }
    );
  }
  function CardTitle({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-title",
        className: cn(
          "text-base leading-snug font-medium group-data-[size=sm]/card:text-sm",
          className
        ),
        ...props
      }
    );
  }
  function CardDescription({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-description",
        className: cn("text-sm text-muted-foreground", className),
        ...props
      }
    );
  }
  function CardAction({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-action",
        className: cn(
          "col-start-2 row-span-2 row-start-1 self-start justify-self-end",
          className
        ),
        ...props
      }
    );
  }
  function CardContent({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-content",
        className: cn("px-4 group-data-[size=sm]/card:px-3", className),
        ...props
      }
    );
  }
  function CardFooter({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "div",
      {
        "data-slot": "card-footer",
        className: cn(
          "flex items-center rounded-b-xl border-t bg-muted/50 p-4 group-data-[size=sm]/card:p-3",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/dialog.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/dialog/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/dialog/index.parts.js
  var index_parts_exports2 = {};
  __export(index_parts_exports2, {
    Backdrop: () => DialogBackdrop,
    Close: () => DialogClose,
    Description: () => DialogDescription,
    Handle: () => DialogHandle,
    Popup: () => DialogPopup,
    Portal: () => DialogPortal,
    Root: () => DialogRoot,
    Title: () => DialogTitle,
    Trigger: () => DialogTrigger,
    Viewport: () => DialogViewport,
    createHandle: () => createDialogHandle
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/dialog/backdrop/DialogBackdrop.js
  init_define_import_meta_env();
  var React21 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/dialog/root/DialogRootContext.js
  init_define_import_meta_env();
  var React20 = __toESM(require_react_shim(), 1);
  var DialogRootContext = /* @__PURE__ */ React20.createContext(void 0);
  if (true) DialogRootContext.displayName = "DialogRootContext";
  function useDialogRootContext(optional) {
    const dialogRootContext = React20.useContext(DialogRootContext);
    if (optional === false && dialogRootContext === void 0) {
      throw new Error(true ? "Base UI: DialogRootContext is missing. Dialog parts must be placed within <Dialog.Root>." : formatErrorMessage_default(27));
    }
    return dialogRootContext;
  }

  // node_modules/@base-ui/react/esm/utils/popupStateMapping.js
  init_define_import_meta_env();
  var CommonPopupDataAttributes = (function(CommonPopupDataAttributes2) {
    CommonPopupDataAttributes2["open"] = "data-open";
    CommonPopupDataAttributes2["closed"] = "data-closed";
    CommonPopupDataAttributes2[CommonPopupDataAttributes2["startingStyle"] = TransitionStatusDataAttributes.startingStyle] = "startingStyle";
    CommonPopupDataAttributes2[CommonPopupDataAttributes2["endingStyle"] = TransitionStatusDataAttributes.endingStyle] = "endingStyle";
    CommonPopupDataAttributes2["anchorHidden"] = "data-anchor-hidden";
    CommonPopupDataAttributes2["side"] = "data-side";
    CommonPopupDataAttributes2["align"] = "data-align";
    return CommonPopupDataAttributes2;
  })({});
  var CommonTriggerDataAttributes = /* @__PURE__ */ (function(CommonTriggerDataAttributes2) {
    CommonTriggerDataAttributes2["popupOpen"] = "data-popup-open";
    CommonTriggerDataAttributes2["pressed"] = "data-pressed";
    return CommonTriggerDataAttributes2;
  })({});
  var TRIGGER_HOOK = {
    [CommonTriggerDataAttributes.popupOpen]: ""
  };
  var PRESSABLE_TRIGGER_HOOK = {
    [CommonTriggerDataAttributes.popupOpen]: "",
    [CommonTriggerDataAttributes.pressed]: ""
  };
  var POPUP_OPEN_HOOK = {
    [CommonPopupDataAttributes.open]: ""
  };
  var POPUP_CLOSED_HOOK = {
    [CommonPopupDataAttributes.closed]: ""
  };
  var ANCHOR_HIDDEN_HOOK = {
    [CommonPopupDataAttributes.anchorHidden]: ""
  };
  var triggerOpenStateMapping = {
    open(value) {
      if (value) {
        return TRIGGER_HOOK;
      }
      return null;
    }
  };
  var pressableTriggerOpenStateMapping = {
    open(value) {
      if (value) {
        return PRESSABLE_TRIGGER_HOOK;
      }
      return null;
    }
  };
  var popupStateMapping = {
    open(value) {
      if (value) {
        return POPUP_OPEN_HOOK;
      }
      return POPUP_CLOSED_HOOK;
    },
    anchorHidden(value) {
      if (value) {
        return ANCHOR_HIDDEN_HOOK;
      }
      return null;
    }
  };

  // node_modules/@base-ui/react/esm/dialog/backdrop/DialogBackdrop.js
  var stateAttributesMapping2 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var DialogBackdrop = /* @__PURE__ */ React21.forwardRef(function DialogBackdrop2(componentProps, forwardedRef) {
    const {
      render,
      className,
      forceRender = false,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useDialogRootContext();
    const open = store.useState("open");
    const nested = store.useState("nested");
    const mounted = store.useState("mounted");
    const transitionStatus = store.useState("transitionStatus");
    const state = {
      open,
      transitionStatus
    };
    return useRenderElement("div", componentProps, {
      state,
      ref: [store.context.backdropRef, forwardedRef],
      stateAttributesMapping: stateAttributesMapping2,
      props: [{
        role: "presentation",
        hidden: !mounted,
        style: {
          userSelect: "none",
          WebkitUserSelect: "none"
        }
      }, elementProps],
      enabled: forceRender || !nested
    });
  });
  if (true) DialogBackdrop.displayName = "DialogBackdrop";

  // node_modules/@base-ui/react/esm/dialog/close/DialogClose.js
  init_define_import_meta_env();
  var React22 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/use-button/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/createBaseUIEventDetails.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/reasons.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/reason-parts.js
  var reason_parts_exports = {};
  __export(reason_parts_exports, {
    cancelOpen: () => cancelOpen,
    chipRemovePress: () => chipRemovePress,
    clearPress: () => clearPress,
    closePress: () => closePress,
    closeWatcher: () => closeWatcher,
    decrementPress: () => decrementPress,
    disabled: () => disabled,
    drag: () => drag,
    escapeKey: () => escapeKey,
    focusOut: () => focusOut,
    imperativeAction: () => imperativeAction,
    incrementPress: () => incrementPress,
    inputBlur: () => inputBlur,
    inputChange: () => inputChange,
    inputClear: () => inputClear,
    inputPaste: () => inputPaste,
    inputPress: () => inputPress,
    itemPress: () => itemPress,
    keyboard: () => keyboard,
    linkPress: () => linkPress,
    listNavigation: () => listNavigation,
    none: () => none,
    outsidePress: () => outsidePress,
    pointer: () => pointer,
    scrub: () => scrub,
    siblingOpen: () => siblingOpen,
    swipe: () => swipe,
    trackPress: () => trackPress,
    triggerFocus: () => triggerFocus,
    triggerHover: () => triggerHover,
    triggerPress: () => triggerPress,
    wheel: () => wheel,
    windowResize: () => windowResize
  });
  init_define_import_meta_env();
  var none = "none";
  var triggerPress = "trigger-press";
  var triggerHover = "trigger-hover";
  var triggerFocus = "trigger-focus";
  var outsidePress = "outside-press";
  var itemPress = "item-press";
  var closePress = "close-press";
  var linkPress = "link-press";
  var clearPress = "clear-press";
  var chipRemovePress = "chip-remove-press";
  var trackPress = "track-press";
  var incrementPress = "increment-press";
  var decrementPress = "decrement-press";
  var inputChange = "input-change";
  var inputClear = "input-clear";
  var inputBlur = "input-blur";
  var inputPaste = "input-paste";
  var inputPress = "input-press";
  var focusOut = "focus-out";
  var escapeKey = "escape-key";
  var closeWatcher = "close-watcher";
  var listNavigation = "list-navigation";
  var keyboard = "keyboard";
  var pointer = "pointer";
  var drag = "drag";
  var wheel = "wheel";
  var scrub = "scrub";
  var cancelOpen = "cancel-open";
  var siblingOpen = "sibling-open";
  var disabled = "disabled";
  var imperativeAction = "imperative-action";
  var swipe = "swipe";
  var windowResize = "window-resize";

  // node_modules/@base-ui/react/esm/utils/createBaseUIEventDetails.js
  function createChangeEventDetails(reason, event, trigger, customProperties) {
    let canceled = false;
    let allowPropagation = false;
    const custom = customProperties ?? EMPTY_OBJECT;
    const details = {
      reason,
      event: event ?? new Event("base-ui"),
      cancel() {
        canceled = true;
      },
      allowPropagation() {
        allowPropagation = true;
      },
      get isCanceled() {
        return canceled;
      },
      get isPropagationAllowed() {
        return allowPropagation;
      },
      trigger,
      ...custom
    };
    return details;
  }

  // node_modules/@base-ui/react/esm/dialog/close/DialogClose.js
  var DialogClose = /* @__PURE__ */ React22.forwardRef(function DialogClose2(componentProps, forwardedRef) {
    const {
      render,
      className,
      disabled: disabled2 = false,
      nativeButton = true,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useDialogRootContext();
    const open = store.useState("open");
    function handleClick(event) {
      if (open) {
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.closePress, event.nativeEvent));
      }
    }
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      native: nativeButton
    });
    const state = {
      disabled: disabled2
    };
    return useRenderElement("button", componentProps, {
      state,
      ref: [forwardedRef, buttonRef],
      props: [{
        onClick: handleClick
      }, elementProps, getButtonProps]
    });
  });
  if (true) DialogClose.displayName = "DialogClose";

  // node_modules/@base-ui/react/esm/dialog/description/DialogDescription.js
  init_define_import_meta_env();
  var React24 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/useBaseUiId.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/useId.js
  init_define_import_meta_env();
  var React23 = __toESM(require_react_shim(), 1);
  var globalId = 0;
  function useGlobalId(idOverride, prefix = "mui") {
    const [defaultId, setDefaultId] = React23.useState(idOverride);
    const id = idOverride || defaultId;
    React23.useEffect(() => {
      if (defaultId == null) {
        globalId += 1;
        setDefaultId(`${prefix}-${globalId}`);
      }
    }, [defaultId, prefix]);
    return id;
  }
  var maybeReactUseId = SafeReact.useId;
  function useId(idOverride, prefix) {
    if (maybeReactUseId !== void 0) {
      const reactId = maybeReactUseId();
      return idOverride ?? (prefix ? `${prefix}-${reactId}` : reactId);
    }
    return useGlobalId(idOverride, prefix);
  }

  // node_modules/@base-ui/react/esm/utils/useBaseUiId.js
  function useBaseUiId(idOverride) {
    return useId(idOverride, "base-ui");
  }

  // node_modules/@base-ui/react/esm/dialog/description/DialogDescription.js
  var DialogDescription = /* @__PURE__ */ React24.forwardRef(function DialogDescription2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useDialogRootContext();
    const id = useBaseUiId(idProp);
    store.useSyncedValueWithCleanup("descriptionElementId", id);
    return useRenderElement("p", componentProps, {
      ref: forwardedRef,
      props: [{
        id
      }, elementProps]
    });
  });
  if (true) DialogDescription.displayName = "DialogDescription";

  // node_modules/@base-ui/react/esm/dialog/popup/DialogPopup.js
  init_define_import_meta_env();
  var React47 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/floating-ui-react/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingDelayGroup.js
  init_define_import_meta_env();
  var React25 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverShared.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/element.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/detectBrowser.js
  init_define_import_meta_env();
  var hasNavigator = typeof navigator !== "undefined";
  var nav = getNavigatorData();
  var platform = getPlatform();
  var userAgent = getUserAgent();
  var isWebKit2 = typeof CSS === "undefined" || !CSS.supports ? false : CSS.supports("-webkit-backdrop-filter:none");
  var isIOS = (
    // iPads can claim to be MacIntel
    nav.platform === "MacIntel" && nav.maxTouchPoints > 1 ? true : /iP(hone|ad|od)|iOS/.test(nav.platform)
  );
  var isFirefox = hasNavigator && /firefox/i.test(userAgent);
  var isSafari = hasNavigator && /apple/i.test(navigator.vendor);
  var isEdge = hasNavigator && /Edg/i.test(userAgent);
  var isAndroid = hasNavigator && /android/i.test(platform) || /android/i.test(userAgent);
  var isMac = hasNavigator && platform.toLowerCase().startsWith("mac") && !navigator.maxTouchPoints;
  var isJSDOM = userAgent.includes("jsdom/");
  function getNavigatorData() {
    if (!hasNavigator) {
      return {
        platform: "",
        maxTouchPoints: -1
      };
    }
    const uaData = navigator.userAgentData;
    if (uaData?.platform) {
      return {
        platform: uaData.platform,
        maxTouchPoints: navigator.maxTouchPoints
      };
    }
    return {
      platform: navigator.platform ?? "",
      maxTouchPoints: navigator.maxTouchPoints ?? -1
    };
  }
  function getUserAgent() {
    if (!hasNavigator) {
      return "";
    }
    const uaData = navigator.userAgentData;
    if (uaData && Array.isArray(uaData.brands)) {
      return uaData.brands.map(({
        brand,
        version: version2
      }) => `${brand}/${version2}`).join(" ");
    }
    return navigator.userAgent;
  }
  function getPlatform() {
    if (!hasNavigator) {
      return "";
    }
    const uaData = navigator.userAgentData;
    if (uaData?.platform) {
      return uaData.platform;
    }
    return navigator.platform ?? "";
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/constants.js
  init_define_import_meta_env();
  var FOCUSABLE_ATTRIBUTE = "data-base-ui-focusable";
  var ACTIVE_KEY = "active";
  var SELECTED_KEY = "selected";
  var TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
  var ARROW_LEFT = "ArrowLeft";
  var ARROW_RIGHT = "ArrowRight";
  var ARROW_UP = "ArrowUp";
  var ARROW_DOWN = "ArrowDown";

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/element.js
  function activeElement(doc) {
    let element = doc.activeElement;
    while (element?.shadowRoot?.activeElement != null) {
      element = element.shadowRoot.activeElement;
    }
    return element;
  }
  function contains(parent, child) {
    if (!parent || !child) {
      return false;
    }
    const rootNode = child.getRootNode?.();
    if (parent.contains(child)) {
      return true;
    }
    if (rootNode && isShadowRoot(rootNode)) {
      let next = child;
      while (next) {
        if (parent === next) {
          return true;
        }
        next = next.parentNode || next.host;
      }
    }
    return false;
  }
  function isTargetInsideEnabledTrigger(target, triggerElements) {
    if (!isElement(target)) {
      return false;
    }
    const targetElement = target;
    if (triggerElements.hasElement(targetElement)) {
      return !targetElement.hasAttribute("data-trigger-disabled");
    }
    for (const [, trigger] of triggerElements.entries()) {
      if (contains(trigger, targetElement)) {
        return !trigger.hasAttribute("data-trigger-disabled");
      }
    }
    return false;
  }
  function getTarget(event) {
    if ("composedPath" in event) {
      return event.composedPath()[0];
    }
    return event.target;
  }
  function isEventTargetWithin(event, node) {
    if (node == null) {
      return false;
    }
    if ("composedPath" in event) {
      return event.composedPath().includes(node);
    }
    const eventAgain = event;
    return eventAgain.target != null && node.contains(eventAgain.target);
  }
  function isRootElement(element) {
    return element.matches("html,body");
  }
  function isTypeableElement(element) {
    return isHTMLElement(element) && element.matches(TYPEABLE_SELECTOR);
  }
  function isTypeableCombobox(element) {
    if (!element) {
      return false;
    }
    return element.getAttribute("role") === "combobox" && isTypeableElement(element);
  }
  function matchesFocusVisible(element) {
    if (!element || isJSDOM) {
      return true;
    }
    try {
      return element.matches(":focus-visible");
    } catch (_e) {
      return true;
    }
  }
  function getFloatingFocusElement(floatingElement) {
    if (!floatingElement) {
      return null;
    }
    return floatingElement.hasAttribute(FOCUSABLE_ATTRIBUTE) ? floatingElement : floatingElement.querySelector(`[${FOCUSABLE_ATTRIBUTE}]`) || floatingElement;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/nodes.js
  init_define_import_meta_env();
  function getNodeChildren(nodes, id, onlyOpenChildren = true) {
    const directChildren = nodes.filter((node) => node.parentId === id && (!onlyOpenChildren || node.context?.open));
    return directChildren.flatMap((child) => [child, ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
  }
  function getNodeAncestors(nodes, id) {
    let allAncestors = [];
    let currentParentId = nodes.find((node) => node.id === id)?.parentId;
    while (currentParentId) {
      const currentNode = nodes.find((node) => node.id === currentParentId);
      currentParentId = currentNode?.parentId;
      if (currentNode) {
        allAncestors = allAncestors.concat(currentNode);
      }
    }
    return allAncestors;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/event.js
  init_define_import_meta_env();
  function stopEvent(event) {
    event.preventDefault();
    event.stopPropagation();
  }
  function isReactEvent(event) {
    return "nativeEvent" in event;
  }
  function isVirtualClick(event) {
    if (event.pointerType === "" && event.isTrusted) {
      return true;
    }
    if (isAndroid && event.pointerType) {
      return event.type === "click" && event.buttons === 1;
    }
    return event.detail === 0 && !event.pointerType;
  }
  function isVirtualPointerEvent(event) {
    if (isJSDOM) {
      return false;
    }
    return !isAndroid && event.width === 0 && event.height === 0 || isAndroid && event.width === 1 && event.height === 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "mouse" || // iOS VoiceOver returns 0.333• for width/height.
    event.width < 1 && event.height < 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "touch";
  }
  function isMouseLikePointerType(pointerType, strict) {
    const values = ["mouse", "pen"];
    if (!strict) {
      values.push("", void 0);
    }
    return values.includes(pointerType);
  }
  function isClickLikeEvent(event) {
    const type = event.type;
    return type === "click" || type === "mousedown" || type === "keydown" || type === "keyup";
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/composite.js
  init_define_import_meta_env();

  // node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
  init_define_import_meta_env();
  var sides = ["top", "right", "bottom", "left"];
  var min = Math.min;
  var max = Math.max;
  var round = Math.round;
  var floor = Math.floor;
  var createCoords = (v) => ({
    x: v,
    y: v
  });
  var oppositeSideMap = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
  };
  function clamp(start, value, end) {
    return max(start, min(value, end));
  }
  function evaluate(value, param) {
    return typeof value === "function" ? value(param) : value;
  }
  function getSide(placement) {
    return placement.split("-")[0];
  }
  function getAlignment(placement) {
    return placement.split("-")[1];
  }
  function getOppositeAxis(axis) {
    return axis === "x" ? "y" : "x";
  }
  function getAxisLength(axis) {
    return axis === "y" ? "height" : "width";
  }
  function getSideAxis(placement) {
    const firstChar = placement[0];
    return firstChar === "t" || firstChar === "b" ? "y" : "x";
  }
  function getAlignmentAxis(placement) {
    return getOppositeAxis(getSideAxis(placement));
  }
  function getAlignmentSides(placement, rects, rtl) {
    if (rtl === void 0) {
      rtl = false;
    }
    const alignment = getAlignment(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const length = getAxisLength(alignmentAxis);
    let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
    if (rects.reference[length] > rects.floating[length]) {
      mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
    }
    return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
  }
  function getExpandedPlacements(placement) {
    const oppositePlacement = getOppositePlacement(placement);
    return [getOppositeAlignmentPlacement(placement), oppositePlacement, getOppositeAlignmentPlacement(oppositePlacement)];
  }
  function getOppositeAlignmentPlacement(placement) {
    return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
  }
  var lrPlacement = ["left", "right"];
  var rlPlacement = ["right", "left"];
  var tbPlacement = ["top", "bottom"];
  var btPlacement = ["bottom", "top"];
  function getSideList(side, isStart, rtl) {
    switch (side) {
      case "top":
      case "bottom":
        if (rtl) return isStart ? rlPlacement : lrPlacement;
        return isStart ? lrPlacement : rlPlacement;
      case "left":
      case "right":
        return isStart ? tbPlacement : btPlacement;
      default:
        return [];
    }
  }
  function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
    const alignment = getAlignment(placement);
    let list = getSideList(getSide(placement), direction === "start", rtl);
    if (alignment) {
      list = list.map((side) => side + "-" + alignment);
      if (flipAlignment) {
        list = list.concat(list.map(getOppositeAlignmentPlacement));
      }
    }
    return list;
  }
  function getOppositePlacement(placement) {
    const side = getSide(placement);
    return oppositeSideMap[side] + placement.slice(side.length);
  }
  function expandPaddingObject(padding) {
    return {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
      ...padding
    };
  }
  function getPaddingObject(padding) {
    return typeof padding !== "number" ? expandPaddingObject(padding) : {
      top: padding,
      right: padding,
      bottom: padding,
      left: padding
    };
  }
  function rectToClientRect(rect) {
    const {
      x,
      y,
      width,
      height
    } = rect;
    return {
      width,
      height,
      top: y,
      left: x,
      right: x + width,
      bottom: y + height,
      x,
      y
    };
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/composite.js
  function isDifferentGridRow(index2, cols, prevRow) {
    return Math.floor(index2 / cols) !== prevRow;
  }
  function isIndexOutOfListBounds(listRef, index2) {
    return index2 < 0 || index2 >= listRef.current.length;
  }
  function getMinListIndex(listRef, disabledIndices) {
    return findNonDisabledListIndex(listRef, {
      disabledIndices
    });
  }
  function getMaxListIndex(listRef, disabledIndices) {
    return findNonDisabledListIndex(listRef, {
      decrement: true,
      startingIndex: listRef.current.length,
      disabledIndices
    });
  }
  function findNonDisabledListIndex(listRef, {
    startingIndex = -1,
    decrement = false,
    disabledIndices,
    amount = 1
  } = {}) {
    let index2 = startingIndex;
    do {
      index2 += decrement ? -amount : amount;
    } while (index2 >= 0 && index2 <= listRef.current.length - 1 && isListIndexDisabled(listRef, index2, disabledIndices));
    return index2;
  }
  function getGridNavigatedIndex(listRef, {
    event,
    orientation,
    loopFocus,
    rtl,
    cols,
    disabledIndices,
    minIndex,
    maxIndex,
    prevIndex,
    stopEvent: stop = false
  }) {
    let nextIndex = prevIndex;
    let verticalDirection;
    if (event.key === ARROW_UP) {
      verticalDirection = "up";
    } else if (event.key === ARROW_DOWN) {
      verticalDirection = "down";
    }
    if (verticalDirection) {
      const rows = [];
      const rowIndexMap = [];
      let hasRoleRow = false;
      let visibleItemCount = 0;
      {
        let currentRowEl = null;
        let currentRowIndex = -1;
        listRef.current.forEach((el, idx) => {
          if (el == null) {
            return;
          }
          visibleItemCount += 1;
          const rowEl = el.closest('[role="row"]');
          if (rowEl) {
            hasRoleRow = true;
          }
          if (rowEl !== currentRowEl || currentRowIndex === -1) {
            currentRowEl = rowEl;
            currentRowIndex += 1;
            rows[currentRowIndex] = [];
          }
          rows[currentRowIndex].push(idx);
          rowIndexMap[idx] = currentRowIndex;
        });
      }
      let hasDomRows = false;
      let inferredDomCols = 0;
      if (hasRoleRow) {
        for (const row of rows) {
          const rowLength = row.length;
          if (rowLength > inferredDomCols) {
            inferredDomCols = rowLength;
          }
          if (rowLength !== cols) {
            hasDomRows = true;
          }
        }
      }
      const hasVirtualizedGaps = hasDomRows && visibleItemCount < listRef.current.length;
      const verticalCols = inferredDomCols || cols;
      const navigateVertically = (direction) => {
        if (!hasDomRows || prevIndex === -1) {
          return void 0;
        }
        const currentRow = rowIndexMap[prevIndex];
        if (currentRow == null) {
          return void 0;
        }
        const colInRow = rows[currentRow].indexOf(prevIndex);
        const step = direction === "up" ? -1 : 1;
        for (let nextRow = currentRow + step, i = 0; i < rows.length; i += 1, nextRow += step) {
          if (nextRow < 0 || nextRow >= rows.length) {
            if (!loopFocus || hasVirtualizedGaps) {
              return void 0;
            }
            nextRow = nextRow < 0 ? rows.length - 1 : 0;
          }
          const targetRow = rows[nextRow];
          for (let col = Math.min(colInRow, targetRow.length - 1); col >= 0; col -= 1) {
            const candidate = targetRow[col];
            if (!isListIndexDisabled(listRef, candidate, disabledIndices)) {
              return candidate;
            }
          }
        }
        return void 0;
      };
      const navigateVerticallyWithInferredRows = (direction) => {
        if (!hasVirtualizedGaps || prevIndex === -1) {
          return void 0;
        }
        const colInRow = prevIndex % verticalCols;
        const rowStep = direction === "up" ? -verticalCols : verticalCols;
        const lastRowStart = maxIndex - maxIndex % verticalCols;
        const rowCount = floor(maxIndex / verticalCols) + 1;
        for (let rowStart = prevIndex - colInRow + rowStep, i = 0; i < rowCount; i += 1, rowStart += rowStep) {
          if (rowStart < 0 || rowStart > maxIndex) {
            if (!loopFocus) {
              return void 0;
            }
            rowStart = rowStart < 0 ? lastRowStart : 0;
          }
          const rowEnd = Math.min(rowStart + verticalCols - 1, maxIndex);
          for (let candidate = Math.min(rowStart + colInRow, rowEnd); candidate >= rowStart; candidate -= 1) {
            if (!isListIndexDisabled(listRef, candidate, disabledIndices)) {
              return candidate;
            }
          }
        }
        return void 0;
      };
      if (stop) {
        stopEvent(event);
      }
      const verticalCandidate = navigateVertically(verticalDirection) ?? navigateVerticallyWithInferredRows(verticalDirection);
      if (verticalCandidate !== void 0) {
        nextIndex = verticalCandidate;
      } else if (prevIndex === -1) {
        nextIndex = verticalDirection === "up" ? maxIndex : minIndex;
      } else {
        nextIndex = findNonDisabledListIndex(listRef, {
          startingIndex: prevIndex,
          amount: verticalCols,
          decrement: verticalDirection === "up",
          disabledIndices
        });
        if (loopFocus) {
          if (verticalDirection === "up" && (prevIndex - verticalCols < minIndex || nextIndex < 0)) {
            const col = prevIndex % verticalCols;
            const maxCol = maxIndex % verticalCols;
            const offset4 = maxIndex - (maxCol - col);
            if (maxCol === col) {
              nextIndex = maxIndex;
            } else {
              nextIndex = maxCol > col ? offset4 : offset4 - verticalCols;
            }
          }
          if (verticalDirection === "down" && prevIndex + verticalCols > maxIndex) {
            nextIndex = findNonDisabledListIndex(listRef, {
              startingIndex: prevIndex % verticalCols - verticalCols,
              amount: verticalCols,
              disabledIndices
            });
          }
        }
      }
      if (isIndexOutOfListBounds(listRef, nextIndex)) {
        nextIndex = prevIndex;
      }
    }
    if (orientation === "both") {
      const prevRow = floor(prevIndex / cols);
      if (event.key === (rtl ? ARROW_LEFT : ARROW_RIGHT)) {
        if (stop) {
          stopEvent(event);
        }
        if (prevIndex % cols !== cols - 1) {
          nextIndex = findNonDisabledListIndex(listRef, {
            startingIndex: prevIndex,
            disabledIndices
          });
          if (loopFocus && isDifferentGridRow(nextIndex, cols, prevRow)) {
            nextIndex = findNonDisabledListIndex(listRef, {
              startingIndex: prevIndex - prevIndex % cols - 1,
              disabledIndices
            });
          }
        } else if (loopFocus) {
          nextIndex = findNonDisabledListIndex(listRef, {
            startingIndex: prevIndex - prevIndex % cols - 1,
            disabledIndices
          });
        }
        if (isDifferentGridRow(nextIndex, cols, prevRow)) {
          nextIndex = prevIndex;
        }
      }
      if (event.key === (rtl ? ARROW_RIGHT : ARROW_LEFT)) {
        if (stop) {
          stopEvent(event);
        }
        if (prevIndex % cols !== 0) {
          nextIndex = findNonDisabledListIndex(listRef, {
            startingIndex: prevIndex,
            decrement: true,
            disabledIndices
          });
          if (loopFocus && isDifferentGridRow(nextIndex, cols, prevRow)) {
            nextIndex = findNonDisabledListIndex(listRef, {
              startingIndex: prevIndex + (cols - prevIndex % cols),
              decrement: true,
              disabledIndices
            });
          }
        } else if (loopFocus) {
          nextIndex = findNonDisabledListIndex(listRef, {
            startingIndex: prevIndex + (cols - prevIndex % cols),
            decrement: true,
            disabledIndices
          });
        }
        if (isDifferentGridRow(nextIndex, cols, prevRow)) {
          nextIndex = prevIndex;
        }
      }
      const lastRow = floor(maxIndex / cols) === prevRow;
      if (isIndexOutOfListBounds(listRef, nextIndex)) {
        if (loopFocus && lastRow) {
          nextIndex = event.key === (rtl ? ARROW_RIGHT : ARROW_LEFT) ? maxIndex : findNonDisabledListIndex(listRef, {
            startingIndex: prevIndex - prevIndex % cols - 1,
            disabledIndices
          });
        } else {
          nextIndex = prevIndex;
        }
      }
    }
    return nextIndex;
  }
  function createGridCellMap(sizes, cols, dense) {
    const cellMap = [];
    let startIndex = 0;
    sizes.forEach(({
      width,
      height
    }, index2) => {
      if (width > cols) {
        if (true) {
          throw new Error(`[Floating UI]: Invalid grid - item width at index ${index2} is greater than grid columns`);
        }
      }
      let itemPlaced = false;
      if (dense) {
        startIndex = 0;
      }
      while (!itemPlaced) {
        const targetCells = [];
        for (let i = 0; i < width; i += 1) {
          for (let j = 0; j < height; j += 1) {
            targetCells.push(startIndex + i + j * cols);
          }
        }
        if (startIndex % cols + width <= cols && targetCells.every((cell) => cellMap[cell] == null)) {
          targetCells.forEach((cell) => {
            cellMap[cell] = index2;
          });
          itemPlaced = true;
        } else {
          startIndex += 1;
        }
      }
    });
    return [...cellMap];
  }
  function getGridCellIndexOfCorner(index2, sizes, cellMap, cols, corner) {
    if (index2 === -1) {
      return -1;
    }
    const firstCellIndex = cellMap.indexOf(index2);
    const sizeItem = sizes[index2];
    switch (corner) {
      case "tl":
        return firstCellIndex;
      case "tr":
        if (!sizeItem) {
          return firstCellIndex;
        }
        return firstCellIndex + sizeItem.width - 1;
      case "bl":
        if (!sizeItem) {
          return firstCellIndex;
        }
        return firstCellIndex + (sizeItem.height - 1) * cols;
      case "br":
        return cellMap.lastIndexOf(index2);
      default:
        return -1;
    }
  }
  function getGridCellIndices(indices, cellMap) {
    return cellMap.flatMap((index2, cellIndex) => indices.includes(index2) ? [cellIndex] : []);
  }
  function isListIndexDisabled(listRef, index2, disabledIndices) {
    const isExplicitlyDisabled = typeof disabledIndices === "function" ? disabledIndices(index2) : disabledIndices?.includes(index2) ?? false;
    if (isExplicitlyDisabled) {
      return true;
    }
    const element = listRef.current[index2];
    if (!element) {
      return false;
    }
    if (!isElementVisible(element)) {
      return true;
    }
    return !disabledIndices && (element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true");
  }
  function isElementVisible(element) {
    return getComputedStyle2(element).display !== "none";
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/tabbable.js
  init_define_import_meta_env();

  // node_modules/tabbable/dist/index.esm.js
  init_define_import_meta_env();
  var candidateSelectors = ["input:not([inert]):not([inert] *)", "select:not([inert]):not([inert] *)", "textarea:not([inert]):not([inert] *)", "a[href]:not([inert]):not([inert] *)", "button:not([inert]):not([inert] *)", "[tabindex]:not(slot):not([inert]):not([inert] *)", "audio[controls]:not([inert]):not([inert] *)", "video[controls]:not([inert]):not([inert] *)", '[contenteditable]:not([contenteditable="false"]):not([inert]):not([inert] *)', "details>summary:first-of-type:not([inert]):not([inert] *)", "details:not([inert]):not([inert] *)"];
  var candidateSelector = /* @__PURE__ */ candidateSelectors.join(",");
  var NoElement = typeof Element === "undefined";
  var matches = NoElement ? function() {
  } : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
  var getRootNode = !NoElement && Element.prototype.getRootNode ? function(element) {
    var _element$getRootNode;
    return element === null || element === void 0 ? void 0 : (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
  } : function(element) {
    return element === null || element === void 0 ? void 0 : element.ownerDocument;
  };
  var _isInert = function isInert(node, lookUp) {
    var _node$getAttribute;
    if (lookUp === void 0) {
      lookUp = true;
    }
    var inertAtt = node === null || node === void 0 ? void 0 : (_node$getAttribute = node.getAttribute) === null || _node$getAttribute === void 0 ? void 0 : _node$getAttribute.call(node, "inert");
    var inert = inertAtt === "" || inertAtt === "true";
    var result = inert || lookUp && node && // closest does not exist on shadow roots, so we fall back to a manual
    // lookup upward, in case it is not defined.
    (typeof node.closest === "function" ? node.closest("[inert]") : _isInert(node.parentNode));
    return result;
  };
  var isContentEditable = function isContentEditable2(node) {
    var _node$getAttribute2;
    var attValue = node === null || node === void 0 ? void 0 : (_node$getAttribute2 = node.getAttribute) === null || _node$getAttribute2 === void 0 ? void 0 : _node$getAttribute2.call(node, "contenteditable");
    return attValue === "" || attValue === "true";
  };
  var getCandidates = function getCandidates2(el, includeContainer, filter) {
    if (_isInert(el)) {
      return [];
    }
    var candidates = Array.prototype.slice.apply(el.querySelectorAll(candidateSelector));
    if (includeContainer && matches.call(el, candidateSelector)) {
      candidates.unshift(el);
    }
    candidates = candidates.filter(filter);
    return candidates;
  };
  var _getCandidatesIteratively = function getCandidatesIteratively(elements, includeContainer, options) {
    var candidates = [];
    var elementsToCheck = Array.from(elements);
    while (elementsToCheck.length) {
      var element = elementsToCheck.shift();
      if (_isInert(element, false)) {
        continue;
      }
      if (element.tagName === "SLOT") {
        var assigned = element.assignedElements();
        var content = assigned.length ? assigned : element.children;
        var nestedCandidates = _getCandidatesIteratively(content, true, options);
        if (options.flatten) {
          candidates.push.apply(candidates, nestedCandidates);
        } else {
          candidates.push({
            scopeParent: element,
            candidates: nestedCandidates
          });
        }
      } else {
        var validCandidate = matches.call(element, candidateSelector);
        if (validCandidate && options.filter(element) && (includeContainer || !elements.includes(element))) {
          candidates.push(element);
        }
        var shadowRoot = element.shadowRoot || // check for an undisclosed shadow
        typeof options.getShadowRoot === "function" && options.getShadowRoot(element);
        var validShadowRoot = !_isInert(shadowRoot, false) && (!options.shadowRootFilter || options.shadowRootFilter(element));
        if (shadowRoot && validShadowRoot) {
          var _nestedCandidates = _getCandidatesIteratively(shadowRoot === true ? element.children : shadowRoot.children, true, options);
          if (options.flatten) {
            candidates.push.apply(candidates, _nestedCandidates);
          } else {
            candidates.push({
              scopeParent: element,
              candidates: _nestedCandidates
            });
          }
        } else {
          elementsToCheck.unshift.apply(elementsToCheck, element.children);
        }
      }
    }
    return candidates;
  };
  var hasTabIndex = function hasTabIndex2(node) {
    return !isNaN(parseInt(node.getAttribute("tabindex"), 10));
  };
  var getTabIndex = function getTabIndex2(node) {
    if (!node) {
      throw new Error("No node provided");
    }
    if (node.tabIndex < 0) {
      if ((/^(AUDIO|VIDEO|DETAILS)$/.test(node.tagName) || isContentEditable(node)) && !hasTabIndex(node)) {
        return 0;
      }
    }
    return node.tabIndex;
  };
  var getSortOrderTabIndex = function getSortOrderTabIndex2(node, isScope) {
    var tabIndex = getTabIndex(node);
    if (tabIndex < 0 && isScope && !hasTabIndex(node)) {
      return 0;
    }
    return tabIndex;
  };
  var sortOrderedTabbables = function sortOrderedTabbables2(a, b) {
    return a.tabIndex === b.tabIndex ? a.documentOrder - b.documentOrder : a.tabIndex - b.tabIndex;
  };
  var isInput = function isInput2(node) {
    return node.tagName === "INPUT";
  };
  var isHiddenInput = function isHiddenInput2(node) {
    return isInput(node) && node.type === "hidden";
  };
  var isDetailsWithSummary = function isDetailsWithSummary2(node) {
    var r2 = node.tagName === "DETAILS" && Array.prototype.slice.apply(node.children).some(function(child) {
      return child.tagName === "SUMMARY";
    });
    return r2;
  };
  var getCheckedRadio = function getCheckedRadio2(nodes, form) {
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].checked && nodes[i].form === form) {
        return nodes[i];
      }
    }
  };
  var isTabbableRadio = function isTabbableRadio2(node) {
    if (!node.name) {
      return true;
    }
    var radioScope = node.form || getRootNode(node);
    var queryRadios = function queryRadios2(name) {
      return radioScope.querySelectorAll('input[type="radio"][name="' + name + '"]');
    };
    var radioSet;
    if (typeof window !== "undefined" && typeof window.CSS !== "undefined" && typeof window.CSS.escape === "function") {
      radioSet = queryRadios(window.CSS.escape(node.name));
    } else {
      try {
        radioSet = queryRadios(node.name);
      } catch (err) {
        console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", err.message);
        return false;
      }
    }
    var checked = getCheckedRadio(radioSet, node.form);
    return !checked || checked === node;
  };
  var isRadio = function isRadio2(node) {
    return isInput(node) && node.type === "radio";
  };
  var isNonTabbableRadio = function isNonTabbableRadio2(node) {
    return isRadio(node) && !isTabbableRadio(node);
  };
  var isNodeAttached = function isNodeAttached2(node) {
    var _nodeRoot;
    var nodeRoot = node && getRootNode(node);
    var nodeRootHost = (_nodeRoot = nodeRoot) === null || _nodeRoot === void 0 ? void 0 : _nodeRoot.host;
    var attached = false;
    if (nodeRoot && nodeRoot !== node) {
      var _nodeRootHost, _nodeRootHost$ownerDo, _node$ownerDocument;
      attached = !!((_nodeRootHost = nodeRootHost) !== null && _nodeRootHost !== void 0 && (_nodeRootHost$ownerDo = _nodeRootHost.ownerDocument) !== null && _nodeRootHost$ownerDo !== void 0 && _nodeRootHost$ownerDo.contains(nodeRootHost) || node !== null && node !== void 0 && (_node$ownerDocument = node.ownerDocument) !== null && _node$ownerDocument !== void 0 && _node$ownerDocument.contains(node));
      while (!attached && nodeRootHost) {
        var _nodeRoot2, _nodeRootHost2, _nodeRootHost2$ownerD;
        nodeRoot = getRootNode(nodeRootHost);
        nodeRootHost = (_nodeRoot2 = nodeRoot) === null || _nodeRoot2 === void 0 ? void 0 : _nodeRoot2.host;
        attached = !!((_nodeRootHost2 = nodeRootHost) !== null && _nodeRootHost2 !== void 0 && (_nodeRootHost2$ownerD = _nodeRootHost2.ownerDocument) !== null && _nodeRootHost2$ownerD !== void 0 && _nodeRootHost2$ownerD.contains(nodeRootHost));
      }
    }
    return attached;
  };
  var isZeroArea = function isZeroArea2(node) {
    var _node$getBoundingClie = node.getBoundingClientRect(), width = _node$getBoundingClie.width, height = _node$getBoundingClie.height;
    return width === 0 && height === 0;
  };
  var isHidden = function isHidden2(node, _ref) {
    var displayCheck = _ref.displayCheck, getShadowRoot = _ref.getShadowRoot;
    if (displayCheck === "full-native") {
      if ("checkVisibility" in node) {
        var visible = node.checkVisibility({
          // Checking opacity might be desirable for some use cases, but natively,
          // opacity zero elements _are_ focusable and tabbable.
          checkOpacity: false,
          opacityProperty: false,
          contentVisibilityAuto: true,
          visibilityProperty: true,
          // This is an alias for `visibilityProperty`. Contemporary browsers
          // support both. However, this alias has wider browser support (Chrome
          // >= 105 and Firefox >= 106, vs. Chrome >= 121 and Firefox >= 122), so
          // we include it anyway.
          checkVisibilityCSS: true
        });
        return !visible;
      }
    }
    if (getComputedStyle(node).visibility === "hidden") {
      return true;
    }
    var isDirectSummary = matches.call(node, "details>summary:first-of-type");
    var nodeUnderDetails = isDirectSummary ? node.parentElement : node;
    if (matches.call(nodeUnderDetails, "details:not([open]) *")) {
      return true;
    }
    if (!displayCheck || displayCheck === "full" || // full-native can run this branch when it falls through in case
    // Element#checkVisibility is unsupported
    displayCheck === "full-native" || displayCheck === "legacy-full") {
      if (typeof getShadowRoot === "function") {
        var originalNode = node;
        while (node) {
          var parentElement = node.parentElement;
          var rootNode = getRootNode(node);
          if (parentElement && !parentElement.shadowRoot && getShadowRoot(parentElement) === true) {
            return isZeroArea(node);
          } else if (node.assignedSlot) {
            node = node.assignedSlot;
          } else if (!parentElement && rootNode !== node.ownerDocument) {
            node = rootNode.host;
          } else {
            node = parentElement;
          }
        }
        node = originalNode;
      }
      if (isNodeAttached(node)) {
        return !node.getClientRects().length;
      }
      if (displayCheck !== "legacy-full") {
        return true;
      }
    } else if (displayCheck === "non-zero-area") {
      return isZeroArea(node);
    }
    return false;
  };
  var isDisabledFromFieldset = function isDisabledFromFieldset2(node) {
    if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(node.tagName)) {
      var parentNode = node.parentElement;
      while (parentNode) {
        if (parentNode.tagName === "FIELDSET" && parentNode.disabled) {
          for (var i = 0; i < parentNode.children.length; i++) {
            var child = parentNode.children.item(i);
            if (child.tagName === "LEGEND") {
              return matches.call(parentNode, "fieldset[disabled] *") ? true : !child.contains(node);
            }
          }
          return true;
        }
        parentNode = parentNode.parentElement;
      }
    }
    return false;
  };
  var isNodeMatchingSelectorFocusable = function isNodeMatchingSelectorFocusable2(options, node) {
    if (node.disabled || isHiddenInput(node) || isHidden(node, options) || // For a details element with a summary, the summary element gets the focus
    isDetailsWithSummary(node) || isDisabledFromFieldset(node)) {
      return false;
    }
    return true;
  };
  var isNodeMatchingSelectorTabbable = function isNodeMatchingSelectorTabbable2(options, node) {
    if (isNonTabbableRadio(node) || getTabIndex(node) < 0 || !isNodeMatchingSelectorFocusable(options, node)) {
      return false;
    }
    return true;
  };
  var isShadowRootTabbable = function isShadowRootTabbable2(shadowHostNode) {
    var tabIndex = parseInt(shadowHostNode.getAttribute("tabindex"), 10);
    if (isNaN(tabIndex) || tabIndex >= 0) {
      return true;
    }
    return false;
  };
  var _sortByOrder = function sortByOrder(candidates) {
    var regularTabbables = [];
    var orderedTabbables = [];
    candidates.forEach(function(item, i) {
      var isScope = !!item.scopeParent;
      var element = isScope ? item.scopeParent : item;
      var candidateTabindex = getSortOrderTabIndex(element, isScope);
      var elements = isScope ? _sortByOrder(item.candidates) : element;
      if (candidateTabindex === 0) {
        isScope ? regularTabbables.push.apply(regularTabbables, elements) : regularTabbables.push(element);
      } else {
        orderedTabbables.push({
          documentOrder: i,
          tabIndex: candidateTabindex,
          item,
          isScope,
          content: elements
        });
      }
    });
    return orderedTabbables.sort(sortOrderedTabbables).reduce(function(acc, sortable) {
      sortable.isScope ? acc.push.apply(acc, sortable.content) : acc.push(sortable.content);
      return acc;
    }, []).concat(regularTabbables);
  };
  var tabbable = function tabbable2(container, options) {
    options = options || {};
    var candidates;
    if (options.getShadowRoot) {
      candidates = _getCandidatesIteratively([container], options.includeContainer, {
        filter: isNodeMatchingSelectorTabbable.bind(null, options),
        flatten: false,
        getShadowRoot: options.getShadowRoot,
        shadowRootFilter: isShadowRootTabbable
      });
    } else {
      candidates = getCandidates(container, options.includeContainer, isNodeMatchingSelectorTabbable.bind(null, options));
    }
    return _sortByOrder(candidates);
  };
  var focusable = function focusable2(container, options) {
    options = options || {};
    var candidates;
    if (options.getShadowRoot) {
      candidates = _getCandidatesIteratively([container], options.includeContainer, {
        filter: isNodeMatchingSelectorFocusable.bind(null, options),
        flatten: true,
        getShadowRoot: options.getShadowRoot
      });
    } else {
      candidates = getCandidates(container, options.includeContainer, isNodeMatchingSelectorFocusable.bind(null, options));
    }
    return candidates;
  };
  var isTabbable = function isTabbable2(node, options) {
    options = options || {};
    if (!node) {
      throw new Error("No node provided");
    }
    if (matches.call(node, candidateSelector) === false) {
      return false;
    }
    return isNodeMatchingSelectorTabbable(options, node);
  };

  // node_modules/@base-ui/utils/esm/owner.js
  init_define_import_meta_env();
  function ownerDocument(node) {
    return node?.ownerDocument || document;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/tabbable.js
  var getTabbableOptions = () => ({
    getShadowRoot: true,
    displayCheck: (
      // JSDOM does not support the `tabbable` library. To solve this we can
      // check if `ResizeObserver` is a real function (not polyfilled), which
      // determines if the current environment is JSDOM-like.
      typeof ResizeObserver === "function" && ResizeObserver.toString().includes("[native code]") ? "full" : "none"
    )
  });
  function getTabbableIn(container, dir) {
    const list = tabbable(container, getTabbableOptions());
    const len = list.length;
    if (len === 0) {
      return void 0;
    }
    const active = activeElement(ownerDocument(container));
    const index2 = list.indexOf(active);
    const nextIndex = index2 === -1 ? dir === 1 ? 0 : len - 1 : index2 + dir;
    return list[nextIndex];
  }
  function getNextTabbable(referenceElement) {
    return getTabbableIn(ownerDocument(referenceElement).body, 1) || referenceElement;
  }
  function getPreviousTabbable(referenceElement) {
    return getTabbableIn(ownerDocument(referenceElement).body, -1) || referenceElement;
  }
  function getTabbableNearElement(referenceElement, dir) {
    if (!referenceElement) {
      return null;
    }
    const list = tabbable(ownerDocument(referenceElement).body, getTabbableOptions());
    const elementCount = list.length;
    if (elementCount === 0) {
      return null;
    }
    const index2 = list.indexOf(referenceElement);
    if (index2 === -1) {
      return null;
    }
    const nextIndex = (index2 + dir + elementCount) % elementCount;
    return list[nextIndex];
  }
  function getTabbableAfterElement(referenceElement) {
    return getTabbableNearElement(referenceElement, 1);
  }
  function getTabbableBeforeElement(referenceElement) {
    return getTabbableNearElement(referenceElement, -1);
  }
  function isOutsideEvent(event, container) {
    const containerElement = container || event.currentTarget;
    const relatedTarget = event.relatedTarget;
    return !relatedTarget || !contains(containerElement, relatedTarget);
  }
  function disableFocusInside(container) {
    const tabbableElements = tabbable(container, getTabbableOptions());
    tabbableElements.forEach((element) => {
      element.dataset.tabindex = element.getAttribute("tabindex") || "";
      element.setAttribute("tabindex", "-1");
    });
  }
  function enableFocusInside(container) {
    const elements = container.querySelectorAll("[data-tabindex]");
    elements.forEach((element) => {
      const tabindex = element.dataset.tabindex;
      delete element.dataset.tabindex;
      if (tabindex) {
        element.setAttribute("tabindex", tabindex);
      } else {
        element.removeAttribute("tabindex");
      }
    });
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverShared.js
  function resolveValue(value, pointerType) {
    if (pointerType != null && !isMouseLikePointerType(pointerType)) {
      return 0;
    }
    if (typeof value === "function") {
      return value();
    }
    return value;
  }
  function getDelay(value, prop, pointerType) {
    const result = resolveValue(value, pointerType);
    if (typeof result === "number") {
      return result;
    }
    return result?.[prop];
  }
  function getRestMs(value) {
    if (typeof value === "function") {
      return value();
    }
    return value;
  }
  function isClickLikeOpenEvent(openEventType, interactedInside) {
    return interactedInside || openEventType === "click" || openEventType === "mousedown";
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingDelayGroup.js
  var import_jsx_runtime5 = __toESM(require_react_shim(), 1);
  var FloatingDelayGroupContext = /* @__PURE__ */ React25.createContext({
    hasProvider: false,
    timeoutMs: 0,
    delayRef: {
      current: 0
    },
    initialDelayRef: {
      current: 0
    },
    timeout: new Timeout(),
    currentIdRef: {
      current: null
    },
    currentContextRef: {
      current: null
    }
  });
  if (true) FloatingDelayGroupContext.displayName = "FloatingDelayGroupContext";
  function FloatingDelayGroup(props) {
    const {
      children,
      delay,
      timeoutMs = 0
    } = props;
    const delayRef = React25.useRef(delay);
    const initialDelayRef = React25.useRef(delay);
    const currentIdRef = React25.useRef(null);
    const currentContextRef = React25.useRef(null);
    const timeout = useTimeout();
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FloatingDelayGroupContext.Provider, {
      value: React25.useMemo(() => ({
        hasProvider: true,
        delayRef,
        initialDelayRef,
        currentIdRef,
        timeoutMs,
        currentContextRef,
        timeout
      }), [timeoutMs, timeout]),
      children
    });
  }
  function useDelayGroup(context, options = {
    open: false
  }) {
    const store = "rootStore" in context ? context.rootStore : context;
    const floatingId = store.useState("floatingId");
    const {
      open
    } = options;
    const groupContext = React25.useContext(FloatingDelayGroupContext);
    const {
      currentIdRef,
      delayRef,
      timeoutMs,
      initialDelayRef,
      currentContextRef,
      hasProvider,
      timeout
    } = groupContext;
    const [isInstantPhase, setIsInstantPhase] = React25.useState(false);
    useIsoLayoutEffect(() => {
      function unset() {
        setIsInstantPhase(false);
        currentContextRef.current?.setIsInstantPhase(false);
        currentIdRef.current = null;
        currentContextRef.current = null;
        delayRef.current = initialDelayRef.current;
      }
      if (!currentIdRef.current) {
        return void 0;
      }
      if (!open && currentIdRef.current === floatingId) {
        setIsInstantPhase(false);
        if (timeoutMs) {
          const closingId = floatingId;
          timeout.start(timeoutMs, () => {
            if (store.select("open") || currentIdRef.current && currentIdRef.current !== closingId) {
              return;
            }
            unset();
          });
          return () => {
            timeout.clear();
          };
        }
        unset();
      }
      return void 0;
    }, [open, floatingId, currentIdRef, delayRef, timeoutMs, initialDelayRef, currentContextRef, timeout, store]);
    useIsoLayoutEffect(() => {
      if (!open) {
        return;
      }
      const prevContext = currentContextRef.current;
      const prevId = currentIdRef.current;
      timeout.clear();
      currentContextRef.current = {
        onOpenChange: store.setOpen,
        setIsInstantPhase
      };
      currentIdRef.current = floatingId;
      delayRef.current = {
        open: 0,
        close: getDelay(initialDelayRef.current, "close")
      };
      if (prevId !== null && prevId !== floatingId) {
        setIsInstantPhase(true);
        prevContext?.setIsInstantPhase(true);
        prevContext?.onOpenChange(false, createChangeEventDetails(reason_parts_exports.none));
      } else {
        setIsInstantPhase(false);
        prevContext?.setIsInstantPhase(false);
      }
    }, [open, floatingId, store, currentIdRef, delayRef, timeoutMs, initialDelayRef, currentContextRef, timeout]);
    useIsoLayoutEffect(() => {
      return () => {
        currentContextRef.current = null;
      };
    }, [currentContextRef]);
    return React25.useMemo(() => ({
      hasProvider,
      delayRef,
      isInstantPhase
    }), [hasProvider, delayRef, isInstantPhase]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingFocusManager.js
  init_define_import_meta_env();
  var React29 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useValueAsRef.js
  init_define_import_meta_env();
  function useValueAsRef(value) {
    const latest = useRefWithInit(createLatestRef, value).current;
    latest.next = value;
    useIsoLayoutEffect(latest.effect);
    return latest;
  }
  function createLatestRef(value) {
    const latest = {
      current: value,
      next: value,
      effect: () => {
        latest.current = latest.next;
      }
    };
    return latest;
  }

  // node_modules/@base-ui/react/esm/utils/FocusGuard.js
  init_define_import_meta_env();
  var React26 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/visuallyHidden.js
  init_define_import_meta_env();
  var visuallyHiddenBase = {
    clipPath: "inset(50%)",
    overflow: "hidden",
    whiteSpace: "nowrap",
    border: 0,
    padding: 0,
    width: 1,
    height: 1,
    margin: -1
  };
  var visuallyHidden = {
    ...visuallyHiddenBase,
    position: "fixed",
    top: 0,
    left: 0
  };
  var visuallyHiddenInput = {
    ...visuallyHiddenBase,
    position: "absolute"
  };

  // node_modules/@base-ui/react/esm/utils/FocusGuard.js
  var import_jsx_runtime6 = __toESM(require_react_shim(), 1);
  var FocusGuard = /* @__PURE__ */ React26.forwardRef(function FocusGuard2(props, ref) {
    const [role, setRole] = React26.useState();
    useIsoLayoutEffect(() => {
      if (isSafari) {
        setRole("button");
      }
    }, []);
    const restProps = {
      tabIndex: 0,
      // Role is only for VoiceOver
      role
    };
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", {
      ...props,
      ref,
      style: visuallyHidden,
      "aria-hidden": role ? void 0 : true,
      ...restProps,
      "data-base-ui-focus-guard": ""
    });
  });
  if (true) FocusGuard.displayName = "FocusGuard";

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/createAttribute.js
  init_define_import_meta_env();
  function createAttribute(name) {
    return `data-base-ui-${name}`;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/enqueueFocus.js
  init_define_import_meta_env();
  var rafId = 0;
  function enqueueFocus(el, options = {}) {
    const {
      preventScroll = false,
      cancelPrevious = true,
      sync = false
    } = options;
    if (cancelPrevious) {
      cancelAnimationFrame(rafId);
    }
    const exec = () => el?.focus({
      preventScroll
    });
    if (sync) {
      exec();
    } else {
      rafId = requestAnimationFrame(exec);
    }
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/markOthers.js
  init_define_import_meta_env();
  var counters = {
    inert: /* @__PURE__ */ new WeakMap(),
    "aria-hidden": /* @__PURE__ */ new WeakMap()
  };
  var markerName = "data-base-ui-inert";
  var uncontrolledElementsSets = {
    inert: /* @__PURE__ */ new WeakSet(),
    "aria-hidden": /* @__PURE__ */ new WeakSet()
  };
  var markerCounterMap = /* @__PURE__ */ new WeakMap();
  var lockCount = 0;
  function getUncontrolledElementsSet(controlAttribute) {
    return uncontrolledElementsSets[controlAttribute];
  }
  function unwrapHost(node) {
    if (!node) {
      return null;
    }
    return isShadowRoot(node) ? node.host : unwrapHost(node.parentNode);
  }
  var correctElements = (parent, targets) => targets.map((target) => {
    if (parent.contains(target)) {
      return target;
    }
    const correctedTarget = unwrapHost(target);
    if (parent.contains(correctedTarget)) {
      return correctedTarget;
    }
    return null;
  }).filter((x) => x != null);
  var buildKeepSet = (targets) => {
    const keep = /* @__PURE__ */ new Set();
    targets.forEach((target) => {
      let node = target;
      while (node && !keep.has(node)) {
        keep.add(node);
        node = node.parentNode;
      }
    });
    return keep;
  };
  var collectOutsideElements = (root, keepElements, stopElements) => {
    const outside = [];
    const walk = (parent) => {
      if (!parent || stopElements.has(parent)) {
        return;
      }
      Array.from(parent.children).forEach((node) => {
        if (getNodeName(node) === "script") {
          return;
        }
        if (keepElements.has(node)) {
          walk(node);
        } else {
          outside.push(node);
        }
      });
    };
    walk(root);
    return outside;
  };
  function applyAttributeToOthers(uncorrectedAvoidElements, body, ariaHidden, inert, {
    mark = true,
    markerIgnoreElements = []
  }) {
    const controlAttribute = inert ? "inert" : ariaHidden ? "aria-hidden" : null;
    let counterMap = null;
    let uncontrolledElementsSet = null;
    const avoidElements = correctElements(body, uncorrectedAvoidElements);
    const markerIgnoreTargets = mark ? correctElements(body, markerIgnoreElements) : [];
    const markerIgnoreSet = new Set(markerIgnoreTargets);
    const markerTargets = mark ? collectOutsideElements(body, buildKeepSet(avoidElements), new Set(avoidElements)).filter((target) => !markerIgnoreSet.has(target)) : [];
    const hiddenElements = [];
    const markedElements = [];
    if (controlAttribute) {
      const map = counters[controlAttribute];
      const currentUncontrolledElementsSet = getUncontrolledElementsSet(controlAttribute);
      uncontrolledElementsSet = currentUncontrolledElementsSet;
      counterMap = map;
      const ariaLiveElements = correctElements(body, Array.from(body.querySelectorAll("[aria-live]")));
      const controlElements = avoidElements.concat(ariaLiveElements);
      const controlTargets = collectOutsideElements(body, buildKeepSet(controlElements), new Set(controlElements));
      controlTargets.forEach((node) => {
        const attr2 = node.getAttribute(controlAttribute);
        const alreadyHidden = attr2 !== null && attr2 !== "false";
        const counterValue = (map.get(node) || 0) + 1;
        map.set(node, counterValue);
        hiddenElements.push(node);
        if (counterValue === 1 && alreadyHidden) {
          currentUncontrolledElementsSet.add(node);
        }
        if (!alreadyHidden) {
          node.setAttribute(controlAttribute, controlAttribute === "inert" ? "" : "true");
        }
      });
    }
    if (mark) {
      markerTargets.forEach((node) => {
        const markerValue = (markerCounterMap.get(node) || 0) + 1;
        markerCounterMap.set(node, markerValue);
        markedElements.push(node);
        if (markerValue === 1) {
          node.setAttribute(markerName, "");
        }
      });
    }
    lockCount += 1;
    return () => {
      if (counterMap) {
        hiddenElements.forEach((element) => {
          const currentCounterValue = counterMap.get(element) || 0;
          const counterValue = currentCounterValue - 1;
          counterMap.set(element, counterValue);
          if (!counterValue) {
            if (!uncontrolledElementsSet?.has(element) && controlAttribute) {
              element.removeAttribute(controlAttribute);
            }
            uncontrolledElementsSet?.delete(element);
          }
        });
      }
      if (mark) {
        markedElements.forEach((element) => {
          const markerValue = (markerCounterMap.get(element) || 0) - 1;
          markerCounterMap.set(element, markerValue);
          if (!markerValue) {
            element.removeAttribute(markerName);
          }
        });
      }
      lockCount -= 1;
      if (!lockCount) {
        counters.inert = /* @__PURE__ */ new WeakMap();
        counters["aria-hidden"] = /* @__PURE__ */ new WeakMap();
        uncontrolledElementsSets.inert = /* @__PURE__ */ new WeakSet();
        uncontrolledElementsSets["aria-hidden"] = /* @__PURE__ */ new WeakSet();
        markerCounterMap = /* @__PURE__ */ new WeakMap();
      }
    };
  }
  function markOthers(avoidElements, options = {}) {
    const {
      ariaHidden = false,
      inert = false,
      mark = true,
      markerIgnoreElements = []
    } = options;
    const body = ownerDocument(avoidElements[0]).body;
    return applyAttributeToOthers(avoidElements, body, ariaHidden, inert, {
      mark,
      markerIgnoreElements
    });
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingPortal.js
  init_define_import_meta_env();
  var React27 = __toESM(require_react_shim(), 1);
  var ReactDOM2 = __toESM(require_react_dom_shim(), 1);
  var import_jsx_runtime7 = __toESM(require_react_shim(), 1);
  var PortalContext = /* @__PURE__ */ React27.createContext(null);
  if (true) PortalContext.displayName = "PortalContext";
  var usePortalContext = () => React27.useContext(PortalContext);
  var attr = createAttribute("portal");
  function useFloatingPortalNode(props = {}) {
    const {
      ref,
      container: containerProp,
      componentProps = EMPTY_OBJECT,
      elementProps
    } = props;
    const uniqueId = useId();
    const portalContext = usePortalContext();
    const parentPortalNode = portalContext?.portalNode;
    const [containerElement, setContainerElement] = React27.useState(null);
    const [portalNode, setPortalNode] = React27.useState(null);
    const setPortalNodeRef = useStableCallback((node) => {
      if (node !== null) {
        setPortalNode(node);
      }
    });
    const containerRef = React27.useRef(null);
    useIsoLayoutEffect(() => {
      if (containerProp === null) {
        if (containerRef.current) {
          containerRef.current = null;
          setPortalNode(null);
          setContainerElement(null);
        }
        return;
      }
      if (uniqueId == null) {
        return;
      }
      const resolvedContainer = (containerProp && (isNode(containerProp) ? containerProp : containerProp.current)) ?? parentPortalNode ?? document.body;
      if (resolvedContainer == null) {
        if (containerRef.current) {
          containerRef.current = null;
          setPortalNode(null);
          setContainerElement(null);
        }
        return;
      }
      if (containerRef.current !== resolvedContainer) {
        containerRef.current = resolvedContainer;
        setPortalNode(null);
        setContainerElement(resolvedContainer);
      }
    }, [containerProp, parentPortalNode, uniqueId]);
    const portalElement = useRenderElement("div", componentProps, {
      ref: [ref, setPortalNodeRef],
      props: [{
        id: uniqueId,
        [attr]: ""
      }, elementProps]
    });
    const portalSubtree = containerElement && portalElement ? /* @__PURE__ */ ReactDOM2.createPortal(portalElement, containerElement) : null;
    return {
      portalNode,
      portalSubtree
    };
  }
  var FloatingPortal = /* @__PURE__ */ React27.forwardRef(function FloatingPortal2(componentProps, forwardedRef) {
    const {
      children,
      container,
      className,
      render,
      renderGuards,
      ...elementProps
    } = componentProps;
    const {
      portalNode,
      portalSubtree
    } = useFloatingPortalNode({
      container,
      ref: forwardedRef,
      componentProps,
      elementProps
    });
    const beforeOutsideRef = React27.useRef(null);
    const afterOutsideRef = React27.useRef(null);
    const beforeInsideRef = React27.useRef(null);
    const afterInsideRef = React27.useRef(null);
    const [focusManagerState, setFocusManagerState] = React27.useState(null);
    const modal = focusManagerState?.modal;
    const open = focusManagerState?.open;
    const shouldRenderGuards = typeof renderGuards === "boolean" ? renderGuards : !!focusManagerState && !focusManagerState.modal && focusManagerState.open && !!portalNode;
    React27.useEffect(() => {
      if (!portalNode || modal) {
        return void 0;
      }
      function onFocus(event) {
        if (portalNode && event.relatedTarget && isOutsideEvent(event)) {
          const focusing = event.type === "focusin";
          const manageFocus = focusing ? enableFocusInside : disableFocusInside;
          manageFocus(portalNode);
        }
      }
      portalNode.addEventListener("focusin", onFocus, true);
      portalNode.addEventListener("focusout", onFocus, true);
      return () => {
        portalNode.removeEventListener("focusin", onFocus, true);
        portalNode.removeEventListener("focusout", onFocus, true);
      };
    }, [portalNode, modal]);
    React27.useEffect(() => {
      if (!portalNode || open) {
        return;
      }
      enableFocusInside(portalNode);
    }, [open, portalNode]);
    const portalContextValue = React27.useMemo(() => ({
      beforeOutsideRef,
      afterOutsideRef,
      beforeInsideRef,
      afterInsideRef,
      portalNode,
      setFocusManagerState
    }), [portalNode]);
    return /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(React27.Fragment, {
      children: [portalSubtree, /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(PortalContext.Provider, {
        value: portalContextValue,
        children: [shouldRenderGuards && portalNode && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(FocusGuard, {
          "data-type": "outside",
          ref: beforeOutsideRef,
          onFocus: (event) => {
            if (isOutsideEvent(event, portalNode)) {
              beforeInsideRef.current?.focus();
            } else {
              const domReference = focusManagerState ? focusManagerState.domReference : null;
              const prevTabbable = getPreviousTabbable(domReference);
              prevTabbable?.focus();
            }
          }
        }), shouldRenderGuards && portalNode && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", {
          "aria-owns": portalNode.id,
          style: ownerVisuallyHidden
        }), portalNode && /* @__PURE__ */ ReactDOM2.createPortal(children, portalNode), shouldRenderGuards && portalNode && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(FocusGuard, {
          "data-type": "outside",
          ref: afterOutsideRef,
          onFocus: (event) => {
            if (isOutsideEvent(event, portalNode)) {
              afterInsideRef.current?.focus();
            } else {
              const domReference = focusManagerState ? focusManagerState.domReference : null;
              const nextTabbable = getNextTabbable(domReference);
              nextTabbable?.focus();
              if (focusManagerState?.closeOnFocusOut) {
                focusManagerState?.onOpenChange(false, createChangeEventDetails(reason_parts_exports.focusOut, event.nativeEvent));
              }
            }
          }
        })]
      })]
    });
  });
  if (true) FloatingPortal.displayName = "FloatingPortal";

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingTree.js
  init_define_import_meta_env();
  var React28 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingTreeStore.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/createEventEmitter.js
  init_define_import_meta_env();
  function createEventEmitter() {
    const map = /* @__PURE__ */ new Map();
    return {
      emit(event, data) {
        map.get(event)?.forEach((listener) => listener(data));
      },
      on(event, listener) {
        if (!map.has(event)) {
          map.set(event, /* @__PURE__ */ new Set());
        }
        map.get(event).add(listener);
      },
      off(event, listener) {
        map.get(event)?.delete(listener);
      }
    };
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingTreeStore.js
  var FloatingTreeStore = class {
    constructor() {
      __publicField(this, "nodesRef", {
        current: []
      });
      __publicField(this, "events", createEventEmitter());
    }
    addNode(node) {
      this.nodesRef.current.push(node);
    }
    removeNode(node) {
      const index2 = this.nodesRef.current.findIndex((n) => n === node);
      if (index2 !== -1) {
        this.nodesRef.current.splice(index2, 1);
      }
    }
  };

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingTree.js
  var import_jsx_runtime8 = __toESM(require_react_shim(), 1);
  var FloatingNodeContext = /* @__PURE__ */ React28.createContext(null);
  if (true) FloatingNodeContext.displayName = "FloatingNodeContext";
  var FloatingTreeContext = /* @__PURE__ */ React28.createContext(null);
  if (true) FloatingTreeContext.displayName = "FloatingTreeContext";
  var useFloatingParentNodeId = () => React28.useContext(FloatingNodeContext)?.id || null;
  var useFloatingTree = (externalTree) => {
    const contextTree = React28.useContext(FloatingTreeContext);
    return externalTree ?? contextTree;
  };
  function useFloatingNodeId(externalTree) {
    const id = useId();
    const tree = useFloatingTree(externalTree);
    const parentId = useFloatingParentNodeId();
    useIsoLayoutEffect(() => {
      if (!id) {
        return void 0;
      }
      const node = {
        id,
        parentId
      };
      tree?.addNode(node);
      return () => {
        tree?.removeNode(node);
      };
    }, [tree, id, parentId]);
    return id;
  }
  function FloatingNode(props) {
    const {
      children,
      id
    } = props;
    const parentId = useFloatingParentNodeId();
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(FloatingNodeContext.Provider, {
      value: React28.useMemo(() => ({
        id,
        parentId
      }), [id, parentId]),
      children
    });
  }
  function FloatingTree(props) {
    const {
      children,
      externalTree
    } = props;
    const tree = useRefWithInit(() => externalTree ?? new FloatingTreeStore()).current;
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(FloatingTreeContext.Provider, {
      value: tree,
      children
    });
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingFocusManager.js
  var import_jsx_runtime9 = __toESM(require_react_shim(), 1);
  function getEventType(event, lastInteractionType) {
    const win = getWindow(event.target);
    if (event instanceof win.KeyboardEvent) {
      return "keyboard";
    }
    if (event instanceof win.FocusEvent) {
      return lastInteractionType || "keyboard";
    }
    if ("pointerType" in event) {
      return event.pointerType || "keyboard";
    }
    if ("touches" in event) {
      return "touch";
    }
    if (event instanceof win.MouseEvent) {
      return lastInteractionType || (event.detail === 0 ? "keyboard" : "mouse");
    }
    return "";
  }
  var LIST_LIMIT = 20;
  var previouslyFocusedElements = [];
  function clearDisconnectedPreviouslyFocusedElements() {
    previouslyFocusedElements = previouslyFocusedElements.filter((entry) => {
      return entry.deref()?.isConnected;
    });
  }
  function addPreviouslyFocusedElement(element) {
    clearDisconnectedPreviouslyFocusedElements();
    if (element && getNodeName(element) !== "body") {
      previouslyFocusedElements.push(new WeakRef(element));
      if (previouslyFocusedElements.length > LIST_LIMIT) {
        previouslyFocusedElements = previouslyFocusedElements.slice(-LIST_LIMIT);
      }
    }
  }
  function getPreviouslyFocusedElement() {
    clearDisconnectedPreviouslyFocusedElements();
    return previouslyFocusedElements[previouslyFocusedElements.length - 1]?.deref();
  }
  function getFirstTabbableElement(container) {
    if (!container) {
      return null;
    }
    const tabbableOptions = getTabbableOptions();
    if (isTabbable(container, tabbableOptions)) {
      return container;
    }
    return tabbable(container, tabbableOptions)[0] || container;
  }
  function isFocusable(element) {
    if (!element || !element.isConnected) {
      return false;
    }
    if (typeof element.checkVisibility === "function") {
      return element.checkVisibility();
    }
    return isElementVisible(element);
  }
  function handleTabIndex(floatingFocusElement, orderRef) {
    if (!orderRef.current.includes("floating") && !floatingFocusElement.getAttribute("role")?.includes("dialog")) {
      return;
    }
    const options = getTabbableOptions();
    const focusableElements = focusable(floatingFocusElement, options);
    const tabbableContent = focusableElements.filter((element) => {
      const dataTabIndex = element.getAttribute("data-tabindex") || "";
      return isTabbable(element, options) || element.hasAttribute("data-tabindex") && !dataTabIndex.startsWith("-");
    });
    const tabIndex = floatingFocusElement.getAttribute("tabindex");
    if (orderRef.current.includes("floating") || tabbableContent.length === 0) {
      if (tabIndex !== "0") {
        floatingFocusElement.setAttribute("tabindex", "0");
      }
    } else if (tabIndex !== "-1" || floatingFocusElement.hasAttribute("data-tabindex") && floatingFocusElement.getAttribute("data-tabindex") !== "-1") {
      floatingFocusElement.setAttribute("tabindex", "-1");
      floatingFocusElement.setAttribute("data-tabindex", "-1");
    }
  }
  function FloatingFocusManager(props) {
    const {
      context,
      children,
      disabled: disabled2 = false,
      initialFocus = true,
      returnFocus = true,
      restoreFocus = false,
      modal = true,
      closeOnFocusOut = true,
      openInteractionType = "",
      nextFocusableElement,
      previousFocusableElement,
      beforeContentFocusGuardRef,
      externalTree,
      getInsideElements
    } = props;
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const domReference = store.useState("domReferenceElement");
    const floating = store.useState("floatingElement");
    const {
      events,
      dataRef
    } = store.context;
    const getNodeId = useStableCallback(() => dataRef.current.floatingContext?.nodeId);
    const ignoreInitialFocus = initialFocus === false;
    const isUntrappedTypeableCombobox = isTypeableCombobox(domReference) && ignoreInitialFocus;
    const orderRef = React29.useRef(["content"]);
    const initialFocusRef = useValueAsRef(initialFocus);
    const returnFocusRef = useValueAsRef(returnFocus);
    const openInteractionTypeRef = useValueAsRef(openInteractionType);
    const tree = useFloatingTree(externalTree);
    const portalContext = usePortalContext();
    const preventReturnFocusRef = React29.useRef(false);
    const isPointerDownRef = React29.useRef(false);
    const pointerDownOutsideRef = React29.useRef(false);
    const tabbableIndexRef = React29.useRef(-1);
    const closeTypeRef = React29.useRef("");
    const lastInteractionTypeRef = React29.useRef("");
    const beforeGuardRef = React29.useRef(null);
    const afterGuardRef = React29.useRef(null);
    const mergedBeforeGuardRef = useMergedRefs(beforeGuardRef, beforeContentFocusGuardRef, portalContext?.beforeInsideRef);
    const mergedAfterGuardRef = useMergedRefs(afterGuardRef, portalContext?.afterInsideRef);
    const blurTimeout = useTimeout();
    const pointerDownTimeout = useTimeout();
    const restoreFocusFrame = useAnimationFrame();
    const isInsidePortal = portalContext != null;
    const floatingFocusElement = getFloatingFocusElement(floating);
    const getTabbableContent = useStableCallback((container = floatingFocusElement) => {
      return container ? tabbable(container, getTabbableOptions()) : [];
    });
    const getResolvedInsideElements = useStableCallback(() => getInsideElements?.().filter((element) => element != null) ?? []);
    const getTabbableElements = useStableCallback((container) => {
      const content = getTabbableContent(container);
      return orderRef.current.map(() => content).filter(Boolean).flat();
    });
    React29.useEffect(() => {
      if (disabled2 || !modal) {
        return void 0;
      }
      function onKeyDown(event) {
        if (event.key === "Tab") {
          if (contains(floatingFocusElement, activeElement(ownerDocument(floatingFocusElement))) && getTabbableContent().length === 0 && !isUntrappedTypeableCombobox) {
            stopEvent(event);
          }
        }
      }
      const doc = ownerDocument(floatingFocusElement);
      doc.addEventListener("keydown", onKeyDown);
      return () => {
        doc.removeEventListener("keydown", onKeyDown);
      };
    }, [disabled2, domReference, floatingFocusElement, modal, orderRef, isUntrappedTypeableCombobox, getTabbableContent, getTabbableElements]);
    React29.useEffect(() => {
      if (disabled2 || !open) {
        return void 0;
      }
      const doc = ownerDocument(floatingFocusElement);
      function clearPointerDownOutside() {
        pointerDownOutsideRef.current = false;
      }
      function onPointerDown(event) {
        const target = getTarget(event);
        const insideElements = getResolvedInsideElements();
        const pointerTargetInside = contains(floating, target) || contains(domReference, target) || contains(portalContext?.portalNode, target) || insideElements.some((element) => element === target || contains(element, target));
        pointerDownOutsideRef.current = !pointerTargetInside;
        lastInteractionTypeRef.current = event.pointerType || "keyboard";
        if (target?.closest(`[${CLICK_TRIGGER_IDENTIFIER}]`)) {
          isPointerDownRef.current = true;
        }
      }
      function onKeyDown() {
        lastInteractionTypeRef.current = "keyboard";
      }
      doc.addEventListener("pointerdown", onPointerDown, true);
      doc.addEventListener("pointerup", clearPointerDownOutside, true);
      doc.addEventListener("pointercancel", clearPointerDownOutside, true);
      doc.addEventListener("keydown", onKeyDown, true);
      return () => {
        doc.removeEventListener("pointerdown", onPointerDown, true);
        doc.removeEventListener("pointerup", clearPointerDownOutside, true);
        doc.removeEventListener("pointercancel", clearPointerDownOutside, true);
        doc.removeEventListener("keydown", onKeyDown, true);
      };
    }, [disabled2, floating, domReference, floatingFocusElement, open, portalContext, getResolvedInsideElements]);
    React29.useEffect(() => {
      if (disabled2 || !closeOnFocusOut) {
        return void 0;
      }
      const doc = ownerDocument(floatingFocusElement);
      function handlePointerDown() {
        isPointerDownRef.current = true;
        pointerDownTimeout.start(0, () => {
          isPointerDownRef.current = false;
        });
      }
      function handleFocusIn(event) {
        const target = getTarget(event);
        const tabbableContent = getTabbableContent();
        const tabbableIndex = tabbableContent.indexOf(target);
        if (tabbableIndex !== -1) {
          tabbableIndexRef.current = tabbableIndex;
        }
      }
      function handleFocusOutside(event) {
        const relatedTarget = event.relatedTarget;
        const currentTarget = event.currentTarget;
        const target = getTarget(event);
        queueMicrotask(() => {
          const nodeId = getNodeId();
          const triggers = store.context.triggerElements;
          const insideElements = getResolvedInsideElements();
          const isRelatedFocusGuard = relatedTarget?.hasAttribute(createAttribute("focus-guard")) && [beforeGuardRef.current, afterGuardRef.current, portalContext?.beforeInsideRef.current, portalContext?.afterInsideRef.current, portalContext?.beforeOutsideRef.current, portalContext?.afterOutsideRef.current, resolveRef(previousFocusableElement), resolveRef(nextFocusableElement)].includes(relatedTarget);
          const movedToUnrelatedNode = !(contains(domReference, relatedTarget) || contains(floating, relatedTarget) || contains(relatedTarget, floating) || contains(portalContext?.portalNode, relatedTarget) || insideElements.some((element) => element === relatedTarget || contains(element, relatedTarget)) || relatedTarget != null && triggers.hasElement(relatedTarget) || triggers.hasMatchingElement((trigger) => contains(trigger, relatedTarget)) || isRelatedFocusGuard || tree && (getNodeChildren(tree.nodesRef.current, nodeId).find((node) => contains(node.context?.elements.floating, relatedTarget) || contains(node.context?.elements.domReference, relatedTarget)) || getNodeAncestors(tree.nodesRef.current, nodeId).find((node) => [node.context?.elements.floating, getFloatingFocusElement(node.context?.elements.floating)].includes(relatedTarget) || node.context?.elements.domReference === relatedTarget)));
          if (currentTarget === domReference && floatingFocusElement) {
            handleTabIndex(floatingFocusElement, orderRef);
          }
          if (restoreFocus && currentTarget !== domReference && !isFocusable(target) && activeElement(doc) === doc.body) {
            if (isHTMLElement(floatingFocusElement)) {
              floatingFocusElement.focus();
              if (restoreFocus === "popup") {
                restoreFocusFrame.request(() => {
                  floatingFocusElement.focus();
                });
                return;
              }
            }
            const prevTabbableIndex = tabbableIndexRef.current;
            const tabbableContent = getTabbableContent();
            const nodeToFocus = tabbableContent[prevTabbableIndex] || tabbableContent[tabbableContent.length - 1] || floatingFocusElement;
            if (isHTMLElement(nodeToFocus)) {
              nodeToFocus.focus();
            }
          }
          if (dataRef.current.insideReactTree) {
            dataRef.current.insideReactTree = false;
            return;
          }
          if ((isUntrappedTypeableCombobox ? true : !modal) && relatedTarget && movedToUnrelatedNode && !isPointerDownRef.current && // Fix React 18 Strict Mode returnFocus due to double rendering.
          // For an "untrapped" typeable combobox (input role=combobox with
          // initialFocus=false), re-opening the popup and tabbing out should still close it even
          // when the previously focused element (e.g. the next tabbable outside the popup) is
          // focused again. Otherwise, the popup remains open on the second Tab sequence:
          // click input -> Tab (closes) -> click input -> Tab.
          // Allow closing when `isUntrappedTypeableCombobox` regardless of the previously focused element.
          (isUntrappedTypeableCombobox || relatedTarget !== getPreviouslyFocusedElement())) {
            preventReturnFocusRef.current = true;
            store.setOpen(false, createChangeEventDetails(reason_parts_exports.focusOut, event));
          }
        });
      }
      function markInsideReactTree() {
        if (pointerDownOutsideRef.current) {
          return;
        }
        dataRef.current.insideReactTree = true;
        blurTimeout.start(0, () => {
          dataRef.current.insideReactTree = false;
        });
      }
      const domReferenceElement = isHTMLElement(domReference) ? domReference : null;
      const cleanups = [];
      if (!floating && !domReferenceElement) {
        return void 0;
      }
      if (domReferenceElement) {
        domReferenceElement.addEventListener("focusout", handleFocusOutside);
        domReferenceElement.addEventListener("pointerdown", handlePointerDown);
        cleanups.push(() => {
          domReferenceElement.removeEventListener("focusout", handleFocusOutside);
          domReferenceElement.removeEventListener("pointerdown", handlePointerDown);
        });
      }
      if (floating) {
        floating.addEventListener("focusin", handleFocusIn);
        floating.addEventListener("focusout", handleFocusOutside);
        if (portalContext) {
          floating.addEventListener("focusout", markInsideReactTree, true);
          cleanups.push(() => {
            floating.removeEventListener("focusout", markInsideReactTree, true);
          });
        }
        cleanups.push(() => {
          floating.removeEventListener("focusin", handleFocusIn);
          floating.removeEventListener("focusout", handleFocusOutside);
        });
      }
      return () => {
        cleanups.forEach((cleanup) => {
          cleanup();
        });
      };
    }, [disabled2, domReference, floating, floatingFocusElement, modal, tree, portalContext, store, closeOnFocusOut, restoreFocus, getTabbableContent, isUntrappedTypeableCombobox, getNodeId, orderRef, dataRef, blurTimeout, pointerDownTimeout, restoreFocusFrame, nextFocusableElement, previousFocusableElement, getResolvedInsideElements]);
    React29.useEffect(() => {
      if (disabled2 || !floating || !open) {
        return void 0;
      }
      const portalNodes = Array.from(portalContext?.portalNode?.querySelectorAll(`[${createAttribute("portal")}]`) || []);
      const ancestors = tree ? getNodeAncestors(tree.nodesRef.current, getNodeId()) : [];
      const rootAncestorComboboxDomReference = ancestors.find((node) => isTypeableCombobox(node.context?.elements.domReference || null))?.context?.elements.domReference;
      const controlInsideElements = [floating, ...portalNodes, beforeGuardRef.current, afterGuardRef.current, portalContext?.beforeOutsideRef.current, portalContext?.afterOutsideRef.current, ...getResolvedInsideElements()];
      const insideElements = [...controlInsideElements, rootAncestorComboboxDomReference, resolveRef(previousFocusableElement), resolveRef(nextFocusableElement), isUntrappedTypeableCombobox ? domReference : null].filter((x) => x != null);
      const ariaHiddenCleanup = markOthers(insideElements, {
        ariaHidden: modal || isUntrappedTypeableCombobox,
        mark: false
      });
      const markerInsideElements = [floating, ...portalNodes].filter((x) => x != null);
      const markerCleanup = markOthers(markerInsideElements);
      return () => {
        markerCleanup();
        ariaHiddenCleanup();
      };
    }, [open, disabled2, domReference, floating, modal, orderRef, portalContext, isUntrappedTypeableCombobox, tree, getNodeId, nextFocusableElement, previousFocusableElement, getResolvedInsideElements]);
    useIsoLayoutEffect(() => {
      if (!open || disabled2 || !isHTMLElement(floatingFocusElement)) {
        return;
      }
      const doc = ownerDocument(floatingFocusElement);
      const previouslyFocusedElement = activeElement(doc);
      queueMicrotask(() => {
        const focusableElements = getTabbableElements(floatingFocusElement);
        const initialFocusValueOrFn = initialFocusRef.current;
        const resolvedInitialFocus = typeof initialFocusValueOrFn === "function" ? initialFocusValueOrFn(openInteractionTypeRef.current || "") : initialFocusValueOrFn;
        if (resolvedInitialFocus === void 0 || resolvedInitialFocus === false) {
          return;
        }
        let elToFocus;
        if (resolvedInitialFocus === true || resolvedInitialFocus === null) {
          elToFocus = focusableElements[0] || floatingFocusElement;
        } else {
          elToFocus = resolveRef(resolvedInitialFocus);
        }
        elToFocus = elToFocus || focusableElements[0] || floatingFocusElement;
        const focusAlreadyInsideFloatingEl = contains(floatingFocusElement, previouslyFocusedElement);
        if (focusAlreadyInsideFloatingEl) {
          return;
        }
        enqueueFocus(elToFocus, {
          preventScroll: elToFocus === floatingFocusElement
        });
      });
    }, [disabled2, open, floatingFocusElement, ignoreInitialFocus, getTabbableElements, initialFocusRef, openInteractionTypeRef]);
    useIsoLayoutEffect(() => {
      if (disabled2 || !floatingFocusElement) {
        return void 0;
      }
      const doc = ownerDocument(floatingFocusElement);
      const previouslyFocusedElement = activeElement(doc);
      addPreviouslyFocusedElement(previouslyFocusedElement);
      function onOpenChangeLocal(details) {
        if (!details.open) {
          closeTypeRef.current = getEventType(details.nativeEvent, lastInteractionTypeRef.current);
        }
        if (details.reason === reason_parts_exports.triggerHover && details.nativeEvent.type === "mouseleave") {
          preventReturnFocusRef.current = true;
        }
        if (details.reason !== reason_parts_exports.outsidePress) {
          return;
        }
        if (details.nested) {
          preventReturnFocusRef.current = false;
        } else if (isVirtualClick(details.nativeEvent) || isVirtualPointerEvent(details.nativeEvent)) {
          preventReturnFocusRef.current = false;
        } else {
          let isPreventScrollSupported = false;
          document.createElement("div").focus({
            get preventScroll() {
              isPreventScrollSupported = true;
              return false;
            }
          });
          if (isPreventScrollSupported) {
            preventReturnFocusRef.current = false;
          } else {
            preventReturnFocusRef.current = true;
          }
        }
      }
      events.on("openchange", onOpenChangeLocal);
      function getReturnElement() {
        const returnFocusValueOrFn = returnFocusRef.current;
        let resolvedReturnFocusValue = typeof returnFocusValueOrFn === "function" ? returnFocusValueOrFn(closeTypeRef.current) : returnFocusValueOrFn;
        if (resolvedReturnFocusValue === void 0 || resolvedReturnFocusValue === false) {
          return null;
        }
        if (resolvedReturnFocusValue === null) {
          resolvedReturnFocusValue = true;
        }
        if (typeof resolvedReturnFocusValue === "boolean") {
          const el = domReference || getPreviouslyFocusedElement();
          return el && el.isConnected ? el : null;
        }
        const fallback = domReference || getPreviouslyFocusedElement();
        return resolveRef(resolvedReturnFocusValue) || fallback || null;
      }
      return () => {
        events.off("openchange", onOpenChangeLocal);
        const activeEl = activeElement(doc);
        const insideElements = getResolvedInsideElements();
        const isFocusInsideFloatingTree = contains(floating, activeEl) || insideElements.some((element) => element === activeEl || contains(element, activeEl)) || tree && getNodeChildren(tree.nodesRef.current, getNodeId(), false).some((node) => contains(node.context?.elements.floating, activeEl));
        const returnElement = getReturnElement();
        queueMicrotask(() => {
          const tabbableReturnElement = getFirstTabbableElement(returnElement);
          const hasExplicitReturnFocus = typeof returnFocusRef.current !== "boolean";
          if (
            // eslint-disable-next-line react-hooks/exhaustive-deps
            returnFocusRef.current && !preventReturnFocusRef.current && isHTMLElement(tabbableReturnElement) && // If the focus moved somewhere else after mount, avoid returning focus
            // since it likely entered a different element which should be
            // respected: https://github.com/floating-ui/floating-ui/issues/2607
            (!hasExplicitReturnFocus && tabbableReturnElement !== activeEl && activeEl !== doc.body ? isFocusInsideFloatingTree : true)
          ) {
            tabbableReturnElement.focus({
              preventScroll: true
            });
          }
          preventReturnFocusRef.current = false;
        });
      };
    }, [disabled2, floating, floatingFocusElement, returnFocusRef, dataRef, events, tree, domReference, getNodeId, getResolvedInsideElements]);
    useIsoLayoutEffect(() => {
      if (!isWebKit2 || open || !floating) {
        return;
      }
      const activeEl = activeElement(ownerDocument(floating));
      if (!isHTMLElement(activeEl) || !isTypeableElement(activeEl)) {
        return;
      }
      if (contains(floating, activeEl)) {
        activeEl.blur();
      }
    }, [open, floating]);
    useIsoLayoutEffect(() => {
      if (disabled2 || !portalContext) {
        return void 0;
      }
      portalContext.setFocusManagerState({
        modal,
        closeOnFocusOut,
        open,
        onOpenChange: store.setOpen,
        domReference
      });
      return () => {
        portalContext.setFocusManagerState(null);
      };
    }, [disabled2, portalContext, modal, open, store, closeOnFocusOut, domReference]);
    useIsoLayoutEffect(() => {
      if (disabled2 || !floatingFocusElement) {
        return void 0;
      }
      handleTabIndex(floatingFocusElement, orderRef);
      return () => {
        queueMicrotask(clearDisconnectedPreviouslyFocusedElements);
      };
    }, [disabled2, floatingFocusElement, orderRef]);
    const shouldRenderGuards = !disabled2 && (modal ? !isUntrappedTypeableCombobox : true) && (isInsidePortal || modal);
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(React29.Fragment, {
      children: [shouldRenderGuards && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(FocusGuard, {
        "data-type": "inside",
        ref: mergedBeforeGuardRef,
        onFocus: (event) => {
          if (modal) {
            const els = getTabbableElements();
            enqueueFocus(els[els.length - 1]);
          } else if (portalContext?.portalNode) {
            preventReturnFocusRef.current = false;
            if (isOutsideEvent(event, portalContext.portalNode)) {
              const nextTabbable = getNextTabbable(domReference);
              nextTabbable?.focus();
            } else {
              resolveRef(previousFocusableElement ?? portalContext.beforeOutsideRef)?.focus();
            }
          }
        }
      }), children, shouldRenderGuards && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(FocusGuard, {
        "data-type": "inside",
        ref: mergedAfterGuardRef,
        onFocus: (event) => {
          if (modal) {
            enqueueFocus(getTabbableElements()[0]);
          } else if (portalContext?.portalNode) {
            if (closeOnFocusOut) {
              preventReturnFocusRef.current = true;
            }
            if (isOutsideEvent(event, portalContext.portalNode)) {
              const prevTabbable = getPreviousTabbable(domReference);
              prevTabbable?.focus();
            } else {
              resolveRef(nextFocusableElement ?? portalContext.afterOutsideRef)?.focus();
            }
          }
        }
      })]
    });
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useClick.js
  init_define_import_meta_env();
  var React30 = __toESM(require_react_shim(), 1);
  function useClick(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const dataRef = store.context.dataRef;
    const {
      enabled = true,
      event: eventOption = "click",
      toggle = true,
      ignoreMouse = false,
      stickIfOpen = true,
      touchOpenDelay = 0,
      reason = reason_parts_exports.triggerPress
    } = props;
    const pointerTypeRef = React30.useRef(void 0);
    const frame = useAnimationFrame();
    const touchOpenTimeout = useTimeout();
    const reference = React30.useMemo(() => ({
      onPointerDown(event) {
        pointerTypeRef.current = event.pointerType;
      },
      onMouseDown(event) {
        const pointerType = pointerTypeRef.current;
        const nativeEvent = event.nativeEvent;
        const open = store.select("open");
        if (event.button !== 0 || eventOption === "click" || isMouseLikePointerType(pointerType, true) && ignoreMouse) {
          return;
        }
        const openEvent = dataRef.current.openEvent;
        const openEventType = openEvent?.type;
        const hasClickedOnInactiveTrigger = store.select("domReferenceElement") !== event.currentTarget;
        const nextOpen = open && hasClickedOnInactiveTrigger || !(open && toggle && (openEvent && stickIfOpen ? openEventType === "click" || openEventType === "mousedown" : true));
        if (isTypeableElement(nativeEvent.target)) {
          const details = createChangeEventDetails(reason, nativeEvent, nativeEvent.target);
          if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) {
            touchOpenTimeout.start(touchOpenDelay, () => {
              store.setOpen(true, details);
            });
          } else {
            store.setOpen(nextOpen, details);
          }
          return;
        }
        const eventCurrentTarget = event.currentTarget;
        frame.request(() => {
          const details = createChangeEventDetails(reason, nativeEvent, eventCurrentTarget);
          if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) {
            touchOpenTimeout.start(touchOpenDelay, () => {
              store.setOpen(true, details);
            });
          } else {
            store.setOpen(nextOpen, details);
          }
        });
      },
      onClick(event) {
        if (eventOption === "mousedown-only") {
          return;
        }
        const pointerType = pointerTypeRef.current;
        if (eventOption === "mousedown" && pointerType) {
          pointerTypeRef.current = void 0;
          return;
        }
        if (isMouseLikePointerType(pointerType, true) && ignoreMouse) {
          return;
        }
        const open = store.select("open");
        const openEvent = dataRef.current.openEvent;
        const hasClickedOnInactiveTrigger = store.select("domReferenceElement") !== event.currentTarget;
        const nextOpen = open && hasClickedOnInactiveTrigger || !(open && toggle && (openEvent && stickIfOpen ? isClickLikeEvent(openEvent) : true));
        const details = createChangeEventDetails(reason, event.nativeEvent, event.currentTarget);
        if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) {
          touchOpenTimeout.start(touchOpenDelay, () => {
            store.setOpen(true, details);
          });
        } else {
          store.setOpen(nextOpen, details);
        }
      },
      onKeyDown() {
        pointerTypeRef.current = void 0;
      }
    }), [dataRef, eventOption, ignoreMouse, store, stickIfOpen, toggle, frame, touchOpenTimeout, touchOpenDelay, reason]);
    return React30.useMemo(() => enabled ? {
      reference
    } : EMPTY_OBJECT, [enabled, reference]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useClientPoint.js
  init_define_import_meta_env();
  var React31 = __toESM(require_react_shim(), 1);
  function createVirtualElement(domElement, data) {
    let offsetX = null;
    let offsetY = null;
    let isAutoUpdateEvent = false;
    return {
      contextElement: domElement || void 0,
      getBoundingClientRect() {
        const domRect = domElement?.getBoundingClientRect() || {
          width: 0,
          height: 0,
          x: 0,
          y: 0
        };
        const isXAxis = data.axis === "x" || data.axis === "both";
        const isYAxis = data.axis === "y" || data.axis === "both";
        const canTrackCursorOnAutoUpdate = ["mouseenter", "mousemove"].includes(data.dataRef.current.openEvent?.type || "") && data.pointerType !== "touch";
        let width = domRect.width;
        let height = domRect.height;
        let x = domRect.x;
        let y = domRect.y;
        if (offsetX == null && data.x && isXAxis) {
          offsetX = domRect.x - data.x;
        }
        if (offsetY == null && data.y && isYAxis) {
          offsetY = domRect.y - data.y;
        }
        x -= offsetX || 0;
        y -= offsetY || 0;
        width = 0;
        height = 0;
        if (!isAutoUpdateEvent || canTrackCursorOnAutoUpdate) {
          width = data.axis === "y" ? domRect.width : 0;
          height = data.axis === "x" ? domRect.height : 0;
          x = isXAxis && data.x != null ? data.x : x;
          y = isYAxis && data.y != null ? data.y : y;
        } else if (isAutoUpdateEvent && !canTrackCursorOnAutoUpdate) {
          height = data.axis === "x" ? domRect.height : height;
          width = data.axis === "y" ? domRect.width : width;
        }
        isAutoUpdateEvent = true;
        return {
          width,
          height,
          x,
          y,
          top: y,
          right: x + width,
          bottom: y + height,
          left: x
        };
      }
    };
  }
  function isMouseBasedEvent(event) {
    return event != null && event.clientX != null;
  }
  function useClientPoint(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const floating = store.useState("floatingElement");
    const domReference = store.useState("domReferenceElement");
    const dataRef = store.context.dataRef;
    const {
      enabled = true,
      axis = "both"
    } = props;
    const initialRef = React31.useRef(false);
    const cleanupListenerRef = React31.useRef(null);
    const [pointerType, setPointerType] = React31.useState();
    const [reactive, setReactive] = React31.useState([]);
    const setReference = useStableCallback((newX, newY, referenceElement) => {
      if (initialRef.current) {
        return;
      }
      if (dataRef.current.openEvent && !isMouseBasedEvent(dataRef.current.openEvent)) {
        return;
      }
      store.set("positionReference", createVirtualElement(referenceElement ?? domReference, {
        x: newX,
        y: newY,
        axis,
        dataRef,
        pointerType
      }));
    });
    const handleReferenceEnterOrMove = useStableCallback((event) => {
      if (!open) {
        setReference(event.clientX, event.clientY, event.currentTarget);
      } else if (!cleanupListenerRef.current) {
        setReactive([]);
      }
    });
    const openCheck = isMouseLikePointerType(pointerType) ? floating : open;
    const addListener = React31.useCallback(() => {
      if (!openCheck || !enabled) {
        return void 0;
      }
      const win = getWindow(floating);
      function handleMouseMove(event) {
        const target = getTarget(event);
        if (!contains(floating, target)) {
          setReference(event.clientX, event.clientY);
        } else {
          win.removeEventListener("mousemove", handleMouseMove);
          cleanupListenerRef.current = null;
        }
      }
      if (!dataRef.current.openEvent || isMouseBasedEvent(dataRef.current.openEvent)) {
        win.addEventListener("mousemove", handleMouseMove);
        const cleanup = () => {
          win.removeEventListener("mousemove", handleMouseMove);
          cleanupListenerRef.current = null;
        };
        cleanupListenerRef.current = cleanup;
        return cleanup;
      }
      store.set("positionReference", domReference);
      return void 0;
    }, [openCheck, enabled, floating, dataRef, domReference, store, setReference]);
    React31.useEffect(() => {
      return addListener();
    }, [addListener, reactive]);
    React31.useEffect(() => {
      if (enabled && !floating) {
        initialRef.current = false;
      }
    }, [enabled, floating]);
    React31.useEffect(() => {
      if (!enabled && open) {
        initialRef.current = true;
      }
    }, [enabled, open]);
    const reference = React31.useMemo(() => {
      function setPointerTypeRef(event) {
        setPointerType(event.pointerType);
      }
      return {
        onPointerDown: setPointerTypeRef,
        onPointerEnter: setPointerTypeRef,
        onMouseMove: handleReferenceEnterOrMove,
        onMouseEnter: handleReferenceEnterOrMove
      };
    }, [handleReferenceEnterOrMove]);
    return React31.useMemo(() => enabled ? {
      reference,
      trigger: reference
    } : {}, [enabled, reference]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useDismiss.js
  init_define_import_meta_env();
  var React32 = __toESM(require_react_shim(), 1);
  var bubbleHandlerKeys = {
    intentional: "onClick",
    sloppy: "onPointerDown"
  };
  function alwaysFalse() {
    return false;
  }
  function normalizeProp(normalizable) {
    return {
      escapeKey: typeof normalizable === "boolean" ? normalizable : normalizable?.escapeKey ?? false,
      outsidePress: typeof normalizable === "boolean" ? normalizable : normalizable?.outsidePress ?? true
    };
  }
  function useDismiss(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const floatingElement = store.useState("floatingElement");
    const {
      dataRef
    } = store.context;
    const {
      enabled = true,
      escapeKey: escapeKey2 = true,
      outsidePress: outsidePressProp = true,
      outsidePressEvent = "sloppy",
      referencePress = alwaysFalse,
      referencePressEvent = "sloppy",
      bubbles,
      externalTree
    } = props;
    const tree = useFloatingTree(externalTree);
    const outsidePressFn = useStableCallback(typeof outsidePressProp === "function" ? outsidePressProp : () => false);
    const outsidePress2 = typeof outsidePressProp === "function" ? outsidePressFn : outsidePressProp;
    const outsidePressEnabled = outsidePress2 !== false;
    const getOutsidePressEventProp = useStableCallback(() => outsidePressEvent);
    const pressStartedInsideRef = React32.useRef(false);
    const pressStartPreventedRef = React32.useRef(false);
    const suppressNextOutsideClickRef = React32.useRef(false);
    const {
      escapeKey: escapeKeyBubbles,
      outsidePress: outsidePressBubbles
    } = normalizeProp(bubbles);
    const touchStateRef = React32.useRef(null);
    const cancelDismissOnEndTimeout = useTimeout();
    const clearInsideReactTreeTimeout = useTimeout();
    const clearInsideReactTree = useStableCallback(() => {
      clearInsideReactTreeTimeout.clear();
      dataRef.current.insideReactTree = false;
    });
    const isComposingRef = React32.useRef(false);
    const currentPointerTypeRef = React32.useRef("");
    const isReferencePressEnabled = useStableCallback(referencePress);
    const closeOnEscapeKeyDown = useStableCallback((event) => {
      if (!open || !enabled || !escapeKey2 || event.key !== "Escape") {
        return;
      }
      if (isComposingRef.current) {
        return;
      }
      const nodeId = dataRef.current.floatingContext?.nodeId;
      const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
      if (!escapeKeyBubbles) {
        if (children.length > 0) {
          let shouldDismiss = true;
          children.forEach((child) => {
            if (child.context?.open && !child.context.dataRef.current.__escapeKeyBubbles) {
              shouldDismiss = false;
            }
          });
          if (!shouldDismiss) {
            return;
          }
        }
      }
      const native = isReactEvent(event) ? event.nativeEvent : event;
      const eventDetails = createChangeEventDetails(reason_parts_exports.escapeKey, native);
      store.setOpen(false, eventDetails);
      if (!escapeKeyBubbles && !eventDetails.isPropagationAllowed) {
        event.stopPropagation();
      }
    });
    const markInsideReactTree = useStableCallback(() => {
      dataRef.current.insideReactTree = true;
      clearInsideReactTreeTimeout.start(0, clearInsideReactTree);
    });
    React32.useEffect(() => {
      if (!open || !enabled) {
        return void 0;
      }
      dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
      dataRef.current.__outsidePressBubbles = outsidePressBubbles;
      const compositionTimeout = new Timeout();
      const preventedPressSuppressionTimeout = new Timeout();
      function handleCompositionStart() {
        compositionTimeout.clear();
        isComposingRef.current = true;
      }
      function handleCompositionEnd() {
        compositionTimeout.start(
          // 0ms or 1ms don't work in Safari. 5ms appears to consistently work.
          // Only apply to WebKit for the test to remain 0ms.
          isWebKit() ? 5 : 0,
          () => {
            isComposingRef.current = false;
          }
        );
      }
      function suppressImmediateOutsideClickAfterPreventedStart() {
        suppressNextOutsideClickRef.current = true;
        preventedPressSuppressionTimeout.start(0, () => {
          suppressNextOutsideClickRef.current = false;
        });
      }
      function resetPressStartState() {
        pressStartedInsideRef.current = false;
        pressStartPreventedRef.current = false;
      }
      function getOutsidePressEvent() {
        const type = currentPointerTypeRef.current;
        const computedType = type === "pen" || !type ? "mouse" : type;
        const outsidePressEventValue = getOutsidePressEventProp();
        const resolved = typeof outsidePressEventValue === "function" ? outsidePressEventValue() : outsidePressEventValue;
        if (typeof resolved === "string") {
          return resolved;
        }
        return resolved[computedType];
      }
      function shouldIgnoreEvent(event) {
        const computedOutsidePressEvent = getOutsidePressEvent();
        return computedOutsidePressEvent === "intentional" && event.type !== "click" || computedOutsidePressEvent === "sloppy" && event.type === "click";
      }
      function isEventWithinFloatingTree(event) {
        const nodeId = dataRef.current.floatingContext?.nodeId;
        const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => isEventTargetWithin(event, node.context?.elements.floating));
        return isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement")) || targetIsInsideChildren;
      }
      function closeOnPressOutside(event) {
        if (shouldIgnoreEvent(event)) {
          clearInsideReactTree();
          return;
        }
        if (dataRef.current.insideReactTree) {
          clearInsideReactTree();
          return;
        }
        const target = getTarget(event);
        const inertSelector = `[${createAttribute("inert")}]`;
        let markers = Array.from(ownerDocument(store.select("floatingElement")).querySelectorAll(inertSelector));
        const targetRoot = isElement(target) ? target.getRootNode() : null;
        if (isShadowRoot(targetRoot)) {
          markers = markers.concat(Array.from(targetRoot.querySelectorAll(inertSelector)));
        }
        const triggers = store.context.triggerElements;
        if (target && (triggers.hasElement(target) || triggers.hasMatchingElement((trigger) => contains(trigger, target)))) {
          return;
        }
        let targetRootAncestor = isElement(target) ? target : null;
        while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
          const nextParent = getParentNode(targetRootAncestor);
          if (isLastTraversableNode(nextParent) || !isElement(nextParent)) {
            break;
          }
          targetRootAncestor = nextParent;
        }
        if (markers.length && isElement(target) && !isRootElement(target) && // Clicked on a direct ancestor (e.g. FloatingOverlay).
        !contains(target, store.select("floatingElement")) && // If the target root element contains none of the markers, then the
        // element was injected after the floating element rendered.
        markers.every((marker) => !contains(targetRootAncestor, marker))) {
          return;
        }
        if (isHTMLElement(target) && !("touches" in event)) {
          const lastTraversableNode = isLastTraversableNode(target);
          const style = getComputedStyle2(target);
          const scrollRe = /auto|scroll/;
          const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
          const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
          const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
          const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
          const isRTL2 = style.direction === "rtl";
          const pressedVerticalScrollbar = canScrollY && (isRTL2 ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
          const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
          if (pressedVerticalScrollbar || pressedHorizontalScrollbar) {
            return;
          }
        }
        if (isEventWithinFloatingTree(event)) {
          return;
        }
        if (getOutsidePressEvent() === "intentional" && suppressNextOutsideClickRef.current) {
          preventedPressSuppressionTimeout.clear();
          suppressNextOutsideClickRef.current = false;
          return;
        }
        if (typeof outsidePress2 === "function" && !outsidePress2(event)) {
          return;
        }
        const nodeId = dataRef.current.floatingContext?.nodeId;
        const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
        if (children.length > 0) {
          let shouldDismiss = true;
          children.forEach((child) => {
            if (child.context?.open && !child.context.dataRef.current.__outsidePressBubbles) {
              shouldDismiss = false;
            }
          });
          if (!shouldDismiss) {
            return;
          }
        }
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.outsidePress, event));
        clearInsideReactTree();
      }
      function handlePointerDown(event) {
        if (getOutsidePressEvent() !== "sloppy" || event.pointerType === "touch" || !store.select("open") || !enabled || isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"))) {
          return;
        }
        closeOnPressOutside(event);
      }
      function handleTouchStart(event) {
        if (getOutsidePressEvent() !== "sloppy" || !store.select("open") || !enabled || isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"))) {
          return;
        }
        const touch = event.touches[0];
        if (touch) {
          touchStateRef.current = {
            startTime: Date.now(),
            startX: touch.clientX,
            startY: touch.clientY,
            dismissOnTouchEnd: false,
            dismissOnMouseDown: true
          };
          cancelDismissOnEndTimeout.start(1e3, () => {
            if (touchStateRef.current) {
              touchStateRef.current.dismissOnTouchEnd = false;
              touchStateRef.current.dismissOnMouseDown = false;
            }
          });
        }
      }
      function handleTouchStartCapture(event) {
        currentPointerTypeRef.current = "touch";
        const target = getTarget(event);
        function callback() {
          handleTouchStart(event);
          target?.removeEventListener(event.type, callback);
        }
        target?.addEventListener(event.type, callback);
      }
      function closeOnPressOutsideCapture(event) {
        cancelDismissOnEndTimeout.clear();
        if (event.type === "pointerdown") {
          currentPointerTypeRef.current = event.pointerType;
        }
        if (event.type === "mousedown" && touchStateRef.current && !touchStateRef.current.dismissOnMouseDown) {
          return;
        }
        const target = getTarget(event);
        function callback() {
          if (event.type === "pointerdown") {
            handlePointerDown(event);
          } else {
            closeOnPressOutside(event);
          }
          target?.removeEventListener(event.type, callback);
        }
        target?.addEventListener(event.type, callback);
      }
      function handlePressEndCapture(event) {
        if (!pressStartedInsideRef.current) {
          return;
        }
        const pressStartedInsideDefaultPrevented = pressStartPreventedRef.current;
        resetPressStartState();
        if (getOutsidePressEvent() !== "intentional") {
          return;
        }
        if (event.type === "pointercancel") {
          if (pressStartedInsideDefaultPrevented) {
            suppressImmediateOutsideClickAfterPreventedStart();
          }
          return;
        }
        if (isEventWithinFloatingTree(event)) {
          return;
        }
        if (pressStartedInsideDefaultPrevented) {
          suppressImmediateOutsideClickAfterPreventedStart();
          return;
        }
        if (typeof outsidePress2 === "function" && !outsidePress2(event)) {
          return;
        }
        preventedPressSuppressionTimeout.clear();
        suppressNextOutsideClickRef.current = true;
        clearInsideReactTree();
      }
      function handleTouchMove(event) {
        if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"))) {
          return;
        }
        const touch = event.touches[0];
        if (!touch) {
          return;
        }
        const deltaX = Math.abs(touch.clientX - touchStateRef.current.startX);
        const deltaY = Math.abs(touch.clientY - touchStateRef.current.startY);
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        if (distance > 5) {
          touchStateRef.current.dismissOnTouchEnd = true;
        }
        if (distance > 10) {
          closeOnPressOutside(event);
          cancelDismissOnEndTimeout.clear();
          touchStateRef.current = null;
        }
      }
      function handleTouchMoveCapture(event) {
        const target = getTarget(event);
        function callback() {
          handleTouchMove(event);
          target?.removeEventListener(event.type, callback);
        }
        target?.addEventListener(event.type, callback);
      }
      function handleTouchEnd(event) {
        if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"))) {
          return;
        }
        if (touchStateRef.current.dismissOnTouchEnd) {
          closeOnPressOutside(event);
        }
        cancelDismissOnEndTimeout.clear();
        touchStateRef.current = null;
      }
      function handleTouchEndCapture(event) {
        const target = getTarget(event);
        function callback() {
          handleTouchEnd(event);
          target?.removeEventListener(event.type, callback);
        }
        target?.addEventListener(event.type, callback);
      }
      const doc = ownerDocument(floatingElement);
      if (escapeKey2) {
        doc.addEventListener("keydown", closeOnEscapeKeyDown);
        doc.addEventListener("compositionstart", handleCompositionStart);
        doc.addEventListener("compositionend", handleCompositionEnd);
      }
      if (outsidePressEnabled) {
        doc.addEventListener("click", closeOnPressOutsideCapture, true);
        doc.addEventListener("pointerdown", closeOnPressOutsideCapture, true);
        doc.addEventListener("pointerup", handlePressEndCapture, true);
        doc.addEventListener("pointercancel", handlePressEndCapture, true);
        doc.addEventListener("mousedown", closeOnPressOutsideCapture, true);
        doc.addEventListener("mouseup", handlePressEndCapture, true);
        doc.addEventListener("touchstart", handleTouchStartCapture, true);
        doc.addEventListener("touchmove", handleTouchMoveCapture, true);
        doc.addEventListener("touchend", handleTouchEndCapture, true);
      }
      return () => {
        if (escapeKey2) {
          doc.removeEventListener("keydown", closeOnEscapeKeyDown);
          doc.removeEventListener("compositionstart", handleCompositionStart);
          doc.removeEventListener("compositionend", handleCompositionEnd);
        }
        if (outsidePressEnabled) {
          doc.removeEventListener("click", closeOnPressOutsideCapture, true);
          doc.removeEventListener("pointerdown", closeOnPressOutsideCapture, true);
          doc.removeEventListener("pointerup", handlePressEndCapture, true);
          doc.removeEventListener("pointercancel", handlePressEndCapture, true);
          doc.removeEventListener("mousedown", closeOnPressOutsideCapture, true);
          doc.removeEventListener("mouseup", handlePressEndCapture, true);
          doc.removeEventListener("touchstart", handleTouchStartCapture, true);
          doc.removeEventListener("touchmove", handleTouchMoveCapture, true);
          doc.removeEventListener("touchend", handleTouchEndCapture, true);
        }
        compositionTimeout.clear();
        preventedPressSuppressionTimeout.clear();
        resetPressStartState();
        suppressNextOutsideClickRef.current = false;
      };
    }, [dataRef, floatingElement, escapeKey2, outsidePressEnabled, outsidePress2, open, enabled, escapeKeyBubbles, outsidePressBubbles, closeOnEscapeKeyDown, clearInsideReactTree, getOutsidePressEventProp, tree, store, cancelDismissOnEndTimeout]);
    React32.useEffect(clearInsideReactTree, [outsidePress2, clearInsideReactTree]);
    const reference = React32.useMemo(() => ({
      onKeyDown: closeOnEscapeKeyDown,
      [bubbleHandlerKeys[referencePressEvent]]: (event) => {
        if (!isReferencePressEnabled()) {
          return;
        }
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerPress, event.nativeEvent));
      },
      ...referencePressEvent !== "intentional" && {
        onClick(event) {
          if (!isReferencePressEnabled()) {
            return;
          }
          store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerPress, event.nativeEvent));
        }
      }
    }), [closeOnEscapeKeyDown, store, referencePressEvent, isReferencePressEnabled]);
    const markPressStartedInsideReactTree = useStableCallback((event) => {
      if (!open || !enabled || event.button !== 0) {
        return;
      }
      const target = getTarget(event.nativeEvent);
      if (!contains(store.select("floatingElement"), target)) {
        return;
      }
      if (!pressStartedInsideRef.current) {
        pressStartedInsideRef.current = true;
        pressStartPreventedRef.current = false;
      }
    });
    const markInsidePressStartPrevented = useStableCallback((event) => {
      if (!open || !enabled) {
        return;
      }
      if (!(event.defaultPrevented || event.nativeEvent.defaultPrevented)) {
        return;
      }
      if (pressStartedInsideRef.current) {
        pressStartPreventedRef.current = true;
      }
    });
    const floating = React32.useMemo(() => ({
      onKeyDown: closeOnEscapeKeyDown,
      // `onMouseDown` may be blocked if `event.preventDefault()` is called in
      // `onPointerDown`, such as with <NumberField.ScrubArea>.
      // See https://github.com/mui/base-ui/pull/3379
      onPointerDown: markInsidePressStartPrevented,
      onMouseDown: markInsidePressStartPrevented,
      onClickCapture: markInsideReactTree,
      onMouseDownCapture(event) {
        markInsideReactTree();
        markPressStartedInsideReactTree(event);
      },
      onPointerDownCapture(event) {
        markInsideReactTree();
        markPressStartedInsideReactTree(event);
      },
      onMouseUpCapture: markInsideReactTree,
      onTouchEndCapture: markInsideReactTree,
      onTouchMoveCapture: markInsideReactTree
    }), [closeOnEscapeKeyDown, markInsideReactTree, markPressStartedInsideReactTree, markInsidePressStartPrevented]);
    return React32.useMemo(() => enabled ? {
      reference,
      floating,
      trigger: reference
    } : {}, [enabled, reference, floating]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useFloating.js
  init_define_import_meta_env();
  var React38 = __toESM(require_react_shim(), 1);

  // node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
  init_define_import_meta_env();

  // node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
  init_define_import_meta_env();

  // node_modules/@floating-ui/core/dist/floating-ui.core.mjs
  init_define_import_meta_env();
  function computeCoordsFromPlacement(_ref, placement, rtl) {
    let {
      reference,
      floating
    } = _ref;
    const sideAxis = getSideAxis(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const alignLength = getAxisLength(alignmentAxis);
    const side = getSide(placement);
    const isVertical = sideAxis === "y";
    const commonX = reference.x + reference.width / 2 - floating.width / 2;
    const commonY = reference.y + reference.height / 2 - floating.height / 2;
    const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
    let coords;
    switch (side) {
      case "top":
        coords = {
          x: commonX,
          y: reference.y - floating.height
        };
        break;
      case "bottom":
        coords = {
          x: commonX,
          y: reference.y + reference.height
        };
        break;
      case "right":
        coords = {
          x: reference.x + reference.width,
          y: commonY
        };
        break;
      case "left":
        coords = {
          x: reference.x - floating.width,
          y: commonY
        };
        break;
      default:
        coords = {
          x: reference.x,
          y: reference.y
        };
    }
    switch (getAlignment(placement)) {
      case "start":
        coords[alignmentAxis] -= commonAlign * (rtl && isVertical ? -1 : 1);
        break;
      case "end":
        coords[alignmentAxis] += commonAlign * (rtl && isVertical ? -1 : 1);
        break;
    }
    return coords;
  }
  async function detectOverflow(state, options) {
    var _await$platform$isEle;
    if (options === void 0) {
      options = {};
    }
    const {
      x,
      y,
      platform: platform3,
      rects,
      elements,
      strategy
    } = state;
    const {
      boundary = "clippingAncestors",
      rootBoundary = "viewport",
      elementContext = "floating",
      altBoundary = false,
      padding = 0
    } = evaluate(options, state);
    const paddingObject = getPaddingObject(padding);
    const altContext = elementContext === "floating" ? "reference" : "floating";
    const element = elements[altBoundary ? altContext : elementContext];
    const clippingClientRect = rectToClientRect(await platform3.getClippingRect({
      element: ((_await$platform$isEle = await (platform3.isElement == null ? void 0 : platform3.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform3.getDocumentElement == null ? void 0 : platform3.getDocumentElement(elements.floating)),
      boundary,
      rootBoundary,
      strategy
    }));
    const rect = elementContext === "floating" ? {
      x,
      y,
      width: rects.floating.width,
      height: rects.floating.height
    } : rects.reference;
    const offsetParent = await (platform3.getOffsetParent == null ? void 0 : platform3.getOffsetParent(elements.floating));
    const offsetScale = await (platform3.isElement == null ? void 0 : platform3.isElement(offsetParent)) ? await (platform3.getScale == null ? void 0 : platform3.getScale(offsetParent)) || {
      x: 1,
      y: 1
    } : {
      x: 1,
      y: 1
    };
    const elementClientRect = rectToClientRect(platform3.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform3.convertOffsetParentRelativeRectToViewportRelativeRect({
      elements,
      rect,
      offsetParent,
      strategy
    }) : rect);
    return {
      top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
      bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
      left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
      right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
    };
  }
  var MAX_RESET_COUNT = 50;
  var computePosition = async (reference, floating, config) => {
    const {
      placement = "bottom",
      strategy = "absolute",
      middleware = [],
      platform: platform3
    } = config;
    const platformWithDetectOverflow = platform3.detectOverflow ? platform3 : {
      ...platform3,
      detectOverflow
    };
    const rtl = await (platform3.isRTL == null ? void 0 : platform3.isRTL(floating));
    let rects = await platform3.getElementRects({
      reference,
      floating,
      strategy
    });
    let {
      x,
      y
    } = computeCoordsFromPlacement(rects, placement, rtl);
    let statefulPlacement = placement;
    let resetCount = 0;
    const middlewareData = {};
    for (let i = 0; i < middleware.length; i++) {
      const currentMiddleware = middleware[i];
      if (!currentMiddleware) {
        continue;
      }
      const {
        name,
        fn
      } = currentMiddleware;
      const {
        x: nextX,
        y: nextY,
        data,
        reset
      } = await fn({
        x,
        y,
        initialPlacement: placement,
        placement: statefulPlacement,
        strategy,
        middlewareData,
        rects,
        platform: platformWithDetectOverflow,
        elements: {
          reference,
          floating
        }
      });
      x = nextX != null ? nextX : x;
      y = nextY != null ? nextY : y;
      middlewareData[name] = {
        ...middlewareData[name],
        ...data
      };
      if (reset && resetCount < MAX_RESET_COUNT) {
        resetCount++;
        if (typeof reset === "object") {
          if (reset.placement) {
            statefulPlacement = reset.placement;
          }
          if (reset.rects) {
            rects = reset.rects === true ? await platform3.getElementRects({
              reference,
              floating,
              strategy
            }) : reset.rects;
          }
          ({
            x,
            y
          } = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
        }
        i = -1;
      }
    }
    return {
      x,
      y,
      placement: statefulPlacement,
      strategy,
      middlewareData
    };
  };
  var flip = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "flip",
      options,
      async fn(state) {
        var _middlewareData$arrow, _middlewareData$flip;
        const {
          placement,
          middlewareData,
          rects,
          initialPlacement,
          platform: platform3,
          elements
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = true,
          fallbackPlacements: specifiedFallbackPlacements,
          fallbackStrategy = "bestFit",
          fallbackAxisSideDirection = "none",
          flipAlignment = true,
          ...detectOverflowOptions
        } = evaluate(options, state);
        if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        const side = getSide(placement);
        const initialSideAxis = getSideAxis(initialPlacement);
        const isBasePlacement = getSide(initialPlacement) === initialPlacement;
        const rtl = await (platform3.isRTL == null ? void 0 : platform3.isRTL(elements.floating));
        const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
        const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
        if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) {
          fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
        }
        const placements2 = [initialPlacement, ...fallbackPlacements];
        const overflow = await platform3.detectOverflow(state, detectOverflowOptions);
        const overflows = [];
        let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
        if (checkMainAxis) {
          overflows.push(overflow[side]);
        }
        if (checkCrossAxis) {
          const sides2 = getAlignmentSides(placement, rects, rtl);
          overflows.push(overflow[sides2[0]], overflow[sides2[1]]);
        }
        overflowsData = [...overflowsData, {
          placement,
          overflows
        }];
        if (!overflows.every((side2) => side2 <= 0)) {
          var _middlewareData$flip2, _overflowsData$filter;
          const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
          const nextPlacement = placements2[nextIndex];
          if (nextPlacement) {
            const ignoreCrossAxisOverflow = checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false;
            if (!ignoreCrossAxisOverflow || // We leave the current main axis only if every placement on that axis
            // overflows the main axis.
            overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) {
              return {
                data: {
                  index: nextIndex,
                  overflows: overflowsData
                },
                reset: {
                  placement: nextPlacement
                }
              };
            }
          }
          let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
          if (!resetPlacement) {
            switch (fallbackStrategy) {
              case "bestFit": {
                var _overflowsData$filter2;
                const placement2 = (_overflowsData$filter2 = overflowsData.filter((d) => {
                  if (hasFallbackAxisSideDirection) {
                    const currentSideAxis = getSideAxis(d.placement);
                    return currentSideAxis === initialSideAxis || // Create a bias to the `y` side axis due to horizontal
                    // reading directions favoring greater width.
                    currentSideAxis === "y";
                  }
                  return true;
                }).map((d) => [d.placement, d.overflows.filter((overflow2) => overflow2 > 0).reduce((acc, overflow2) => acc + overflow2, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
                if (placement2) {
                  resetPlacement = placement2;
                }
                break;
              }
              case "initialPlacement":
                resetPlacement = initialPlacement;
                break;
            }
          }
          if (placement !== resetPlacement) {
            return {
              reset: {
                placement: resetPlacement
              }
            };
          }
        }
        return {};
      }
    };
  };
  function getSideOffsets(overflow, rect) {
    return {
      top: overflow.top - rect.height,
      right: overflow.right - rect.width,
      bottom: overflow.bottom - rect.height,
      left: overflow.left - rect.width
    };
  }
  function isAnySideFullyClipped(overflow) {
    return sides.some((side) => overflow[side] >= 0);
  }
  var hide = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "hide",
      options,
      async fn(state) {
        const {
          rects,
          platform: platform3
        } = state;
        const {
          strategy = "referenceHidden",
          ...detectOverflowOptions
        } = evaluate(options, state);
        switch (strategy) {
          case "referenceHidden": {
            const overflow = await platform3.detectOverflow(state, {
              ...detectOverflowOptions,
              elementContext: "reference"
            });
            const offsets = getSideOffsets(overflow, rects.reference);
            return {
              data: {
                referenceHiddenOffsets: offsets,
                referenceHidden: isAnySideFullyClipped(offsets)
              }
            };
          }
          case "escaped": {
            const overflow = await platform3.detectOverflow(state, {
              ...detectOverflowOptions,
              altBoundary: true
            });
            const offsets = getSideOffsets(overflow, rects.floating);
            return {
              data: {
                escapedOffsets: offsets,
                escaped: isAnySideFullyClipped(offsets)
              }
            };
          }
          default: {
            return {};
          }
        }
      }
    };
  };
  var originSides = /* @__PURE__ */ new Set(["left", "top"]);
  async function convertValueToCoords(state, options) {
    const {
      placement,
      platform: platform3,
      elements
    } = state;
    const rtl = await (platform3.isRTL == null ? void 0 : platform3.isRTL(elements.floating));
    const side = getSide(placement);
    const alignment = getAlignment(placement);
    const isVertical = getSideAxis(placement) === "y";
    const mainAxisMulti = originSides.has(side) ? -1 : 1;
    const crossAxisMulti = rtl && isVertical ? -1 : 1;
    const rawValue = evaluate(options, state);
    let {
      mainAxis,
      crossAxis,
      alignmentAxis
    } = typeof rawValue === "number" ? {
      mainAxis: rawValue,
      crossAxis: 0,
      alignmentAxis: null
    } : {
      mainAxis: rawValue.mainAxis || 0,
      crossAxis: rawValue.crossAxis || 0,
      alignmentAxis: rawValue.alignmentAxis
    };
    if (alignment && typeof alignmentAxis === "number") {
      crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
    }
    return isVertical ? {
      x: crossAxis * crossAxisMulti,
      y: mainAxis * mainAxisMulti
    } : {
      x: mainAxis * mainAxisMulti,
      y: crossAxis * crossAxisMulti
    };
  }
  var offset = function(options) {
    if (options === void 0) {
      options = 0;
    }
    return {
      name: "offset",
      options,
      async fn(state) {
        var _middlewareData$offse, _middlewareData$arrow;
        const {
          x,
          y,
          placement,
          middlewareData
        } = state;
        const diffCoords = await convertValueToCoords(state, options);
        if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        return {
          x: x + diffCoords.x,
          y: y + diffCoords.y,
          data: {
            ...diffCoords,
            placement
          }
        };
      }
    };
  };
  var shift = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "shift",
      options,
      async fn(state) {
        const {
          x,
          y,
          placement,
          platform: platform3
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = false,
          limiter = {
            fn: (_ref) => {
              let {
                x: x2,
                y: y2
              } = _ref;
              return {
                x: x2,
                y: y2
              };
            }
          },
          ...detectOverflowOptions
        } = evaluate(options, state);
        const coords = {
          x,
          y
        };
        const overflow = await platform3.detectOverflow(state, detectOverflowOptions);
        const crossAxis = getSideAxis(getSide(placement));
        const mainAxis = getOppositeAxis(crossAxis);
        let mainAxisCoord = coords[mainAxis];
        let crossAxisCoord = coords[crossAxis];
        if (checkMainAxis) {
          const minSide = mainAxis === "y" ? "top" : "left";
          const maxSide = mainAxis === "y" ? "bottom" : "right";
          const min2 = mainAxisCoord + overflow[minSide];
          const max2 = mainAxisCoord - overflow[maxSide];
          mainAxisCoord = clamp(min2, mainAxisCoord, max2);
        }
        if (checkCrossAxis) {
          const minSide = crossAxis === "y" ? "top" : "left";
          const maxSide = crossAxis === "y" ? "bottom" : "right";
          const min2 = crossAxisCoord + overflow[minSide];
          const max2 = crossAxisCoord - overflow[maxSide];
          crossAxisCoord = clamp(min2, crossAxisCoord, max2);
        }
        const limitedCoords = limiter.fn({
          ...state,
          [mainAxis]: mainAxisCoord,
          [crossAxis]: crossAxisCoord
        });
        return {
          ...limitedCoords,
          data: {
            x: limitedCoords.x - x,
            y: limitedCoords.y - y,
            enabled: {
              [mainAxis]: checkMainAxis,
              [crossAxis]: checkCrossAxis
            }
          }
        };
      }
    };
  };
  var limitShift = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      options,
      fn(state) {
        const {
          x,
          y,
          placement,
          rects,
          middlewareData
        } = state;
        const {
          offset: offset4 = 0,
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = true
        } = evaluate(options, state);
        const coords = {
          x,
          y
        };
        const crossAxis = getSideAxis(placement);
        const mainAxis = getOppositeAxis(crossAxis);
        let mainAxisCoord = coords[mainAxis];
        let crossAxisCoord = coords[crossAxis];
        const rawOffset = evaluate(offset4, state);
        const computedOffset = typeof rawOffset === "number" ? {
          mainAxis: rawOffset,
          crossAxis: 0
        } : {
          mainAxis: 0,
          crossAxis: 0,
          ...rawOffset
        };
        if (checkMainAxis) {
          const len = mainAxis === "y" ? "height" : "width";
          const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
          const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
          if (mainAxisCoord < limitMin) {
            mainAxisCoord = limitMin;
          } else if (mainAxisCoord > limitMax) {
            mainAxisCoord = limitMax;
          }
        }
        if (checkCrossAxis) {
          var _middlewareData$offse, _middlewareData$offse2;
          const len = mainAxis === "y" ? "width" : "height";
          const isOriginSide = originSides.has(getSide(placement));
          const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
          const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
          if (crossAxisCoord < limitMin) {
            crossAxisCoord = limitMin;
          } else if (crossAxisCoord > limitMax) {
            crossAxisCoord = limitMax;
          }
        }
        return {
          [mainAxis]: mainAxisCoord,
          [crossAxis]: crossAxisCoord
        };
      }
    };
  };
  var size = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "size",
      options,
      async fn(state) {
        var _state$middlewareData, _state$middlewareData2;
        const {
          placement,
          rects,
          platform: platform3,
          elements
        } = state;
        const {
          apply = () => {
          },
          ...detectOverflowOptions
        } = evaluate(options, state);
        const overflow = await platform3.detectOverflow(state, detectOverflowOptions);
        const side = getSide(placement);
        const alignment = getAlignment(placement);
        const isYAxis = getSideAxis(placement) === "y";
        const {
          width,
          height
        } = rects.floating;
        let heightSide;
        let widthSide;
        if (side === "top" || side === "bottom") {
          heightSide = side;
          widthSide = alignment === (await (platform3.isRTL == null ? void 0 : platform3.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
        } else {
          widthSide = side;
          heightSide = alignment === "end" ? "top" : "bottom";
        }
        const maximumClippingHeight = height - overflow.top - overflow.bottom;
        const maximumClippingWidth = width - overflow.left - overflow.right;
        const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
        const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
        const noShift = !state.middlewareData.shift;
        let availableHeight = overflowAvailableHeight;
        let availableWidth = overflowAvailableWidth;
        if ((_state$middlewareData = state.middlewareData.shift) != null && _state$middlewareData.enabled.x) {
          availableWidth = maximumClippingWidth;
        }
        if ((_state$middlewareData2 = state.middlewareData.shift) != null && _state$middlewareData2.enabled.y) {
          availableHeight = maximumClippingHeight;
        }
        if (noShift && !alignment) {
          const xMin = max(overflow.left, 0);
          const xMax = max(overflow.right, 0);
          const yMin = max(overflow.top, 0);
          const yMax = max(overflow.bottom, 0);
          if (isYAxis) {
            availableWidth = width - 2 * (xMin !== 0 || xMax !== 0 ? xMin + xMax : max(overflow.left, overflow.right));
          } else {
            availableHeight = height - 2 * (yMin !== 0 || yMax !== 0 ? yMin + yMax : max(overflow.top, overflow.bottom));
          }
        }
        await apply({
          ...state,
          availableWidth,
          availableHeight
        });
        const nextDimensions = await platform3.getDimensions(elements.floating);
        if (width !== nextDimensions.width || height !== nextDimensions.height) {
          return {
            reset: {
              rects: true
            }
          };
        }
        return {};
      }
    };
  };

  // node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
  function getCssDimensions(element) {
    const css = getComputedStyle2(element);
    let width = parseFloat(css.width) || 0;
    let height = parseFloat(css.height) || 0;
    const hasOffset = isHTMLElement(element);
    const offsetWidth = hasOffset ? element.offsetWidth : width;
    const offsetHeight = hasOffset ? element.offsetHeight : height;
    const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
    if (shouldFallback) {
      width = offsetWidth;
      height = offsetHeight;
    }
    return {
      width,
      height,
      $: shouldFallback
    };
  }
  function unwrapElement(element) {
    return !isElement(element) ? element.contextElement : element;
  }
  function getScale(element) {
    const domElement = unwrapElement(element);
    if (!isHTMLElement(domElement)) {
      return createCoords(1);
    }
    const rect = domElement.getBoundingClientRect();
    const {
      width,
      height,
      $
    } = getCssDimensions(domElement);
    let x = ($ ? round(rect.width) : rect.width) / width;
    let y = ($ ? round(rect.height) : rect.height) / height;
    if (!x || !Number.isFinite(x)) {
      x = 1;
    }
    if (!y || !Number.isFinite(y)) {
      y = 1;
    }
    return {
      x,
      y
    };
  }
  var noOffsets = /* @__PURE__ */ createCoords(0);
  function getVisualOffsets(element) {
    const win = getWindow(element);
    if (!isWebKit() || !win.visualViewport) {
      return noOffsets;
    }
    return {
      x: win.visualViewport.offsetLeft,
      y: win.visualViewport.offsetTop
    };
  }
  function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
    if (isFixed === void 0) {
      isFixed = false;
    }
    if (!floatingOffsetParent || isFixed && floatingOffsetParent !== getWindow(element)) {
      return false;
    }
    return isFixed;
  }
  function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
    if (includeScale === void 0) {
      includeScale = false;
    }
    if (isFixedStrategy === void 0) {
      isFixedStrategy = false;
    }
    const clientRect = element.getBoundingClientRect();
    const domElement = unwrapElement(element);
    let scale = createCoords(1);
    if (includeScale) {
      if (offsetParent) {
        if (isElement(offsetParent)) {
          scale = getScale(offsetParent);
        }
      } else {
        scale = getScale(element);
      }
    }
    const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
    let x = (clientRect.left + visualOffsets.x) / scale.x;
    let y = (clientRect.top + visualOffsets.y) / scale.y;
    let width = clientRect.width / scale.x;
    let height = clientRect.height / scale.y;
    if (domElement) {
      const win = getWindow(domElement);
      const offsetWin = offsetParent && isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
      let currentWin = win;
      let currentIFrame = getFrameElement(currentWin);
      while (currentIFrame && offsetParent && offsetWin !== currentWin) {
        const iframeScale = getScale(currentIFrame);
        const iframeRect = currentIFrame.getBoundingClientRect();
        const css = getComputedStyle2(currentIFrame);
        const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
        const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
        x *= iframeScale.x;
        y *= iframeScale.y;
        width *= iframeScale.x;
        height *= iframeScale.y;
        x += left;
        y += top;
        currentWin = getWindow(currentIFrame);
        currentIFrame = getFrameElement(currentWin);
      }
    }
    return rectToClientRect({
      width,
      height,
      x,
      y
    });
  }
  function getWindowScrollBarX(element, rect) {
    const leftScroll = getNodeScroll(element).scrollLeft;
    if (!rect) {
      return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
    }
    return rect.left + leftScroll;
  }
  function getHTMLOffset(documentElement, scroll) {
    const htmlRect = documentElement.getBoundingClientRect();
    const x = htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect);
    const y = htmlRect.top + scroll.scrollTop;
    return {
      x,
      y
    };
  }
  function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
    let {
      elements,
      rect,
      offsetParent,
      strategy
    } = _ref;
    const isFixed = strategy === "fixed";
    const documentElement = getDocumentElement(offsetParent);
    const topLayer = elements ? isTopLayer(elements.floating) : false;
    if (offsetParent === documentElement || topLayer && isFixed) {
      return rect;
    }
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    let scale = createCoords(1);
    const offsets = createCoords(0);
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent);
        scale = getScale(offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      }
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    return {
      width: rect.width * scale.x,
      height: rect.height * scale.y,
      x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
      y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
    };
  }
  function getClientRects(element) {
    return Array.from(element.getClientRects());
  }
  function getDocumentRect(element) {
    const html = getDocumentElement(element);
    const scroll = getNodeScroll(element);
    const body = element.ownerDocument.body;
    const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
    const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
    let x = -scroll.scrollLeft + getWindowScrollBarX(element);
    const y = -scroll.scrollTop;
    if (getComputedStyle2(body).direction === "rtl") {
      x += max(html.clientWidth, body.clientWidth) - width;
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  var SCROLLBAR_MAX = 25;
  function getViewportRect(element, strategy) {
    const win = getWindow(element);
    const html = getDocumentElement(element);
    const visualViewport = win.visualViewport;
    let width = html.clientWidth;
    let height = html.clientHeight;
    let x = 0;
    let y = 0;
    if (visualViewport) {
      width = visualViewport.width;
      height = visualViewport.height;
      const visualViewportBased = isWebKit();
      if (!visualViewportBased || visualViewportBased && strategy === "fixed") {
        x = visualViewport.offsetLeft;
        y = visualViewport.offsetTop;
      }
    }
    const windowScrollbarX = getWindowScrollBarX(html);
    if (windowScrollbarX <= 0) {
      const doc = html.ownerDocument;
      const body = doc.body;
      const bodyStyles = getComputedStyle(body);
      const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
      const clippingStableScrollbarWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
      if (clippingStableScrollbarWidth <= SCROLLBAR_MAX) {
        width -= clippingStableScrollbarWidth;
      }
    } else if (windowScrollbarX <= SCROLLBAR_MAX) {
      width += windowScrollbarX;
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  function getInnerBoundingClientRect(element, strategy) {
    const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
    const top = clientRect.top + element.clientTop;
    const left = clientRect.left + element.clientLeft;
    const scale = isHTMLElement(element) ? getScale(element) : createCoords(1);
    const width = element.clientWidth * scale.x;
    const height = element.clientHeight * scale.y;
    const x = left * scale.x;
    const y = top * scale.y;
    return {
      width,
      height,
      x,
      y
    };
  }
  function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
    let rect;
    if (clippingAncestor === "viewport") {
      rect = getViewportRect(element, strategy);
    } else if (clippingAncestor === "document") {
      rect = getDocumentRect(getDocumentElement(element));
    } else if (isElement(clippingAncestor)) {
      rect = getInnerBoundingClientRect(clippingAncestor, strategy);
    } else {
      const visualOffsets = getVisualOffsets(element);
      rect = {
        x: clippingAncestor.x - visualOffsets.x,
        y: clippingAncestor.y - visualOffsets.y,
        width: clippingAncestor.width,
        height: clippingAncestor.height
      };
    }
    return rectToClientRect(rect);
  }
  function hasFixedPositionAncestor(element, stopNode) {
    const parentNode = getParentNode(element);
    if (parentNode === stopNode || !isElement(parentNode) || isLastTraversableNode(parentNode)) {
      return false;
    }
    return getComputedStyle2(parentNode).position === "fixed" || hasFixedPositionAncestor(parentNode, stopNode);
  }
  function getClippingElementAncestors(element, cache) {
    const cachedResult = cache.get(element);
    if (cachedResult) {
      return cachedResult;
    }
    let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
    let currentContainingBlockComputedStyle = null;
    const elementIsFixed = getComputedStyle2(element).position === "fixed";
    let currentNode = elementIsFixed ? getParentNode(element) : element;
    while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
      const computedStyle = getComputedStyle2(currentNode);
      const currentNodeIsContaining = isContainingBlock(currentNode);
      if (!currentNodeIsContaining && computedStyle.position === "fixed") {
        currentContainingBlockComputedStyle = null;
      }
      const shouldDropCurrentNode = elementIsFixed ? !currentNodeIsContaining && !currentContainingBlockComputedStyle : !currentNodeIsContaining && computedStyle.position === "static" && !!currentContainingBlockComputedStyle && (currentContainingBlockComputedStyle.position === "absolute" || currentContainingBlockComputedStyle.position === "fixed") || isOverflowElement(currentNode) && !currentNodeIsContaining && hasFixedPositionAncestor(element, currentNode);
      if (shouldDropCurrentNode) {
        result = result.filter((ancestor) => ancestor !== currentNode);
      } else {
        currentContainingBlockComputedStyle = computedStyle;
      }
      currentNode = getParentNode(currentNode);
    }
    cache.set(element, result);
    return result;
  }
  function getClippingRect(_ref) {
    let {
      element,
      boundary,
      rootBoundary,
      strategy
    } = _ref;
    const elementClippingAncestors = boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary);
    const clippingAncestors = [...elementClippingAncestors, rootBoundary];
    const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
    let top = firstRect.top;
    let right = firstRect.right;
    let bottom = firstRect.bottom;
    let left = firstRect.left;
    for (let i = 1; i < clippingAncestors.length; i++) {
      const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
      top = max(rect.top, top);
      right = min(rect.right, right);
      bottom = min(rect.bottom, bottom);
      left = max(rect.left, left);
    }
    return {
      width: right - left,
      height: bottom - top,
      x: left,
      y: top
    };
  }
  function getDimensions(element) {
    const {
      width,
      height
    } = getCssDimensions(element);
    return {
      width,
      height
    };
  }
  function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    const documentElement = getDocumentElement(offsetParent);
    const isFixed = strategy === "fixed";
    const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    const offsets = createCoords(0);
    function setLeftRTLScrollbarOffset() {
      offsets.x = getWindowScrollBarX(documentElement);
    }
    if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      } else if (documentElement) {
        setLeftRTLScrollbarOffset();
      }
    }
    if (isFixed && !isOffsetParentAnElement && documentElement) {
      setLeftRTLScrollbarOffset();
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    const x = rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x;
    const y = rect.top + scroll.scrollTop - offsets.y - htmlOffset.y;
    return {
      x,
      y,
      width: rect.width,
      height: rect.height
    };
  }
  function isStaticPositioned(element) {
    return getComputedStyle2(element).position === "static";
  }
  function getTrueOffsetParent(element, polyfill) {
    if (!isHTMLElement(element) || getComputedStyle2(element).position === "fixed") {
      return null;
    }
    if (polyfill) {
      return polyfill(element);
    }
    let rawOffsetParent = element.offsetParent;
    if (getDocumentElement(element) === rawOffsetParent) {
      rawOffsetParent = rawOffsetParent.ownerDocument.body;
    }
    return rawOffsetParent;
  }
  function getOffsetParent(element, polyfill) {
    const win = getWindow(element);
    if (isTopLayer(element)) {
      return win;
    }
    if (!isHTMLElement(element)) {
      let svgOffsetParent = getParentNode(element);
      while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
        if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) {
          return svgOffsetParent;
        }
        svgOffsetParent = getParentNode(svgOffsetParent);
      }
      return win;
    }
    let offsetParent = getTrueOffsetParent(element, polyfill);
    while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) {
      offsetParent = getTrueOffsetParent(offsetParent, polyfill);
    }
    if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) {
      return win;
    }
    return offsetParent || getContainingBlock(element) || win;
  }
  var getElementRects = async function(data) {
    const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
    const getDimensionsFn = this.getDimensions;
    const floatingDimensions = await getDimensionsFn(data.floating);
    return {
      reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
      floating: {
        x: 0,
        y: 0,
        width: floatingDimensions.width,
        height: floatingDimensions.height
      }
    };
  };
  function isRTL(element) {
    return getComputedStyle2(element).direction === "rtl";
  }
  var platform2 = {
    convertOffsetParentRelativeRectToViewportRelativeRect,
    getDocumentElement,
    getClippingRect,
    getOffsetParent,
    getElementRects,
    getClientRects,
    getDimensions,
    getScale,
    isElement,
    isRTL
  };
  function rectsAreEqual(a, b) {
    return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
  }
  function observeMove(element, onMove) {
    let io = null;
    let timeoutId;
    const root = getDocumentElement(element);
    function cleanup() {
      var _io;
      clearTimeout(timeoutId);
      (_io = io) == null || _io.disconnect();
      io = null;
    }
    function refresh(skip, threshold) {
      if (skip === void 0) {
        skip = false;
      }
      if (threshold === void 0) {
        threshold = 1;
      }
      cleanup();
      const elementRectForRootMargin = element.getBoundingClientRect();
      const {
        left,
        top,
        width,
        height
      } = elementRectForRootMargin;
      if (!skip) {
        onMove();
      }
      if (!width || !height) {
        return;
      }
      const insetTop = floor(top);
      const insetRight = floor(root.clientWidth - (left + width));
      const insetBottom = floor(root.clientHeight - (top + height));
      const insetLeft = floor(left);
      const rootMargin = -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px";
      const options = {
        rootMargin,
        threshold: max(0, min(1, threshold)) || 1
      };
      let isFirstUpdate = true;
      function handleObserve(entries) {
        const ratio = entries[0].intersectionRatio;
        if (ratio !== threshold) {
          if (!isFirstUpdate) {
            return refresh();
          }
          if (!ratio) {
            timeoutId = setTimeout(() => {
              refresh(false, 1e-7);
            }, 1e3);
          } else {
            refresh(false, ratio);
          }
        }
        if (ratio === 1 && !rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) {
          refresh();
        }
        isFirstUpdate = false;
      }
      try {
        io = new IntersectionObserver(handleObserve, {
          ...options,
          // Handle <iframe>s
          root: root.ownerDocument
        });
      } catch (_e) {
        io = new IntersectionObserver(handleObserve, options);
      }
      io.observe(element);
    }
    refresh(true);
    return cleanup;
  }
  function autoUpdate(reference, floating, update2, options) {
    if (options === void 0) {
      options = {};
    }
    const {
      ancestorScroll = true,
      ancestorResize = true,
      elementResize = typeof ResizeObserver === "function",
      layoutShift = typeof IntersectionObserver === "function",
      animationFrame = false
    } = options;
    const referenceEl = unwrapElement(reference);
    const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
    ancestors.forEach((ancestor) => {
      ancestorScroll && ancestor.addEventListener("scroll", update2, {
        passive: true
      });
      ancestorResize && ancestor.addEventListener("resize", update2);
    });
    const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update2) : null;
    let reobserveFrame = -1;
    let resizeObserver = null;
    if (elementResize) {
      resizeObserver = new ResizeObserver((_ref) => {
        let [firstEntry] = _ref;
        if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
          resizeObserver.unobserve(floating);
          cancelAnimationFrame(reobserveFrame);
          reobserveFrame = requestAnimationFrame(() => {
            var _resizeObserver;
            (_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
          });
        }
        update2();
      });
      if (referenceEl && !animationFrame) {
        resizeObserver.observe(referenceEl);
      }
      if (floating) {
        resizeObserver.observe(floating);
      }
    }
    let frameId;
    let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
    if (animationFrame) {
      frameLoop();
    }
    function frameLoop() {
      const nextRefRect = getBoundingClientRect(reference);
      if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) {
        update2();
      }
      prevRefRect = nextRefRect;
      frameId = requestAnimationFrame(frameLoop);
    }
    update2();
    return () => {
      var _resizeObserver2;
      ancestors.forEach((ancestor) => {
        ancestorScroll && ancestor.removeEventListener("scroll", update2);
        ancestorResize && ancestor.removeEventListener("resize", update2);
      });
      cleanupIo == null || cleanupIo();
      (_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
      resizeObserver = null;
      if (animationFrame) {
        cancelAnimationFrame(frameId);
      }
    };
  }
  var offset2 = offset;
  var shift2 = shift;
  var flip2 = flip;
  var size2 = size;
  var hide2 = hide;
  var limitShift2 = limitShift;
  var computePosition2 = (reference, floating, options) => {
    const cache = /* @__PURE__ */ new Map();
    const mergedOptions = {
      platform: platform2,
      ...options
    };
    const platformWithCache = {
      ...mergedOptions.platform,
      _c: cache
    };
    return computePosition(reference, floating, {
      ...mergedOptions,
      platform: platformWithCache
    });
  };

  // node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
  var React33 = __toESM(require_react_shim(), 1);
  var import_react2 = __toESM(require_react_shim(), 1);
  var ReactDOM3 = __toESM(require_react_dom_shim(), 1);
  var isClient = typeof document !== "undefined";
  var noop2 = function noop3() {
  };
  var index = isClient ? import_react2.useLayoutEffect : noop2;
  function deepEqual(a, b) {
    if (a === b) {
      return true;
    }
    if (typeof a !== typeof b) {
      return false;
    }
    if (typeof a === "function" && a.toString() === b.toString()) {
      return true;
    }
    let length;
    let i;
    let keys;
    if (a && b && typeof a === "object") {
      if (Array.isArray(a)) {
        length = a.length;
        if (length !== b.length) return false;
        for (i = length; i-- !== 0; ) {
          if (!deepEqual(a[i], b[i])) {
            return false;
          }
        }
        return true;
      }
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length) {
        return false;
      }
      for (i = length; i-- !== 0; ) {
        if (!{}.hasOwnProperty.call(b, keys[i])) {
          return false;
        }
      }
      for (i = length; i-- !== 0; ) {
        const key = keys[i];
        if (key === "_owner" && a.$$typeof) {
          continue;
        }
        if (!deepEqual(a[key], b[key])) {
          return false;
        }
      }
      return true;
    }
    return a !== a && b !== b;
  }
  function getDPR(element) {
    if (typeof window === "undefined") {
      return 1;
    }
    const win = element.ownerDocument.defaultView || window;
    return win.devicePixelRatio || 1;
  }
  function roundByDPR(element, value) {
    const dpr = getDPR(element);
    return Math.round(value * dpr) / dpr;
  }
  function useLatestRef(value) {
    const ref = React33.useRef(value);
    index(() => {
      ref.current = value;
    });
    return ref;
  }
  function useFloating(options) {
    if (options === void 0) {
      options = {};
    }
    const {
      placement = "bottom",
      strategy = "absolute",
      middleware = [],
      platform: platform3,
      elements: {
        reference: externalReference,
        floating: externalFloating
      } = {},
      transform = true,
      whileElementsMounted,
      open
    } = options;
    const [data, setData] = React33.useState({
      x: 0,
      y: 0,
      strategy,
      placement,
      middlewareData: {},
      isPositioned: false
    });
    const [latestMiddleware, setLatestMiddleware] = React33.useState(middleware);
    if (!deepEqual(latestMiddleware, middleware)) {
      setLatestMiddleware(middleware);
    }
    const [_reference, _setReference] = React33.useState(null);
    const [_floating, _setFloating] = React33.useState(null);
    const setReference = React33.useCallback((node) => {
      if (node !== referenceRef.current) {
        referenceRef.current = node;
        _setReference(node);
      }
    }, []);
    const setFloating = React33.useCallback((node) => {
      if (node !== floatingRef.current) {
        floatingRef.current = node;
        _setFloating(node);
      }
    }, []);
    const referenceEl = externalReference || _reference;
    const floatingEl = externalFloating || _floating;
    const referenceRef = React33.useRef(null);
    const floatingRef = React33.useRef(null);
    const dataRef = React33.useRef(data);
    const hasWhileElementsMounted = whileElementsMounted != null;
    const whileElementsMountedRef = useLatestRef(whileElementsMounted);
    const platformRef = useLatestRef(platform3);
    const openRef = useLatestRef(open);
    const update2 = React33.useCallback(() => {
      if (!referenceRef.current || !floatingRef.current) {
        return;
      }
      const config = {
        placement,
        strategy,
        middleware: latestMiddleware
      };
      if (platformRef.current) {
        config.platform = platformRef.current;
      }
      computePosition2(referenceRef.current, floatingRef.current, config).then((data2) => {
        const fullData = {
          ...data2,
          // The floating element's position may be recomputed while it's closed
          // but still mounted (such as when transitioning out). To ensure
          // `isPositioned` will be `false` initially on the next open, avoid
          // setting it to `true` when `open === false` (must be specified).
          isPositioned: openRef.current !== false
        };
        if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
          dataRef.current = fullData;
          ReactDOM3.flushSync(() => {
            setData(fullData);
          });
        }
      });
    }, [latestMiddleware, placement, strategy, platformRef, openRef]);
    index(() => {
      if (open === false && dataRef.current.isPositioned) {
        dataRef.current.isPositioned = false;
        setData((data2) => ({
          ...data2,
          isPositioned: false
        }));
      }
    }, [open]);
    const isMountedRef = React33.useRef(false);
    index(() => {
      isMountedRef.current = true;
      return () => {
        isMountedRef.current = false;
      };
    }, []);
    index(() => {
      if (referenceEl) referenceRef.current = referenceEl;
      if (floatingEl) floatingRef.current = floatingEl;
      if (referenceEl && floatingEl) {
        if (whileElementsMountedRef.current) {
          return whileElementsMountedRef.current(referenceEl, floatingEl, update2);
        }
        update2();
      }
    }, [referenceEl, floatingEl, update2, whileElementsMountedRef, hasWhileElementsMounted]);
    const refs = React33.useMemo(() => ({
      reference: referenceRef,
      floating: floatingRef,
      setReference,
      setFloating
    }), [setReference, setFloating]);
    const elements = React33.useMemo(() => ({
      reference: referenceEl,
      floating: floatingEl
    }), [referenceEl, floatingEl]);
    const floatingStyles = React33.useMemo(() => {
      const initialStyles = {
        position: strategy,
        left: 0,
        top: 0
      };
      if (!elements.floating) {
        return initialStyles;
      }
      const x = roundByDPR(elements.floating, data.x);
      const y = roundByDPR(elements.floating, data.y);
      if (transform) {
        return {
          ...initialStyles,
          transform: "translate(" + x + "px, " + y + "px)",
          ...getDPR(elements.floating) >= 1.5 && {
            willChange: "transform"
          }
        };
      }
      return {
        position: strategy,
        left: x,
        top: y
      };
    }, [strategy, transform, elements.floating, data.x, data.y]);
    return React33.useMemo(() => ({
      ...data,
      update: update2,
      refs,
      elements,
      floatingStyles
    }), [data, update2, refs, elements, floatingStyles]);
  }
  var offset3 = (options, deps) => {
    const result = offset2(options);
    return {
      name: result.name,
      fn: result.fn,
      options: [options, deps]
    };
  };
  var shift3 = (options, deps) => {
    const result = shift2(options);
    return {
      name: result.name,
      fn: result.fn,
      options: [options, deps]
    };
  };
  var limitShift3 = (options, deps) => {
    const result = limitShift2(options);
    return {
      fn: result.fn,
      options: [options, deps]
    };
  };
  var flip3 = (options, deps) => {
    const result = flip2(options);
    return {
      name: result.name,
      fn: result.fn,
      options: [options, deps]
    };
  };
  var size3 = (options, deps) => {
    const result = size2(options);
    return {
      name: result.name,
      fn: result.fn,
      options: [options, deps]
    };
  };
  var hide3 = (options, deps) => {
    const result = hide2(options);
    return {
      name: result.name,
      fn: result.fn,
      options: [options, deps]
    };
  };

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useFloatingRootContext.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingRootStore.js
  init_define_import_meta_env();

  // node_modules/@base-ui/utils/esm/store/createSelector.js
  init_define_import_meta_env();

  // node_modules/reselect/dist/reselect.mjs
  init_define_import_meta_env();
  var runIdentityFunctionCheck = (resultFunc, inputSelectorsResults, outputSelectorResult) => {
    if (inputSelectorsResults.length === 1 && inputSelectorsResults[0] === outputSelectorResult) {
      let isInputSameAsOutput = false;
      try {
        const emptyObject = {};
        if (resultFunc(emptyObject) === emptyObject)
          isInputSameAsOutput = true;
      } catch {
      }
      if (isInputSameAsOutput) {
        let stack = void 0;
        try {
          throw new Error();
        } catch (e) {
          ;
          ({ stack } = e);
        }
        console.warn(
          "The result function returned its own inputs without modification. e.g\n`createSelector([state => state.todos], todos => todos)`\nThis could lead to inefficient memoization and unnecessary re-renders.\nEnsure transformation logic is in the result function, and extraction logic is in the input selectors.",
          { stack }
        );
      }
    }
  };
  var runInputStabilityCheck = (inputSelectorResultsObject, options, inputSelectorArgs) => {
    const { memoize, memoizeOptions } = options;
    const { inputSelectorResults, inputSelectorResultsCopy } = inputSelectorResultsObject;
    const createAnEmptyObject = memoize(() => ({}), ...memoizeOptions);
    const areInputSelectorResultsEqual = createAnEmptyObject.apply(null, inputSelectorResults) === createAnEmptyObject.apply(null, inputSelectorResultsCopy);
    if (!areInputSelectorResultsEqual) {
      let stack = void 0;
      try {
        throw new Error();
      } catch (e) {
        ;
        ({ stack } = e);
      }
      console.warn(
        "An input selector returned a different result when passed same arguments.\nThis means your output selector will likely run more frequently than intended.\nAvoid returning a new reference inside your input selector, e.g.\n`createSelector([state => state.todos.map(todo => todo.id)], todoIds => todoIds.length)`",
        {
          arguments: inputSelectorArgs,
          firstInputs: inputSelectorResults,
          secondInputs: inputSelectorResultsCopy,
          stack
        }
      );
    }
  };
  var globalDevModeChecks = {
    inputStabilityCheck: "once",
    identityFunctionCheck: "once"
  };
  var NOT_FOUND = /* @__PURE__ */ Symbol("NOT_FOUND");
  function assertIsFunction(func, errorMessage = `expected a function, instead received ${typeof func}`) {
    if (typeof func !== "function") {
      throw new TypeError(errorMessage);
    }
  }
  function assertIsObject(object, errorMessage = `expected an object, instead received ${typeof object}`) {
    if (typeof object !== "object") {
      throw new TypeError(errorMessage);
    }
  }
  function assertIsArrayOfFunctions(array, errorMessage = `expected all items to be functions, instead received the following types: `) {
    if (!array.every((item) => typeof item === "function")) {
      const itemTypes = array.map(
        (item) => typeof item === "function" ? `function ${item.name || "unnamed"}()` : typeof item
      ).join(", ");
      throw new TypeError(`${errorMessage}[${itemTypes}]`);
    }
  }
  var ensureIsArray = (item) => {
    return Array.isArray(item) ? item : [item];
  };
  function getDependencies(createSelectorArgs) {
    const dependencies = Array.isArray(createSelectorArgs[0]) ? createSelectorArgs[0] : createSelectorArgs;
    assertIsArrayOfFunctions(
      dependencies,
      `createSelector expects all input-selectors to be functions, but received the following types: `
    );
    return dependencies;
  }
  function collectInputSelectorResults(dependencies, inputSelectorArgs) {
    const inputSelectorResults = [];
    const { length } = dependencies;
    for (let i = 0; i < length; i++) {
      inputSelectorResults.push(dependencies[i].apply(null, inputSelectorArgs));
    }
    return inputSelectorResults;
  }
  var getDevModeChecksExecutionInfo = (firstRun, devModeChecks) => {
    const { identityFunctionCheck, inputStabilityCheck } = {
      ...globalDevModeChecks,
      ...devModeChecks
    };
    return {
      identityFunctionCheck: {
        shouldRun: identityFunctionCheck === "always" || identityFunctionCheck === "once" && firstRun,
        run: runIdentityFunctionCheck
      },
      inputStabilityCheck: {
        shouldRun: inputStabilityCheck === "always" || inputStabilityCheck === "once" && firstRun,
        run: runInputStabilityCheck
      }
    };
  };
  var proto = Object.getPrototypeOf({});
  function createSingletonCache(equals) {
    let entry;
    return {
      get(key) {
        if (entry && equals(entry.key, key)) {
          return entry.value;
        }
        return NOT_FOUND;
      },
      put(key, value) {
        entry = { key, value };
      },
      getEntries() {
        return entry ? [entry] : [];
      },
      clear() {
        entry = void 0;
      }
    };
  }
  function createLruCache2(maxSize, equals) {
    let entries = [];
    function get(key) {
      const cacheIndex = entries.findIndex((entry) => equals(key, entry.key));
      if (cacheIndex > -1) {
        const entry = entries[cacheIndex];
        if (cacheIndex > 0) {
          entries.splice(cacheIndex, 1);
          entries.unshift(entry);
        }
        return entry.value;
      }
      return NOT_FOUND;
    }
    function put(key, value) {
      if (get(key) === NOT_FOUND) {
        entries.unshift({ key, value });
        if (entries.length > maxSize) {
          entries.pop();
        }
      }
    }
    function getEntries() {
      return entries;
    }
    function clear() {
      entries = [];
    }
    return { get, put, getEntries, clear };
  }
  var referenceEqualityCheck = (a, b) => a === b;
  function createCacheKeyComparator(equalityCheck) {
    return function areArgumentsShallowlyEqual(prev, next) {
      if (prev === null || next === null || prev.length !== next.length) {
        return false;
      }
      const { length } = prev;
      for (let i = 0; i < length; i++) {
        if (!equalityCheck(prev[i], next[i])) {
          return false;
        }
      }
      return true;
    };
  }
  function lruMemoize(func, equalityCheckOrOptions) {
    const providedOptions = typeof equalityCheckOrOptions === "object" ? equalityCheckOrOptions : { equalityCheck: equalityCheckOrOptions };
    const {
      equalityCheck = referenceEqualityCheck,
      maxSize = 1,
      resultEqualityCheck
    } = providedOptions;
    const comparator = createCacheKeyComparator(equalityCheck);
    let resultsCount = 0;
    const cache = maxSize <= 1 ? createSingletonCache(comparator) : createLruCache2(maxSize, comparator);
    function memoized() {
      let value = cache.get(arguments);
      if (value === NOT_FOUND) {
        value = func.apply(null, arguments);
        resultsCount++;
        if (resultEqualityCheck) {
          const entries = cache.getEntries();
          const matchingEntry = entries.find(
            (entry) => resultEqualityCheck(entry.value, value)
          );
          if (matchingEntry) {
            value = matchingEntry.value;
            resultsCount !== 0 && resultsCount--;
          }
        }
        cache.put(arguments, value);
      }
      return value;
    }
    memoized.clearCache = () => {
      cache.clear();
      memoized.resetResultsCount();
    };
    memoized.resultsCount = () => resultsCount;
    memoized.resetResultsCount = () => {
      resultsCount = 0;
    };
    return memoized;
  }
  var StrongRef = class {
    constructor(value) {
      this.value = value;
    }
    deref() {
      return this.value;
    }
  };
  var Ref = typeof WeakRef !== "undefined" ? WeakRef : StrongRef;
  var UNTERMINATED = 0;
  var TERMINATED = 1;
  function createCacheNode() {
    return {
      s: UNTERMINATED,
      v: void 0,
      o: null,
      p: null
    };
  }
  function weakMapMemoize(func, options = {}) {
    let fnNode = createCacheNode();
    const { resultEqualityCheck } = options;
    let lastResult;
    let resultsCount = 0;
    function memoized() {
      let cacheNode = fnNode;
      const { length } = arguments;
      for (let i = 0, l = length; i < l; i++) {
        const arg = arguments[i];
        if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
          let objectCache = cacheNode.o;
          if (objectCache === null) {
            cacheNode.o = objectCache = /* @__PURE__ */ new WeakMap();
          }
          const objectNode = objectCache.get(arg);
          if (objectNode === void 0) {
            cacheNode = createCacheNode();
            objectCache.set(arg, cacheNode);
          } else {
            cacheNode = objectNode;
          }
        } else {
          let primitiveCache = cacheNode.p;
          if (primitiveCache === null) {
            cacheNode.p = primitiveCache = /* @__PURE__ */ new Map();
          }
          const primitiveNode = primitiveCache.get(arg);
          if (primitiveNode === void 0) {
            cacheNode = createCacheNode();
            primitiveCache.set(arg, cacheNode);
          } else {
            cacheNode = primitiveNode;
          }
        }
      }
      const terminatedNode = cacheNode;
      let result;
      if (cacheNode.s === TERMINATED) {
        result = cacheNode.v;
      } else {
        result = func.apply(null, arguments);
        resultsCount++;
        if (resultEqualityCheck) {
          const lastResultValue = lastResult?.deref?.() ?? lastResult;
          if (lastResultValue != null && resultEqualityCheck(lastResultValue, result)) {
            result = lastResultValue;
            resultsCount !== 0 && resultsCount--;
          }
          const needsWeakRef = typeof result === "object" && result !== null || typeof result === "function";
          lastResult = needsWeakRef ? new Ref(result) : result;
        }
      }
      terminatedNode.s = TERMINATED;
      terminatedNode.v = result;
      return result;
    }
    memoized.clearCache = () => {
      fnNode = createCacheNode();
      memoized.resetResultsCount();
    };
    memoized.resultsCount = () => resultsCount;
    memoized.resetResultsCount = () => {
      resultsCount = 0;
    };
    return memoized;
  }
  function createSelectorCreator(memoizeOrOptions, ...memoizeOptionsFromArgs) {
    const createSelectorCreatorOptions = typeof memoizeOrOptions === "function" ? {
      memoize: memoizeOrOptions,
      memoizeOptions: memoizeOptionsFromArgs
    } : memoizeOrOptions;
    const createSelector22 = (...createSelectorArgs) => {
      let recomputations = 0;
      let dependencyRecomputations = 0;
      let lastResult;
      let directlyPassedOptions = {};
      let resultFunc = createSelectorArgs.pop();
      if (typeof resultFunc === "object") {
        directlyPassedOptions = resultFunc;
        resultFunc = createSelectorArgs.pop();
      }
      assertIsFunction(
        resultFunc,
        `createSelector expects an output function after the inputs, but received: [${typeof resultFunc}]`
      );
      const combinedOptions = {
        ...createSelectorCreatorOptions,
        ...directlyPassedOptions
      };
      const {
        memoize,
        memoizeOptions = [],
        argsMemoize = weakMapMemoize,
        argsMemoizeOptions = [],
        devModeChecks = {}
      } = combinedOptions;
      const finalMemoizeOptions = ensureIsArray(memoizeOptions);
      const finalArgsMemoizeOptions = ensureIsArray(argsMemoizeOptions);
      const dependencies = getDependencies(createSelectorArgs);
      const memoizedResultFunc = memoize(function recomputationWrapper() {
        recomputations++;
        return resultFunc.apply(
          null,
          arguments
        );
      }, ...finalMemoizeOptions);
      let firstRun = true;
      const selector = argsMemoize(function dependenciesChecker() {
        dependencyRecomputations++;
        const inputSelectorResults = collectInputSelectorResults(
          dependencies,
          arguments
        );
        lastResult = memoizedResultFunc.apply(null, inputSelectorResults);
        if (true) {
          const { identityFunctionCheck, inputStabilityCheck } = getDevModeChecksExecutionInfo(firstRun, devModeChecks);
          if (identityFunctionCheck.shouldRun) {
            identityFunctionCheck.run(
              resultFunc,
              inputSelectorResults,
              lastResult
            );
          }
          if (inputStabilityCheck.shouldRun) {
            const inputSelectorResultsCopy = collectInputSelectorResults(
              dependencies,
              arguments
            );
            inputStabilityCheck.run(
              { inputSelectorResults, inputSelectorResultsCopy },
              { memoize, memoizeOptions: finalMemoizeOptions },
              arguments
            );
          }
          if (firstRun)
            firstRun = false;
        }
        return lastResult;
      }, ...finalArgsMemoizeOptions);
      return Object.assign(selector, {
        resultFunc,
        memoizedResultFunc,
        dependencies,
        dependencyRecomputations: () => dependencyRecomputations,
        resetDependencyRecomputations: () => {
          dependencyRecomputations = 0;
        },
        lastResult: () => lastResult,
        recomputations: () => recomputations,
        resetRecomputations: () => {
          recomputations = 0;
        },
        memoize,
        argsMemoize
      });
    };
    Object.assign(createSelector22, {
      withTypes: () => createSelector22
    });
    return createSelector22;
  }
  var createSelector = /* @__PURE__ */ createSelectorCreator(weakMapMemoize);
  var createStructuredSelector = Object.assign(
    (inputSelectorsObject, selectorCreator = createSelector) => {
      assertIsObject(
        inputSelectorsObject,
        `createStructuredSelector expects first argument to be an object where each property is a selector, instead received a ${typeof inputSelectorsObject}`
      );
      const inputSelectorKeys = Object.keys(inputSelectorsObject);
      const dependencies = inputSelectorKeys.map(
        (key) => inputSelectorsObject[key]
      );
      const structuredSelector = selectorCreator(
        dependencies,
        (...inputSelectorResults) => {
          return inputSelectorResults.reduce((composition, value, index2) => {
            composition[inputSelectorKeys[index2]] = value;
            return composition;
          }, {});
        }
      );
      return structuredSelector;
    },
    { withTypes: () => createStructuredSelector }
  );

  // node_modules/@base-ui/utils/esm/store/createSelector.js
  var reselectCreateSelector = createSelectorCreator({
    memoize: lruMemoize,
    memoizeOptions: {
      maxSize: 1,
      equalityCheck: Object.is
    }
  });
  var createSelector2 = (a, b, c, d, e, f, ...other) => {
    if (other.length > 0) {
      throw new Error(true ? "Unsupported number of selectors" : formatErrorMessage_default(1));
    }
    let selector;
    if (a && b && c && d && e && f) {
      selector = (state, a1, a2, a3) => {
        const va = a(state, a1, a2, a3);
        const vb = b(state, a1, a2, a3);
        const vc = c(state, a1, a2, a3);
        const vd = d(state, a1, a2, a3);
        const ve = e(state, a1, a2, a3);
        return f(va, vb, vc, vd, ve, a1, a2, a3);
      };
    } else if (a && b && c && d && e) {
      selector = (state, a1, a2, a3) => {
        const va = a(state, a1, a2, a3);
        const vb = b(state, a1, a2, a3);
        const vc = c(state, a1, a2, a3);
        const vd = d(state, a1, a2, a3);
        return e(va, vb, vc, vd, a1, a2, a3);
      };
    } else if (a && b && c && d) {
      selector = (state, a1, a2, a3) => {
        const va = a(state, a1, a2, a3);
        const vb = b(state, a1, a2, a3);
        const vc = c(state, a1, a2, a3);
        return d(va, vb, vc, a1, a2, a3);
      };
    } else if (a && b && c) {
      selector = (state, a1, a2, a3) => {
        const va = a(state, a1, a2, a3);
        const vb = b(state, a1, a2, a3);
        return c(va, vb, a1, a2, a3);
      };
    } else if (a && b) {
      selector = (state, a1, a2, a3) => {
        const va = a(state, a1, a2, a3);
        return b(va, a1, a2, a3);
      };
    } else if (a) {
      selector = a;
    } else {
      throw (
        /* minify-error-disabled */
        new Error("Missing arguments")
      );
    }
    return selector;
  };

  // node_modules/@base-ui/utils/esm/store/useStore.js
  init_define_import_meta_env();
  var React35 = __toESM(require_react_shim(), 1);
  var import_shim = __toESM(require_shim(), 1);
  var import_with_selector = __toESM(require_with_selector(), 1);

  // node_modules/@base-ui/utils/esm/fastHooks.js
  init_define_import_meta_env();
  var React34 = __toESM(require_react_shim(), 1);
  var hooks = [];
  var currentInstance = void 0;
  function getInstance() {
    return currentInstance;
  }
  function register(hook) {
    hooks.push(hook);
  }
  function fastComponent(fn) {
    const FastComponent = (props, forwardedRef) => {
      const instance = useRefWithInit(createInstance).current;
      let result;
      try {
        currentInstance = instance;
        for (const hook of hooks) {
          hook.before(instance);
        }
        result = fn(props, forwardedRef);
        for (const hook of hooks) {
          hook.after(instance);
        }
        instance.didInitialize = true;
      } finally {
        currentInstance = void 0;
      }
      return result;
    };
    FastComponent.displayName = fn.displayName || fn.name;
    return FastComponent;
  }
  function fastComponentRef(fn) {
    return /* @__PURE__ */ React34.forwardRef(fastComponent(fn));
  }
  function createInstance() {
    return {
      didInitialize: false
    };
  }

  // node_modules/@base-ui/utils/esm/store/useStore.js
  var canUseRawUseSyncExternalStore = isReactVersionAtLeast(19);
  var useStoreImplementation = canUseRawUseSyncExternalStore ? useStoreFast : useStoreLegacy;
  function useStore(store, selector, a1, a2, a3) {
    return useStoreImplementation(store, selector, a1, a2, a3);
  }
  function useStoreR19(store, selector, a1, a2, a3) {
    const getSelection = React35.useCallback(() => selector(store.getSnapshot(), a1, a2, a3), [store, selector, a1, a2, a3]);
    return (0, import_shim.useSyncExternalStore)(store.subscribe, getSelection, getSelection);
  }
  register({
    before(instance) {
      instance.syncIndex = 0;
      if (!instance.didInitialize) {
        instance.syncTick = 1;
        instance.syncHooks = [];
        instance.didChangeStore = true;
        instance.getSnapshot = () => {
          let didChange2 = false;
          for (let i = 0; i < instance.syncHooks.length; i += 1) {
            const hook = instance.syncHooks[i];
            const value = hook.selector(hook.store.state, hook.a1, hook.a2, hook.a3);
            if (hook.didChange || !Object.is(hook.value, value)) {
              didChange2 = true;
              hook.value = value;
              hook.didChange = false;
            }
          }
          if (didChange2) {
            instance.syncTick += 1;
          }
          return instance.syncTick;
        };
      }
    },
    after(instance) {
      if (instance.syncHooks.length > 0) {
        if (instance.didChangeStore) {
          instance.didChangeStore = false;
          instance.subscribe = (onStoreChange) => {
            const stores = /* @__PURE__ */ new Set();
            for (const hook of instance.syncHooks) {
              stores.add(hook.store);
            }
            const unsubscribes = [];
            for (const store of stores) {
              unsubscribes.push(store.subscribe(onStoreChange));
            }
            return () => {
              for (const unsubscribe of unsubscribes) {
                unsubscribe();
              }
            };
          };
        }
        (0, import_shim.useSyncExternalStore)(instance.subscribe, instance.getSnapshot, instance.getSnapshot);
      }
    }
  });
  function useStoreFast(store, selector, a1, a2, a3) {
    const instance = getInstance();
    if (!instance) {
      return useStoreR19(store, selector, a1, a2, a3);
    }
    const index2 = instance.syncIndex;
    instance.syncIndex += 1;
    let hook;
    if (!instance.didInitialize) {
      hook = {
        store,
        selector,
        a1,
        a2,
        a3,
        value: selector(store.getSnapshot(), a1, a2, a3),
        didChange: false
      };
      instance.syncHooks.push(hook);
    } else {
      hook = instance.syncHooks[index2];
      if (hook.store !== store || hook.selector !== selector || !Object.is(hook.a1, a1) || !Object.is(hook.a2, a2) || !Object.is(hook.a3, a3)) {
        if (hook.store !== store) {
          instance.didChangeStore = true;
        }
        hook.store = store;
        hook.selector = selector;
        hook.a1 = a1;
        hook.a2 = a2;
        hook.a3 = a3;
        hook.didChange = true;
      }
    }
    return hook.value;
  }
  function useStoreLegacy(store, selector, a1, a2, a3) {
    return (0, import_with_selector.useSyncExternalStoreWithSelector)(store.subscribe, store.getSnapshot, store.getSnapshot, (state) => selector(state, a1, a2, a3));
  }

  // node_modules/@base-ui/utils/esm/store/Store.js
  init_define_import_meta_env();
  var Store = class {
    /**
     * The current state of the store.
     * This property is updated immediately when the state changes as a result of calling {@link setState}, {@link update}, or {@link set}.
     * To subscribe to state changes, use the {@link useState} method. The value returned by {@link useState} is updated after the component renders (similarly to React's useState).
     * The values can be used directly (to avoid subscribing to the store) in effects or event handlers.
     *
     * Do not modify properties in state directly. Instead, use the provided methods to ensure proper state management and listener notification.
     */
    // Internal state to handle recursive `setState()` calls
    constructor(state) {
      /**
       * Registers a listener that will be called whenever the store's state changes.
       *
       * @param fn The listener function to be called on state changes.
       * @returns A function to unsubscribe the listener.
       */
      __publicField(this, "subscribe", (fn) => {
        this.listeners.add(fn);
        return () => {
          this.listeners.delete(fn);
        };
      });
      /**
       * Returns the current state of the store.
       */
      __publicField(this, "getSnapshot", () => {
        return this.state;
      });
      this.state = state;
      this.listeners = /* @__PURE__ */ new Set();
      this.updateTick = 0;
    }
    /**
     * Updates the entire store's state and notifies all registered listeners.
     *
     * @param newState The new state to set for the store.
     */
    setState(newState) {
      if (this.state === newState) {
        return;
      }
      this.state = newState;
      this.updateTick += 1;
      const currentTick = this.updateTick;
      for (const listener of this.listeners) {
        if (currentTick !== this.updateTick) {
          return;
        }
        listener(newState);
      }
    }
    /**
     * Merges the provided changes into the current state and notifies listeners if there are changes.
     *
     * @param changes An object containing the changes to apply to the current state.
     */
    update(changes) {
      for (const key in changes) {
        if (!Object.is(this.state[key], changes[key])) {
          this.setState({
            ...this.state,
            ...changes
          });
          return;
        }
      }
    }
    /**
     * Sets a specific key in the store's state to a new value and notifies listeners if the value has changed.
     *
     * @param key The key in the store's state to update.
     * @param value The new value to set for the specified key.
     */
    set(key, value) {
      if (!Object.is(this.state[key], value)) {
        this.setState({
          ...this.state,
          [key]: value
        });
      }
    }
    /**
     * Gives the state a new reference and updates all registered listeners.
     */
    notifyAll() {
      const newState = {
        ...this.state
      };
      this.setState(newState);
    }
    use(selector, a1, a2, a3) {
      return useStore(this, selector, a1, a2, a3);
    }
  };

  // node_modules/@base-ui/utils/esm/store/ReactStore.js
  init_define_import_meta_env();
  var React36 = __toESM(require_react_shim(), 1);
  var ReactStore = class extends Store {
    /**
     * Creates a new ReactStore instance.
     *
     * @param state Initial state of the store.
     * @param context Non-reactive context values.
     * @param selectors Optional selectors for use with `useState`.
     */
    constructor(state, context = {}, selectors6) {
      super(state);
      this.context = context;
      this.selectors = selectors6;
    }
    /**
     * Non-reactive values such as refs, callbacks, etc.
     */
    /**
     * Synchronizes a single external value into the store.
     *
     * Note that the while the value in `state` is updated immediately, the value returned
     * by `useState` is updated before the next render (similarly to React's `useState`).
     */
    useSyncedValue(key, value) {
      React36.useDebugValue(key);
      useIsoLayoutEffect(() => {
        if (this.state[key] !== value) {
          this.set(key, value);
        }
      }, [key, value]);
    }
    /**
     * Synchronizes a single external value into the store and
     * cleans it up (sets to `undefined`) on unmount.
     *
     * Note that the while the value in `state` is updated immediately, the value returned
     * by `useState` is updated before the next render (similarly to React's `useState`).
     */
    useSyncedValueWithCleanup(key, value) {
      const store = this;
      useIsoLayoutEffect(() => {
        if (store.state[key] !== value) {
          store.set(key, value);
        }
        return () => {
          store.set(key, void 0);
        };
      }, [store, key, value]);
    }
    /**
     * Synchronizes multiple external values into the store.
     *
     * Note that the while the values in `state` are updated immediately, the values returned
     * by `useState` are updated before the next render (similarly to React's `useState`).
     */
    useSyncedValues(statePart) {
      const store = this;
      if (true) {
        React36.useDebugValue(statePart, (p) => Object.keys(p));
        const keys = React36.useRef(Object.keys(statePart)).current;
        const nextKeys = Object.keys(statePart);
        if (keys.length !== nextKeys.length || keys.some((key, index2) => key !== nextKeys[index2])) {
          console.error("ReactStore.useSyncedValues expects the same prop keys on every render. Keys should be stable.");
        }
      }
      const dependencies = Object.values(statePart);
      useIsoLayoutEffect(() => {
        store.update(statePart);
      }, [store, ...dependencies]);
    }
    /**
     * Registers a controllable prop pair (`controlled`, `defaultValue`) for a specific key. If `controlled`
     * is non-undefined, the store's state at `key` is updated to match `controlled`.
     */
    useControlledProp(key, controlled) {
      React36.useDebugValue(key);
      const isControlled = controlled !== void 0;
      useIsoLayoutEffect(() => {
        if (isControlled && !Object.is(this.state[key], controlled)) {
          super.setState({
            ...this.state,
            [key]: controlled
          });
        }
      }, [key, controlled, isControlled]);
      if (true) {
        const cache = this.controlledValues ?? (this.controlledValues = /* @__PURE__ */ new Map());
        if (!cache.has(key)) {
          cache.set(key, isControlled);
        }
        const previouslyControlled = cache.get(key);
        if (previouslyControlled !== void 0 && previouslyControlled !== isControlled) {
          console.error(`A component is changing the ${isControlled ? "" : "un"}controlled state of ${key.toString()} to be ${isControlled ? "un" : ""}controlled. Elements should not switch from uncontrolled to controlled (or vice versa).`);
        }
      }
    }
    /** Gets the current value from the store using a selector with the provided key.
     *
     * @param key Key of the selector to use.
     */
    select(key, a1, a2, a3) {
      const selector = this.selectors[key];
      return selector(this.state, a1, a2, a3);
    }
    /**
     * Returns a value from the store's state using a selector function.
     * Used to subscribe to specific parts of the state.
     * This methods causes a rerender whenever the selected state changes.
     *
     * @param key Key of the selector to use.
     */
    useState(key, a1, a2, a3) {
      React36.useDebugValue(key);
      return useStore(this, this.selectors[key], a1, a2, a3);
    }
    /**
     * Wraps a function with `useStableCallback` to ensure it has a stable reference
     * and assigns it to the context.
     *
     * @param key Key of the event callback. Must be a function in the context.
     * @param fn Function to assign.
     */
    useContextCallback(key, fn) {
      React36.useDebugValue(key);
      const stableFunction = useStableCallback(fn ?? NOOP);
      this.context[key] = stableFunction;
    }
    /**
     * Returns a stable setter function for a specific key in the store's state.
     * It's commonly used to pass as a ref callback to React elements.
     *
     * @param key Key of the state to set.
     */
    useStateSetter(key) {
      const ref = React36.useRef(void 0);
      if (ref.current === void 0) {
        ref.current = (value) => {
          this.set(key, value);
        };
      }
      return ref.current;
    }
    /**
     * Observes changes derived from the store's selectors and calls the listener when the selected value changes.
     *
     * @param key Key of the selector to observe.
     * @param listener Listener function called when the selector result changes.
     */
    observe(selector, listener) {
      let selectFn;
      if (typeof selector === "function") {
        selectFn = selector;
      } else {
        selectFn = this.selectors[selector];
      }
      let prevValue = selectFn(this.state);
      listener(prevValue, prevValue, this);
      return this.subscribe((nextState) => {
        const nextValue = selectFn(nextState);
        if (!Object.is(prevValue, nextValue)) {
          const oldValue = prevValue;
          prevValue = nextValue;
          listener(nextValue, oldValue, this);
        }
      });
    }
  };

  // node_modules/@base-ui/react/esm/floating-ui-react/components/FloatingRootStore.js
  var selectors = {
    open: createSelector2((state) => state.open),
    domReferenceElement: createSelector2((state) => state.domReferenceElement),
    referenceElement: createSelector2((state) => state.positionReference ?? state.referenceElement),
    floatingElement: createSelector2((state) => state.floatingElement),
    floatingId: createSelector2((state) => state.floatingId)
  };
  var FloatingRootStore = class extends ReactStore {
    constructor(options) {
      const {
        nested,
        noEmit,
        onOpenChange,
        triggerElements,
        ...initialState
      } = options;
      super({
        ...initialState,
        positionReference: initialState.referenceElement,
        domReferenceElement: initialState.referenceElement
      }, {
        onOpenChange,
        dataRef: {
          current: {}
        },
        events: createEventEmitter(),
        nested,
        noEmit,
        triggerElements
      }, selectors);
      /**
       * Emits the `openchange` event through the internal event emitter and calls the `onOpenChange` handler with the provided arguments.
       *
       * @param newOpen The new open state.
       * @param eventDetails Details about the event that triggered the open state change.
       */
      __publicField(this, "setOpen", (newOpen, eventDetails) => {
        if (!newOpen || !this.state.open || // Prevent a pending hover-open from overwriting a click-open event, while allowing
        // click events to upgrade a hover-open.
        isClickLikeEvent(eventDetails.event)) {
          this.context.dataRef.current.openEvent = newOpen ? eventDetails.event : void 0;
        }
        if (!this.context.noEmit) {
          const details = {
            open: newOpen,
            reason: eventDetails.reason,
            nativeEvent: eventDetails.event,
            nested: this.context.nested,
            triggerElement: eventDetails.trigger
          };
          this.context.events.emit("openchange", details);
        }
        this.context.onOpenChange?.(newOpen, eventDetails);
      });
    }
  };

  // node_modules/@base-ui/react/esm/utils/popups/popupStoreUtils.js
  init_define_import_meta_env();
  var React37 = __toESM(require_react_shim(), 1);
  function useTriggerRegistration(id, store) {
    const registeredElementIdRef = React37.useRef(null);
    const registeredElementRef = React37.useRef(null);
    return React37.useCallback((element) => {
      if (id === void 0) {
        return;
      }
      if (registeredElementIdRef.current !== null) {
        const registeredId = registeredElementIdRef.current;
        const registeredElement = registeredElementRef.current;
        const currentElement = store.context.triggerElements.getById(registeredId);
        if (registeredElement && currentElement === registeredElement) {
          store.context.triggerElements.delete(registeredId);
        }
        registeredElementIdRef.current = null;
        registeredElementRef.current = null;
      }
      if (element !== null) {
        registeredElementIdRef.current = id;
        registeredElementRef.current = element;
        store.context.triggerElements.add(id, element);
      }
    }, [store, id]);
  }
  function useTriggerDataForwarding(triggerId, triggerElementRef, store, stateUpdates) {
    const isMountedByThisTrigger = store.useState("isMountedByTrigger", triggerId);
    const baseRegisterTrigger = useTriggerRegistration(triggerId, store);
    const registerTrigger = useStableCallback((element) => {
      baseRegisterTrigger(element);
      if (!element || !store.select("open")) {
        return;
      }
      const activeTriggerId = store.select("activeTriggerId");
      if (activeTriggerId === triggerId) {
        store.update({
          activeTriggerElement: element,
          ...stateUpdates
        });
        return;
      }
      if (activeTriggerId == null) {
        store.update({
          activeTriggerId: triggerId,
          activeTriggerElement: element,
          ...stateUpdates
        });
      }
    });
    useIsoLayoutEffect(() => {
      if (isMountedByThisTrigger) {
        store.update({
          activeTriggerElement: triggerElementRef.current,
          ...stateUpdates
        });
      }
    }, [isMountedByThisTrigger, store, triggerElementRef, ...Object.values(stateUpdates)]);
    return {
      registerTrigger,
      isMountedByThisTrigger
    };
  }
  function useImplicitActiveTrigger(store) {
    const open = store.useState("open");
    useIsoLayoutEffect(() => {
      if (open && !store.select("activeTriggerId") && store.context.triggerElements.size === 1) {
        const iteratorResult = store.context.triggerElements.entries().next();
        if (!iteratorResult.done) {
          const [implicitTriggerId, implicitTriggerElement] = iteratorResult.value;
          store.update({
            activeTriggerId: implicitTriggerId,
            activeTriggerElement: implicitTriggerElement
          });
        }
      }
    }, [open, store]);
  }
  function useOpenStateTransitions(open, store, onUnmount) {
    const {
      mounted,
      setMounted,
      transitionStatus
    } = useTransitionStatus(open);
    store.useSyncedValues({
      mounted,
      transitionStatus
    });
    const forceUnmount = useStableCallback(() => {
      setMounted(false);
      store.update({
        activeTriggerId: null,
        activeTriggerElement: null,
        mounted: false
      });
      onUnmount?.();
      store.context.onOpenChangeComplete?.(false);
    });
    const preventUnmountingOnClose = store.useState("preventUnmountingOnClose");
    useOpenChangeComplete({
      enabled: !preventUnmountingOnClose,
      open,
      ref: store.context.popupRef,
      onComplete() {
        if (!open) {
          forceUnmount();
        }
      }
    });
    return {
      forceUnmount,
      transitionStatus
    };
  }

  // node_modules/@base-ui/react/esm/utils/popups/popupTriggerMap.js
  init_define_import_meta_env();
  var PopupTriggerMap = class {
    constructor() {
      this.elementsSet = /* @__PURE__ */ new Set();
      this.idMap = /* @__PURE__ */ new Map();
    }
    /**
     * Adds a trigger element with the given ID.
     *
     * Note: The provided element is assumed to not be registered under multiple IDs.
     */
    add(id, element) {
      const existingElement = this.idMap.get(id);
      if (existingElement === element) {
        return;
      }
      if (existingElement !== void 0) {
        this.elementsSet.delete(existingElement);
      }
      this.elementsSet.add(element);
      this.idMap.set(id, element);
      if (true) {
        if (this.elementsSet.size !== this.idMap.size) {
          throw new Error("Base UI: A trigger element cannot be registered under multiple IDs in PopupTriggerMap.");
        }
      }
    }
    /**
     * Removes the trigger element with the given ID.
     */
    delete(id) {
      const element = this.idMap.get(id);
      if (element) {
        this.elementsSet.delete(element);
        this.idMap.delete(id);
      }
    }
    /**
     * Whether the given element is registered as a trigger.
     */
    hasElement(element) {
      return this.elementsSet.has(element);
    }
    /**
     * Whether there is a registered trigger element matching the given predicate.
     */
    hasMatchingElement(predicate) {
      for (const element of this.elementsSet) {
        if (predicate(element)) {
          return true;
        }
      }
      return false;
    }
    /**
     * Returns the trigger element associated with the given ID, or undefined if no such element exists.
     */
    getById(id) {
      return this.idMap.get(id);
    }
    /**
     * Returns an iterable of all registered trigger entries, where each entry is a tuple of [id, element].
     */
    entries() {
      return this.idMap.entries();
    }
    /**
     * Returns an iterable of all registered trigger elements.
     */
    elements() {
      return this.elementsSet.values();
    }
    /**
     * Returns the number of registered trigger elements.
     */
    get size() {
      return this.idMap.size;
    }
  };

  // node_modules/@base-ui/react/esm/utils/popups/store.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/floating-ui-react/utils/getEmptyRootContext.js
  init_define_import_meta_env();
  function getEmptyRootContext() {
    return new FloatingRootStore({
      open: false,
      floatingElement: null,
      referenceElement: null,
      triggerElements: new PopupTriggerMap(),
      floatingId: "",
      nested: false,
      noEmit: false,
      onOpenChange: void 0
    });
  }

  // node_modules/@base-ui/react/esm/utils/popups/store.js
  function createInitialPopupStoreState() {
    return {
      open: false,
      openProp: void 0,
      mounted: false,
      transitionStatus: "idle",
      floatingRootContext: getEmptyRootContext(),
      preventUnmountingOnClose: false,
      payload: void 0,
      activeTriggerId: null,
      activeTriggerElement: null,
      triggerIdProp: void 0,
      popupElement: null,
      positionerElement: null,
      activeTriggerProps: EMPTY_OBJECT,
      inactiveTriggerProps: EMPTY_OBJECT,
      popupProps: EMPTY_OBJECT
    };
  }
  var activeTriggerIdSelector = createSelector2((state) => state.triggerIdProp ?? state.activeTriggerId);
  var popupStoreSelectors = {
    open: createSelector2((state) => state.openProp ?? state.open),
    mounted: createSelector2((state) => state.mounted),
    transitionStatus: createSelector2((state) => state.transitionStatus),
    floatingRootContext: createSelector2((state) => state.floatingRootContext),
    preventUnmountingOnClose: createSelector2((state) => state.preventUnmountingOnClose),
    payload: createSelector2((state) => state.payload),
    activeTriggerId: activeTriggerIdSelector,
    activeTriggerElement: createSelector2((state) => state.mounted ? state.activeTriggerElement : null),
    /**
     * Whether the trigger with the given ID was used to open the popup.
     */
    isTriggerActive: createSelector2((state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId),
    /**
     * Whether the popup is open and was activated by a trigger with the given ID.
     */
    isOpenedByTrigger: createSelector2((state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId && state.open),
    /**
     * Whether the popup is mounted and was activated by a trigger with the given ID.
     */
    isMountedByTrigger: createSelector2((state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId && state.mounted),
    triggerProps: createSelector2((state, isActive) => isActive ? state.activeTriggerProps : state.inactiveTriggerProps),
    popupProps: createSelector2((state) => state.popupProps),
    popupElement: createSelector2((state) => state.popupElement),
    positionerElement: createSelector2((state) => state.positionerElement)
  };

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useFloatingRootContext.js
  function useFloatingRootContext(options) {
    const {
      open = false,
      onOpenChange,
      elements = {}
    } = options;
    const floatingId = useId();
    const nested = useFloatingParentNodeId() != null;
    if (true) {
      const optionDomReference = elements.reference;
      if (optionDomReference && !isElement(optionDomReference)) {
        console.error("Cannot pass a virtual element to the `elements.reference` option,", "as it must be a real DOM element. Use `context.setPositionReference()`", "instead.");
      }
    }
    const store = useRefWithInit(() => new FloatingRootStore({
      open,
      onOpenChange,
      referenceElement: elements.reference ?? null,
      floatingElement: elements.floating ?? null,
      triggerElements: new PopupTriggerMap(),
      floatingId,
      nested,
      noEmit: false
    })).current;
    useIsoLayoutEffect(() => {
      const valuesToSync = {
        open,
        floatingId
      };
      if (elements.reference !== void 0) {
        valuesToSync.referenceElement = elements.reference;
        valuesToSync.domReferenceElement = isElement(elements.reference) ? elements.reference : null;
      }
      if (elements.floating !== void 0) {
        valuesToSync.floatingElement = elements.floating;
      }
      store.update(valuesToSync);
    }, [open, floatingId, elements.reference, elements.floating, store]);
    store.context.onOpenChange = onOpenChange;
    store.context.nested = nested;
    store.context.noEmit = false;
    return store;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useFloating.js
  function useFloating2(options = {}) {
    const {
      nodeId,
      externalTree
    } = options;
    const internalRootStore = useFloatingRootContext(options);
    const rootContext = options.rootContext || internalRootStore;
    const rootContextElements = {
      reference: rootContext.useState("referenceElement"),
      floating: rootContext.useState("floatingElement"),
      domReference: rootContext.useState("domReferenceElement")
    };
    const [positionReference, setPositionReferenceRaw] = React38.useState(null);
    const domReferenceRef = React38.useRef(null);
    const tree = useFloatingTree(externalTree);
    useIsoLayoutEffect(() => {
      if (rootContextElements.domReference) {
        domReferenceRef.current = rootContextElements.domReference;
      }
    }, [rootContextElements.domReference]);
    const position = useFloating({
      ...options,
      elements: {
        ...rootContextElements,
        ...positionReference && {
          reference: positionReference
        }
      }
    });
    const setPositionReference = React38.useCallback((node) => {
      const computedPositionReference = isElement(node) ? {
        getBoundingClientRect: () => node.getBoundingClientRect(),
        getClientRects: () => node.getClientRects(),
        contextElement: node
      } : node;
      setPositionReferenceRaw(computedPositionReference);
      position.refs.setReference(computedPositionReference);
    }, [position.refs]);
    const [localDomReference, setLocalDomReference] = React38.useState(null);
    const [localFloatingElement, setLocalFloatingElement] = React38.useState(null);
    rootContext.useSyncedValue("referenceElement", localDomReference);
    rootContext.useSyncedValue("domReferenceElement", isElement(localDomReference) ? localDomReference : null);
    rootContext.useSyncedValue("floatingElement", localFloatingElement);
    const setReference = React38.useCallback((node) => {
      if (isElement(node) || node === null) {
        domReferenceRef.current = node;
        setLocalDomReference(node);
      }
      if (isElement(position.refs.reference.current) || position.refs.reference.current === null || // Don't allow setting virtual elements using the old technique back to
      // `null` to support `positionReference` + an unstable `reference`
      // callback ref.
      node !== null && !isElement(node)) {
        position.refs.setReference(node);
      }
    }, [position.refs, setLocalDomReference]);
    const setFloating = React38.useCallback((node) => {
      setLocalFloatingElement(node);
      position.refs.setFloating(node);
    }, [position.refs]);
    const refs = React38.useMemo(() => ({
      ...position.refs,
      setReference,
      setFloating,
      setPositionReference,
      domReference: domReferenceRef
    }), [position.refs, setReference, setFloating, setPositionReference]);
    const elements = React38.useMemo(() => ({
      ...position.elements,
      domReference: rootContextElements.domReference
    }), [position.elements, rootContextElements.domReference]);
    const open = rootContext.useState("open");
    const floatingId = rootContext.useState("floatingId");
    const context = React38.useMemo(() => ({
      ...position,
      dataRef: rootContext.context.dataRef,
      open,
      onOpenChange: rootContext.setOpen,
      events: rootContext.context.events,
      floatingId,
      refs,
      elements,
      nodeId,
      rootStore: rootContext
    }), [position, refs, elements, nodeId, rootContext, open, floatingId]);
    useIsoLayoutEffect(() => {
      rootContext.context.dataRef.current.floatingContext = context;
      const node = tree?.nodesRef.current.find((n) => n.id === nodeId);
      if (node) {
        node.context = context;
      }
    });
    return React38.useMemo(() => ({
      ...position,
      context,
      refs,
      elements,
      rootStore: rootContext
    }), [position, refs, elements, context, rootContext]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useSyncedFloatingRootContext.js
  init_define_import_meta_env();
  function useSyncedFloatingRootContext(options) {
    const {
      popupStore,
      noEmit = false,
      treatPopupAsFloatingElement = false,
      onOpenChange
    } = options;
    const floatingId = useId();
    const nested = useFloatingParentNodeId() != null;
    const open = popupStore.useState("open");
    const referenceElement = popupStore.useState("activeTriggerElement");
    const floatingElement = popupStore.useState(treatPopupAsFloatingElement ? "popupElement" : "positionerElement");
    const triggerElements = popupStore.context.triggerElements;
    const store = useRefWithInit(() => new FloatingRootStore({
      open,
      referenceElement,
      floatingElement,
      triggerElements,
      onOpenChange,
      floatingId,
      nested,
      noEmit
    })).current;
    useIsoLayoutEffect(() => {
      const valuesToSync = {
        open,
        floatingId,
        referenceElement,
        floatingElement
      };
      if (isElement(referenceElement)) {
        valuesToSync.domReferenceElement = referenceElement;
      }
      if (store.state.positionReference === store.state.referenceElement) {
        valuesToSync.positionReference = referenceElement;
      }
      store.update(valuesToSync);
    }, [open, floatingId, referenceElement, floatingElement, store]);
    store.context.onOpenChange = onOpenChange;
    store.context.nested = nested;
    store.context.noEmit = noEmit;
    return store;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useFocus.js
  init_define_import_meta_env();
  var React39 = __toESM(require_react_shim(), 1);
  var isMacSafari = isMac && isSafari;
  function useFocus(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const {
      events,
      dataRef
    } = store.context;
    const {
      enabled = true,
      delay
    } = props;
    const blockFocusRef = React39.useRef(false);
    const blockedReferenceRef = React39.useRef(null);
    const timeout = useTimeout();
    const keyboardModalityRef = React39.useRef(true);
    React39.useEffect(() => {
      const domReference = store.select("domReferenceElement");
      if (!enabled) {
        return void 0;
      }
      const win = getWindow(domReference);
      function onBlur() {
        const currentDomReference = store.select("domReferenceElement");
        if (!store.select("open") && isHTMLElement(currentDomReference) && currentDomReference === activeElement(ownerDocument(currentDomReference))) {
          blockFocusRef.current = true;
        }
      }
      function onKeyDown() {
        keyboardModalityRef.current = true;
      }
      function onPointerDown() {
        keyboardModalityRef.current = false;
      }
      win.addEventListener("blur", onBlur);
      if (isMacSafari) {
        win.addEventListener("keydown", onKeyDown, true);
        win.addEventListener("pointerdown", onPointerDown, true);
      }
      return () => {
        win.removeEventListener("blur", onBlur);
        if (isMacSafari) {
          win.removeEventListener("keydown", onKeyDown, true);
          win.removeEventListener("pointerdown", onPointerDown, true);
        }
      };
    }, [store, enabled]);
    React39.useEffect(() => {
      if (!enabled) {
        return void 0;
      }
      function onOpenChangeLocal(details) {
        if (details.reason === reason_parts_exports.triggerPress || details.reason === reason_parts_exports.escapeKey) {
          const referenceElement = store.select("domReferenceElement");
          if (isElement(referenceElement)) {
            blockedReferenceRef.current = referenceElement;
            blockFocusRef.current = true;
          }
        }
      }
      events.on("openchange", onOpenChangeLocal);
      return () => {
        events.off("openchange", onOpenChangeLocal);
      };
    }, [events, enabled, store]);
    const reference = React39.useMemo(() => ({
      onMouseLeave() {
        blockFocusRef.current = false;
        blockedReferenceRef.current = null;
      },
      onFocus(event) {
        const focusTarget = event.currentTarget;
        if (blockFocusRef.current) {
          if (blockedReferenceRef.current === focusTarget) {
            return;
          }
          blockFocusRef.current = false;
          blockedReferenceRef.current = null;
        }
        const target = getTarget(event.nativeEvent);
        if (isElement(target)) {
          if (isMacSafari && !event.relatedTarget) {
            if (!keyboardModalityRef.current && !isTypeableElement(target)) {
              return;
            }
          } else if (!matchesFocusVisible(target)) {
            return;
          }
        }
        const movedFromOtherEnabledTrigger = isTargetInsideEnabledTrigger(event.relatedTarget, store.context.triggerElements);
        const {
          nativeEvent,
          currentTarget
        } = event;
        const delayValue = typeof delay === "function" ? delay() : delay;
        if (store.select("open") && movedFromOtherEnabledTrigger || delayValue === 0 || delayValue === void 0) {
          store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerFocus, nativeEvent, currentTarget));
          return;
        }
        timeout.start(delayValue, () => {
          if (blockFocusRef.current) {
            return;
          }
          store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerFocus, nativeEvent, currentTarget));
        });
      },
      onBlur(event) {
        blockFocusRef.current = false;
        blockedReferenceRef.current = null;
        const relatedTarget = event.relatedTarget;
        const nativeEvent = event.nativeEvent;
        const movedToFocusGuard = isElement(relatedTarget) && relatedTarget.hasAttribute(createAttribute("focus-guard")) && relatedTarget.getAttribute("data-type") === "outside";
        timeout.start(0, () => {
          const domReference = store.select("domReferenceElement");
          const activeEl = activeElement(domReference ? domReference.ownerDocument : document);
          if (!relatedTarget && activeEl === domReference) {
            return;
          }
          if (contains(dataRef.current.floatingContext?.refs.floating.current, activeEl) || contains(domReference, activeEl) || movedToFocusGuard) {
            return;
          }
          const nextFocusedElement = relatedTarget ?? activeEl;
          if (isTargetInsideEnabledTrigger(nextFocusedElement, store.context.triggerElements)) {
            return;
          }
          store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerFocus, nativeEvent));
        });
      }
    }), [dataRef, store, timeout, delay]);
    return React39.useMemo(() => enabled ? {
      reference,
      trigger: reference
    } : {}, [enabled, reference]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverFloatingInteraction.js
  init_define_import_meta_env();
  var React40 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverInteractionSharedState.js
  init_define_import_meta_env();
  var interactiveSelector = `button,a,[role="button"],select,[tabindex]:not([tabindex="-1"]),${TYPEABLE_SELECTOR}`;
  function isInteractiveElement(element) {
    return element ? Boolean(element.closest(interactiveSelector)) : false;
  }
  var HoverInteraction = class _HoverInteraction {
    constructor() {
      __publicField(this, "dispose", () => {
        this.openChangeTimeout.clear();
        this.restTimeout.clear();
      });
      __publicField(this, "disposeEffect", () => {
        return this.dispose;
      });
      this.pointerType = void 0;
      this.interactedInside = false;
      this.handler = void 0;
      this.blockMouseMove = true;
      this.performedPointerEventsMutation = false;
      this.pointerEventsScopeElement = null;
      this.pointerEventsReferenceElement = null;
      this.pointerEventsFloatingElement = null;
      this.restTimeoutPending = false;
      this.openChangeTimeout = new Timeout();
      this.restTimeout = new Timeout();
      this.handleCloseOptions = void 0;
    }
    static create() {
      return new _HoverInteraction();
    }
  };
  function clearSafePolygonPointerEventsMutation(instance) {
    if (!instance.performedPointerEventsMutation) {
      return;
    }
    instance.pointerEventsScopeElement?.style.removeProperty("pointer-events");
    instance.pointerEventsReferenceElement?.style.removeProperty("pointer-events");
    instance.pointerEventsFloatingElement?.style.removeProperty("pointer-events");
    instance.performedPointerEventsMutation = false;
    instance.pointerEventsScopeElement = null;
    instance.pointerEventsReferenceElement = null;
    instance.pointerEventsFloatingElement = null;
  }
  function applySafePolygonPointerEventsMutation(instance, options) {
    const {
      scopeElement,
      referenceElement,
      floatingElement
    } = options;
    clearSafePolygonPointerEventsMutation(instance);
    instance.performedPointerEventsMutation = true;
    instance.pointerEventsScopeElement = scopeElement;
    instance.pointerEventsReferenceElement = referenceElement;
    instance.pointerEventsFloatingElement = floatingElement;
    scopeElement.style.pointerEvents = "none";
    referenceElement.style.pointerEvents = "auto";
    floatingElement.style.pointerEvents = "auto";
  }
  function useHoverInteractionSharedState(store) {
    const instance = useRefWithInit(HoverInteraction.create).current;
    const data = store.context.dataRef.current;
    if (!data.hoverInteractionState) {
      data.hoverInteractionState = instance;
    }
    useOnMount(data.hoverInteractionState.disposeEffect);
    return data.hoverInteractionState;
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverFloatingInteraction.js
  function useHoverFloatingInteraction(context, parameters = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const floatingElement = store.useState("floatingElement");
    const domReferenceElement = store.useState("domReferenceElement");
    const {
      dataRef
    } = store.context;
    const {
      enabled = true,
      closeDelay: closeDelayProp = 0
    } = parameters;
    const instance = useHoverInteractionSharedState(store);
    const tree = useFloatingTree();
    const parentId = useFloatingParentNodeId();
    const isClickLikeOpenEvent2 = useStableCallback(() => {
      return isClickLikeOpenEvent(dataRef.current.openEvent?.type, instance.interactedInside);
    });
    const isHoverOpen = useStableCallback(() => {
      const type = dataRef.current.openEvent?.type;
      return type?.includes("mouse") && type !== "mousedown";
    });
    const isRelatedTargetInsideEnabledTrigger = useStableCallback((target) => {
      return isTargetInsideEnabledTrigger(target, store.context.triggerElements);
    });
    const closeWithDelay = React40.useCallback((event) => {
      const closeDelay = getDelay(closeDelayProp, "close", instance.pointerType);
      const close = () => {
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerHover, event));
        tree?.events.emit("floating.closed", event);
      };
      if (closeDelay) {
        instance.openChangeTimeout.start(closeDelay, close);
      } else {
        instance.openChangeTimeout.clear();
        close();
      }
    }, [closeDelayProp, store, instance, tree]);
    const clearPointerEvents = useStableCallback(() => {
      clearSafePolygonPointerEventsMutation(instance);
    });
    const handleInteractInside = useStableCallback((event) => {
      const target = getTarget(event);
      if (!isInteractiveElement(target)) {
        instance.interactedInside = false;
        return;
      }
      instance.interactedInside = target?.closest("[aria-haspopup]") != null;
    });
    useIsoLayoutEffect(() => {
      if (!open) {
        instance.pointerType = void 0;
        instance.restTimeoutPending = false;
        instance.interactedInside = false;
        clearPointerEvents();
      }
    }, [open, instance, clearPointerEvents]);
    React40.useEffect(() => {
      return clearPointerEvents;
    }, [clearPointerEvents]);
    useIsoLayoutEffect(() => {
      if (!enabled) {
        return void 0;
      }
      if (open && instance.handleCloseOptions?.blockPointerEvents && isHoverOpen() && isElement(domReferenceElement) && floatingElement) {
        const ref = domReferenceElement;
        const floatingEl = floatingElement;
        const doc = ownerDocument(floatingElement);
        const parentFloating = tree?.nodesRef.current.find((node) => node.id === parentId)?.context?.elements.floating;
        if (parentFloating) {
          parentFloating.style.pointerEvents = "";
        }
        const scopeElement = instance.handleCloseOptions?.getScope?.() ?? instance.pointerEventsScopeElement ?? parentFloating ?? ref.closest("[data-rootownerid]") ?? doc.body;
        applySafePolygonPointerEventsMutation(instance, {
          scopeElement,
          referenceElement: ref,
          floatingElement: floatingEl
        });
        return () => {
          clearPointerEvents();
        };
      }
      return void 0;
    }, [enabled, open, domReferenceElement, floatingElement, instance, isHoverOpen, tree, parentId, clearPointerEvents]);
    const childClosedTimeout = useTimeout();
    React40.useEffect(() => {
      if (!enabled) {
        return void 0;
      }
      function onFloatingMouseEnter() {
        instance.openChangeTimeout.clear();
        childClosedTimeout.clear();
        tree?.events.off("floating.closed", onNodeClosed);
        clearPointerEvents();
      }
      function onFloatingMouseLeave(event) {
        if (tree && parentId && getNodeChildren(tree.nodesRef.current, parentId).length > 0) {
          tree.events.on("floating.closed", onNodeClosed);
          return;
        }
        if (isRelatedTargetInsideEnabledTrigger(event.relatedTarget)) {
          return;
        }
        if (instance.handler) {
          instance.handler(event);
          return;
        }
        clearPointerEvents();
        if (!isClickLikeOpenEvent2()) {
          closeWithDelay(event);
        }
      }
      function onNodeClosed(event) {
        if (!tree || !parentId || getNodeChildren(tree.nodesRef.current, parentId).length > 0) {
          return;
        }
        childClosedTimeout.start(0, () => {
          tree.events.off("floating.closed", onNodeClosed);
          store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerHover, event));
          tree.events.emit("floating.closed", event);
        });
      }
      const floating = floatingElement;
      if (floating) {
        floating.addEventListener("mouseenter", onFloatingMouseEnter);
        floating.addEventListener("mouseleave", onFloatingMouseLeave);
        floating.addEventListener("pointerdown", handleInteractInside, true);
      }
      return () => {
        if (floating) {
          floating.removeEventListener("mouseenter", onFloatingMouseEnter);
          floating.removeEventListener("mouseleave", onFloatingMouseLeave);
          floating.removeEventListener("pointerdown", handleInteractInside, true);
        }
        tree?.events.off("floating.closed", onNodeClosed);
      };
    }, [enabled, floatingElement, store, dataRef, isClickLikeOpenEvent2, isRelatedTargetInsideEnabledTrigger, closeWithDelay, clearPointerEvents, handleInteractInside, instance, tree, parentId, childClosedTimeout]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useHoverReferenceInteraction.js
  init_define_import_meta_env();
  var React41 = __toESM(require_react_shim(), 1);
  var ReactDOM4 = __toESM(require_react_dom_shim(), 1);
  var EMPTY_REF = {
    current: null
  };
  function useHoverReferenceInteraction(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const {
      dataRef,
      events
    } = store.context;
    const {
      enabled = true,
      delay = 0,
      handleClose = null,
      mouseOnly = false,
      restMs = 0,
      move = true,
      triggerElementRef = EMPTY_REF,
      externalTree,
      isActiveTrigger = true,
      getHandleCloseContext
    } = props;
    const tree = useFloatingTree(externalTree);
    const instance = useHoverInteractionSharedState(store);
    const handleCloseRef = useValueAsRef(handleClose);
    const delayRef = useValueAsRef(delay);
    const restMsRef = useValueAsRef(restMs);
    const enabledRef = useValueAsRef(enabled);
    if (isActiveTrigger) {
      instance.handleCloseOptions = handleCloseRef.current?.__options;
    }
    const isClickLikeOpenEvent2 = useStableCallback(() => {
      return isClickLikeOpenEvent(dataRef.current.openEvent?.type, instance.interactedInside);
    });
    const isRelatedTargetInsideEnabledTrigger = useStableCallback((target) => {
      return isTargetInsideEnabledTrigger(target, store.context.triggerElements);
    });
    const isOverInactiveTrigger = useStableCallback((currentDomReference, currentTarget, target) => {
      const allTriggers = store.context.triggerElements;
      if (allTriggers.hasElement(currentTarget)) {
        return !currentDomReference || !contains(currentDomReference, currentTarget);
      }
      if (!isElement(target)) {
        return false;
      }
      const targetElement = target;
      return allTriggers.hasMatchingElement((trigger) => contains(trigger, targetElement)) && (!currentDomReference || !contains(currentDomReference, targetElement));
    });
    const closeWithDelay = React41.useCallback((event, runElseBranch = true) => {
      const closeDelay = getDelay(delayRef.current, "close", instance.pointerType);
      if (closeDelay) {
        instance.openChangeTimeout.start(closeDelay, () => {
          store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerHover, event));
          tree?.events.emit("floating.closed", event);
        });
      } else if (runElseBranch) {
        instance.openChangeTimeout.clear();
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.triggerHover, event));
        tree?.events.emit("floating.closed", event);
      }
    }, [delayRef, store, instance, tree]);
    const cleanupMouseMoveHandler = useStableCallback(() => {
      if (!instance.handler) {
        return;
      }
      const doc = ownerDocument(store.select("domReferenceElement"));
      doc.removeEventListener("mousemove", instance.handler);
      instance.handler = void 0;
    });
    React41.useEffect(() => cleanupMouseMoveHandler, [cleanupMouseMoveHandler]);
    const clearPointerEvents = useStableCallback(() => {
      clearSafePolygonPointerEventsMutation(instance);
    });
    React41.useEffect(() => {
      if (!enabled) {
        return void 0;
      }
      function onOpenChangeLocal(details) {
        if (!details.open) {
          cleanupMouseMoveHandler();
          instance.openChangeTimeout.clear();
          instance.restTimeout.clear();
          instance.blockMouseMove = true;
          instance.restTimeoutPending = false;
        }
      }
      events.on("openchange", onOpenChangeLocal);
      return () => {
        events.off("openchange", onOpenChangeLocal);
      };
    }, [enabled, events, instance, cleanupMouseMoveHandler]);
    React41.useEffect(() => {
      if (!enabled) {
        return void 0;
      }
      const trigger = triggerElementRef.current ?? (isActiveTrigger ? store.select("domReferenceElement") : null);
      if (!isElement(trigger)) {
        return void 0;
      }
      function onMouseEnter(event) {
        instance.openChangeTimeout.clear();
        instance.blockMouseMove = false;
        if (mouseOnly && !isMouseLikePointerType(instance.pointerType)) {
          return;
        }
        const restMsValue = getRestMs(restMsRef.current);
        if (restMsValue > 0 && !getDelay(delayRef.current, "open")) {
          return;
        }
        const openDelay = getDelay(delayRef.current, "open", instance.pointerType);
        const triggerNode = event.currentTarget ?? null;
        const currentDomReference = store.select("domReferenceElement");
        const isOverInactive = triggerNode == null ? false : isOverInactiveTrigger(currentDomReference, triggerNode, event.target);
        const isOpen = store.select("open");
        const shouldOpen = !isOpen || isOverInactive;
        if (isOverInactive && isOpen) {
          store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerHover, event, triggerNode));
        } else if (openDelay) {
          instance.openChangeTimeout.start(openDelay, () => {
            if (shouldOpen) {
              store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerHover, event, triggerNode));
            }
          });
        } else if (shouldOpen) {
          store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerHover, event, triggerNode));
        }
      }
      function onMouseLeave(event) {
        if (isClickLikeOpenEvent2()) {
          clearPointerEvents();
          return;
        }
        cleanupMouseMoveHandler();
        const domReferenceElement = store.select("domReferenceElement");
        const doc = ownerDocument(domReferenceElement);
        instance.restTimeout.clear();
        instance.restTimeoutPending = false;
        const handleCloseContextBase = dataRef.current.floatingContext ?? getHandleCloseContext?.();
        const ignoreRelatedTargetTrigger = isRelatedTargetInsideEnabledTrigger(event.relatedTarget);
        if (ignoreRelatedTargetTrigger) {
          return;
        }
        if (handleCloseRef.current && handleCloseContextBase) {
          if (!store.select("open")) {
            instance.openChangeTimeout.clear();
          }
          const currentTrigger = triggerElementRef.current;
          instance.handler = handleCloseRef.current({
            ...handleCloseContextBase,
            tree,
            x: event.clientX,
            y: event.clientY,
            onClose() {
              clearPointerEvents();
              cleanupMouseMoveHandler();
              if (enabledRef.current && !isClickLikeOpenEvent2() && currentTrigger === store.select("domReferenceElement")) {
                closeWithDelay(event, true);
              }
            }
          });
          doc.addEventListener("mousemove", instance.handler);
          instance.handler(event);
          return;
        }
        const shouldClose = instance.pointerType === "touch" ? !contains(store.select("floatingElement"), event.relatedTarget) : true;
        if (shouldClose) {
          closeWithDelay(event);
        }
      }
      if (move) {
        trigger.addEventListener("mousemove", onMouseEnter, {
          once: true
        });
      }
      trigger.addEventListener("mouseenter", onMouseEnter);
      trigger.addEventListener("mouseleave", onMouseLeave);
      return () => {
        if (move) {
          trigger.removeEventListener("mousemove", onMouseEnter);
        }
        trigger.removeEventListener("mouseenter", onMouseEnter);
        trigger.removeEventListener("mouseleave", onMouseLeave);
      };
    }, [cleanupMouseMoveHandler, clearPointerEvents, dataRef, delayRef, closeWithDelay, store, enabled, handleCloseRef, instance, isActiveTrigger, isOverInactiveTrigger, isClickLikeOpenEvent2, isRelatedTargetInsideEnabledTrigger, mouseOnly, move, restMsRef, triggerElementRef, tree, enabledRef, getHandleCloseContext]);
    return React41.useMemo(() => {
      if (!enabled) {
        return void 0;
      }
      function setPointerRef(event) {
        instance.pointerType = event.pointerType;
      }
      return {
        onPointerDown: setPointerRef,
        onPointerEnter: setPointerRef,
        onMouseMove(event) {
          const {
            nativeEvent
          } = event;
          const trigger = event.currentTarget;
          const currentDomReference = store.select("domReferenceElement");
          const currentOpen = store.select("open");
          const isOverInactive = isOverInactiveTrigger(currentDomReference, trigger, event.target);
          if (mouseOnly && !isMouseLikePointerType(instance.pointerType)) {
            return;
          }
          const restMsValue = getRestMs(restMsRef.current);
          if (currentOpen && !isOverInactive || restMsValue === 0) {
            return;
          }
          if (!isOverInactive && instance.restTimeoutPending && event.movementX ** 2 + event.movementY ** 2 < 2) {
            return;
          }
          instance.restTimeout.clear();
          function handleMouseMove() {
            instance.restTimeoutPending = false;
            if (isClickLikeOpenEvent2()) {
              return;
            }
            const latestOpen = store.select("open");
            if (!instance.blockMouseMove && (!latestOpen || isOverInactive)) {
              store.setOpen(true, createChangeEventDetails(reason_parts_exports.triggerHover, nativeEvent, trigger));
            }
          }
          if (instance.pointerType === "touch") {
            ReactDOM4.flushSync(() => {
              handleMouseMove();
            });
          } else if (isOverInactive && currentOpen) {
            handleMouseMove();
          } else {
            instance.restTimeoutPending = true;
            instance.restTimeout.start(restMsValue, handleMouseMove);
          }
        }
      };
    }, [enabled, instance, isClickLikeOpenEvent2, isOverInactiveTrigger, mouseOnly, store, restMsRef]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useInteractions.js
  init_define_import_meta_env();
  var React42 = __toESM(require_react_shim(), 1);
  function useInteractions(propsList = []) {
    const referenceDeps = propsList.map((key) => key?.reference);
    const floatingDeps = propsList.map((key) => key?.floating);
    const itemDeps = propsList.map((key) => key?.item);
    const triggerDeps = propsList.map((key) => key?.trigger);
    const getReferenceProps = React42.useCallback(
      (userProps) => mergeProps2(userProps, propsList, "reference"),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      referenceDeps
    );
    const getFloatingProps = React42.useCallback(
      (userProps) => mergeProps2(userProps, propsList, "floating"),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      floatingDeps
    );
    const getItemProps = React42.useCallback(
      (userProps) => mergeProps2(userProps, propsList, "item"),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      itemDeps
    );
    const getTriggerProps = React42.useCallback(
      (userProps) => mergeProps2(userProps, propsList, "trigger"),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      triggerDeps
    );
    return React42.useMemo(() => ({
      getReferenceProps,
      getFloatingProps,
      getItemProps,
      getTriggerProps
    }), [getReferenceProps, getFloatingProps, getItemProps, getTriggerProps]);
  }
  function mergeProps2(userProps, propsList, elementKey) {
    const eventHandlers = /* @__PURE__ */ new Map();
    const isItem = elementKey === "item";
    const outputProps = {};
    if (elementKey === "floating") {
      outputProps.tabIndex = -1;
      outputProps[FOCUSABLE_ATTRIBUTE] = "";
    }
    for (const key in userProps) {
      if (isItem && userProps) {
        if (key === ACTIVE_KEY || key === SELECTED_KEY) {
          continue;
        }
      }
      outputProps[key] = userProps[key];
    }
    for (let i = 0; i < propsList.length; i += 1) {
      let props;
      const propsOrGetProps = propsList[i]?.[elementKey];
      if (typeof propsOrGetProps === "function") {
        props = userProps ? propsOrGetProps(userProps) : null;
      } else {
        props = propsOrGetProps;
      }
      if (!props) {
        continue;
      }
      mutablyMergeProps(outputProps, props, isItem, eventHandlers);
    }
    mutablyMergeProps(outputProps, userProps, isItem, eventHandlers);
    return outputProps;
  }
  function mutablyMergeProps(outputProps, props, isItem, eventHandlers) {
    for (const key in props) {
      const value = props[key];
      if (isItem && (key === ACTIVE_KEY || key === SELECTED_KEY)) {
        continue;
      }
      if (!key.startsWith("on")) {
        outputProps[key] = value;
      } else {
        if (!eventHandlers.has(key)) {
          eventHandlers.set(key, []);
        }
        if (typeof value === "function") {
          eventHandlers.get(key)?.push(value);
          outputProps[key] = (...args) => {
            return eventHandlers.get(key)?.map((fn) => fn(...args)).find((val) => val !== void 0);
          };
        }
      }
    }
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useListNavigation.js
  init_define_import_meta_env();
  var React43 = __toESM(require_react_shim(), 1);
  var ESCAPE = "Escape";
  function doSwitch(orientation, vertical, horizontal) {
    switch (orientation) {
      case "vertical":
        return vertical;
      case "horizontal":
        return horizontal;
      default:
        return vertical || horizontal;
    }
  }
  function isMainOrientationKey(key, orientation) {
    const vertical = key === ARROW_UP || key === ARROW_DOWN;
    const horizontal = key === ARROW_LEFT || key === ARROW_RIGHT;
    return doSwitch(orientation, vertical, horizontal);
  }
  function isMainOrientationToEndKey(key, orientation, rtl) {
    const vertical = key === ARROW_DOWN;
    const horizontal = rtl ? key === ARROW_LEFT : key === ARROW_RIGHT;
    return doSwitch(orientation, vertical, horizontal) || key === "Enter" || key === " " || key === "";
  }
  function isCrossOrientationOpenKey(key, orientation, rtl) {
    const vertical = rtl ? key === ARROW_LEFT : key === ARROW_RIGHT;
    const horizontal = key === ARROW_DOWN;
    return doSwitch(orientation, vertical, horizontal);
  }
  function isCrossOrientationCloseKey(key, orientation, rtl, cols) {
    const vertical = rtl ? key === ARROW_RIGHT : key === ARROW_LEFT;
    const horizontal = key === ARROW_UP;
    if (orientation === "both" || orientation === "horizontal" && cols && cols > 1) {
      return key === ESCAPE;
    }
    return doSwitch(orientation, vertical, horizontal);
  }
  function useListNavigation(context, props) {
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const floatingElement = store.useState("floatingElement");
    const domReferenceElement = store.useState("domReferenceElement");
    const dataRef = store.context.dataRef;
    const {
      listRef,
      activeIndex,
      onNavigate: onNavigateProp = () => {
      },
      enabled = true,
      selectedIndex = null,
      allowEscape = false,
      loopFocus = false,
      nested = false,
      rtl = false,
      virtual = false,
      focusItemOnOpen = "auto",
      focusItemOnHover = true,
      openOnArrowKeyDown = true,
      disabledIndices = void 0,
      orientation = "vertical",
      parentOrientation,
      cols = 1,
      id,
      resetOnPointerLeave = true,
      externalTree
    } = props;
    if (true) {
      if (allowEscape) {
        if (!loopFocus) {
          console.warn("`useListNavigation` looping must be enabled to allow escaping.");
        }
        if (!virtual) {
          console.warn("`useListNavigation` must be virtual to allow escaping.");
        }
      }
      if (orientation === "vertical" && cols > 1) {
        console.warn("In grid list navigation mode (`cols` > 1), the `orientation` should", 'be either "horizontal" or "both".');
      }
    }
    const floatingFocusElement = getFloatingFocusElement(floatingElement);
    const floatingFocusElementRef = useValueAsRef(floatingFocusElement);
    const parentId = useFloatingParentNodeId();
    const tree = useFloatingTree(externalTree);
    useIsoLayoutEffect(() => {
      dataRef.current.orientation = orientation;
    }, [dataRef, orientation]);
    const typeableComboboxReference = isTypeableCombobox(domReferenceElement);
    const focusItemOnOpenRef = React43.useRef(focusItemOnOpen);
    const indexRef = React43.useRef(selectedIndex ?? -1);
    const keyRef = React43.useRef(null);
    const isPointerModalityRef = React43.useRef(true);
    const onNavigate = useStableCallback((event) => {
      onNavigateProp(indexRef.current === -1 ? null : indexRef.current, event);
    });
    const previousOnNavigateRef = React43.useRef(onNavigate);
    const previousMountedRef = React43.useRef(!!floatingElement);
    const previousOpenRef = React43.useRef(open);
    const forceSyncFocusRef = React43.useRef(false);
    const forceScrollIntoViewRef = React43.useRef(false);
    const disabledIndicesRef = useValueAsRef(disabledIndices);
    const latestOpenRef = useValueAsRef(open);
    const selectedIndexRef = useValueAsRef(selectedIndex);
    const resetOnPointerLeaveRef = useValueAsRef(resetOnPointerLeave);
    const focusItem = useStableCallback(() => {
      function runFocus(item2) {
        if (virtual) {
          tree?.events.emit("virtualfocus", item2);
        } else {
          enqueueFocus(item2, {
            sync: forceSyncFocusRef.current,
            preventScroll: true
          });
        }
      }
      const initialItem = listRef.current[indexRef.current];
      const forceScrollIntoView = forceScrollIntoViewRef.current;
      if (initialItem) {
        runFocus(initialItem);
      }
      const scheduler2 = forceSyncFocusRef.current ? (v) => v() : requestAnimationFrame;
      scheduler2(() => {
        const waitedItem = listRef.current[indexRef.current] || initialItem;
        if (!waitedItem) {
          return;
        }
        if (!initialItem) {
          runFocus(waitedItem);
        }
        const shouldScrollIntoView = (
          // eslint-disable-next-line @typescript-eslint/no-use-before-define
          item && (forceScrollIntoView || !isPointerModalityRef.current)
        );
        if (shouldScrollIntoView) {
          waitedItem.scrollIntoView?.({
            block: "nearest",
            inline: "nearest"
          });
        }
      });
    });
    useIsoLayoutEffect(() => {
      if (!enabled) {
        return;
      }
      if (open && floatingElement) {
        indexRef.current = selectedIndex ?? -1;
        if (focusItemOnOpenRef.current && selectedIndex != null) {
          forceScrollIntoViewRef.current = true;
          onNavigate();
        }
      } else if (previousMountedRef.current) {
        indexRef.current = -1;
        previousOnNavigateRef.current();
      }
    }, [enabled, open, floatingElement, selectedIndex, onNavigate]);
    useIsoLayoutEffect(() => {
      if (!enabled) {
        return;
      }
      if (!open) {
        forceSyncFocusRef.current = false;
        return;
      }
      if (!floatingElement) {
        return;
      }
      if (activeIndex == null) {
        forceSyncFocusRef.current = false;
        if (selectedIndexRef.current != null) {
          return;
        }
        if (previousMountedRef.current) {
          indexRef.current = -1;
          focusItem();
        }
        if ((!previousOpenRef.current || !previousMountedRef.current) && focusItemOnOpenRef.current && (keyRef.current != null || focusItemOnOpenRef.current === true && keyRef.current == null)) {
          let runs = 0;
          const waitForListPopulated = () => {
            if (listRef.current[0] == null) {
              if (runs < 2) {
                const scheduler2 = runs ? requestAnimationFrame : queueMicrotask;
                scheduler2(waitForListPopulated);
              }
              runs += 1;
            } else {
              indexRef.current = keyRef.current == null || isMainOrientationToEndKey(keyRef.current, orientation, rtl) || nested ? getMinListIndex(listRef) : getMaxListIndex(listRef);
              keyRef.current = null;
              onNavigate();
            }
          };
          waitForListPopulated();
        }
      } else if (!isIndexOutOfListBounds(listRef, activeIndex)) {
        indexRef.current = activeIndex;
        focusItem();
        forceScrollIntoViewRef.current = false;
      }
    }, [enabled, open, floatingElement, activeIndex, selectedIndexRef, nested, listRef, orientation, rtl, onNavigate, focusItem, disabledIndicesRef]);
    useIsoLayoutEffect(() => {
      if (!enabled || floatingElement || !tree || virtual || !previousMountedRef.current) {
        return;
      }
      const nodes = tree.nodesRef.current;
      const parent = nodes.find((node) => node.id === parentId)?.context?.elements.floating;
      const activeEl = activeElement(ownerDocument(floatingElement));
      const treeContainsActiveEl = nodes.some((node) => node.context && contains(node.context.elements.floating, activeEl));
      if (parent && !treeContainsActiveEl && isPointerModalityRef.current) {
        parent.focus({
          preventScroll: true
        });
      }
    }, [enabled, floatingElement, tree, parentId, virtual]);
    useIsoLayoutEffect(() => {
      previousOnNavigateRef.current = onNavigate;
      previousOpenRef.current = open;
      previousMountedRef.current = !!floatingElement;
    });
    useIsoLayoutEffect(() => {
      if (!open) {
        keyRef.current = null;
        focusItemOnOpenRef.current = focusItemOnOpen;
      }
    }, [open, focusItemOnOpen]);
    const hasActiveIndex = activeIndex != null;
    const item = React43.useMemo(() => {
      function syncCurrentTarget(event) {
        if (!latestOpenRef.current) {
          return;
        }
        const index2 = listRef.current.indexOf(event.currentTarget);
        if (index2 !== -1 && indexRef.current !== index2) {
          indexRef.current = index2;
          onNavigate(event);
        }
      }
      const itemProps = {
        onFocus(event) {
          forceSyncFocusRef.current = true;
          syncCurrentTarget(event);
        },
        onClick: ({
          currentTarget
        }) => currentTarget.focus({
          preventScroll: true
        }),
        // Safari
        onMouseMove(event) {
          forceSyncFocusRef.current = true;
          forceScrollIntoViewRef.current = false;
          if (focusItemOnHover) {
            syncCurrentTarget(event);
          }
        },
        onPointerLeave(event) {
          if (!latestOpenRef.current || !isPointerModalityRef.current || event.pointerType === "touch") {
            return;
          }
          forceSyncFocusRef.current = true;
          const relatedTarget = event.relatedTarget;
          if (!focusItemOnHover || listRef.current.includes(relatedTarget)) {
            return;
          }
          if (!resetOnPointerLeaveRef.current) {
            return;
          }
          enqueueFocus(null, {
            sync: true
          });
          indexRef.current = -1;
          onNavigate(event);
          if (!virtual) {
            const floatingFocusEl = floatingFocusElementRef.current;
            const activeEl = activeElement(ownerDocument(floatingFocusEl));
            if (floatingFocusEl && contains(floatingFocusEl, activeEl)) {
              floatingFocusEl.focus({
                preventScroll: true
              });
            }
          }
        }
      };
      return itemProps;
    }, [latestOpenRef, floatingFocusElementRef, focusItemOnHover, listRef, onNavigate, resetOnPointerLeaveRef, virtual]);
    const getParentOrientation = React43.useCallback(() => {
      return parentOrientation ?? tree?.nodesRef.current.find((node) => node.id === parentId)?.context?.dataRef?.current.orientation;
    }, [parentId, tree, parentOrientation]);
    const commonOnKeyDown = useStableCallback((event) => {
      isPointerModalityRef.current = false;
      forceSyncFocusRef.current = true;
      if (event.which === 229) {
        return;
      }
      if (!latestOpenRef.current && event.currentTarget === floatingFocusElementRef.current) {
        return;
      }
      if (nested && isCrossOrientationCloseKey(event.key, orientation, rtl, cols)) {
        if (!isMainOrientationKey(event.key, getParentOrientation())) {
          stopEvent(event);
        }
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.listNavigation, event.nativeEvent));
        if (isHTMLElement(domReferenceElement)) {
          if (virtual) {
            tree?.events.emit("virtualfocus", domReferenceElement);
          } else {
            domReferenceElement.focus();
          }
        }
        return;
      }
      const currentIndex = indexRef.current;
      const minIndex = getMinListIndex(listRef, disabledIndices);
      const maxIndex = getMaxListIndex(listRef, disabledIndices);
      if (!typeableComboboxReference) {
        if (event.key === "Home") {
          stopEvent(event);
          indexRef.current = minIndex;
          onNavigate(event);
        }
        if (event.key === "End") {
          stopEvent(event);
          indexRef.current = maxIndex;
          onNavigate(event);
        }
      }
      if (cols > 1) {
        const sizes = Array.from({
          length: listRef.current.length
        }, () => ({
          width: 1,
          height: 1
        }));
        const cellMap = createGridCellMap(sizes, cols, false);
        const minGridIndex = cellMap.findIndex((index3) => index3 != null && !isListIndexDisabled(listRef, index3, disabledIndices));
        const maxGridIndex = cellMap.reduce((foundIndex, index3, cellIndex) => index3 != null && !isListIndexDisabled(listRef, index3, disabledIndices) ? cellIndex : foundIndex, -1);
        const index2 = cellMap[getGridNavigatedIndex({
          current: cellMap.map((itemIndex) => itemIndex != null ? listRef.current[itemIndex] : null)
        }, {
          event,
          orientation,
          loopFocus,
          rtl,
          cols,
          // treat undefined (empty grid spaces) as disabled indices so we
          // don't end up in them
          disabledIndices: getGridCellIndices([...(typeof disabledIndices !== "function" ? disabledIndices : null) || listRef.current.map((_, listIndex) => isListIndexDisabled(listRef, listIndex, disabledIndices) ? listIndex : void 0), void 0], cellMap),
          minIndex: minGridIndex,
          maxIndex: maxGridIndex,
          prevIndex: getGridCellIndexOfCorner(
            indexRef.current > maxIndex ? minIndex : indexRef.current,
            sizes,
            cellMap,
            cols,
            // use a corner matching the edge closest to the direction
            // we're moving in so we don't end up in the same item. Prefer
            // top/left over bottom/right.
            // eslint-disable-next-line no-nested-ternary
            event.key === ARROW_DOWN ? "bl" : event.key === (rtl ? ARROW_LEFT : ARROW_RIGHT) ? "tr" : "tl"
          ),
          stopEvent: true
        })];
        if (index2 != null) {
          indexRef.current = index2;
          onNavigate(event);
        }
        if (orientation === "both") {
          return;
        }
      }
      if (isMainOrientationKey(event.key, orientation)) {
        stopEvent(event);
        if (open && !virtual && activeElement(event.currentTarget.ownerDocument) === event.currentTarget) {
          indexRef.current = isMainOrientationToEndKey(event.key, orientation, rtl) ? minIndex : maxIndex;
          onNavigate(event);
          return;
        }
        if (isMainOrientationToEndKey(event.key, orientation, rtl)) {
          if (loopFocus) {
            if (currentIndex >= maxIndex) {
              if (allowEscape && currentIndex !== listRef.current.length) {
                indexRef.current = -1;
              } else {
                forceSyncFocusRef.current = false;
                indexRef.current = minIndex;
              }
            } else {
              indexRef.current = findNonDisabledListIndex(listRef, {
                startingIndex: currentIndex,
                disabledIndices
              });
            }
          } else {
            indexRef.current = Math.min(maxIndex, findNonDisabledListIndex(listRef, {
              startingIndex: currentIndex,
              disabledIndices
            }));
          }
        } else if (loopFocus) {
          if (currentIndex <= minIndex) {
            if (allowEscape && currentIndex !== -1) {
              indexRef.current = listRef.current.length;
            } else {
              forceSyncFocusRef.current = false;
              indexRef.current = maxIndex;
            }
          } else {
            indexRef.current = findNonDisabledListIndex(listRef, {
              startingIndex: currentIndex,
              decrement: true,
              disabledIndices
            });
          }
        } else {
          indexRef.current = Math.max(minIndex, findNonDisabledListIndex(listRef, {
            startingIndex: currentIndex,
            decrement: true,
            disabledIndices
          }));
        }
        if (isIndexOutOfListBounds(listRef, indexRef.current)) {
          indexRef.current = -1;
        }
        onNavigate(event);
      }
    });
    const ariaActiveDescendantProp = React43.useMemo(() => {
      return virtual && open && hasActiveIndex && {
        "aria-activedescendant": `${id}-${activeIndex}`
      };
    }, [virtual, open, hasActiveIndex, id, activeIndex]);
    const floating = React43.useMemo(() => {
      return {
        "aria-orientation": orientation === "both" ? void 0 : orientation,
        ...!typeableComboboxReference ? ariaActiveDescendantProp : {},
        onKeyDown(event) {
          if (event.key === "Tab" && event.shiftKey && open && !virtual) {
            const target = getTarget(event.nativeEvent);
            if (target && !contains(floatingFocusElementRef.current, target)) {
              return;
            }
            stopEvent(event);
            store.setOpen(false, createChangeEventDetails(reason_parts_exports.focusOut, event.nativeEvent));
            if (isHTMLElement(domReferenceElement)) {
              domReferenceElement.focus();
            }
            return;
          }
          commonOnKeyDown(event);
        },
        onPointerMove() {
          isPointerModalityRef.current = true;
        }
      };
    }, [ariaActiveDescendantProp, commonOnKeyDown, floatingFocusElementRef, orientation, typeableComboboxReference, store, open, virtual, domReferenceElement]);
    const trigger = React43.useMemo(() => {
      function checkVirtualMouse(event) {
        if (focusItemOnOpen === "auto" && isVirtualClick(event.nativeEvent)) {
          focusItemOnOpenRef.current = !virtual;
        }
      }
      function checkVirtualPointer(event) {
        focusItemOnOpenRef.current = focusItemOnOpen;
        if (focusItemOnOpen === "auto" && isVirtualPointerEvent(event.nativeEvent)) {
          focusItemOnOpenRef.current = true;
        }
      }
      return {
        onKeyDown(event) {
          const currentOpen = store.select("open");
          isPointerModalityRef.current = false;
          const isArrowKey = event.key.startsWith("Arrow");
          const isParentCrossOpenKey = isCrossOrientationOpenKey(event.key, getParentOrientation(), rtl);
          const isMainKey = isMainOrientationKey(event.key, orientation);
          const isNavigationKey = (nested ? isParentCrossOpenKey : isMainKey) || event.key === "Enter" || event.key.trim() === "";
          if (virtual && currentOpen) {
            return commonOnKeyDown(event);
          }
          if (!currentOpen && !openOnArrowKeyDown && isArrowKey) {
            return void 0;
          }
          if (isNavigationKey) {
            const isParentMainKey = isMainOrientationKey(event.key, getParentOrientation());
            keyRef.current = nested && isParentMainKey ? null : event.key;
          }
          if (nested) {
            if (isParentCrossOpenKey) {
              stopEvent(event);
              if (currentOpen) {
                indexRef.current = getMinListIndex(listRef, disabledIndicesRef.current);
                onNavigate(event);
              } else {
                store.setOpen(true, createChangeEventDetails(reason_parts_exports.listNavigation, event.nativeEvent, event.currentTarget));
              }
            }
            return void 0;
          }
          if (isMainKey) {
            if (selectedIndexRef.current != null) {
              indexRef.current = selectedIndexRef.current;
            }
            stopEvent(event);
            if (!currentOpen && openOnArrowKeyDown) {
              store.setOpen(true, createChangeEventDetails(reason_parts_exports.listNavigation, event.nativeEvent, event.currentTarget));
            } else {
              commonOnKeyDown(event);
            }
            if (currentOpen) {
              onNavigate(event);
            }
          }
          return void 0;
        },
        onFocus(event) {
          if (store.select("open") && !virtual) {
            indexRef.current = -1;
            onNavigate(event);
          }
        },
        onPointerDown: checkVirtualPointer,
        onPointerEnter: checkVirtualPointer,
        onMouseDown: checkVirtualMouse,
        onClick: checkVirtualMouse
      };
    }, [commonOnKeyDown, disabledIndicesRef, focusItemOnOpen, listRef, nested, onNavigate, store, openOnArrowKeyDown, orientation, getParentOrientation, rtl, selectedIndexRef, virtual]);
    const reference = React43.useMemo(() => {
      return {
        ...ariaActiveDescendantProp,
        ...trigger
      };
    }, [ariaActiveDescendantProp, trigger]);
    return React43.useMemo(() => enabled ? {
      reference,
      floating,
      item,
      trigger
    } : {}, [enabled, reference, floating, trigger, item]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useRole.js
  init_define_import_meta_env();
  var React44 = __toESM(require_react_shim(), 1);
  var componentRoleToAriaRoleMap = /* @__PURE__ */ new Map([["select", "listbox"], ["combobox", "listbox"], ["label", false]]);
  function useRole(context, props = {}) {
    const store = "rootStore" in context ? context.rootStore : context;
    const open = store.useState("open");
    const defaultFloatingId = store.useState("floatingId");
    const domReference = store.useState("domReferenceElement");
    const floatingElement = store.useState("floatingElement");
    const {
      role = "dialog"
    } = props;
    const defaultReferenceId = useId();
    const referenceId = domReference?.id || defaultReferenceId;
    const floatingId = React44.useMemo(() => getFloatingFocusElement(floatingElement)?.id || defaultFloatingId, [floatingElement, defaultFloatingId]);
    const ariaRole = componentRoleToAriaRoleMap.get(role) ?? role;
    const parentId = useFloatingParentNodeId();
    const isNested = parentId != null;
    const trigger = React44.useMemo(() => {
      if (ariaRole === "tooltip" || role === "label") {
        return EMPTY_OBJECT;
      }
      return {
        "aria-haspopup": ariaRole === "alertdialog" ? "dialog" : ariaRole,
        "aria-expanded": "false",
        ...ariaRole === "listbox" && {
          role: "combobox"
        },
        ...ariaRole === "menu" && isNested && {
          role: "menuitem"
        },
        ...role === "select" && {
          "aria-autocomplete": "none"
        },
        ...role === "combobox" && {
          "aria-autocomplete": "list"
        }
      };
    }, [ariaRole, isNested, role]);
    const reference = React44.useMemo(() => {
      if (ariaRole === "tooltip" || role === "label") {
        return {
          [`aria-${role === "label" ? "labelledby" : "describedby"}`]: open ? floatingId : void 0
        };
      }
      const triggerProps = trigger;
      return {
        ...triggerProps,
        "aria-expanded": open ? "true" : "false",
        "aria-controls": open ? floatingId : void 0,
        ...ariaRole === "menu" && {
          id: referenceId
        }
      };
    }, [ariaRole, floatingId, open, referenceId, role, trigger]);
    const floating = React44.useMemo(() => {
      const floatingProps = {
        id: floatingId,
        ...ariaRole && {
          role: ariaRole
        }
      };
      if (ariaRole === "tooltip" || role === "label") {
        return floatingProps;
      }
      return {
        ...floatingProps,
        ...ariaRole === "menu" && {
          "aria-labelledby": referenceId
        }
      };
    }, [ariaRole, floatingId, referenceId, role]);
    const item = React44.useCallback(({
      active,
      selected
    }) => {
      const commonProps = {
        role: "option",
        ...active && {
          id: `${floatingId}-fui-option`
        }
      };
      switch (role) {
        case "select":
        case "combobox":
          return {
            ...commonProps,
            "aria-selected": selected
          };
        default:
      }
      return {};
    }, [floatingId, role]);
    return React44.useMemo(() => ({
      reference,
      floating,
      item,
      trigger
    }), [reference, floating, trigger, item]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/hooks/useTypeahead.js
  init_define_import_meta_env();
  var React45 = __toESM(require_react_shim(), 1);
  function useTypeahead(context, props) {
    const store = "rootStore" in context ? context.rootStore : context;
    const dataRef = store.context.dataRef;
    const open = store.useState("open");
    const {
      listRef,
      elementsRef,
      activeIndex,
      onMatch: onMatchProp,
      onTypingChange,
      enabled = true,
      resetMs = 750,
      selectedIndex = null
    } = props;
    const timeout = useTimeout();
    const stringRef = React45.useRef("");
    const prevIndexRef = React45.useRef(selectedIndex ?? activeIndex ?? -1);
    const matchIndexRef = React45.useRef(null);
    useIsoLayoutEffect(() => {
      if (!open && selectedIndex !== null) {
        return;
      }
      timeout.clear();
      matchIndexRef.current = null;
      if (stringRef.current !== "") {
        stringRef.current = "";
      }
    }, [open, selectedIndex, timeout]);
    useIsoLayoutEffect(() => {
      if (open && stringRef.current === "") {
        prevIndexRef.current = selectedIndex ?? activeIndex ?? -1;
      }
    }, [open, selectedIndex, activeIndex]);
    const setTypingChange = useStableCallback((value) => {
      if (value) {
        if (!dataRef.current.typing) {
          dataRef.current.typing = value;
          onTypingChange?.(value);
        }
      } else if (dataRef.current.typing) {
        dataRef.current.typing = value;
        onTypingChange?.(value);
      }
    });
    const onKeyDown = useStableCallback((event) => {
      function isVisible(index3) {
        const element = elementsRef?.current[index3];
        return !element || isElementVisible(element);
      }
      function getMatchingIndex(list, string, startIndex2 = 0) {
        if (list.length === 0) {
          return -1;
        }
        const normalizedStartIndex = (startIndex2 % list.length + list.length) % list.length;
        const lowerString = string.toLocaleLowerCase();
        for (let offset4 = 0; offset4 < list.length; offset4 += 1) {
          const index3 = (normalizedStartIndex + offset4) % list.length;
          const text = list[index3];
          if (!text?.toLocaleLowerCase().startsWith(lowerString) || !isVisible(index3)) {
            continue;
          }
          return index3;
        }
        return -1;
      }
      const listContent = listRef.current;
      if (stringRef.current.length > 0 && event.key === " ") {
        stopEvent(event);
        setTypingChange(true);
      }
      if (stringRef.current.length > 0 && stringRef.current[0] !== " ") {
        if (getMatchingIndex(listContent, stringRef.current) === -1 && event.key !== " ") {
          setTypingChange(false);
        }
      }
      if (listContent == null || // Character key.
      event.key.length !== 1 || // Modifier key.
      event.ctrlKey || event.metaKey || event.altKey) {
        return;
      }
      if (open && event.key !== " ") {
        stopEvent(event);
        setTypingChange(true);
      }
      const isNewSession = stringRef.current === "";
      if (isNewSession) {
        prevIndexRef.current = selectedIndex ?? activeIndex ?? -1;
      }
      const allowRapidSuccessionOfFirstLetter = listContent.every((text) => text ? text[0]?.toLocaleLowerCase() !== text[1]?.toLocaleLowerCase() : true);
      if (allowRapidSuccessionOfFirstLetter && stringRef.current === event.key) {
        stringRef.current = "";
        prevIndexRef.current = matchIndexRef.current;
      }
      stringRef.current += event.key;
      timeout.start(resetMs, () => {
        stringRef.current = "";
        prevIndexRef.current = matchIndexRef.current;
        setTypingChange(false);
      });
      const prevIndex = isNewSession ? selectedIndex ?? activeIndex ?? -1 : prevIndexRef.current;
      const startIndex = (prevIndex ?? 0) + 1;
      const index2 = getMatchingIndex(listContent, stringRef.current, startIndex);
      if (index2 !== -1) {
        onMatchProp?.(index2);
        matchIndexRef.current = index2;
      } else if (event.key !== " ") {
        stringRef.current = "";
        setTypingChange(false);
      }
    });
    const onBlur = useStableCallback((event) => {
      const next = event.relatedTarget;
      const currentDomReferenceElement = store.select("domReferenceElement");
      const currentFloatingElement = store.select("floatingElement");
      const withinReference = contains(currentDomReferenceElement, next);
      const withinFloating = contains(currentFloatingElement, next);
      if (withinReference || withinFloating) {
        return;
      }
      timeout.clear();
      stringRef.current = "";
      prevIndexRef.current = matchIndexRef.current;
      setTypingChange(false);
    });
    const reference = React45.useMemo(() => ({
      onKeyDown,
      onBlur
    }), [onKeyDown, onBlur]);
    const floating = React45.useMemo(() => {
      return {
        onKeyDown,
        onBlur
      };
    }, [onKeyDown, onBlur]);
    return React45.useMemo(() => enabled ? {
      reference,
      floating
    } : {}, [enabled, reference, floating]);
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/safePolygon.js
  init_define_import_meta_env();
  var CURSOR_SPEED_THRESHOLD = 0.1;
  var CURSOR_SPEED_THRESHOLD_SQUARED = CURSOR_SPEED_THRESHOLD * CURSOR_SPEED_THRESHOLD;
  var POLYGON_BUFFER = 0.5;
  function hasIntersectingEdge(pointX, pointY, xi, yi, xj, yj) {
    return yi >= pointY !== yj >= pointY && pointX <= (xj - xi) * (pointY - yi) / (yj - yi) + xi;
  }
  function isPointInQuadrilateral(pointX, pointY, x1, y1, x2, y2, x3, y3, x4, y4) {
    let isInsideValue = false;
    if (hasIntersectingEdge(pointX, pointY, x1, y1, x2, y2)) {
      isInsideValue = !isInsideValue;
    }
    if (hasIntersectingEdge(pointX, pointY, x2, y2, x3, y3)) {
      isInsideValue = !isInsideValue;
    }
    if (hasIntersectingEdge(pointX, pointY, x3, y3, x4, y4)) {
      isInsideValue = !isInsideValue;
    }
    if (hasIntersectingEdge(pointX, pointY, x4, y4, x1, y1)) {
      isInsideValue = !isInsideValue;
    }
    return isInsideValue;
  }
  function isInsideRect(pointX, pointY, rect) {
    return pointX >= rect.x && pointX <= rect.x + rect.width && pointY >= rect.y && pointY <= rect.y + rect.height;
  }
  function isInsideAxisAlignedRect(pointX, pointY, x1, y1, x2, y2) {
    const minX = Math.min(x1, x2);
    const maxX = Math.max(x1, x2);
    const minY = Math.min(y1, y2);
    const maxY = Math.max(y1, y2);
    return pointX >= minX && pointX <= maxX && pointY >= minY && pointY <= maxY;
  }
  function safePolygon(options = {}) {
    const {
      blockPointerEvents = false
    } = options;
    const timeout = new Timeout();
    const fn = ({
      x,
      y,
      placement,
      elements,
      onClose,
      nodeId,
      tree
    }) => {
      const side = placement?.split("-")[0];
      let hasLanded = false;
      let lastX = null;
      let lastY = null;
      let lastCursorTime = typeof performance !== "undefined" ? performance.now() : 0;
      function isCursorMovingSlowly(nextX, nextY) {
        const currentTime = performance.now();
        const elapsedTime = currentTime - lastCursorTime;
        if (lastX === null || lastY === null || elapsedTime === 0) {
          lastX = nextX;
          lastY = nextY;
          lastCursorTime = currentTime;
          return false;
        }
        const deltaX = nextX - lastX;
        const deltaY = nextY - lastY;
        const distanceSquared = deltaX * deltaX + deltaY * deltaY;
        const thresholdSquared = elapsedTime * elapsedTime * CURSOR_SPEED_THRESHOLD_SQUARED;
        lastX = nextX;
        lastY = nextY;
        lastCursorTime = currentTime;
        return distanceSquared < thresholdSquared;
      }
      function close() {
        timeout.clear();
        onClose();
      }
      return function onMouseMove(event) {
        timeout.clear();
        const domReference = elements.domReference;
        const floating = elements.floating;
        if (!domReference || !floating || side == null || x == null || y == null) {
          return void 0;
        }
        const {
          clientX,
          clientY
        } = event;
        const target = getTarget(event);
        const isLeave = event.type === "mouseleave";
        const isOverFloatingEl = contains(floating, target);
        const isOverReferenceEl = contains(domReference, target);
        if (isOverFloatingEl) {
          hasLanded = true;
          if (!isLeave) {
            return void 0;
          }
        }
        if (isOverReferenceEl) {
          hasLanded = false;
          if (!isLeave) {
            hasLanded = true;
            return void 0;
          }
        }
        if (isLeave && isElement(event.relatedTarget) && contains(floating, event.relatedTarget)) {
          return void 0;
        }
        function hasOpenChildNode() {
          return Boolean(tree && getNodeChildren(tree.nodesRef.current, nodeId).length > 0);
        }
        function closeIfNoOpenChild() {
          if (!hasOpenChildNode()) {
            close();
          }
        }
        if (hasOpenChildNode()) {
          return void 0;
        }
        const refRect = domReference.getBoundingClientRect();
        const rect = floating.getBoundingClientRect();
        const cursorLeaveFromRight = x > rect.right - rect.width / 2;
        const cursorLeaveFromBottom = y > rect.bottom - rect.height / 2;
        const isFloatingWider = rect.width > refRect.width;
        const isFloatingTaller = rect.height > refRect.height;
        const left = (isFloatingWider ? refRect : rect).left;
        const right = (isFloatingWider ? refRect : rect).right;
        const top = (isFloatingTaller ? refRect : rect).top;
        const bottom = (isFloatingTaller ? refRect : rect).bottom;
        if (side === "top" && y >= refRect.bottom - 1 || side === "bottom" && y <= refRect.top + 1 || side === "left" && x >= refRect.right - 1 || side === "right" && x <= refRect.left + 1) {
          closeIfNoOpenChild();
          return void 0;
        }
        let isInsideTroughRect = false;
        switch (side) {
          case "top":
            isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, left, refRect.top + 1, right, rect.bottom - 1);
            break;
          case "bottom":
            isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, left, rect.top + 1, right, refRect.bottom - 1);
            break;
          case "left":
            isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, rect.right - 1, bottom, refRect.left + 1, top);
            break;
          case "right":
            isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, refRect.right - 1, bottom, rect.left + 1, top);
            break;
          default:
        }
        if (isInsideTroughRect) {
          return void 0;
        }
        if (hasLanded && !isInsideRect(clientX, clientY, refRect)) {
          closeIfNoOpenChild();
          return void 0;
        }
        if (!isLeave && isCursorMovingSlowly(clientX, clientY)) {
          closeIfNoOpenChild();
          return void 0;
        }
        let isInsidePolygon = false;
        switch (side) {
          case "top": {
            const cursorXOffset = isFloatingWider ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
            const cursorPointOneX = isFloatingWider ? x + cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
            const cursorPointTwoX = isFloatingWider ? x - cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
            const cursorPointY = y + POLYGON_BUFFER + 1;
            const commonYLeft = cursorLeaveFromRight ? rect.bottom - POLYGON_BUFFER : isFloatingWider ? rect.bottom - POLYGON_BUFFER : rect.top;
            const commonYRight = cursorLeaveFromRight ? isFloatingWider ? rect.bottom - POLYGON_BUFFER : rect.top : rect.bottom - POLYGON_BUFFER;
            isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointOneX, cursorPointY, cursorPointTwoX, cursorPointY, rect.left, commonYLeft, rect.right, commonYRight);
            break;
          }
          case "bottom": {
            const cursorXOffset = isFloatingWider ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
            const cursorPointOneX = isFloatingWider ? x + cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
            const cursorPointTwoX = isFloatingWider ? x - cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
            const cursorPointY = y - POLYGON_BUFFER;
            const commonYLeft = cursorLeaveFromRight ? rect.top + POLYGON_BUFFER : isFloatingWider ? rect.top + POLYGON_BUFFER : rect.bottom;
            const commonYRight = cursorLeaveFromRight ? isFloatingWider ? rect.top + POLYGON_BUFFER : rect.bottom : rect.top + POLYGON_BUFFER;
            isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointOneX, cursorPointY, cursorPointTwoX, cursorPointY, rect.left, commonYLeft, rect.right, commonYRight);
            break;
          }
          case "left": {
            const cursorYOffset = isFloatingTaller ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
            const cursorPointOneY = isFloatingTaller ? y + cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
            const cursorPointTwoY = isFloatingTaller ? y - cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
            const cursorPointX = x + POLYGON_BUFFER + 1;
            const commonXTop = cursorLeaveFromBottom ? rect.right - POLYGON_BUFFER : isFloatingTaller ? rect.right - POLYGON_BUFFER : rect.left;
            const commonXBottom = cursorLeaveFromBottom ? isFloatingTaller ? rect.right - POLYGON_BUFFER : rect.left : rect.right - POLYGON_BUFFER;
            isInsidePolygon = isPointInQuadrilateral(clientX, clientY, commonXTop, rect.top, commonXBottom, rect.bottom, cursorPointX, cursorPointOneY, cursorPointX, cursorPointTwoY);
            break;
          }
          case "right": {
            const cursorYOffset = isFloatingTaller ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
            const cursorPointOneY = isFloatingTaller ? y + cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
            const cursorPointTwoY = isFloatingTaller ? y - cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
            const cursorPointX = x - POLYGON_BUFFER;
            const commonXTop = cursorLeaveFromBottom ? rect.left + POLYGON_BUFFER : isFloatingTaller ? rect.left + POLYGON_BUFFER : rect.right;
            const commonXBottom = cursorLeaveFromBottom ? isFloatingTaller ? rect.left + POLYGON_BUFFER : rect.right : rect.left + POLYGON_BUFFER;
            isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointX, cursorPointOneY, cursorPointX, cursorPointTwoY, commonXTop, rect.top, commonXBottom, rect.bottom);
            break;
          }
          default:
        }
        if (!isInsidePolygon) {
          closeIfNoOpenChild();
        } else if (!hasLanded) {
          timeout.start(40, closeIfNoOpenChild);
        }
        return void 0;
      };
    };
    fn.__options = {
      blockPointerEvents
    };
    return fn;
  }

  // node_modules/@base-ui/react/esm/dialog/popup/DialogPopupCssVars.js
  init_define_import_meta_env();
  var DialogPopupCssVars = /* @__PURE__ */ (function(DialogPopupCssVars2) {
    DialogPopupCssVars2["nestedDialogs"] = "--nested-dialogs";
    return DialogPopupCssVars2;
  })({});

  // node_modules/@base-ui/react/esm/dialog/popup/DialogPopupDataAttributes.js
  init_define_import_meta_env();
  var DialogPopupDataAttributes = (function(DialogPopupDataAttributes2) {
    DialogPopupDataAttributes2[DialogPopupDataAttributes2["open"] = CommonPopupDataAttributes.open] = "open";
    DialogPopupDataAttributes2[DialogPopupDataAttributes2["closed"] = CommonPopupDataAttributes.closed] = "closed";
    DialogPopupDataAttributes2[DialogPopupDataAttributes2["startingStyle"] = CommonPopupDataAttributes.startingStyle] = "startingStyle";
    DialogPopupDataAttributes2[DialogPopupDataAttributes2["endingStyle"] = CommonPopupDataAttributes.endingStyle] = "endingStyle";
    DialogPopupDataAttributes2["nested"] = "data-nested";
    DialogPopupDataAttributes2["nestedDialogOpen"] = "data-nested-dialog-open";
    return DialogPopupDataAttributes2;
  })({});

  // node_modules/@base-ui/react/esm/dialog/portal/DialogPortalContext.js
  init_define_import_meta_env();
  var React46 = __toESM(require_react_shim(), 1);
  var DialogPortalContext = /* @__PURE__ */ React46.createContext(void 0);
  if (true) DialogPortalContext.displayName = "DialogPortalContext";
  function useDialogPortalContext() {
    const value = React46.useContext(DialogPortalContext);
    if (value === void 0) {
      throw new Error(true ? "Base UI: <Dialog.Portal> is missing." : formatErrorMessage_default(26));
    }
    return value;
  }

  // node_modules/@base-ui/react/esm/composite/composite.js
  init_define_import_meta_env();
  var ARROW_UP2 = "ArrowUp";
  var ARROW_DOWN2 = "ArrowDown";
  var ARROW_LEFT2 = "ArrowLeft";
  var ARROW_RIGHT2 = "ArrowRight";
  var HOME = "Home";
  var END = "End";
  var HORIZONTAL_KEYS = /* @__PURE__ */ new Set([ARROW_LEFT2, ARROW_RIGHT2]);
  var VERTICAL_KEYS = /* @__PURE__ */ new Set([ARROW_UP2, ARROW_DOWN2]);
  var ARROW_KEYS = /* @__PURE__ */ new Set([...HORIZONTAL_KEYS, ...VERTICAL_KEYS]);
  var ALL_KEYS = /* @__PURE__ */ new Set([...ARROW_KEYS, HOME, END]);
  var COMPOSITE_KEYS = /* @__PURE__ */ new Set([ARROW_UP2, ARROW_DOWN2, ARROW_LEFT2, ARROW_RIGHT2, HOME, END]);

  // node_modules/@base-ui/react/esm/dialog/popup/DialogPopup.js
  var import_jsx_runtime10 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping3 = {
    ...popupStateMapping,
    ...transitionStatusMapping,
    nestedDialogOpen(value) {
      return value ? {
        [DialogPopupDataAttributes.nestedDialogOpen]: ""
      } : null;
    }
  };
  var DialogPopup = /* @__PURE__ */ React47.forwardRef(function DialogPopup2(componentProps, forwardedRef) {
    const {
      className,
      finalFocus,
      initialFocus,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useDialogRootContext();
    const descriptionElementId = store.useState("descriptionElementId");
    const disablePointerDismissal = store.useState("disablePointerDismissal");
    const floatingRootContext = store.useState("floatingRootContext");
    const rootPopupProps = store.useState("popupProps");
    const modal = store.useState("modal");
    const mounted = store.useState("mounted");
    const nested = store.useState("nested");
    const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
    const open = store.useState("open");
    const openMethod = store.useState("openMethod");
    const titleElementId = store.useState("titleElementId");
    const transitionStatus = store.useState("transitionStatus");
    const role = store.useState("role");
    useDialogPortalContext();
    useOpenChangeComplete({
      open,
      ref: store.context.popupRef,
      onComplete() {
        if (open) {
          store.context.onOpenChangeComplete?.(true);
        }
      }
    });
    function defaultInitialFocus(interactionType) {
      if (interactionType === "touch") {
        return store.context.popupRef.current;
      }
      return true;
    }
    const resolvedInitialFocus = initialFocus === void 0 ? defaultInitialFocus : initialFocus;
    const nestedDialogOpen = nestedOpenDialogCount > 0;
    const state = {
      open,
      nested,
      transitionStatus,
      nestedDialogOpen
    };
    const element = useRenderElement("div", componentProps, {
      state,
      props: [rootPopupProps, {
        "aria-labelledby": titleElementId ?? void 0,
        "aria-describedby": descriptionElementId ?? void 0,
        role,
        tabIndex: -1,
        hidden: !mounted,
        onKeyDown(event) {
          if (COMPOSITE_KEYS.has(event.key)) {
            event.stopPropagation();
          }
        },
        style: {
          [DialogPopupCssVars.nestedDialogs]: nestedOpenDialogCount
        }
      }, elementProps],
      ref: [forwardedRef, store.context.popupRef, store.useStateSetter("popupElement")],
      stateAttributesMapping: stateAttributesMapping3
    });
    return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(FloatingFocusManager, {
      context: floatingRootContext,
      openInteractionType: openMethod,
      disabled: !mounted,
      closeOnFocusOut: !disablePointerDismissal,
      initialFocus: resolvedInitialFocus,
      returnFocus: finalFocus,
      modal: modal !== false,
      restoreFocus: "popup",
      children: element
    });
  });
  if (true) DialogPopup.displayName = "DialogPopup";

  // node_modules/@base-ui/react/esm/dialog/portal/DialogPortal.js
  init_define_import_meta_env();
  var React49 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/inertValue.js
  init_define_import_meta_env();
  function inertValue(value) {
    if (isReactVersionAtLeast(19)) {
      return value;
    }
    return value ? "true" : void 0;
  }

  // node_modules/@base-ui/react/esm/utils/InternalBackdrop.js
  init_define_import_meta_env();
  var React48 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime11 = __toESM(require_react_shim(), 1);
  var InternalBackdrop = /* @__PURE__ */ React48.forwardRef(function InternalBackdrop2(props, ref) {
    const {
      cutout,
      ...otherProps
    } = props;
    let clipPath;
    if (cutout) {
      const rect = cutout?.getBoundingClientRect();
      clipPath = `polygon(
      0% 0%,
      100% 0%,
      100% 100%,
      0% 100%,
      0% 0%,
      ${rect.left}px ${rect.top}px,
      ${rect.left}px ${rect.bottom}px,
      ${rect.right}px ${rect.bottom}px,
      ${rect.right}px ${rect.top}px,
      ${rect.left}px ${rect.top}px
    )`;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", {
      ref,
      role: "presentation",
      "data-base-ui-inert": "",
      ...otherProps,
      style: {
        position: "fixed",
        inset: 0,
        userSelect: "none",
        WebkitUserSelect: "none",
        clipPath
      }
    });
  });
  if (true) InternalBackdrop.displayName = "InternalBackdrop";

  // node_modules/@base-ui/react/esm/dialog/portal/DialogPortal.js
  var import_jsx_runtime12 = __toESM(require_react_shim(), 1);
  var DialogPortal = /* @__PURE__ */ React49.forwardRef(function DialogPortal2(props, forwardedRef) {
    const {
      keepMounted = false,
      ...portalProps
    } = props;
    const {
      store
    } = useDialogRootContext();
    const mounted = store.useState("mounted");
    const modal = store.useState("modal");
    const open = store.useState("open");
    const shouldRender = mounted || keepMounted;
    if (!shouldRender) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(DialogPortalContext.Provider, {
      value: keepMounted,
      children: /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(FloatingPortal, {
        ref: forwardedRef,
        ...portalProps,
        children: [mounted && modal === true && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(InternalBackdrop, {
          ref: store.context.internalBackdropRef,
          inert: inertValue(!open)
        }), props.children]
      })
    });
  });
  if (true) DialogPortal.displayName = "DialogPortal";

  // node_modules/@base-ui/react/esm/dialog/root/DialogRoot.js
  init_define_import_meta_env();
  var React56 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useOnFirstRender.js
  init_define_import_meta_env();
  var React50 = __toESM(require_react_shim(), 1);
  function useOnFirstRender(fn) {
    const ref = React50.useRef(true);
    if (ref.current) {
      ref.current = false;
      fn();
    }
  }

  // node_modules/@base-ui/react/esm/dialog/root/useDialogRoot.js
  init_define_import_meta_env();
  var React54 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useScrollLock.js
  init_define_import_meta_env();
  var originalHtmlStyles = {};
  var originalBodyStyles = {};
  var originalHtmlScrollBehavior = "";
  function hasInsetScrollbars(referenceElement) {
    if (typeof document === "undefined") {
      return false;
    }
    const doc = ownerDocument(referenceElement);
    const win = getWindow(doc);
    return win.innerWidth - doc.documentElement.clientWidth > 0;
  }
  function supportsStableScrollbarGutter(referenceElement) {
    const supported = typeof CSS !== "undefined" && CSS.supports && CSS.supports("scrollbar-gutter", "stable");
    if (!supported || typeof document === "undefined") {
      return false;
    }
    const doc = ownerDocument(referenceElement);
    const html = doc.documentElement;
    const body = doc.body;
    const scrollContainer = isOverflowElement(html) ? html : body;
    const originalScrollContainerOverflowY = scrollContainer.style.overflowY;
    const originalHtmlStyleGutter = html.style.scrollbarGutter;
    html.style.scrollbarGutter = "stable";
    scrollContainer.style.overflowY = "scroll";
    const before = scrollContainer.offsetWidth;
    scrollContainer.style.overflowY = "hidden";
    const after = scrollContainer.offsetWidth;
    scrollContainer.style.overflowY = originalScrollContainerOverflowY;
    html.style.scrollbarGutter = originalHtmlStyleGutter;
    return before === after;
  }
  function preventScrollOverlayScrollbars(referenceElement) {
    const doc = ownerDocument(referenceElement);
    const html = doc.documentElement;
    const body = doc.body;
    const elementToLock = isOverflowElement(html) ? html : body;
    const originalElementToLockStyles = {
      overflowY: elementToLock.style.overflowY,
      overflowX: elementToLock.style.overflowX
    };
    Object.assign(elementToLock.style, {
      overflowY: "hidden",
      overflowX: "hidden"
    });
    return () => {
      Object.assign(elementToLock.style, originalElementToLockStyles);
    };
  }
  function preventScrollInsetScrollbars(referenceElement) {
    const doc = ownerDocument(referenceElement);
    const html = doc.documentElement;
    const body = doc.body;
    const win = getWindow(html);
    let scrollTop = 0;
    let scrollLeft = 0;
    let updateGutterOnly = false;
    const resizeFrame = AnimationFrame.create();
    if (isWebKit2 && (win.visualViewport?.scale ?? 1) !== 1) {
      return () => {
      };
    }
    function lockScroll() {
      const htmlStyles = win.getComputedStyle(html);
      const bodyStyles = win.getComputedStyle(body);
      const htmlScrollbarGutterValue = htmlStyles.scrollbarGutter || "";
      const hasBothEdges = htmlScrollbarGutterValue.includes("both-edges");
      const scrollbarGutterValue = hasBothEdges ? "stable both-edges" : "stable";
      scrollTop = html.scrollTop;
      scrollLeft = html.scrollLeft;
      originalHtmlStyles = {
        scrollbarGutter: html.style.scrollbarGutter,
        overflowY: html.style.overflowY,
        overflowX: html.style.overflowX
      };
      originalHtmlScrollBehavior = html.style.scrollBehavior;
      originalBodyStyles = {
        position: body.style.position,
        height: body.style.height,
        width: body.style.width,
        boxSizing: body.style.boxSizing,
        overflowY: body.style.overflowY,
        overflowX: body.style.overflowX,
        scrollBehavior: body.style.scrollBehavior
      };
      const isScrollableY = html.scrollHeight > html.clientHeight;
      const isScrollableX = html.scrollWidth > html.clientWidth;
      const hasConstantOverflowY = htmlStyles.overflowY === "scroll" || bodyStyles.overflowY === "scroll";
      const hasConstantOverflowX = htmlStyles.overflowX === "scroll" || bodyStyles.overflowX === "scroll";
      const scrollbarWidth = Math.max(0, win.innerWidth - body.clientWidth);
      const scrollbarHeight = Math.max(0, win.innerHeight - body.clientHeight);
      const marginY = parseFloat(bodyStyles.marginTop) + parseFloat(bodyStyles.marginBottom);
      const marginX = parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight);
      const elementToLock = isOverflowElement(html) ? html : body;
      updateGutterOnly = supportsStableScrollbarGutter(referenceElement);
      if (updateGutterOnly) {
        html.style.scrollbarGutter = scrollbarGutterValue;
        elementToLock.style.overflowY = "hidden";
        elementToLock.style.overflowX = "hidden";
        return;
      }
      Object.assign(html.style, {
        scrollbarGutter: scrollbarGutterValue,
        overflowY: "hidden",
        overflowX: "hidden"
      });
      if (isScrollableY || hasConstantOverflowY) {
        html.style.overflowY = "scroll";
      }
      if (isScrollableX || hasConstantOverflowX) {
        html.style.overflowX = "scroll";
      }
      Object.assign(body.style, {
        position: "relative",
        height: marginY || scrollbarHeight ? `calc(100dvh - ${marginY + scrollbarHeight}px)` : "100dvh",
        width: marginX || scrollbarWidth ? `calc(100vw - ${marginX + scrollbarWidth}px)` : "100vw",
        boxSizing: "border-box",
        overflow: "hidden",
        scrollBehavior: "unset"
      });
      body.scrollTop = scrollTop;
      body.scrollLeft = scrollLeft;
      html.setAttribute("data-base-ui-scroll-locked", "");
      html.style.scrollBehavior = "unset";
    }
    function cleanup() {
      Object.assign(html.style, originalHtmlStyles);
      Object.assign(body.style, originalBodyStyles);
      if (!updateGutterOnly) {
        html.scrollTop = scrollTop;
        html.scrollLeft = scrollLeft;
        html.removeAttribute("data-base-ui-scroll-locked");
        html.style.scrollBehavior = originalHtmlScrollBehavior;
      }
    }
    function handleResize() {
      cleanup();
      resizeFrame.request(lockScroll);
    }
    lockScroll();
    win.addEventListener("resize", handleResize);
    return () => {
      resizeFrame.cancel();
      cleanup();
      if (typeof win.removeEventListener === "function") {
        win.removeEventListener("resize", handleResize);
      }
    };
  }
  var ScrollLocker = class {
    constructor() {
      __publicField(this, "lockCount", 0);
      __publicField(this, "restore", null);
      __publicField(this, "timeoutLock", Timeout.create());
      __publicField(this, "timeoutUnlock", Timeout.create());
      __publicField(this, "release", () => {
        this.lockCount -= 1;
        if (this.lockCount === 0 && this.restore) {
          this.timeoutUnlock.start(0, this.unlock);
        }
      });
      __publicField(this, "unlock", () => {
        if (this.lockCount === 0 && this.restore) {
          this.restore?.();
          this.restore = null;
        }
      });
    }
    acquire(referenceElement) {
      this.lockCount += 1;
      if (this.lockCount === 1 && this.restore === null) {
        this.timeoutLock.start(0, () => this.lock(referenceElement));
      }
      return this.release;
    }
    lock(referenceElement) {
      if (this.lockCount === 0 || this.restore !== null) {
        return;
      }
      const doc = ownerDocument(referenceElement);
      const html = doc.documentElement;
      const htmlOverflowY = getWindow(html).getComputedStyle(html).overflowY;
      if (htmlOverflowY === "hidden" || htmlOverflowY === "clip") {
        this.restore = NOOP;
        return;
      }
      const hasOverlayScrollbars = isIOS || !hasInsetScrollbars(referenceElement);
      this.restore = hasOverlayScrollbars ? preventScrollOverlayScrollbars(referenceElement) : preventScrollInsetScrollbars(referenceElement);
    }
  };
  var SCROLL_LOCKER = new ScrollLocker();
  function useScrollLock(enabled = true, referenceElement = null) {
    useIsoLayoutEffect(() => {
      if (!enabled) {
        return void 0;
      }
      return SCROLL_LOCKER.acquire(referenceElement);
    }, [enabled, referenceElement]);
  }

  // node_modules/@base-ui/react/esm/utils/useOpenInteractionType.js
  init_define_import_meta_env();
  var React53 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useEnhancedClickHandler.js
  init_define_import_meta_env();
  var React51 = __toESM(require_react_shim(), 1);
  function useEnhancedClickHandler(handler) {
    const lastClickInteractionTypeRef = React51.useRef("");
    const handlePointerDown = React51.useCallback((event) => {
      if (event.defaultPrevented) {
        return;
      }
      lastClickInteractionTypeRef.current = event.pointerType;
      handler(event, event.pointerType);
    }, [handler]);
    const handleClick = React51.useCallback((event) => {
      if (event.detail === 0) {
        handler(event, "keyboard");
        return;
      }
      if ("pointerType" in event) {
        handler(event, event.pointerType);
      } else {
        handler(event, lastClickInteractionTypeRef.current);
      }
      lastClickInteractionTypeRef.current = "";
    }, [handler]);
    return {
      onClick: handleClick,
      onPointerDown: handlePointerDown
    };
  }

  // node_modules/@base-ui/react/esm/utils/useValueChanged.js
  init_define_import_meta_env();
  var React52 = __toESM(require_react_shim(), 1);
  function useValueChanged(value, onChange) {
    const valueRef = React52.useRef(value);
    const onChangeCallback = useStableCallback(onChange);
    useIsoLayoutEffect(() => {
      if (valueRef.current === value) {
        return;
      }
      onChangeCallback(valueRef.current);
    }, [value, onChangeCallback]);
    useIsoLayoutEffect(() => {
      valueRef.current = value;
    }, [value]);
  }

  // node_modules/@base-ui/react/esm/utils/useOpenInteractionType.js
  function useOpenInteractionType(open) {
    const [openMethod, setOpenMethod] = React53.useState(null);
    const handleTriggerClick = useStableCallback((_, interactionType) => {
      if (!open) {
        setOpenMethod(interactionType || // On iOS Safari, the hitslop around touch targets means tapping outside an element's
        // bounds does not fire `pointerdown` but does fire `mousedown`. The `interactionType`
        // will be "" in that case.
        (isIOS ? "touch" : ""));
      }
    });
    useValueChanged(open, (previousOpen) => {
      if (previousOpen && !open) {
        setOpenMethod(null);
      }
    });
    const {
      onClick,
      onPointerDown
    } = useEnhancedClickHandler(handleTriggerClick);
    return React53.useMemo(() => ({
      openMethod,
      triggerProps: {
        onClick,
        onPointerDown
      }
    }), [openMethod, onClick, onPointerDown]);
  }

  // node_modules/@base-ui/react/esm/dialog/root/useDialogRoot.js
  function useDialogRoot(params) {
    const {
      store,
      parentContext,
      actionsRef
    } = params;
    const open = store.useState("open");
    const disablePointerDismissal = store.useState("disablePointerDismissal");
    const modal = store.useState("modal");
    const popupElement = store.useState("popupElement");
    const {
      openMethod,
      triggerProps
    } = useOpenInteractionType(open);
    useImplicitActiveTrigger(store);
    const {
      forceUnmount
    } = useOpenStateTransitions(open, store);
    const createDialogEventDetails = useStableCallback((reason) => {
      const details = createChangeEventDetails(reason);
      details.preventUnmountOnClose = () => {
        store.set("preventUnmountingOnClose", true);
      };
      return details;
    });
    const handleImperativeClose = React54.useCallback(() => {
      store.setOpen(false, createDialogEventDetails(reason_parts_exports.imperativeAction));
    }, [store, createDialogEventDetails]);
    React54.useImperativeHandle(actionsRef, () => ({
      unmount: forceUnmount,
      close: handleImperativeClose
    }), [forceUnmount, handleImperativeClose]);
    const floatingRootContext = useSyncedFloatingRootContext({
      popupStore: store,
      onOpenChange: store.setOpen,
      treatPopupAsFloatingElement: true,
      noEmit: true
    });
    const [ownNestedOpenDialogs, setOwnNestedOpenDialogs] = React54.useState(0);
    const isTopmost = ownNestedOpenDialogs === 0;
    const role = useRole(floatingRootContext);
    const dismiss = useDismiss(floatingRootContext, {
      outsidePressEvent() {
        if (store.context.internalBackdropRef.current || store.context.backdropRef.current) {
          return "intentional";
        }
        return {
          mouse: modal === "trap-focus" ? "sloppy" : "intentional",
          touch: "sloppy"
        };
      },
      outsidePress(event) {
        if (!store.context.outsidePressEnabledRef.current) {
          return false;
        }
        if ("button" in event && event.button !== 0) {
          return false;
        }
        if ("touches" in event && event.touches.length !== 1) {
          return false;
        }
        const target = getTarget(event);
        if (isTopmost && !disablePointerDismissal) {
          const eventTarget = target;
          if (modal) {
            return store.context.internalBackdropRef.current || store.context.backdropRef.current ? store.context.internalBackdropRef.current === eventTarget || store.context.backdropRef.current === eventTarget || contains(eventTarget, popupElement) && !eventTarget?.hasAttribute("data-base-ui-portal") : true;
          }
          return true;
        }
        return false;
      },
      escapeKey: isTopmost
    });
    useScrollLock(open && modal === true, popupElement);
    const {
      getReferenceProps,
      getFloatingProps,
      getTriggerProps
    } = useInteractions([role, dismiss]);
    store.useContextCallback("onNestedDialogOpen", (ownChildrenCount) => {
      setOwnNestedOpenDialogs(ownChildrenCount + 1);
    });
    store.useContextCallback("onNestedDialogClose", () => {
      setOwnNestedOpenDialogs(0);
    });
    React54.useEffect(() => {
      if (parentContext?.onNestedDialogOpen && open) {
        parentContext.onNestedDialogOpen(ownNestedOpenDialogs);
      }
      if (parentContext?.onNestedDialogClose && !open) {
        parentContext.onNestedDialogClose();
      }
      return () => {
        if (parentContext?.onNestedDialogClose && open) {
          parentContext.onNestedDialogClose();
        }
      };
    }, [open, parentContext, ownNestedOpenDialogs]);
    const activeTriggerProps = React54.useMemo(() => getReferenceProps(triggerProps), [getReferenceProps, triggerProps]);
    const inactiveTriggerProps = React54.useMemo(() => getTriggerProps(triggerProps), [getTriggerProps, triggerProps]);
    const popupProps = React54.useMemo(() => getFloatingProps(), [getFloatingProps]);
    store.useSyncedValues({
      openMethod,
      activeTriggerProps,
      inactiveTriggerProps,
      popupProps,
      floatingRootContext,
      nestedOpenDialogCount: ownNestedOpenDialogs
    });
  }

  // node_modules/@base-ui/react/esm/dialog/store/DialogStore.js
  init_define_import_meta_env();
  var React55 = __toESM(require_react_shim(), 1);
  var selectors2 = {
    ...popupStoreSelectors,
    modal: createSelector2((state) => state.modal),
    nested: createSelector2((state) => state.nested),
    nestedOpenDialogCount: createSelector2((state) => state.nestedOpenDialogCount),
    disablePointerDismissal: createSelector2((state) => state.disablePointerDismissal),
    openMethod: createSelector2((state) => state.openMethod),
    descriptionElementId: createSelector2((state) => state.descriptionElementId),
    titleElementId: createSelector2((state) => state.titleElementId),
    viewportElement: createSelector2((state) => state.viewportElement),
    role: createSelector2((state) => state.role)
  };
  var DialogStore = class extends ReactStore {
    constructor(initialState) {
      super(createInitialState(initialState), {
        popupRef: /* @__PURE__ */ React55.createRef(),
        backdropRef: /* @__PURE__ */ React55.createRef(),
        internalBackdropRef: /* @__PURE__ */ React55.createRef(),
        outsidePressEnabledRef: {
          current: true
        },
        triggerElements: new PopupTriggerMap(),
        onOpenChange: void 0,
        onOpenChangeComplete: void 0
      }, selectors2);
      __publicField(this, "setOpen", (nextOpen, eventDetails) => {
        eventDetails.preventUnmountOnClose = () => {
          this.set("preventUnmountingOnClose", true);
        };
        if (!nextOpen && eventDetails.trigger == null && this.state.activeTriggerId != null) {
          eventDetails.trigger = this.state.activeTriggerElement ?? void 0;
        }
        this.context.onOpenChange?.(nextOpen, eventDetails);
        if (eventDetails.isCanceled) {
          return;
        }
        const details = {
          open: nextOpen,
          nativeEvent: eventDetails.event,
          reason: eventDetails.reason,
          nested: this.state.nested
        };
        this.state.floatingRootContext.context.events?.emit("openchange", details);
        const updatedState = {
          open: nextOpen
        };
        const newTriggerId = eventDetails.trigger?.id ?? null;
        if (newTriggerId || nextOpen) {
          updatedState.activeTriggerId = newTriggerId;
          updatedState.activeTriggerElement = eventDetails.trigger ?? null;
        }
        this.update(updatedState);
      });
    }
  };
  function createInitialState(initialState = {}) {
    return {
      ...createInitialPopupStoreState(),
      modal: true,
      disablePointerDismissal: false,
      popupElement: null,
      viewportElement: null,
      descriptionElementId: void 0,
      titleElementId: void 0,
      openMethod: null,
      nested: false,
      nestedOpenDialogCount: 0,
      role: "dialog",
      ...initialState
    };
  }

  // node_modules/@base-ui/react/esm/dialog/root/DialogRoot.js
  var import_jsx_runtime13 = __toESM(require_react_shim(), 1);
  function DialogRoot(props) {
    const {
      children,
      open: openProp,
      defaultOpen = false,
      onOpenChange,
      onOpenChangeComplete,
      disablePointerDismissal = false,
      modal = true,
      actionsRef,
      handle,
      triggerId: triggerIdProp,
      defaultTriggerId: defaultTriggerIdProp = null
    } = props;
    const parentDialogRootContext = useDialogRootContext(true);
    const nested = Boolean(parentDialogRootContext);
    const store = useRefWithInit(() => {
      return handle?.store ?? new DialogStore({
        open: defaultOpen,
        openProp,
        activeTriggerId: defaultTriggerIdProp,
        triggerIdProp,
        modal,
        disablePointerDismissal,
        nested
      });
    }).current;
    useOnFirstRender(() => {
      if (openProp === void 0 && store.state.open === false && defaultOpen === true) {
        store.update({
          open: true,
          activeTriggerId: defaultTriggerIdProp
        });
      }
    });
    store.useControlledProp("openProp", openProp);
    store.useControlledProp("triggerIdProp", triggerIdProp);
    store.useSyncedValues({
      disablePointerDismissal,
      nested,
      modal
    });
    store.useContextCallback("onOpenChange", onOpenChange);
    store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
    const payload = store.useState("payload");
    useDialogRoot({
      store,
      actionsRef,
      parentContext: parentDialogRootContext?.store.context,
      onOpenChange,
      triggerIdProp
    });
    const contextValue = React56.useMemo(() => ({
      store
    }), [store]);
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(DialogRootContext.Provider, {
      value: contextValue,
      children: typeof children === "function" ? children({
        payload
      }) : children
    });
  }

  // node_modules/@base-ui/react/esm/dialog/viewport/DialogViewport.js
  init_define_import_meta_env();
  var React57 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/dialog/viewport/DialogViewportDataAttributes.js
  init_define_import_meta_env();
  var DialogViewportDataAttributes = (function(DialogViewportDataAttributes2) {
    DialogViewportDataAttributes2[DialogViewportDataAttributes2["open"] = CommonPopupDataAttributes.open] = "open";
    DialogViewportDataAttributes2[DialogViewportDataAttributes2["closed"] = CommonPopupDataAttributes.closed] = "closed";
    DialogViewportDataAttributes2[DialogViewportDataAttributes2["startingStyle"] = CommonPopupDataAttributes.startingStyle] = "startingStyle";
    DialogViewportDataAttributes2[DialogViewportDataAttributes2["endingStyle"] = CommonPopupDataAttributes.endingStyle] = "endingStyle";
    DialogViewportDataAttributes2["nested"] = "data-nested";
    DialogViewportDataAttributes2["nestedDialogOpen"] = "data-nested-dialog-open";
    return DialogViewportDataAttributes2;
  })({});

  // node_modules/@base-ui/react/esm/dialog/viewport/DialogViewport.js
  var stateAttributesMapping4 = {
    ...popupStateMapping,
    ...transitionStatusMapping,
    nested(value) {
      return value ? {
        [DialogViewportDataAttributes.nested]: ""
      } : null;
    },
    nestedDialogOpen(value) {
      return value ? {
        [DialogViewportDataAttributes.nestedDialogOpen]: ""
      } : null;
    }
  };
  var DialogViewport = /* @__PURE__ */ React57.forwardRef(function DialogViewport2(componentProps, forwardedRef) {
    const {
      className,
      render,
      children,
      ...elementProps
    } = componentProps;
    const keepMounted = useDialogPortalContext();
    const {
      store
    } = useDialogRootContext();
    const open = store.useState("open");
    const nested = store.useState("nested");
    const transitionStatus = store.useState("transitionStatus");
    const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
    const mounted = store.useState("mounted");
    const nestedDialogOpen = nestedOpenDialogCount > 0;
    const state = {
      open,
      nested,
      transitionStatus,
      nestedDialogOpen
    };
    const shouldRender = keepMounted || mounted;
    return useRenderElement("div", componentProps, {
      enabled: shouldRender,
      state,
      ref: [forwardedRef, store.useStateSetter("viewportElement")],
      stateAttributesMapping: stateAttributesMapping4,
      props: [{
        role: "presentation",
        hidden: !mounted,
        style: {
          pointerEvents: !open ? "none" : void 0
        },
        children
      }, elementProps]
    });
  });
  if (true) DialogViewport.displayName = "DialogViewport";

  // node_modules/@base-ui/react/esm/dialog/title/DialogTitle.js
  init_define_import_meta_env();
  var React58 = __toESM(require_react_shim(), 1);
  var DialogTitle = /* @__PURE__ */ React58.forwardRef(function DialogTitle2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useDialogRootContext();
    const id = useBaseUiId(idProp);
    store.useSyncedValueWithCleanup("titleElementId", id);
    return useRenderElement("h2", componentProps, {
      ref: forwardedRef,
      props: [{
        id
      }, elementProps]
    });
  });
  if (true) DialogTitle.displayName = "DialogTitle";

  // node_modules/@base-ui/react/esm/dialog/trigger/DialogTrigger.js
  init_define_import_meta_env();
  var React59 = __toESM(require_react_shim(), 1);
  var DialogTrigger = /* @__PURE__ */ React59.forwardRef(function DialogTrigger2(componentProps, forwardedRef) {
    const {
      render,
      className,
      disabled: disabled2 = false,
      nativeButton = true,
      id: idProp,
      payload,
      handle,
      ...elementProps
    } = componentProps;
    const dialogRootContext = useDialogRootContext(true);
    const store = handle?.store ?? dialogRootContext?.store;
    if (!store) {
      throw new Error(true ? "Base UI: <Dialog.Trigger> must be used within <Dialog.Root> or provided with a handle." : formatErrorMessage_default(79));
    }
    const thisTriggerId = useBaseUiId(idProp);
    const floatingContext = store.useState("floatingRootContext");
    const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
    const triggerElementRef = React59.useRef(null);
    const {
      registerTrigger,
      isMountedByThisTrigger
    } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
      payload
    });
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      native: nativeButton
    });
    const click = useClick(floatingContext, {
      enabled: floatingContext != null
    });
    const localInteractionProps = useInteractions([click]);
    const state = {
      disabled: disabled2,
      open: isOpenedByThisTrigger
    };
    const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
    return useRenderElement("button", componentProps, {
      state,
      ref: [buttonRef, forwardedRef, registerTrigger, triggerElementRef],
      props: [localInteractionProps.getReferenceProps(), rootTriggerProps, {
        [CLICK_TRIGGER_IDENTIFIER]: "",
        id: thisTriggerId
      }, elementProps, getButtonProps],
      stateAttributesMapping: triggerOpenStateMapping
    });
  });
  if (true) DialogTrigger.displayName = "DialogTrigger";

  // node_modules/@base-ui/react/esm/dialog/store/DialogHandle.js
  init_define_import_meta_env();
  var DialogHandle = class {
    /**
     * Internal store holding the dialog state.
     * @internal
     */
    constructor(store) {
      this.store = store ?? new DialogStore();
    }
    /**
     * Opens the dialog and associates it with the trigger with the given id.
     * The trigger, if provided, must be a Dialog.Trigger component with this handle passed as a prop.
     *
     * This method should only be called in an event handler or an effect (not during rendering).
     *
     * @param triggerId ID of the trigger to associate with the dialog. If null, the dialog will open without a trigger association.
     */
    open(triggerId) {
      const triggerElement = triggerId ? this.store.context.triggerElements.getById(triggerId) : void 0;
      if (true) {
        if (triggerId && !triggerElement) {
          console.warn(`Base UI: DialogHandle.open: No trigger found with id "${triggerId}". The dialog will open, but the trigger will not be associated with the dialog.`);
        }
      }
      this.store.setOpen(true, createChangeEventDetails(reason_parts_exports.imperativeAction, void 0, triggerElement));
    }
    /**
     * Opens the dialog and sets the payload.
     * Does not associate the dialog with any trigger.
     *
     * @param payload Payload to set when opening the dialog.
     */
    openWithPayload(payload) {
      this.store.set("payload", payload);
      this.store.setOpen(true, createChangeEventDetails(reason_parts_exports.imperativeAction, void 0, void 0));
    }
    /**
     * Closes the dialog.
     */
    close() {
      this.store.setOpen(false, createChangeEventDetails(reason_parts_exports.imperativeAction, void 0, void 0));
    }
    /**
     * Indicates whether the dialog is currently open.
     */
    get isOpen() {
      return this.store.state.open;
    }
  };
  function createDialogHandle() {
    return new DialogHandle();
  }

  // node_modules/lucide-react/dist/esm/lucide-react.js
  init_define_import_meta_env();

  // node_modules/lucide-react/dist/esm/createLucideIcon.js
  init_define_import_meta_env();
  var import_react4 = __toESM(require_react_shim());

  // node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.js
  init_define_import_meta_env();
  var mergeClasses = (...classes) => classes.filter((className, index2, array) => {
    return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index2;
  }).join(" ").trim();

  // node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.js
  init_define_import_meta_env();
  var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

  // node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.js
  init_define_import_meta_env();

  // node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.js
  init_define_import_meta_env();
  var toCamelCase = (string) => string.replace(
    /^([A-Z])|[\s-_]+(\w)/g,
    (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
  );

  // node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.js
  var toPascalCase = (string) => {
    const camelCase = toCamelCase(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
  };

  // node_modules/lucide-react/dist/esm/Icon.js
  init_define_import_meta_env();
  var import_react3 = __toESM(require_react_shim());

  // node_modules/lucide-react/dist/esm/defaultAttributes.js
  init_define_import_meta_env();
  var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  };

  // node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.js
  init_define_import_meta_env();
  var hasA11yProp = (props) => {
    for (const prop in props) {
      if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
        return true;
      }
    }
    return false;
  };

  // node_modules/lucide-react/dist/esm/Icon.js
  var Icon = (0, import_react3.forwardRef)(
    ({
      color = "currentColor",
      size: size4 = 24,
      strokeWidth = 2,
      absoluteStrokeWidth,
      className = "",
      children,
      iconNode,
      ...rest
    }, ref) => (0, import_react3.createElement)(
      "svg",
      {
        ref,
        ...defaultAttributes,
        width: size4,
        height: size4,
        stroke: color,
        strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size4) : strokeWidth,
        className: mergeClasses("lucide", className),
        ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
        ...rest
      },
      [
        ...iconNode.map(([tag, attrs]) => (0, import_react3.createElement)(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    )
  );

  // node_modules/lucide-react/dist/esm/createLucideIcon.js
  var createLucideIcon = (iconName, iconNode) => {
    const Component = (0, import_react4.forwardRef)(
      ({ className, ...props }, ref) => (0, import_react4.createElement)(Icon, {
        ref,
        iconNode,
        className: mergeClasses(
          `lucide-${toKebabCase(toPascalCase(iconName))}`,
          `lucide-${iconName}`,
          className
        ),
        ...props
      })
    );
    Component.displayName = toPascalCase(iconName);
    return Component;
  };

  // node_modules/lucide-react/dist/esm/icons/check.js
  init_define_import_meta_env();
  var __iconNode = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
  var Check = createLucideIcon("check", __iconNode);

  // node_modules/lucide-react/dist/esm/icons/chevron-down.js
  init_define_import_meta_env();
  var __iconNode2 = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
  var ChevronDown = createLucideIcon("chevron-down", __iconNode2);

  // node_modules/lucide-react/dist/esm/icons/chevron-right.js
  init_define_import_meta_env();
  var __iconNode3 = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]];
  var ChevronRight = createLucideIcon("chevron-right", __iconNode3);

  // node_modules/lucide-react/dist/esm/icons/chevron-up.js
  init_define_import_meta_env();
  var __iconNode4 = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
  var ChevronUp = createLucideIcon("chevron-up", __iconNode4);

  // node_modules/lucide-react/dist/esm/icons/panel-left.js
  init_define_import_meta_env();
  var __iconNode5 = [
    ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
    ["path", { d: "M9 3v18", key: "fh3hqa" }]
  ];
  var PanelLeft = createLucideIcon("panel-left", __iconNode5);

  // node_modules/lucide-react/dist/esm/icons/x.js
  init_define_import_meta_env();
  var __iconNode6 = [
    ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
    ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
  ];
  var X = createLucideIcon("x", __iconNode6);

  // src/components/ui/dialog.tsx
  var import_jsx_runtime14 = __toESM(require_react_shim(), 1);
  function Dialog({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(index_parts_exports2.Root, { "data-slot": "dialog", ...props });
  }
  function DialogTrigger3({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(index_parts_exports2.Trigger, { "data-slot": "dialog-trigger", ...props });
  }
  function DialogPortal3({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(index_parts_exports2.Portal, { "data-slot": "dialog-portal", ...props });
  }
  function DialogClose3({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(index_parts_exports2.Close, { "data-slot": "dialog-close", ...props });
  }
  function DialogOverlay({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      index_parts_exports2.Backdrop,
      {
        "data-slot": "dialog-overlay",
        className: cn(
          "fixed inset-0 isolate z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0",
          className
        ),
        ...props
      }
    );
  }
  function DialogContent({
    className,
    children,
    showCloseButton = true,
    ...props
  }) {
    const setsOwnWidth = typeof className === "string" && /(?:^|\s)(?:sm:|md:|lg:)?max-w-/.test(className);
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(DialogPortal3, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(DialogOverlay, {}),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(
        index_parts_exports2.Popup,
        {
          "data-slot": "dialog-content",
          className: cn(
            "fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-background p-4 text-sm ring-1 ring-foreground/10 duration-100 outline-none data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",
            !setsOwnWidth && "sm:max-w-sm",
            className
          ),
          ...props,
          children: [
            children,
            showCloseButton && /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(
              index_parts_exports2.Close,
              {
                "data-slot": "dialog-close",
                render: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
                  Button3,
                  {
                    variant: "ghost",
                    className: "absolute top-2 right-2",
                    size: "icon-sm"
                  }
                ),
                children: [
                  /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
                    X,
                    {}
                  ),
                  /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("span", { className: "sr-only", children: "Close" })
                ]
              }
            )
          ]
        }
      )
    ] });
  }
  function DialogHeader({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      "div",
      {
        "data-slot": "dialog-header",
        className: cn("flex flex-col gap-2", className),
        ...props
      }
    );
  }
  function DialogFooter({
    className,
    showCloseButton = false,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(
      "div",
      {
        "data-slot": "dialog-footer",
        className: cn(
          "-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 sm:flex-row sm:justify-end",
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(index_parts_exports2.Close, { render: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Button3, { variant: "outline" }), children: "Close" })
        ]
      }
    );
  }
  function DialogTitle3({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      index_parts_exports2.Title,
      {
        "data-slot": "dialog-title",
        className: cn("text-base leading-none font-medium", className),
        ...props
      }
    );
  }
  function DialogDescription3({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      index_parts_exports2.Description,
      {
        "data-slot": "dialog-description",
        className: cn(
          "text-sm text-muted-foreground *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/dropdown-menu.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/menu/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/menu/index.parts.js
  var index_parts_exports3 = {};
  __export(index_parts_exports3, {
    Arrow: () => MenuArrow,
    Backdrop: () => MenuBackdrop,
    CheckboxItem: () => MenuCheckboxItem,
    CheckboxItemIndicator: () => MenuCheckboxItemIndicator,
    Group: () => MenuGroup,
    GroupLabel: () => MenuGroupLabel,
    Handle: () => MenuHandle,
    Item: () => MenuItem,
    LinkItem: () => MenuLinkItem,
    Popup: () => MenuPopup,
    Portal: () => MenuPortal,
    Positioner: () => MenuPositioner,
    RadioGroup: () => MenuRadioGroup,
    RadioItem: () => MenuRadioItem,
    RadioItemIndicator: () => MenuRadioItemIndicator,
    Root: () => MenuRoot,
    Separator: () => Separator,
    SubmenuRoot: () => MenuSubmenuRoot,
    SubmenuTrigger: () => MenuSubmenuTrigger,
    Trigger: () => MenuTrigger,
    Viewport: () => MenuViewport,
    createHandle: () => createMenuHandle
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/menu/arrow/MenuArrow.js
  init_define_import_meta_env();
  var React62 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/positioner/MenuPositionerContext.js
  init_define_import_meta_env();
  var React60 = __toESM(require_react_shim(), 1);
  var MenuPositionerContext = /* @__PURE__ */ React60.createContext(void 0);
  if (true) MenuPositionerContext.displayName = "MenuPositionerContext";
  function useMenuPositionerContext(optional) {
    const context = React60.useContext(MenuPositionerContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: MenuPositionerContext is missing. MenuPositioner parts must be placed within <Menu.Positioner>." : formatErrorMessage_default(33));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/root/MenuRootContext.js
  init_define_import_meta_env();
  var React61 = __toESM(require_react_shim(), 1);
  var MenuRootContext = /* @__PURE__ */ React61.createContext(void 0);
  if (true) MenuRootContext.displayName = "MenuRootContext";
  function useMenuRootContext(optional) {
    const context = React61.useContext(MenuRootContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: MenuRootContext is missing. Menu parts must be placed within <Menu.Root>." : formatErrorMessage_default(36));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/arrow/MenuArrow.js
  var MenuArrow = /* @__PURE__ */ React62.forwardRef(function MenuArrow2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useMenuRootContext();
    const {
      arrowRef,
      side,
      align,
      arrowUncentered,
      arrowStyles
    } = useMenuPositionerContext();
    const open = store.useState("open");
    const state = {
      open,
      side,
      align,
      uncentered: arrowUncentered
    };
    return useRenderElement("div", componentProps, {
      ref: [arrowRef, forwardedRef],
      stateAttributesMapping: popupStateMapping,
      state,
      props: {
        style: arrowStyles,
        "aria-hidden": true,
        ...elementProps
      }
    });
  });
  if (true) MenuArrow.displayName = "MenuArrow";

  // node_modules/@base-ui/react/esm/menu/backdrop/MenuBackdrop.js
  init_define_import_meta_env();
  var React64 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/context-menu/root/ContextMenuRootContext.js
  init_define_import_meta_env();
  var React63 = __toESM(require_react_shim(), 1);
  var ContextMenuRootContext = /* @__PURE__ */ React63.createContext(void 0);
  if (true) ContextMenuRootContext.displayName = "ContextMenuRootContext";
  function useContextMenuRootContext(optional = true) {
    const context = React63.useContext(ContextMenuRootContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: ContextMenuRootContext is missing. ContextMenu parts must be placed within <ContextMenu.Root>." : formatErrorMessage_default(25));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/backdrop/MenuBackdrop.js
  var stateAttributesMapping5 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var MenuBackdrop = /* @__PURE__ */ React64.forwardRef(function MenuBackdrop2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useMenuRootContext();
    const open = store.useState("open");
    const mounted = store.useState("mounted");
    const transitionStatus = store.useState("transitionStatus");
    const lastOpenChangeReason = store.useState("lastOpenChangeReason");
    const contextMenuContext = useContextMenuRootContext();
    const state = {
      open,
      transitionStatus
    };
    return useRenderElement("div", componentProps, {
      ref: contextMenuContext?.backdropRef ? [forwardedRef, contextMenuContext.backdropRef] : forwardedRef,
      state,
      stateAttributesMapping: stateAttributesMapping5,
      props: [{
        role: "presentation",
        hidden: !mounted,
        style: {
          pointerEvents: lastOpenChangeReason === reason_parts_exports.triggerHover ? "none" : void 0,
          userSelect: "none",
          WebkitUserSelect: "none"
        }
      }, elementProps]
    });
  });
  if (true) MenuBackdrop.displayName = "MenuBackdrop";

  // node_modules/@base-ui/react/esm/menu/checkbox-item/MenuCheckboxItem.js
  init_define_import_meta_env();
  var React71 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/utils/esm/useControlled.js
  init_define_import_meta_env();
  var React65 = __toESM(require_react_shim(), 1);
  function useControlled({
    controlled,
    default: defaultProp,
    name,
    state = "value"
  }) {
    const {
      current: isControlled
    } = React65.useRef(controlled !== void 0);
    const [valueState, setValue] = React65.useState(defaultProp);
    const value = isControlled ? controlled : valueState;
    if (true) {
      React65.useEffect(() => {
        if (isControlled !== (controlled !== void 0)) {
          console.error([`Base UI: A component is changing the ${isControlled ? "" : "un"}controlled ${state} state of ${name} to be ${isControlled ? "un" : ""}controlled.`, "Elements should not switch from uncontrolled to controlled (or vice versa).", `Decide between using a controlled or uncontrolled ${name} element for the lifetime of the component.`, "The nature of the state is determined during the first render. It's considered controlled if the value is not `undefined`.", "More info: https://fb.me/react-controlled-components"].join("\n"));
        }
      }, [state, name, controlled]);
      const {
        current: defaultValue
      } = React65.useRef(defaultProp);
      React65.useEffect(() => {
        if (!isControlled && JSON.stringify(defaultValue) !== JSON.stringify(defaultProp)) {
          console.error([`Base UI: A component is changing the default ${state} state of an uncontrolled ${name} after being initialized. To suppress this warning opt to use a controlled ${name}.`].join("\n"));
        }
      }, [JSON.stringify(defaultProp)]);
    }
    const setValueIfUncontrolled = React65.useCallback((newValue) => {
      if (!isControlled) {
        setValue(newValue);
      }
    }, []);
    return [value, setValueIfUncontrolled];
  }

  // node_modules/@base-ui/react/esm/menu/checkbox-item/MenuCheckboxItemContext.js
  init_define_import_meta_env();
  var React66 = __toESM(require_react_shim(), 1);
  var MenuCheckboxItemContext = /* @__PURE__ */ React66.createContext(void 0);
  if (true) MenuCheckboxItemContext.displayName = "MenuCheckboxItemContext";
  function useMenuCheckboxItemContext() {
    const context = React66.useContext(MenuCheckboxItemContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: MenuCheckboxItemContext is missing. MenuCheckboxItem parts must be placed within <Menu.CheckboxItem>." : formatErrorMessage_default(30));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/item/useMenuItem.js
  init_define_import_meta_env();
  var React68 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/item/useMenuItemCommonProps.js
  init_define_import_meta_env();
  var React67 = __toESM(require_react_shim(), 1);
  function useMenuItemCommonProps(params) {
    const {
      closeOnClick,
      highlighted,
      id,
      nodeId,
      store,
      typingRef,
      itemRef,
      itemMetadata
    } = params;
    const {
      events: menuEvents
    } = store.useState("floatingTreeRoot");
    const contextMenuContext = useContextMenuRootContext(true);
    const isContextMenu = contextMenuContext !== void 0;
    return React67.useMemo(() => ({
      id,
      role: "menuitem",
      tabIndex: highlighted ? 0 : -1,
      onKeyDown(event) {
        if (event.key === " " && typingRef?.current) {
          event.preventDefault();
        }
      },
      onMouseMove(event) {
        if (!nodeId) {
          return;
        }
        menuEvents.emit("itemhover", {
          nodeId,
          target: event.currentTarget
        });
      },
      onClick(event) {
        if (closeOnClick) {
          menuEvents.emit("close", {
            domEvent: event,
            reason: reason_parts_exports.itemPress
          });
        }
      },
      onMouseUp(event) {
        if (contextMenuContext) {
          const initialCursorPoint = contextMenuContext.initialCursorPointRef.current;
          contextMenuContext.initialCursorPointRef.current = null;
          if (isContextMenu && initialCursorPoint && Math.abs(event.clientX - initialCursorPoint.x) <= 1 && Math.abs(event.clientY - initialCursorPoint.y) <= 1) {
            return;
          }
          if (isContextMenu && !isMac && event.button === 2) {
            return;
          }
        }
        if (itemRef.current && store.context.allowMouseUpTriggerRef.current && (!isContextMenu || event.button === 2)) {
          if (!itemMetadata || itemMetadata.type === "regular-item") {
            itemRef.current.click();
          }
        }
      }
    }), [closeOnClick, highlighted, id, menuEvents, nodeId, store, typingRef, itemRef, contextMenuContext, isContextMenu, itemMetadata]);
  }

  // node_modules/@base-ui/react/esm/menu/item/useMenuItem.js
  var REGULAR_ITEM = {
    type: "regular-item"
  };
  function useMenuItem(params) {
    const {
      closeOnClick,
      disabled: disabled2 = false,
      highlighted,
      id,
      store,
      typingRef = store.context.typingRef,
      nativeButton,
      itemMetadata,
      nodeId
    } = params;
    const itemRef = React68.useRef(null);
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      focusableWhenDisabled: true,
      native: nativeButton,
      composite: true
    });
    const commonProps = useMenuItemCommonProps({
      closeOnClick,
      highlighted,
      id,
      nodeId,
      store,
      typingRef,
      itemRef,
      itemMetadata
    });
    const getItemProps = React68.useCallback((externalProps) => {
      return mergeProps(commonProps, {
        onMouseEnter() {
          if (itemMetadata.type !== "submenu-trigger") {
            return;
          }
          itemMetadata.setActive();
        }
      }, externalProps, getButtonProps);
    }, [commonProps, getButtonProps, itemMetadata]);
    const mergedRef = useMergedRefs(itemRef, buttonRef);
    return React68.useMemo(() => ({
      getItemProps,
      itemRef: mergedRef
    }), [getItemProps, mergedRef]);
  }

  // node_modules/@base-ui/react/esm/composite/list/useCompositeListItem.js
  init_define_import_meta_env();
  var React70 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/composite/list/CompositeListContext.js
  init_define_import_meta_env();
  var React69 = __toESM(require_react_shim(), 1);
  var CompositeListContext = /* @__PURE__ */ React69.createContext({
    register: () => {
    },
    unregister: () => {
    },
    subscribeMapChange: () => {
      return () => {
      };
    },
    elementsRef: {
      current: []
    },
    nextIndexRef: {
      current: 0
    }
  });
  if (true) CompositeListContext.displayName = "CompositeListContext";
  function useCompositeListContext() {
    return React69.useContext(CompositeListContext);
  }

  // node_modules/@base-ui/react/esm/composite/list/useCompositeListItem.js
  var IndexGuessBehavior = /* @__PURE__ */ (function(IndexGuessBehavior2) {
    IndexGuessBehavior2[IndexGuessBehavior2["None"] = 0] = "None";
    IndexGuessBehavior2[IndexGuessBehavior2["GuessFromOrder"] = 1] = "GuessFromOrder";
    return IndexGuessBehavior2;
  })({});
  function useCompositeListItem(params = {}) {
    const {
      label,
      metadata,
      textRef,
      indexGuessBehavior,
      index: externalIndex
    } = params;
    const {
      register: register2,
      unregister,
      subscribeMapChange,
      elementsRef,
      labelsRef,
      nextIndexRef
    } = useCompositeListContext();
    const indexRef = React70.useRef(-1);
    const [index2, setIndex] = React70.useState(externalIndex ?? (indexGuessBehavior === IndexGuessBehavior.GuessFromOrder ? () => {
      if (indexRef.current === -1) {
        const newIndex = nextIndexRef.current;
        nextIndexRef.current += 1;
        indexRef.current = newIndex;
      }
      return indexRef.current;
    } : -1));
    const componentRef = React70.useRef(null);
    const ref = React70.useCallback((node) => {
      componentRef.current = node;
      if (index2 !== -1 && node !== null) {
        elementsRef.current[index2] = node;
        if (labelsRef) {
          const isLabelDefined = label !== void 0;
          labelsRef.current[index2] = isLabelDefined ? label : textRef?.current?.textContent ?? node.textContent;
        }
      }
    }, [index2, elementsRef, labelsRef, label, textRef]);
    useIsoLayoutEffect(() => {
      if (externalIndex != null) {
        return void 0;
      }
      const node = componentRef.current;
      if (node) {
        register2(node, metadata);
        return () => {
          unregister(node);
        };
      }
      return void 0;
    }, [externalIndex, register2, unregister, metadata]);
    useIsoLayoutEffect(() => {
      if (externalIndex != null) {
        return void 0;
      }
      return subscribeMapChange((map) => {
        const i = componentRef.current ? map.get(componentRef.current)?.index : null;
        if (i != null) {
          setIndex(i);
        }
      });
    }, [externalIndex, subscribeMapChange, setIndex]);
    return React70.useMemo(() => ({
      ref,
      index: index2
    }), [index2, ref]);
  }

  // node_modules/@base-ui/react/esm/menu/utils/stateAttributesMapping.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/menu/checkbox-item/MenuCheckboxItemDataAttributes.js
  init_define_import_meta_env();
  var MenuCheckboxItemDataAttributes = /* @__PURE__ */ (function(MenuCheckboxItemDataAttributes2) {
    MenuCheckboxItemDataAttributes2["checked"] = "data-checked";
    MenuCheckboxItemDataAttributes2["unchecked"] = "data-unchecked";
    MenuCheckboxItemDataAttributes2["disabled"] = "data-disabled";
    MenuCheckboxItemDataAttributes2["highlighted"] = "data-highlighted";
    return MenuCheckboxItemDataAttributes2;
  })({});

  // node_modules/@base-ui/react/esm/menu/utils/stateAttributesMapping.js
  var itemMapping = {
    checked(value) {
      if (value) {
        return {
          [MenuCheckboxItemDataAttributes.checked]: ""
        };
      }
      return {
        [MenuCheckboxItemDataAttributes.unchecked]: ""
      };
    },
    ...transitionStatusMapping
  };

  // node_modules/@base-ui/react/esm/menu/checkbox-item/MenuCheckboxItem.js
  var import_jsx_runtime15 = __toESM(require_react_shim(), 1);
  var MenuCheckboxItem = /* @__PURE__ */ React71.forwardRef(function MenuCheckboxItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      label,
      nativeButton = false,
      disabled: disabled2 = false,
      closeOnClick = false,
      checked: checkedProp,
      defaultChecked,
      onCheckedChange,
      ...elementProps
    } = componentProps;
    const listItem = useCompositeListItem({
      label
    });
    const menuPositionerContext = useMenuPositionerContext(true);
    const id = useBaseUiId(idProp);
    const {
      store
    } = useMenuRootContext();
    const highlighted = store.useState("isActive", listItem.index);
    const itemProps = store.useState("itemProps");
    const [checked, setChecked] = useControlled({
      controlled: checkedProp,
      default: defaultChecked ?? false,
      name: "MenuCheckboxItem",
      state: "checked"
    });
    const {
      getItemProps,
      itemRef
    } = useMenuItem({
      closeOnClick,
      disabled: disabled2,
      highlighted,
      id,
      store,
      nativeButton,
      nodeId: menuPositionerContext?.nodeId,
      itemMetadata: REGULAR_ITEM
    });
    const state = React71.useMemo(() => ({
      disabled: disabled2,
      highlighted,
      checked
    }), [disabled2, highlighted, checked]);
    const handleClick = useStableCallback((event) => {
      const details = {
        ...createChangeEventDetails(reason_parts_exports.itemPress, event.nativeEvent),
        preventUnmountOnClose: () => {
        }
      };
      onCheckedChange?.(!checked, details);
      if (details.isCanceled) {
        return;
      }
      setChecked((currentlyChecked) => !currentlyChecked);
    });
    const element = useRenderElement("div", componentProps, {
      state,
      stateAttributesMapping: itemMapping,
      props: [itemProps, {
        role: "menuitemcheckbox",
        "aria-checked": checked,
        onClick: handleClick
      }, elementProps, getItemProps],
      ref: [itemRef, forwardedRef, listItem.ref]
    });
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(MenuCheckboxItemContext.Provider, {
      value: state,
      children: element
    });
  });
  if (true) MenuCheckboxItem.displayName = "MenuCheckboxItem";

  // node_modules/@base-ui/react/esm/menu/checkbox-item-indicator/MenuCheckboxItemIndicator.js
  init_define_import_meta_env();
  var React72 = __toESM(require_react_shim(), 1);
  var MenuCheckboxItemIndicator = /* @__PURE__ */ React72.forwardRef(function MenuCheckboxItemIndicator2(componentProps, forwardedRef) {
    const {
      render,
      className,
      keepMounted = false,
      ...elementProps
    } = componentProps;
    const item = useMenuCheckboxItemContext();
    const indicatorRef = React72.useRef(null);
    const {
      transitionStatus,
      setMounted
    } = useTransitionStatus(item.checked);
    useOpenChangeComplete({
      open: item.checked,
      ref: indicatorRef,
      onComplete() {
        if (!item.checked) {
          setMounted(false);
        }
      }
    });
    const state = {
      checked: item.checked,
      disabled: item.disabled,
      highlighted: item.highlighted,
      transitionStatus
    };
    const element = useRenderElement("span", componentProps, {
      state,
      ref: [forwardedRef, indicatorRef],
      stateAttributesMapping: itemMapping,
      props: {
        "aria-hidden": true,
        ...elementProps
      },
      enabled: keepMounted || item.checked
    });
    return element;
  });
  if (true) MenuCheckboxItemIndicator.displayName = "MenuCheckboxItemIndicator";

  // node_modules/@base-ui/react/esm/menu/group/MenuGroup.js
  init_define_import_meta_env();
  var React74 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/group/MenuGroupContext.js
  init_define_import_meta_env();
  var React73 = __toESM(require_react_shim(), 1);
  var MenuGroupContext = /* @__PURE__ */ React73.createContext(void 0);
  if (true) MenuGroupContext.displayName = "MenuGroupContext";
  function useMenuGroupRootContext() {
    const context = React73.useContext(MenuGroupContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: MenuGroupRootContext is missing. Menu group parts must be used within <Menu.Group>." : formatErrorMessage_default(31));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/group/MenuGroup.js
  var import_jsx_runtime16 = __toESM(require_react_shim(), 1);
  var MenuGroup = /* @__PURE__ */ React74.forwardRef(function MenuGroup2(componentProps, forwardedRef) {
    const {
      render,
      className,
      ...elementProps
    } = componentProps;
    const [labelId, setLabelId] = React74.useState(void 0);
    const context = React74.useMemo(() => ({
      setLabelId
    }), [setLabelId]);
    const element = useRenderElement("div", componentProps, {
      ref: forwardedRef,
      props: {
        role: "group",
        "aria-labelledby": labelId,
        ...elementProps
      }
    });
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(MenuGroupContext.Provider, {
      value: context,
      children: element
    });
  });
  if (true) MenuGroup.displayName = "MenuGroup";

  // node_modules/@base-ui/react/esm/menu/group-label/MenuGroupLabel.js
  init_define_import_meta_env();
  var React75 = __toESM(require_react_shim(), 1);
  var MenuGroupLabel = /* @__PURE__ */ React75.forwardRef(function MenuGroupLabelComponent(componentProps, forwardedRef) {
    const {
      className,
      render,
      id: idProp,
      ...elementProps
    } = componentProps;
    const id = useBaseUiId(idProp);
    const {
      setLabelId
    } = useMenuGroupRootContext();
    useIsoLayoutEffect(() => {
      setLabelId(id);
      return () => {
        setLabelId(void 0);
      };
    }, [setLabelId, id]);
    return useRenderElement("div", componentProps, {
      ref: forwardedRef,
      props: {
        id,
        role: "presentation",
        ...elementProps
      }
    });
  });
  if (true) MenuGroupLabel.displayName = "MenuGroupLabel";

  // node_modules/@base-ui/react/esm/menu/item/MenuItem.js
  init_define_import_meta_env();
  var React76 = __toESM(require_react_shim(), 1);
  var MenuItem = /* @__PURE__ */ React76.forwardRef(function MenuItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      label,
      nativeButton = false,
      disabled: disabled2 = false,
      closeOnClick = true,
      ...elementProps
    } = componentProps;
    const listItem = useCompositeListItem({
      label
    });
    const menuPositionerContext = useMenuPositionerContext(true);
    const id = useBaseUiId(idProp);
    const {
      store
    } = useMenuRootContext();
    const highlighted = store.useState("isActive", listItem.index);
    const itemProps = store.useState("itemProps");
    const {
      getItemProps,
      itemRef
    } = useMenuItem({
      closeOnClick,
      disabled: disabled2,
      highlighted,
      id,
      store,
      nativeButton,
      nodeId: menuPositionerContext?.nodeId,
      itemMetadata: REGULAR_ITEM
    });
    const state = {
      disabled: disabled2,
      highlighted
    };
    return useRenderElement("div", componentProps, {
      state,
      props: [itemProps, elementProps, getItemProps],
      ref: [itemRef, forwardedRef, listItem.ref]
    });
  });
  if (true) MenuItem.displayName = "MenuItem";

  // node_modules/@base-ui/react/esm/menu/link-item/MenuLinkItem.js
  init_define_import_meta_env();
  var React77 = __toESM(require_react_shim(), 1);
  var MenuLinkItem = /* @__PURE__ */ React77.forwardRef(function MenuLinkItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      label,
      closeOnClick = false,
      ...elementProps
    } = componentProps;
    const linkRef = React77.useRef(null);
    const listItem = useCompositeListItem({
      label
    });
    const menuPositionerContext = useMenuPositionerContext(true);
    const nodeId = menuPositionerContext?.nodeId;
    const id = useBaseUiId(idProp);
    const {
      store
    } = useMenuRootContext();
    const highlighted = store.useState("isActive", listItem.index);
    const itemProps = store.useState("itemProps");
    const typingRef = store.context.typingRef;
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      native: false,
      composite: true
    });
    const commonProps = useMenuItemCommonProps({
      closeOnClick,
      highlighted,
      id,
      nodeId,
      store,
      typingRef,
      itemRef: linkRef
    });
    function getItemProps(externalProps) {
      return mergeProps(commonProps, externalProps, getButtonProps);
    }
    const state = React77.useMemo(() => ({
      highlighted
    }), [highlighted]);
    return useRenderElement("a", componentProps, {
      state,
      props: [itemProps, elementProps, getItemProps],
      ref: [linkRef, buttonRef, forwardedRef, listItem.ref]
    });
  });
  if (true) MenuLinkItem.displayName = "MenuLinkItem";

  // node_modules/@base-ui/react/esm/menu/popup/MenuPopup.js
  init_define_import_meta_env();
  var React79 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/toolbar/root/ToolbarRootContext.js
  init_define_import_meta_env();
  var React78 = __toESM(require_react_shim(), 1);
  var ToolbarRootContext = /* @__PURE__ */ React78.createContext(void 0);
  if (true) ToolbarRootContext.displayName = "ToolbarRootContext";
  function useToolbarRootContext(optional) {
    const context = React78.useContext(ToolbarRootContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: ToolbarRootContext is missing. Toolbar parts must be placed within <Toolbar.Root>." : formatErrorMessage_default(69));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/utils/getDisabledMountTransitionStyles.js
  init_define_import_meta_env();
  function getDisabledMountTransitionStyles(transitionStatus) {
    return transitionStatus === "starting" ? DISABLED_TRANSITIONS_STYLE : EMPTY_OBJECT;
  }

  // node_modules/@base-ui/react/esm/menu/popup/MenuPopup.js
  var import_jsx_runtime17 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping6 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var MenuPopup = /* @__PURE__ */ React79.forwardRef(function MenuPopup2(componentProps, forwardedRef) {
    const {
      render,
      className,
      finalFocus,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useMenuRootContext();
    const {
      side,
      align
    } = useMenuPositionerContext();
    const insideToolbar = useToolbarRootContext(true) != null;
    const open = store.useState("open");
    const transitionStatus = store.useState("transitionStatus");
    const popupProps = store.useState("popupProps");
    const mounted = store.useState("mounted");
    const instantType = store.useState("instantType");
    const triggerElement = store.useState("activeTriggerElement");
    const parent = store.useState("parent");
    const lastOpenChangeReason = store.useState("lastOpenChangeReason");
    const rootId = store.useState("rootId");
    const floatingContext = store.useState("floatingRootContext");
    const floatingTreeRoot = store.useState("floatingTreeRoot");
    const closeDelay = store.useState("closeDelay");
    const activeTriggerElement = store.useState("activeTriggerElement");
    const isContextMenu = parent.type === "context-menu";
    useOpenChangeComplete({
      open,
      ref: store.context.popupRef,
      onComplete() {
        if (open) {
          store.context.onOpenChangeComplete?.(true);
        }
      }
    });
    React79.useEffect(() => {
      function handleClose(event) {
        store.setOpen(false, createChangeEventDetails(event.reason, event.domEvent));
      }
      floatingTreeRoot.events.on("close", handleClose);
      return () => {
        floatingTreeRoot.events.off("close", handleClose);
      };
    }, [floatingTreeRoot.events, store]);
    const hoverEnabled = store.useState("hoverEnabled");
    const disabled2 = store.useState("disabled");
    useHoverFloatingInteraction(floatingContext, {
      enabled: hoverEnabled && !disabled2 && !isContextMenu && parent.type !== "menubar",
      closeDelay
    });
    const state = {
      transitionStatus,
      side,
      align,
      open,
      nested: parent.type === "menu",
      instant: instantType
    };
    const setPopupElement = React79.useCallback((element2) => {
      store.set("popupElement", element2);
    }, [store]);
    const element = useRenderElement("div", componentProps, {
      state,
      ref: [forwardedRef, store.context.popupRef, setPopupElement],
      stateAttributesMapping: stateAttributesMapping6,
      props: [popupProps, {
        onKeyDown(event) {
          if (insideToolbar && COMPOSITE_KEYS.has(event.key)) {
            event.stopPropagation();
          }
        }
      }, getDisabledMountTransitionStyles(transitionStatus), elementProps, {
        "data-rootownerid": rootId
      }]
    });
    let returnFocus = parent.type === void 0 || isContextMenu;
    if (triggerElement || parent.type === "menubar" && lastOpenChangeReason !== reason_parts_exports.outsidePress) {
      returnFocus = true;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(FloatingFocusManager, {
      context: floatingContext,
      modal: isContextMenu,
      disabled: !mounted,
      returnFocus: finalFocus === void 0 ? returnFocus : finalFocus,
      initialFocus: parent.type !== "menu",
      restoreFocus: true,
      externalTree: parent.type !== "menubar" ? floatingTreeRoot : void 0,
      previousFocusableElement: activeTriggerElement,
      nextFocusableElement: parent.type === void 0 ? store.context.triggerFocusTargetRef : void 0,
      beforeContentFocusGuardRef: parent.type === void 0 ? store.context.beforeContentFocusGuardRef : void 0,
      children: element
    });
  });
  if (true) MenuPopup.displayName = "MenuPopup";

  // node_modules/@base-ui/react/esm/menu/portal/MenuPortal.js
  init_define_import_meta_env();
  var React81 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/portal/MenuPortalContext.js
  init_define_import_meta_env();
  var React80 = __toESM(require_react_shim(), 1);
  var MenuPortalContext = /* @__PURE__ */ React80.createContext(void 0);
  if (true) MenuPortalContext.displayName = "MenuPortalContext";
  function useMenuPortalContext() {
    const value = React80.useContext(MenuPortalContext);
    if (value === void 0) {
      throw new Error(true ? "Base UI: <Menu.Portal> is missing." : formatErrorMessage_default(32));
    }
    return value;
  }

  // node_modules/@base-ui/react/esm/menu/portal/MenuPortal.js
  var import_jsx_runtime18 = __toESM(require_react_shim(), 1);
  var MenuPortal = /* @__PURE__ */ React81.forwardRef(function MenuPortal2(props, forwardedRef) {
    const {
      keepMounted = false,
      ...portalProps
    } = props;
    const {
      store
    } = useMenuRootContext();
    const mounted = store.useState("mounted");
    const shouldRender = mounted || keepMounted;
    if (!shouldRender) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(MenuPortalContext.Provider, {
      value: keepMounted,
      children: /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(FloatingPortal, {
        ref: forwardedRef,
        ...portalProps
      })
    });
  });
  if (true) MenuPortal.displayName = "MenuPortal";

  // node_modules/@base-ui/react/esm/menu/positioner/MenuPositioner.js
  init_define_import_meta_env();
  var React85 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/useAnchorPositioning.js
  init_define_import_meta_env();
  var React83 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/direction-provider/DirectionContext.js
  init_define_import_meta_env();
  var React82 = __toESM(require_react_shim(), 1);
  var DirectionContext = /* @__PURE__ */ React82.createContext(void 0);
  if (true) DirectionContext.displayName = "DirectionContext";
  function useDirection() {
    const context = React82.useContext(DirectionContext);
    return context?.direction ?? "ltr";
  }

  // node_modules/@base-ui/react/esm/floating-ui-react/middleware/arrow.js
  init_define_import_meta_env();
  var baseArrow = (options) => ({
    name: "arrow",
    options,
    async fn(state) {
      const {
        x,
        y,
        placement,
        rects,
        platform: platform3,
        elements,
        middlewareData
      } = state;
      const {
        element,
        padding = 0,
        offsetParent = "real"
      } = evaluate(options, state) || {};
      if (element == null) {
        return {};
      }
      const paddingObject = getPaddingObject(padding);
      const coords = {
        x,
        y
      };
      const axis = getAlignmentAxis(placement);
      const length = getAxisLength(axis);
      const arrowDimensions = await platform3.getDimensions(element);
      const isYAxis = axis === "y";
      const minProp = isYAxis ? "top" : "left";
      const maxProp = isYAxis ? "bottom" : "right";
      const clientProp = isYAxis ? "clientHeight" : "clientWidth";
      const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
      const startDiff = coords[axis] - rects.reference[axis];
      const arrowOffsetParent = offsetParent === "real" ? await platform3.getOffsetParent?.(element) : elements.floating;
      let clientSize = elements.floating[clientProp] || rects.floating[length];
      if (!clientSize || !await platform3.isElement?.(arrowOffsetParent)) {
        clientSize = elements.floating[clientProp] || rects.floating[length];
      }
      const centerToReference = endDiff / 2 - startDiff / 2;
      const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
      const minPadding = Math.min(paddingObject[minProp], largestPossiblePadding);
      const maxPadding = Math.min(paddingObject[maxProp], largestPossiblePadding);
      const min2 = minPadding;
      const max2 = clientSize - arrowDimensions[length] - maxPadding;
      const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
      const offset4 = clamp(min2, center, max2);
      const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset4 && rects.reference[length] / 2 - (center < min2 ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
      const alignmentOffset = shouldAddOffset ? center < min2 ? center - min2 : center - max2 : 0;
      return {
        [axis]: coords[axis] + alignmentOffset,
        data: {
          [axis]: offset4,
          centerOffset: center - offset4 - alignmentOffset,
          ...shouldAddOffset && {
            alignmentOffset
          }
        },
        reset: shouldAddOffset
      };
    }
  });
  var arrow4 = (options, deps) => ({
    ...baseArrow(options),
    options: [options, deps]
  });

  // node_modules/@base-ui/react/esm/utils/hideMiddleware.js
  init_define_import_meta_env();
  var hide4 = {
    name: "hide",
    async fn(state) {
      const {
        width,
        height,
        x,
        y
      } = state.rects.reference;
      const anchorHidden = width === 0 && height === 0 && x === 0 && y === 0;
      const nativeHideResult = await hide3().fn(state);
      return {
        data: {
          referenceHidden: nativeHideResult.data?.referenceHidden || anchorHidden
        }
      };
    }
  };

  // node_modules/@base-ui/react/esm/utils/adaptiveOriginMiddleware.js
  init_define_import_meta_env();
  var DEFAULT_SIDES = {
    sideX: "left",
    sideY: "top"
  };
  var adaptiveOrigin = {
    name: "adaptiveOrigin",
    async fn(state) {
      const {
        x: rawX,
        y: rawY,
        rects: {
          floating: floatRect
        },
        elements: {
          floating
        },
        platform: platform3,
        strategy,
        placement
      } = state;
      const win = getWindow(floating);
      const styles = win.getComputedStyle(floating);
      const hasTransition = styles.transitionDuration !== "0s" && styles.transitionDuration !== "";
      if (!hasTransition) {
        return {
          x: rawX,
          y: rawY,
          data: DEFAULT_SIDES
        };
      }
      const offsetParent = await platform3.getOffsetParent?.(floating);
      let offsetDimensions = {
        width: 0,
        height: 0
      };
      if (strategy === "fixed" && win?.visualViewport) {
        offsetDimensions = {
          width: win.visualViewport.width,
          height: win.visualViewport.height
        };
      } else if (offsetParent === win) {
        const doc = ownerDocument(floating);
        offsetDimensions = {
          width: doc.documentElement.clientWidth,
          height: doc.documentElement.clientHeight
        };
      } else if (await platform3.isElement?.(offsetParent)) {
        offsetDimensions = await platform3.getDimensions(offsetParent);
      }
      const currentSide = getSide(placement);
      let x = rawX;
      let y = rawY;
      if (currentSide === "left") {
        x = offsetDimensions.width - (rawX + floatRect.width);
      }
      if (currentSide === "top") {
        y = offsetDimensions.height - (rawY + floatRect.height);
      }
      const sideX = currentSide === "left" ? "right" : DEFAULT_SIDES.sideX;
      const sideY = currentSide === "top" ? "bottom" : DEFAULT_SIDES.sideY;
      return {
        x,
        y,
        data: {
          sideX,
          sideY
        }
      };
    }
  };

  // node_modules/@base-ui/react/esm/utils/useAnchorPositioning.js
  function getLogicalSide(sideParam, renderedSide, isRtl) {
    const isLogicalSideParam = sideParam === "inline-start" || sideParam === "inline-end";
    const logicalRight = isRtl ? "inline-start" : "inline-end";
    const logicalLeft = isRtl ? "inline-end" : "inline-start";
    return {
      top: "top",
      right: isLogicalSideParam ? logicalRight : "right",
      bottom: "bottom",
      left: isLogicalSideParam ? logicalLeft : "left"
    }[renderedSide];
  }
  function getOffsetData(state, sideParam, isRtl) {
    const {
      rects,
      placement
    } = state;
    const data = {
      side: getLogicalSide(sideParam, getSide(placement), isRtl),
      align: getAlignment(placement) || "center",
      anchor: {
        width: rects.reference.width,
        height: rects.reference.height
      },
      positioner: {
        width: rects.floating.width,
        height: rects.floating.height
      }
    };
    return data;
  }
  function useAnchorPositioning(params) {
    const {
      // Public parameters
      anchor,
      positionMethod = "absolute",
      side: sideParam = "bottom",
      sideOffset = 0,
      align = "center",
      alignOffset = 0,
      collisionBoundary,
      collisionPadding: collisionPaddingParam = 5,
      sticky = false,
      arrowPadding = 5,
      disableAnchorTracking = false,
      // Private parameters
      keepMounted = false,
      floatingRootContext,
      mounted,
      collisionAvoidance,
      shiftCrossAxis = false,
      nodeId,
      adaptiveOrigin: adaptiveOrigin2,
      lazyFlip = false,
      externalTree
    } = params;
    const [mountSide, setMountSide] = React83.useState(null);
    if (!mounted && mountSide !== null) {
      setMountSide(null);
    }
    const collisionAvoidanceSide = collisionAvoidance.side || "flip";
    const collisionAvoidanceAlign = collisionAvoidance.align || "flip";
    const collisionAvoidanceFallbackAxisSide = collisionAvoidance.fallbackAxisSide || "end";
    const anchorFn = typeof anchor === "function" ? anchor : void 0;
    const anchorFnCallback = useStableCallback(anchorFn);
    const anchorDep = anchorFn ? anchorFnCallback : anchor;
    const anchorValueRef = useValueAsRef(anchor);
    const direction = useDirection();
    const isRtl = direction === "rtl";
    const side = mountSide || {
      top: "top",
      right: "right",
      bottom: "bottom",
      left: "left",
      "inline-end": isRtl ? "left" : "right",
      "inline-start": isRtl ? "right" : "left"
    }[sideParam];
    const placement = align === "center" ? side : `${side}-${align}`;
    let collisionPadding = collisionPaddingParam;
    const bias = 1;
    const biasTop = sideParam === "bottom" ? bias : 0;
    const biasBottom = sideParam === "top" ? bias : 0;
    const biasLeft = sideParam === "right" ? bias : 0;
    const biasRight = sideParam === "left" ? bias : 0;
    if (typeof collisionPadding === "number") {
      collisionPadding = {
        top: collisionPadding + biasTop,
        right: collisionPadding + biasRight,
        bottom: collisionPadding + biasBottom,
        left: collisionPadding + biasLeft
      };
    } else if (collisionPadding) {
      collisionPadding = {
        top: (collisionPadding.top || 0) + biasTop,
        right: (collisionPadding.right || 0) + biasRight,
        bottom: (collisionPadding.bottom || 0) + biasBottom,
        left: (collisionPadding.left || 0) + biasLeft
      };
    }
    const commonCollisionProps = {
      boundary: collisionBoundary === "clipping-ancestors" ? "clippingAncestors" : collisionBoundary,
      padding: collisionPadding
    };
    const arrowRef = React83.useRef(null);
    const sideOffsetRef = useValueAsRef(sideOffset);
    const alignOffsetRef = useValueAsRef(alignOffset);
    const sideOffsetDep = typeof sideOffset !== "function" ? sideOffset : 0;
    const alignOffsetDep = typeof alignOffset !== "function" ? alignOffset : 0;
    const middleware = [offset3((state) => {
      const data = getOffsetData(state, sideParam, isRtl);
      const sideAxis = typeof sideOffsetRef.current === "function" ? sideOffsetRef.current(data) : sideOffsetRef.current;
      const alignAxis = typeof alignOffsetRef.current === "function" ? alignOffsetRef.current(data) : alignOffsetRef.current;
      return {
        mainAxis: sideAxis,
        crossAxis: alignAxis,
        alignmentAxis: alignAxis
      };
    }, [sideOffsetDep, alignOffsetDep, isRtl, sideParam])];
    const shiftDisabled = collisionAvoidanceAlign === "none" && collisionAvoidanceSide !== "shift";
    const crossAxisShiftEnabled = !shiftDisabled && (sticky || shiftCrossAxis || collisionAvoidanceSide === "shift");
    const flipMiddleware = collisionAvoidanceSide === "none" ? null : flip3({
      ...commonCollisionProps,
      // Ensure the popup flips if it's been limited by its --available-height and it resizes.
      // Since the size() padding is smaller than the flip() padding, flip() will take precedence.
      padding: {
        top: collisionPadding.top + bias,
        right: collisionPadding.right + bias,
        bottom: collisionPadding.bottom + bias,
        left: collisionPadding.left + bias
      },
      mainAxis: !shiftCrossAxis && collisionAvoidanceSide === "flip",
      crossAxis: collisionAvoidanceAlign === "flip" ? "alignment" : false,
      fallbackAxisSideDirection: collisionAvoidanceFallbackAxisSide
    });
    const shiftMiddleware = shiftDisabled ? null : shift3((data) => {
      const html = ownerDocument(data.elements.floating).documentElement;
      return {
        ...commonCollisionProps,
        // Use the Layout Viewport to avoid shifting around when pinch-zooming
        // for context menus.
        rootBoundary: shiftCrossAxis ? {
          x: 0,
          y: 0,
          width: html.clientWidth,
          height: html.clientHeight
        } : void 0,
        mainAxis: collisionAvoidanceAlign !== "none",
        crossAxis: crossAxisShiftEnabled,
        limiter: sticky || shiftCrossAxis ? void 0 : limitShift3((limitData) => {
          if (!arrowRef.current) {
            return {};
          }
          const {
            width,
            height
          } = arrowRef.current.getBoundingClientRect();
          const sideAxis = getSideAxis(getSide(limitData.placement));
          const arrowSize = sideAxis === "y" ? width : height;
          const offsetAmount = sideAxis === "y" ? collisionPadding.left + collisionPadding.right : collisionPadding.top + collisionPadding.bottom;
          return {
            offset: arrowSize / 2 + offsetAmount / 2
          };
        })
      };
    }, [commonCollisionProps, sticky, shiftCrossAxis, collisionPadding, collisionAvoidanceAlign]);
    if (collisionAvoidanceSide === "shift" || collisionAvoidanceAlign === "shift" || align === "center") {
      middleware.push(shiftMiddleware, flipMiddleware);
    } else {
      middleware.push(flipMiddleware, shiftMiddleware);
    }
    middleware.push(size3({
      ...commonCollisionProps,
      apply({
        elements: {
          floating
        },
        availableWidth,
        availableHeight,
        rects
      }) {
        const floatingStyle = floating.style;
        floatingStyle.setProperty("--available-width", `${availableWidth}px`);
        floatingStyle.setProperty("--available-height", `${availableHeight}px`);
        const dpr = window.devicePixelRatio || 1;
        const {
          x: x2,
          y: y2,
          width,
          height
        } = rects.reference;
        const anchorWidth = (Math.round((x2 + width) * dpr) - Math.round(x2 * dpr)) / dpr;
        const anchorHeight = (Math.round((y2 + height) * dpr) - Math.round(y2 * dpr)) / dpr;
        floatingStyle.setProperty("--anchor-width", `${anchorWidth}px`);
        floatingStyle.setProperty("--anchor-height", `${anchorHeight}px`);
      }
    }), arrow4(() => ({
      // `transform-origin` calculations rely on an element existing. If the arrow hasn't been set,
      // we'll create a fake element.
      element: arrowRef.current || document.createElement("div"),
      padding: arrowPadding,
      offsetParent: "floating"
    }), [arrowPadding]), {
      name: "transformOrigin",
      fn(state) {
        const {
          elements: elements2,
          middlewareData: middlewareData2,
          placement: renderedPlacement2,
          rects,
          y: y2
        } = state;
        const currentRenderedSide = getSide(renderedPlacement2);
        const currentRenderedAxis = getSideAxis(currentRenderedSide);
        const arrowEl = arrowRef.current;
        const arrowX = middlewareData2.arrow?.x || 0;
        const arrowY = middlewareData2.arrow?.y || 0;
        const arrowWidth = arrowEl?.clientWidth || 0;
        const arrowHeight = arrowEl?.clientHeight || 0;
        const transformX = arrowX + arrowWidth / 2;
        const transformY = arrowY + arrowHeight / 2;
        const shiftY = Math.abs(middlewareData2.shift?.y || 0);
        const halfAnchorHeight = rects.reference.height / 2;
        const sideOffsetValue = typeof sideOffset === "function" ? sideOffset(getOffsetData(state, sideParam, isRtl)) : sideOffset;
        const isOverlappingAnchor = shiftY > sideOffsetValue;
        const adjacentTransformOrigin = {
          top: `${transformX}px calc(100% + ${sideOffsetValue}px)`,
          bottom: `${transformX}px ${-sideOffsetValue}px`,
          left: `calc(100% + ${sideOffsetValue}px) ${transformY}px`,
          right: `${-sideOffsetValue}px ${transformY}px`
        }[currentRenderedSide];
        const overlapTransformOrigin = `${transformX}px ${rects.reference.y + halfAnchorHeight - y2}px`;
        elements2.floating.style.setProperty("--transform-origin", crossAxisShiftEnabled && currentRenderedAxis === "y" && isOverlappingAnchor ? overlapTransformOrigin : adjacentTransformOrigin);
        return {};
      }
    }, hide4, adaptiveOrigin2);
    useIsoLayoutEffect(() => {
      if (!mounted && floatingRootContext) {
        floatingRootContext.update({
          referenceElement: null,
          floatingElement: null,
          domReferenceElement: null
        });
      }
    }, [mounted, floatingRootContext]);
    const autoUpdateOptions = React83.useMemo(() => ({
      elementResize: !disableAnchorTracking && typeof ResizeObserver !== "undefined",
      layoutShift: !disableAnchorTracking && typeof IntersectionObserver !== "undefined"
    }), [disableAnchorTracking]);
    const {
      refs,
      elements,
      x,
      y,
      middlewareData,
      update: update2,
      placement: renderedPlacement,
      context,
      isPositioned,
      floatingStyles: originalFloatingStyles
    } = useFloating2({
      rootContext: floatingRootContext,
      placement,
      middleware,
      strategy: positionMethod,
      whileElementsMounted: keepMounted ? void 0 : (...args) => autoUpdate(...args, autoUpdateOptions),
      nodeId,
      externalTree
    });
    const {
      sideX,
      sideY
    } = middlewareData.adaptiveOrigin || DEFAULT_SIDES;
    const resolvedPosition = isPositioned ? positionMethod : "fixed";
    const floatingStyles = React83.useMemo(() => {
      const base = adaptiveOrigin2 ? {
        position: resolvedPosition,
        [sideX]: x,
        [sideY]: y
      } : {
        position: resolvedPosition,
        ...originalFloatingStyles
      };
      if (!isPositioned) {
        base.opacity = 0;
      }
      return base;
    }, [adaptiveOrigin2, resolvedPosition, sideX, x, sideY, y, originalFloatingStyles, isPositioned]);
    const registeredPositionReferenceRef = React83.useRef(null);
    useIsoLayoutEffect(() => {
      if (!mounted) {
        return;
      }
      const anchorValue = anchorValueRef.current;
      const resolvedAnchor = typeof anchorValue === "function" ? anchorValue() : anchorValue;
      const unwrappedElement = (isRef(resolvedAnchor) ? resolvedAnchor.current : resolvedAnchor) || null;
      const finalAnchor = unwrappedElement || null;
      if (finalAnchor !== registeredPositionReferenceRef.current) {
        refs.setPositionReference(finalAnchor);
        registeredPositionReferenceRef.current = finalAnchor;
      }
    }, [mounted, refs, anchorDep, anchorValueRef]);
    React83.useEffect(() => {
      if (!mounted) {
        return;
      }
      const anchorValue = anchorValueRef.current;
      if (typeof anchorValue === "function") {
        return;
      }
      if (isRef(anchorValue) && anchorValue.current !== registeredPositionReferenceRef.current) {
        refs.setPositionReference(anchorValue.current);
        registeredPositionReferenceRef.current = anchorValue.current;
      }
    }, [mounted, refs, anchorDep, anchorValueRef]);
    React83.useEffect(() => {
      if (keepMounted && mounted && elements.domReference && elements.floating) {
        return autoUpdate(elements.domReference, elements.floating, update2, autoUpdateOptions);
      }
      return void 0;
    }, [keepMounted, mounted, elements, update2, autoUpdateOptions]);
    const renderedSide = getSide(renderedPlacement);
    const logicalRenderedSide = getLogicalSide(sideParam, renderedSide, isRtl);
    const renderedAlign = getAlignment(renderedPlacement) || "center";
    const anchorHidden = Boolean(middlewareData.hide?.referenceHidden);
    useIsoLayoutEffect(() => {
      if (lazyFlip && mounted && isPositioned) {
        setMountSide(renderedSide);
      }
    }, [lazyFlip, mounted, isPositioned, renderedSide]);
    const arrowStyles = React83.useMemo(() => ({
      position: "absolute",
      top: middlewareData.arrow?.y,
      left: middlewareData.arrow?.x
    }), [middlewareData.arrow]);
    const arrowUncentered = middlewareData.arrow?.centerOffset !== 0;
    return React83.useMemo(() => ({
      positionerStyles: floatingStyles,
      arrowStyles,
      arrowRef,
      arrowUncentered,
      side: logicalRenderedSide,
      align: renderedAlign,
      physicalSide: renderedSide,
      anchorHidden,
      refs,
      context,
      isPositioned,
      update: update2
    }), [floatingStyles, arrowStyles, arrowRef, arrowUncentered, logicalRenderedSide, renderedAlign, renderedSide, anchorHidden, refs, context, isPositioned, update2]);
  }
  function isRef(param) {
    return param != null && "current" in param;
  }

  // node_modules/@base-ui/react/esm/composite/list/CompositeList.js
  init_define_import_meta_env();
  var React84 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime19 = __toESM(require_react_shim(), 1);
  function CompositeList(props) {
    const {
      children,
      elementsRef,
      labelsRef,
      onMapChange: onMapChangeProp
    } = props;
    const onMapChange = useStableCallback(onMapChangeProp);
    const nextIndexRef = React84.useRef(0);
    const listeners = useRefWithInit(createListeners).current;
    const map = useRefWithInit(createMap).current;
    const [mapTick, setMapTick] = React84.useState(0);
    const lastTickRef = React84.useRef(mapTick);
    const register2 = useStableCallback((node, metadata) => {
      map.set(node, metadata ?? null);
      lastTickRef.current += 1;
      setMapTick(lastTickRef.current);
    });
    const unregister = useStableCallback((node) => {
      map.delete(node);
      lastTickRef.current += 1;
      setMapTick(lastTickRef.current);
    });
    const sortedMap = React84.useMemo(() => {
      disableEslintWarning(mapTick);
      const newMap = /* @__PURE__ */ new Map();
      const sortedNodes = Array.from(map.keys()).filter((node) => node.isConnected).sort(sortByDocumentPosition);
      sortedNodes.forEach((node, index2) => {
        const metadata = map.get(node) ?? {};
        newMap.set(node, {
          ...metadata,
          index: index2
        });
      });
      return newMap;
    }, [map, mapTick]);
    useIsoLayoutEffect(() => {
      if (typeof MutationObserver !== "function" || sortedMap.size === 0) {
        return void 0;
      }
      const mutationObserver = new MutationObserver((entries) => {
        const diff = /* @__PURE__ */ new Set();
        const updateDiff = (node) => diff.has(node) ? diff.delete(node) : diff.add(node);
        entries.forEach((entry) => {
          entry.removedNodes.forEach(updateDiff);
          entry.addedNodes.forEach(updateDiff);
        });
        if (diff.size === 0) {
          lastTickRef.current += 1;
          setMapTick(lastTickRef.current);
        }
      });
      sortedMap.forEach((_, node) => {
        if (node.parentElement) {
          mutationObserver.observe(node.parentElement, {
            childList: true
          });
        }
      });
      return () => {
        mutationObserver.disconnect();
      };
    }, [sortedMap]);
    useIsoLayoutEffect(() => {
      const shouldUpdateLengths = lastTickRef.current === mapTick;
      if (shouldUpdateLengths) {
        if (elementsRef.current.length !== sortedMap.size) {
          elementsRef.current.length = sortedMap.size;
        }
        if (labelsRef && labelsRef.current.length !== sortedMap.size) {
          labelsRef.current.length = sortedMap.size;
        }
        nextIndexRef.current = sortedMap.size;
      }
      onMapChange(sortedMap);
    }, [onMapChange, sortedMap, elementsRef, labelsRef, mapTick]);
    useIsoLayoutEffect(() => {
      return () => {
        elementsRef.current = [];
      };
    }, [elementsRef]);
    useIsoLayoutEffect(() => {
      return () => {
        if (labelsRef) {
          labelsRef.current = [];
        }
      };
    }, [labelsRef]);
    const subscribeMapChange = useStableCallback((fn) => {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    });
    useIsoLayoutEffect(() => {
      listeners.forEach((l) => l(sortedMap));
    }, [listeners, sortedMap]);
    const contextValue = React84.useMemo(() => ({
      register: register2,
      unregister,
      subscribeMapChange,
      elementsRef,
      labelsRef,
      nextIndexRef
    }), [register2, unregister, subscribeMapChange, elementsRef, labelsRef, nextIndexRef]);
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(CompositeListContext.Provider, {
      value: contextValue,
      children
    });
  }
  function createMap() {
    return /* @__PURE__ */ new Map();
  }
  function createListeners() {
    return /* @__PURE__ */ new Set();
  }
  function sortByDocumentPosition(a, b) {
    const position = a.compareDocumentPosition(b);
    if (position & Node.DOCUMENT_POSITION_FOLLOWING || position & Node.DOCUMENT_POSITION_CONTAINED_BY) {
      return -1;
    }
    if (position & Node.DOCUMENT_POSITION_PRECEDING || position & Node.DOCUMENT_POSITION_CONTAINS) {
      return 1;
    }
    return 0;
  }
  function disableEslintWarning(_) {
  }

  // node_modules/@base-ui/react/esm/menu/positioner/MenuPositioner.js
  var import_jsx_runtime20 = __toESM(require_react_shim(), 1);
  var MenuPositioner = /* @__PURE__ */ React85.forwardRef(function MenuPositioner2(componentProps, forwardedRef) {
    const {
      anchor: anchorProp,
      positionMethod: positionMethodProp = "absolute",
      className,
      render,
      side,
      align: alignProp,
      sideOffset: sideOffsetProp = 0,
      alignOffset: alignOffsetProp = 0,
      collisionBoundary = "clipping-ancestors",
      collisionPadding = 5,
      arrowPadding = 5,
      sticky = false,
      disableAnchorTracking = false,
      collisionAvoidance: collisionAvoidanceProp = DROPDOWN_COLLISION_AVOIDANCE,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useMenuRootContext();
    const keepMounted = useMenuPortalContext();
    const contextMenuContext = useContextMenuRootContext(true);
    const parent = store.useState("parent");
    const floatingRootContext = store.useState("floatingRootContext");
    const floatingTreeRoot = store.useState("floatingTreeRoot");
    const mounted = store.useState("mounted");
    const open = store.useState("open");
    const modal = store.useState("modal");
    const triggerElement = store.useState("activeTriggerElement");
    const transitionStatus = store.useState("transitionStatus");
    const positionerElement = store.useState("positionerElement");
    const instantType = store.useState("instantType");
    const hasViewport = store.useState("hasViewport");
    const lastOpenChangeReason = store.useState("lastOpenChangeReason");
    const floatingNodeId = store.useState("floatingNodeId");
    const floatingParentNodeId = store.useState("floatingParentNodeId");
    const domReference = floatingRootContext.useState("domReferenceElement");
    const previousTriggerRef = React85.useRef(null);
    const runOnceAnimationsFinish = useAnimationsFinished(positionerElement, false, false);
    let anchor = anchorProp;
    let sideOffset = sideOffsetProp;
    let alignOffset = alignOffsetProp;
    let align = alignProp;
    let collisionAvoidance = collisionAvoidanceProp;
    if (parent.type === "context-menu") {
      anchor = anchorProp ?? parent.context?.anchor;
      align = align ?? "start";
      if (!side && align !== "center") {
        alignOffset = componentProps.alignOffset ?? 2;
        sideOffset = componentProps.sideOffset ?? -5;
      }
    }
    let computedSide = side;
    let computedAlign = align;
    if (parent.type === "menu") {
      computedSide = computedSide ?? "inline-end";
      computedAlign = computedAlign ?? "start";
      collisionAvoidance = componentProps.collisionAvoidance ?? POPUP_COLLISION_AVOIDANCE;
    } else if (parent.type === "menubar") {
      computedSide = computedSide ?? "bottom";
      computedAlign = computedAlign ?? "start";
    }
    const contextMenu = parent.type === "context-menu";
    const positioner = useAnchorPositioning({
      anchor,
      floatingRootContext,
      positionMethod: contextMenuContext ? "fixed" : positionMethodProp,
      mounted,
      side: computedSide,
      sideOffset,
      align: computedAlign,
      alignOffset,
      arrowPadding: contextMenu ? 0 : arrowPadding,
      collisionBoundary,
      collisionPadding,
      sticky,
      nodeId: floatingNodeId,
      keepMounted,
      disableAnchorTracking,
      collisionAvoidance,
      shiftCrossAxis: contextMenu && !("side" in collisionAvoidance && collisionAvoidance.side === "flip"),
      externalTree: floatingTreeRoot,
      adaptiveOrigin: hasViewport ? adaptiveOrigin : void 0
    });
    const positionerProps = React85.useMemo(() => {
      const hiddenStyles = {};
      if (!open) {
        hiddenStyles.pointerEvents = "none";
      }
      return {
        role: "presentation",
        hidden: !mounted,
        style: {
          ...positioner.positionerStyles,
          ...hiddenStyles
        }
      };
    }, [open, mounted, positioner.positionerStyles]);
    React85.useEffect(() => {
      function onMenuOpenChange(details) {
        if (details.open) {
          if (details.parentNodeId === floatingNodeId) {
            store.set("hoverEnabled", false);
          }
          if (details.nodeId !== floatingNodeId && details.parentNodeId === store.select("floatingParentNodeId")) {
            store.setOpen(false, createChangeEventDetails(reason_parts_exports.siblingOpen));
          }
        }
      }
      floatingTreeRoot.events.on("menuopenchange", onMenuOpenChange);
      return () => {
        floatingTreeRoot.events.off("menuopenchange", onMenuOpenChange);
      };
    }, [store, floatingTreeRoot.events, floatingNodeId]);
    React85.useEffect(() => {
      if (store.select("floatingParentNodeId") == null) {
        return void 0;
      }
      function onParentClose(details) {
        if (details.open || details.nodeId !== store.select("floatingParentNodeId")) {
          return;
        }
        const reason = details.reason ?? reason_parts_exports.siblingOpen;
        store.setOpen(false, createChangeEventDetails(reason));
      }
      floatingTreeRoot.events.on("menuopenchange", onParentClose);
      return () => {
        floatingTreeRoot.events.off("menuopenchange", onParentClose);
      };
    }, [floatingTreeRoot.events, store]);
    const closeTimeout = useTimeout();
    React85.useEffect(() => {
      if (!open) {
        closeTimeout.clear();
      }
    }, [open, closeTimeout]);
    React85.useEffect(() => {
      function onItemHover(event) {
        if (!open || event.nodeId !== store.select("floatingParentNodeId")) {
          return;
        }
        if (event.target && triggerElement && triggerElement !== event.target) {
          const delay = store.select("closeDelay");
          if (delay > 0) {
            if (!closeTimeout.isStarted()) {
              closeTimeout.start(delay, () => {
                store.setOpen(false, createChangeEventDetails(reason_parts_exports.siblingOpen));
              });
            }
          } else {
            store.setOpen(false, createChangeEventDetails(reason_parts_exports.siblingOpen));
          }
        } else {
          closeTimeout.clear();
        }
      }
      floatingTreeRoot.events.on("itemhover", onItemHover);
      return () => {
        floatingTreeRoot.events.off("itemhover", onItemHover);
      };
    }, [floatingTreeRoot.events, open, triggerElement, store, closeTimeout]);
    React85.useEffect(() => {
      const eventDetails = {
        open,
        nodeId: floatingNodeId,
        parentNodeId: floatingParentNodeId,
        reason: store.select("lastOpenChangeReason")
      };
      floatingTreeRoot.events.emit("menuopenchange", eventDetails);
    }, [floatingTreeRoot.events, open, store, floatingNodeId, floatingParentNodeId]);
    useIsoLayoutEffect(() => {
      const currentTrigger = domReference;
      const previousTrigger = previousTriggerRef.current;
      if (currentTrigger) {
        previousTriggerRef.current = currentTrigger;
      }
      if (previousTrigger && currentTrigger && currentTrigger !== previousTrigger) {
        store.set("instantType", void 0);
        const abortController = new AbortController();
        runOnceAnimationsFinish(() => {
          store.set("instantType", "trigger-change");
        }, abortController.signal);
        return () => {
          abortController.abort();
        };
      }
      return void 0;
    }, [domReference, runOnceAnimationsFinish, store]);
    const state = {
      open,
      side: positioner.side,
      align: positioner.align,
      anchorHidden: positioner.anchorHidden,
      nested: parent.type === "menu",
      instant: instantType
    };
    const contextValue = React85.useMemo(() => ({
      side: positioner.side,
      align: positioner.align,
      arrowRef: positioner.arrowRef,
      arrowUncentered: positioner.arrowUncentered,
      arrowStyles: positioner.arrowStyles,
      nodeId: positioner.context.nodeId
    }), [positioner.side, positioner.align, positioner.arrowRef, positioner.arrowUncentered, positioner.arrowStyles, positioner.context.nodeId]);
    const element = useRenderElement("div", componentProps, {
      state,
      stateAttributesMapping: popupStateMapping,
      ref: [forwardedRef, store.useStateSetter("positionerElement")],
      props: [positionerProps, getDisabledMountTransitionStyles(transitionStatus), elementProps]
    });
    const shouldRenderBackdrop = mounted && parent.type !== "menu" && (parent.type !== "menubar" && modal && lastOpenChangeReason !== reason_parts_exports.triggerHover || parent.type === "menubar" && parent.context.modal);
    let backdropCutout = null;
    if (parent.type === "menubar") {
      backdropCutout = parent.context.contentElement;
    } else if (parent.type === void 0) {
      backdropCutout = triggerElement;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(MenuPositionerContext.Provider, {
      value: contextValue,
      children: [shouldRenderBackdrop && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(InternalBackdrop, {
        ref: parent.type === "context-menu" || parent.type === "nested-context-menu" ? parent.context.internalBackdropRef : null,
        inert: inertValue(!open),
        cutout: backdropCutout
      }), /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(FloatingNode, {
        id: floatingNodeId,
        children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(CompositeList, {
          elementsRef: store.context.itemDomElements,
          labelsRef: store.context.itemLabels,
          children: element
        })
      })]
    });
  });
  if (true) MenuPositioner.displayName = "MenuPositioner";

  // node_modules/@base-ui/react/esm/menu/radio-group/MenuRadioGroup.js
  init_define_import_meta_env();
  var React87 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/radio-group/MenuRadioGroupContext.js
  init_define_import_meta_env();
  var React86 = __toESM(require_react_shim(), 1);
  var MenuRadioGroupContext = /* @__PURE__ */ React86.createContext(void 0);
  if (true) MenuRadioGroupContext.displayName = "MenuRadioGroupContext";
  function useMenuRadioGroupContext() {
    const context = React86.useContext(MenuRadioGroupContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: MenuRadioGroupContext is missing. MenuRadioGroup parts must be placed within <Menu.RadioGroup>." : formatErrorMessage_default(34));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/radio-group/MenuRadioGroup.js
  var import_jsx_runtime21 = __toESM(require_react_shim(), 1);
  var MenuRadioGroup = /* @__PURE__ */ React87.memo(/* @__PURE__ */ React87.forwardRef(function MenuRadioGroup2(componentProps, forwardedRef) {
    const {
      render,
      className,
      value: valueProp,
      defaultValue,
      onValueChange: onValueChangeProp,
      disabled: disabled2 = false,
      ...elementProps
    } = componentProps;
    const [value, setValueUnwrapped] = useControlled({
      controlled: valueProp,
      default: defaultValue,
      name: "MenuRadioGroup"
    });
    const onValueChange = useStableCallback(onValueChangeProp);
    const setValue = useStableCallback((newValue, eventDetails) => {
      onValueChange?.(newValue, eventDetails);
      if (eventDetails.isCanceled) {
        return;
      }
      setValueUnwrapped(newValue);
    });
    const state = {
      disabled: disabled2
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: forwardedRef,
      props: {
        role: "group",
        "aria-disabled": disabled2 || void 0,
        ...elementProps
      }
    });
    const context = React87.useMemo(() => ({
      value,
      setValue,
      disabled: disabled2
    }), [value, setValue, disabled2]);
    return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(MenuRadioGroupContext.Provider, {
      value: context,
      children: element
    });
  }));
  if (true) MenuRadioGroup.displayName = "MenuRadioGroup";

  // node_modules/@base-ui/react/esm/menu/radio-item/MenuRadioItem.js
  init_define_import_meta_env();
  var React89 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menu/radio-item/MenuRadioItemContext.js
  init_define_import_meta_env();
  var React88 = __toESM(require_react_shim(), 1);
  var MenuRadioItemContext = /* @__PURE__ */ React88.createContext(void 0);
  if (true) MenuRadioItemContext.displayName = "MenuRadioItemContext";
  function useMenuRadioItemContext() {
    const context = React88.useContext(MenuRadioItemContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: MenuRadioItemContext is missing. MenuRadioItem parts must be placed within <Menu.RadioItem>." : formatErrorMessage_default(35));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/radio-item/MenuRadioItem.js
  var import_jsx_runtime22 = __toESM(require_react_shim(), 1);
  var MenuRadioItem = /* @__PURE__ */ React89.forwardRef(function MenuRadioItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      label,
      nativeButton = false,
      disabled: disabledProp = false,
      closeOnClick = false,
      value,
      ...elementProps
    } = componentProps;
    const listItem = useCompositeListItem({
      label
    });
    const menuPositionerContext = useMenuPositionerContext(true);
    const id = useBaseUiId(idProp);
    const {
      store
    } = useMenuRootContext();
    const highlighted = store.useState("isActive", listItem.index);
    const itemProps = store.useState("itemProps");
    const {
      value: selectedValue,
      setValue: setSelectedValue,
      disabled: groupDisabled
    } = useMenuRadioGroupContext();
    const disabled2 = groupDisabled || disabledProp;
    const checked = selectedValue === value;
    const {
      getItemProps,
      itemRef
    } = useMenuItem({
      closeOnClick,
      disabled: disabled2,
      highlighted,
      id,
      store,
      nativeButton,
      nodeId: menuPositionerContext?.nodeId,
      itemMetadata: REGULAR_ITEM
    });
    const state = React89.useMemo(() => ({
      disabled: disabled2,
      highlighted,
      checked
    }), [disabled2, highlighted, checked]);
    const handleClick = useStableCallback((event) => {
      const details = {
        ...createChangeEventDetails(reason_parts_exports.itemPress, event.nativeEvent),
        preventUnmountOnClose: () => {
        }
      };
      setSelectedValue(value, details);
    });
    const element = useRenderElement("div", componentProps, {
      state,
      stateAttributesMapping: itemMapping,
      props: [itemProps, {
        role: "menuitemradio",
        "aria-checked": checked,
        onClick: handleClick
      }, elementProps, getItemProps],
      ref: [itemRef, forwardedRef, listItem.ref]
    });
    return /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(MenuRadioItemContext.Provider, {
      value: state,
      children: element
    });
  });
  if (true) MenuRadioItem.displayName = "MenuRadioItem";

  // node_modules/@base-ui/react/esm/menu/radio-item-indicator/MenuRadioItemIndicator.js
  init_define_import_meta_env();
  var React90 = __toESM(require_react_shim(), 1);
  var MenuRadioItemIndicator = /* @__PURE__ */ React90.forwardRef(function MenuRadioItemIndicator2(componentProps, forwardedRef) {
    const {
      render,
      className,
      keepMounted = false,
      ...elementProps
    } = componentProps;
    const item = useMenuRadioItemContext();
    const indicatorRef = React90.useRef(null);
    const {
      transitionStatus,
      setMounted
    } = useTransitionStatus(item.checked);
    useOpenChangeComplete({
      open: item.checked,
      ref: indicatorRef,
      onComplete() {
        if (!item.checked) {
          setMounted(false);
        }
      }
    });
    const state = {
      checked: item.checked,
      disabled: item.disabled,
      highlighted: item.highlighted,
      transitionStatus
    };
    const element = useRenderElement("span", componentProps, {
      state,
      stateAttributesMapping: itemMapping,
      ref: [forwardedRef, indicatorRef],
      props: {
        "aria-hidden": true,
        ...elementProps
      },
      enabled: keepMounted || item.checked
    });
    return element;
  });
  if (true) MenuRadioItemIndicator.displayName = "MenuRadioItemIndicator";

  // node_modules/@base-ui/react/esm/menu/root/MenuRoot.js
  init_define_import_meta_env();
  var React94 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/menubar/MenubarContext.js
  init_define_import_meta_env();
  var React91 = __toESM(require_react_shim(), 1);
  var MenubarContext = /* @__PURE__ */ React91.createContext(null);
  if (true) MenubarContext.displayName = "MenubarContext";
  function useMenubarContext(optional) {
    const context = React91.useContext(MenubarContext);
    if (context === null && !optional) {
      throw new Error(true ? "Base UI: MenubarContext is missing. Menubar parts must be placed within <Menubar>." : formatErrorMessage_default(5));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/menu/store/MenuStore.js
  init_define_import_meta_env();
  var React92 = __toESM(require_react_shim(), 1);
  var selectors3 = {
    ...popupStoreSelectors,
    disabled: createSelector2((state) => state.parent.type === "menubar" ? state.parent.context.disabled || state.disabled : state.disabled),
    modal: createSelector2((state) => (state.parent.type === void 0 || state.parent.type === "context-menu") && (state.modal ?? true)),
    allowMouseEnter: createSelector2((state) => state.allowMouseEnter),
    stickIfOpen: createSelector2((state) => state.stickIfOpen),
    parent: createSelector2((state) => state.parent),
    rootId: createSelector2((state) => {
      if (state.parent.type === "menu") {
        return state.parent.store.select("rootId");
      }
      return state.parent.type !== void 0 ? state.parent.context.rootId : state.rootId;
    }),
    activeIndex: createSelector2((state) => state.activeIndex),
    isActive: createSelector2((state, itemIndex) => state.activeIndex === itemIndex),
    hoverEnabled: createSelector2((state) => state.hoverEnabled),
    instantType: createSelector2((state) => state.instantType),
    lastOpenChangeReason: createSelector2((state) => state.openChangeReason),
    floatingTreeRoot: createSelector2((state) => {
      if (state.parent.type === "menu") {
        return state.parent.store.select("floatingTreeRoot");
      }
      return state.floatingTreeRoot;
    }),
    floatingNodeId: createSelector2((state) => state.floatingNodeId),
    floatingParentNodeId: createSelector2((state) => state.floatingParentNodeId),
    itemProps: createSelector2((state) => state.itemProps),
    closeDelay: createSelector2((state) => state.closeDelay),
    hasViewport: createSelector2((state) => state.hasViewport),
    keyboardEventRelay: createSelector2((state) => {
      if (state.keyboardEventRelay) {
        return state.keyboardEventRelay;
      }
      if (state.parent.type === "menu") {
        return state.parent.store.select("keyboardEventRelay");
      }
      return void 0;
    })
  };
  var MenuStore = class _MenuStore extends ReactStore {
    constructor(initialState) {
      super({
        ...createInitialState2(),
        ...initialState
      }, {
        positionerRef: /* @__PURE__ */ React92.createRef(),
        popupRef: /* @__PURE__ */ React92.createRef(),
        typingRef: {
          current: false
        },
        itemDomElements: {
          current: []
        },
        itemLabels: {
          current: []
        },
        allowMouseUpTriggerRef: {
          current: false
        },
        triggerFocusTargetRef: /* @__PURE__ */ React92.createRef(),
        beforeContentFocusGuardRef: /* @__PURE__ */ React92.createRef(),
        onOpenChangeComplete: void 0,
        triggerElements: new PopupTriggerMap()
      }, selectors3);
      __publicField(this, "unsubscribeParentListener", null);
      this.unsubscribeParentListener = this.observe("parent", (parent) => {
        this.unsubscribeParentListener?.();
        if (parent.type === "menu") {
          let rootId = parent.store.select("rootId");
          let floatingTreeRoot = parent.store.select("floatingTreeRoot");
          let keyboardEventRelay = parent.store.select("keyboardEventRelay");
          this.unsubscribeParentListener = parent.store.subscribe(() => {
            const nextRootId = parent.store.select("rootId");
            const nextFloatingTreeRoot = parent.store.select("floatingTreeRoot");
            const nextKeyboardEventRelay = parent.store.select("keyboardEventRelay");
            if (rootId === nextRootId && floatingTreeRoot === nextFloatingTreeRoot && keyboardEventRelay === nextKeyboardEventRelay) {
              return;
            }
            rootId = nextRootId;
            floatingTreeRoot = nextFloatingTreeRoot;
            keyboardEventRelay = nextKeyboardEventRelay;
            this.notifyAll();
          });
          this.context.allowMouseUpTriggerRef = parent.store.context.allowMouseUpTriggerRef;
          return;
        }
        if (parent.type !== void 0) {
          this.context.allowMouseUpTriggerRef = parent.context.allowMouseUpTriggerRef;
        }
        this.unsubscribeParentListener = null;
      });
    }
    setOpen(open, eventDetails) {
      this.state.floatingRootContext.context.events.emit("setOpen", {
        open,
        eventDetails
      });
    }
    static useStore(externalStore, initialState) {
      const internalStore = useRefWithInit(() => {
        return new _MenuStore(initialState);
      }).current;
      return externalStore ?? internalStore;
    }
  };
  function createInitialState2() {
    return {
      ...createInitialPopupStoreState(),
      disabled: false,
      modal: true,
      allowMouseEnter: false,
      stickIfOpen: true,
      parent: {
        type: void 0
      },
      rootId: void 0,
      activeIndex: null,
      hoverEnabled: true,
      instantType: void 0,
      openChangeReason: null,
      floatingTreeRoot: new FloatingTreeStore(),
      floatingNodeId: void 0,
      floatingParentNodeId: null,
      itemProps: EMPTY_OBJECT,
      keyboardEventRelay: void 0,
      closeDelay: 0,
      hasViewport: false
    };
  }

  // node_modules/@base-ui/react/esm/menu/submenu-root/MenuSubmenuRootContext.js
  init_define_import_meta_env();
  var React93 = __toESM(require_react_shim(), 1);
  var MenuSubmenuRootContext = /* @__PURE__ */ React93.createContext(void 0);
  if (true) MenuSubmenuRootContext.displayName = "MenuSubmenuRootContext";
  function useMenuSubmenuRootContext() {
    return React93.useContext(MenuSubmenuRootContext);
  }

  // node_modules/@base-ui/react/esm/menu/root/MenuRoot.js
  var import_jsx_runtime23 = __toESM(require_react_shim(), 1);
  var MenuRoot = fastComponent(function MenuRoot2(props) {
    const {
      children,
      open: openProp,
      onOpenChange,
      onOpenChangeComplete,
      defaultOpen = false,
      disabled: disabledProp = false,
      modal: modalProp,
      loopFocus = true,
      orientation = "vertical",
      actionsRef,
      closeParentOnEsc = false,
      handle,
      triggerId: triggerIdProp,
      defaultTriggerId: defaultTriggerIdProp = null,
      highlightItemOnHover = true
    } = props;
    const contextMenuContext = useContextMenuRootContext(true);
    const parentMenuRootContext = useMenuRootContext(true);
    const menubarContext = useMenubarContext(true);
    const isSubmenu = useMenuSubmenuRootContext();
    const parentFromContext = React94.useMemo(() => {
      if (isSubmenu && parentMenuRootContext) {
        return {
          type: "menu",
          store: parentMenuRootContext.store
        };
      }
      if (menubarContext) {
        return {
          type: "menubar",
          context: menubarContext
        };
      }
      if (contextMenuContext && !parentMenuRootContext) {
        return {
          type: "context-menu",
          context: contextMenuContext
        };
      }
      return {
        type: void 0
      };
    }, [contextMenuContext, parentMenuRootContext, menubarContext, isSubmenu]);
    const store = MenuStore.useStore(handle?.store, {
      open: defaultOpen,
      openProp,
      activeTriggerId: defaultTriggerIdProp,
      triggerIdProp,
      parent: parentFromContext
    });
    useOnFirstRender(() => {
      if (openProp === void 0 && store.state.open === false && defaultOpen === true) {
        store.update({
          open: true,
          activeTriggerId: defaultTriggerIdProp
        });
      }
    });
    store.useControlledProp("openProp", openProp);
    store.useControlledProp("triggerIdProp", triggerIdProp);
    store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
    const floatingTreeRoot = store.useState("floatingTreeRoot");
    const floatingNodeIdFromContext = useFloatingNodeId(floatingTreeRoot);
    const floatingParentNodeIdFromContext = useFloatingParentNodeId();
    useIsoLayoutEffect(() => {
      if (contextMenuContext && !parentMenuRootContext) {
        store.update({
          parent: {
            type: "context-menu",
            context: contextMenuContext
          },
          floatingNodeId: floatingNodeIdFromContext,
          floatingParentNodeId: floatingParentNodeIdFromContext
        });
      } else if (parentMenuRootContext) {
        store.update({
          floatingNodeId: floatingNodeIdFromContext,
          floatingParentNodeId: floatingParentNodeIdFromContext
        });
      }
    }, [contextMenuContext, parentMenuRootContext, floatingNodeIdFromContext, floatingParentNodeIdFromContext, store]);
    const open = store.useState("open");
    const activeTriggerElement = store.useState("activeTriggerElement");
    const positionerElement = store.useState("positionerElement");
    const hoverEnabled = store.useState("hoverEnabled");
    const modal = store.useState("modal");
    const disabled2 = store.useState("disabled");
    const lastOpenChangeReason = store.useState("lastOpenChangeReason");
    const parent = store.useState("parent");
    const activeIndex = store.useState("activeIndex");
    const payload = store.useState("payload");
    const floatingParentNodeId = store.useState("floatingParentNodeId");
    const openEventRef = React94.useRef(null);
    const nested = floatingParentNodeId != null;
    let floatingEvents;
    if (true) {
      if (parent.type !== void 0 && modalProp !== void 0) {
        console.warn("Base UI: The `modal` prop is not supported on nested menus. It will be ignored.");
      }
    }
    store.useSyncedValues({
      disabled: disabledProp,
      modal: parent.type === void 0 ? modalProp : void 0,
      rootId: useId()
    });
    const {
      openMethod,
      triggerProps: interactionTypeProps
    } = useOpenInteractionType(open);
    useImplicitActiveTrigger(store);
    const {
      forceUnmount
    } = useOpenStateTransitions(open, store, () => {
      store.update({
        allowMouseEnter: false,
        stickIfOpen: true
      });
    });
    const allowOutsidePressDismissalRef = React94.useRef(parent.type !== "context-menu");
    const allowOutsidePressDismissalTimeout = useTimeout();
    React94.useEffect(() => {
      if (!open) {
        openEventRef.current = null;
      }
      if (parent.type !== "context-menu") {
        return;
      }
      if (!open) {
        allowOutsidePressDismissalTimeout.clear();
        allowOutsidePressDismissalRef.current = false;
        return;
      }
      allowOutsidePressDismissalTimeout.start(500, () => {
        allowOutsidePressDismissalRef.current = true;
      });
    }, [allowOutsidePressDismissalTimeout, open, parent.type]);
    useScrollLock(open && modal && lastOpenChangeReason !== reason_parts_exports.triggerHover && openMethod !== "touch", positionerElement);
    useIsoLayoutEffect(() => {
      if (!open && !hoverEnabled) {
        store.set("hoverEnabled", true);
      }
    }, [open, hoverEnabled, store]);
    const allowTouchToCloseRef = React94.useRef(true);
    const allowTouchToCloseTimeout = useTimeout();
    const setOpen = useStableCallback((nextOpen, eventDetails) => {
      const reason = eventDetails.reason;
      if (open === nextOpen && eventDetails.trigger === activeTriggerElement && lastOpenChangeReason === reason) {
        return;
      }
      eventDetails.preventUnmountOnClose = () => {
        store.set("preventUnmountingOnClose", true);
      };
      if (!nextOpen && eventDetails.trigger == null) {
        eventDetails.trigger = activeTriggerElement ?? void 0;
      }
      onOpenChange?.(nextOpen, eventDetails);
      if (eventDetails.isCanceled) {
        return;
      }
      const details = {
        open: nextOpen,
        nativeEvent: eventDetails.event,
        reason: eventDetails.reason,
        nested
      };
      floatingEvents?.emit("openchange", details);
      const nativeEvent = eventDetails.event;
      if (nextOpen === false && nativeEvent?.type === "click" && nativeEvent.pointerType === "touch" && !allowTouchToCloseRef.current) {
        return;
      }
      if (!nextOpen && activeIndex !== null) {
        const activeOption = store.context.itemDomElements.current[activeIndex];
        queueMicrotask(() => {
          activeOption?.setAttribute("tabindex", "-1");
        });
      }
      if (nextOpen && reason === reason_parts_exports.triggerFocus) {
        allowTouchToCloseRef.current = false;
        allowTouchToCloseTimeout.start(300, () => {
          allowTouchToCloseRef.current = true;
        });
      } else {
        allowTouchToCloseRef.current = true;
        allowTouchToCloseTimeout.clear();
      }
      const isKeyboardClick = (reason === reason_parts_exports.triggerPress || reason === reason_parts_exports.itemPress) && nativeEvent.detail === 0 && nativeEvent?.isTrusted;
      const isDismissClose = !nextOpen && (reason === reason_parts_exports.escapeKey || reason == null);
      const updatedState = {
        open: nextOpen,
        openChangeReason: reason
      };
      openEventRef.current = eventDetails.event ?? null;
      const newTriggerId = eventDetails.trigger?.id ?? null;
      if (newTriggerId || nextOpen) {
        updatedState.activeTriggerId = newTriggerId;
        updatedState.activeTriggerElement = eventDetails.trigger ?? null;
      }
      store.update(updatedState);
      if (parent.type === "menubar" && (reason === reason_parts_exports.triggerFocus || reason === reason_parts_exports.focusOut || reason === reason_parts_exports.triggerHover || reason === reason_parts_exports.listNavigation || reason === reason_parts_exports.siblingOpen)) {
        store.set("instantType", "group");
      } else if (isKeyboardClick || isDismissClose) {
        store.set("instantType", isKeyboardClick ? "click" : "dismiss");
      } else {
        store.set("instantType", void 0);
      }
    });
    const createMenuEventDetails = React94.useCallback((reason) => {
      const details = createChangeEventDetails(reason);
      details.preventUnmountOnClose = () => {
        store.set("preventUnmountingOnClose", true);
      };
      return details;
    }, [store]);
    const handleImperativeClose = React94.useCallback(() => {
      store.setOpen(false, createMenuEventDetails(reason_parts_exports.imperativeAction));
    }, [store, createMenuEventDetails]);
    React94.useImperativeHandle(actionsRef, () => ({
      unmount: forceUnmount,
      close: handleImperativeClose
    }), [forceUnmount, handleImperativeClose]);
    let ctx;
    if (parent.type === "context-menu") {
      ctx = parent.context;
    }
    React94.useImperativeHandle(ctx?.positionerRef, () => positionerElement, [positionerElement]);
    React94.useImperativeHandle(ctx?.actionsRef, () => ({
      setOpen
    }), [setOpen]);
    const floatingRootContext = useSyncedFloatingRootContext({
      popupStore: store,
      onOpenChange: setOpen
    });
    floatingEvents = floatingRootContext.context.events;
    React94.useEffect(() => {
      const handleSetOpenEvent = ({
        open: nextOpen,
        eventDetails
      }) => setOpen(nextOpen, eventDetails);
      floatingEvents.on("setOpen", handleSetOpenEvent);
      return () => {
        floatingEvents?.off("setOpen", handleSetOpenEvent);
      };
    }, [floatingEvents, setOpen]);
    const dismiss = useDismiss(floatingRootContext, {
      enabled: !disabled2,
      bubbles: {
        escapeKey: closeParentOnEsc && parent.type === "menu"
      },
      outsidePress() {
        if (parent.type !== "context-menu" || openEventRef.current?.type === "contextmenu") {
          return true;
        }
        return allowOutsidePressDismissalRef.current;
      },
      externalTree: nested ? floatingTreeRoot : void 0
    });
    const role = useRole(floatingRootContext, {
      role: "menu"
    });
    const direction = useDirection();
    const setActiveIndex = React94.useCallback((index2) => {
      if (store.select("activeIndex") === index2) {
        return;
      }
      store.set("activeIndex", index2);
    }, [store]);
    const listNavigation2 = useListNavigation(floatingRootContext, {
      enabled: !disabled2,
      listRef: store.context.itemDomElements,
      activeIndex,
      nested: parent.type !== void 0,
      loopFocus,
      orientation,
      parentOrientation: parent.type === "menubar" ? parent.context.orientation : void 0,
      rtl: direction === "rtl",
      disabledIndices: EMPTY_ARRAY,
      onNavigate: setActiveIndex,
      openOnArrowKeyDown: parent.type !== "context-menu",
      externalTree: nested ? floatingTreeRoot : void 0,
      focusItemOnHover: highlightItemOnHover
    });
    const onTypingChange = React94.useCallback((nextTyping) => {
      store.context.typingRef.current = nextTyping;
    }, [store]);
    const typeahead = useTypeahead(floatingRootContext, {
      listRef: store.context.itemLabels,
      elementsRef: store.context.itemDomElements,
      activeIndex,
      resetMs: TYPEAHEAD_RESET_MS,
      onMatch: (index2) => {
        if (open && index2 !== activeIndex) {
          store.set("activeIndex", index2);
        }
      },
      onTypingChange
    });
    const {
      getReferenceProps,
      getFloatingProps,
      getItemProps,
      getTriggerProps
    } = useInteractions([dismiss, role, listNavigation2, typeahead]);
    const activeTriggerProps = React94.useMemo(() => {
      const mergedProps = mergeProps(getReferenceProps(), {
        onMouseMove() {
          store.set("allowMouseEnter", true);
        }
      }, interactionTypeProps);
      delete mergedProps.role;
      return mergedProps;
    }, [getReferenceProps, store, interactionTypeProps]);
    const inactiveTriggerProps = React94.useMemo(() => {
      const triggerProps = getTriggerProps();
      if (!triggerProps) {
        return triggerProps;
      }
      const mergedProps = mergeProps(triggerProps, interactionTypeProps);
      delete mergedProps.role;
      delete mergedProps["aria-controls"];
      return mergedProps;
    }, [getTriggerProps, interactionTypeProps]);
    const popupProps = React94.useMemo(() => getFloatingProps({
      onMouseMove() {
        store.set("allowMouseEnter", true);
        if (parent.type === "menu") {
          store.set("hoverEnabled", false);
        }
      },
      onClick() {
        if (store.select("hoverEnabled")) {
          store.set("hoverEnabled", false);
        }
      },
      onKeyDown(event) {
        const relay = store.select("keyboardEventRelay");
        if (relay && !event.isPropagationStopped()) {
          relay(event);
        }
      }
    }), [getFloatingProps, parent.type, store]);
    const itemProps = React94.useMemo(() => getItemProps(), [getItemProps]);
    store.useSyncedValues({
      floatingRootContext,
      activeTriggerProps,
      inactiveTriggerProps,
      popupProps,
      itemProps
    });
    const context = React94.useMemo(() => ({
      store,
      parent: parentFromContext
    }), [store, parentFromContext]);
    const content = /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(MenuRootContext.Provider, {
      value: context,
      children: typeof children === "function" ? children({
        payload
      }) : children
    });
    if (parent.type === void 0 || parent.type === "context-menu") {
      return /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(FloatingTree, {
        externalTree: floatingTreeRoot,
        children: content
      });
    }
    return content;
  });
  if (true) MenuRoot.displayName = "MenuRoot";

  // node_modules/@base-ui/react/esm/menu/submenu-root/MenuSubmenuRoot.js
  init_define_import_meta_env();
  var React95 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime24 = __toESM(require_react_shim(), 1);
  function MenuSubmenuRoot(props) {
    const parentMenu = useMenuRootContext().store;
    const contextValue = React95.useMemo(() => ({
      parentMenu
    }), [parentMenu]);
    return /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(MenuSubmenuRootContext.Provider, {
      value: contextValue,
      children: /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(MenuRoot, {
        ...props
      })
    });
  }

  // node_modules/@base-ui/react/esm/menu/trigger/MenuTrigger.js
  init_define_import_meta_env();
  var React98 = __toESM(require_react_shim(), 1);
  var ReactDOM5 = __toESM(require_react_dom_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/getPseudoElementBounds.js
  init_define_import_meta_env();
  function getPseudoElementBounds(element) {
    const elementRect = element.getBoundingClientRect();
    if (true) {
      return elementRect;
    }
    const beforeStyles = window.getComputedStyle(element, "::before");
    const afterStyles = window.getComputedStyle(element, "::after");
    const hasPseudoElements = beforeStyles.content !== "none" || afterStyles.content !== "none";
    if (!hasPseudoElements) {
      return elementRect;
    }
    const beforeWidth = parseFloat(beforeStyles.width) || 0;
    const beforeHeight = parseFloat(beforeStyles.height) || 0;
    const afterWidth = parseFloat(afterStyles.width) || 0;
    const afterHeight = parseFloat(afterStyles.height) || 0;
    const totalWidth = Math.max(elementRect.width, beforeWidth, afterWidth);
    const totalHeight = Math.max(elementRect.height, beforeHeight, afterHeight);
    const widthDiff = totalWidth - elementRect.width;
    const heightDiff = totalHeight - elementRect.height;
    return {
      left: elementRect.left - widthDiff / 2,
      right: elementRect.right + widthDiff / 2,
      top: elementRect.top - heightDiff / 2,
      bottom: elementRect.bottom + heightDiff / 2
    };
  }

  // node_modules/@base-ui/react/esm/composite/item/CompositeItem.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/composite/item/useCompositeItem.js
  init_define_import_meta_env();
  var React96 = __toESM(require_react_shim(), 1);
  function useCompositeItem(params = {}) {
    const {
      highlightItemOnHover,
      highlightedIndex,
      onHighlightedIndexChange
    } = useCompositeRootContext();
    const {
      ref,
      index: index2
    } = useCompositeListItem(params);
    const isHighlighted = highlightedIndex === index2;
    const itemRef = React96.useRef(null);
    const mergedRef = useMergedRefs(ref, itemRef);
    const compositeProps = React96.useMemo(() => ({
      tabIndex: isHighlighted ? 0 : -1,
      onFocus() {
        onHighlightedIndexChange(index2);
      },
      onMouseMove() {
        const item = itemRef.current;
        if (!highlightItemOnHover || !item) {
          return;
        }
        const disabled2 = item.hasAttribute("disabled") || item.ariaDisabled === "true";
        if (!isHighlighted && !disabled2) {
          item.focus();
        }
      }
    }), [isHighlighted, onHighlightedIndexChange, index2, highlightItemOnHover]);
    return {
      compositeProps,
      compositeRef: mergedRef,
      index: index2
    };
  }

  // node_modules/@base-ui/react/esm/composite/item/CompositeItem.js
  function CompositeItem(componentProps) {
    const {
      render,
      className,
      state = EMPTY_OBJECT,
      props = EMPTY_ARRAY,
      refs = EMPTY_ARRAY,
      metadata,
      stateAttributesMapping: stateAttributesMapping16,
      tag = "div",
      ...elementProps
    } = componentProps;
    const {
      compositeProps,
      compositeRef
    } = useCompositeItem({
      metadata
    });
    return useRenderElement(tag, componentProps, {
      state,
      ref: [...refs, compositeRef],
      props: [compositeProps, ...props, elementProps],
      stateAttributesMapping: stateAttributesMapping16
    });
  }

  // node_modules/@base-ui/react/esm/menu/utils/findRootOwnerId.js
  init_define_import_meta_env();
  function findRootOwnerId(node) {
    if (isHTMLElement(node) && node.hasAttribute("data-rootownerid")) {
      return node.getAttribute("data-rootownerid") ?? void 0;
    }
    if (isLastTraversableNode(node)) {
      return void 0;
    }
    return findRootOwnerId(getParentNode(node));
  }

  // node_modules/@base-ui/react/esm/utils/useMixedToggleClickHandler.js
  init_define_import_meta_env();
  var React97 = __toESM(require_react_shim(), 1);
  function useMixedToggleClickHandler(params) {
    const {
      enabled = true,
      mouseDownAction,
      open
    } = params;
    const ignoreClickRef = React97.useRef(false);
    return React97.useMemo(() => {
      if (!enabled) {
        return EMPTY_OBJECT;
      }
      return {
        onMouseDown: (event) => {
          if (mouseDownAction === "open" && !open || mouseDownAction === "close" && open) {
            ignoreClickRef.current = true;
            ownerDocument(event.currentTarget).addEventListener("click", () => {
              ignoreClickRef.current = false;
            }, {
              once: true
            });
          }
        },
        onClick: (event) => {
          if (ignoreClickRef.current) {
            ignoreClickRef.current = false;
            event.preventBaseUIHandler();
          }
        }
      };
    }, [enabled, mouseDownAction, open]);
  }

  // node_modules/@base-ui/react/esm/menu/trigger/MenuTrigger.js
  var import_jsx_runtime25 = __toESM(require_react_shim(), 1);
  var BOUNDARY_OFFSET = 2;
  var MenuTrigger = fastComponentRef(function MenuTrigger2(componentProps, forwardedRef) {
    const {
      render,
      className,
      disabled: disabledProp = false,
      nativeButton = true,
      id: idProp,
      openOnHover: openOnHoverProp,
      delay = 100,
      closeDelay = 0,
      handle,
      payload,
      ...elementProps
    } = componentProps;
    const rootContext = useMenuRootContext(true);
    const store = handle?.store ?? rootContext?.store;
    if (!store) {
      throw new Error(true ? "Base UI: <Menu.Trigger> must be either used within a <Menu.Root> component or provided with a handle." : formatErrorMessage_default(85));
    }
    const thisTriggerId = useBaseUiId(idProp);
    const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
    const floatingRootContext = store.useState("floatingRootContext");
    const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
    const triggerElementRef = React98.useRef(null);
    const parent = useMenuParent();
    const compositeRootContext = useCompositeRootContext(true);
    const floatingTreeRootFromContext = useFloatingTree();
    const floatingTreeRoot = React98.useMemo(() => {
      return floatingTreeRootFromContext ?? new FloatingTreeStore();
    }, [floatingTreeRootFromContext]);
    const floatingNodeId = useFloatingNodeId(floatingTreeRoot);
    const floatingParentNodeId = useFloatingParentNodeId();
    const {
      registerTrigger,
      isMountedByThisTrigger
    } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
      payload,
      closeDelay,
      parent,
      floatingTreeRoot,
      floatingNodeId,
      floatingParentNodeId,
      keyboardEventRelay: compositeRootContext?.relayKeyboardEvent
    });
    const isInMenubar = parent.type === "menubar";
    const rootDisabled = store.useState("disabled");
    const disabled2 = disabledProp || rootDisabled || isInMenubar && parent.context.disabled;
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      native: nativeButton
    });
    React98.useEffect(() => {
      if (!isOpenedByThisTrigger && parent.type === void 0) {
        store.context.allowMouseUpTriggerRef.current = false;
      }
    }, [store, isOpenedByThisTrigger, parent.type]);
    const triggerRef = React98.useRef(null);
    const allowMouseUpTriggerTimeout = useTimeout();
    const handleDocumentMouseUp = useStableCallback((mouseEvent) => {
      if (!triggerRef.current) {
        return;
      }
      allowMouseUpTriggerTimeout.clear();
      store.context.allowMouseUpTriggerRef.current = false;
      const mouseUpTarget = mouseEvent.target;
      if (contains(triggerRef.current, mouseUpTarget) || contains(store.select("positionerElement"), mouseUpTarget) || mouseUpTarget === triggerRef.current) {
        return;
      }
      if (mouseUpTarget != null && findRootOwnerId(mouseUpTarget) === store.select("rootId")) {
        return;
      }
      const bounds = getPseudoElementBounds(triggerRef.current);
      if (mouseEvent.clientX >= bounds.left - BOUNDARY_OFFSET && mouseEvent.clientX <= bounds.right + BOUNDARY_OFFSET && mouseEvent.clientY >= bounds.top - BOUNDARY_OFFSET && mouseEvent.clientY <= bounds.bottom + BOUNDARY_OFFSET) {
        return;
      }
      floatingTreeRoot.events.emit("close", {
        domEvent: mouseEvent,
        reason: reason_parts_exports.cancelOpen
      });
    });
    React98.useEffect(() => {
      if (isOpenedByThisTrigger && store.select("lastOpenChangeReason") === reason_parts_exports.triggerHover) {
        const doc = ownerDocument(triggerRef.current);
        doc.addEventListener("mouseup", handleDocumentMouseUp, {
          once: true
        });
      }
    }, [isOpenedByThisTrigger, handleDocumentMouseUp, store]);
    const parentMenubarHasSubmenuOpen = isInMenubar && parent.context.hasSubmenuOpen;
    const openOnHover = openOnHoverProp ?? parentMenubarHasSubmenuOpen;
    const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
      enabled: openOnHover && !disabled2 && parent.type !== "context-menu" && (!isInMenubar || parentMenubarHasSubmenuOpen && !isMountedByThisTrigger),
      handleClose: safePolygon({
        blockPointerEvents: !isInMenubar
      }),
      mouseOnly: true,
      move: false,
      restMs: parent.type === void 0 ? delay : void 0,
      delay: {
        close: closeDelay
      },
      triggerElementRef,
      externalTree: floatingTreeRoot,
      isActiveTrigger: isTriggerActive
    });
    const stickIfOpen = useStickIfOpen(isOpenedByThisTrigger, store.select("lastOpenChangeReason"));
    const click = useClick(floatingRootContext, {
      enabled: !disabled2 && parent.type !== "context-menu",
      event: isOpenedByThisTrigger && isInMenubar ? "click" : "mousedown",
      toggle: true,
      ignoreMouse: false,
      stickIfOpen: parent.type === void 0 ? stickIfOpen : false
    });
    const focus = useFocus(floatingRootContext, {
      enabled: !disabled2 && parentMenubarHasSubmenuOpen
    });
    const mixedToggleHandlers = useMixedToggleClickHandler({
      open: isOpenedByThisTrigger,
      enabled: isInMenubar,
      mouseDownAction: "open"
    });
    const localInteractionProps = useInteractions([click, focus]);
    const state = {
      disabled: disabled2,
      open: isOpenedByThisTrigger
    };
    const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
    const ref = [triggerRef, forwardedRef, buttonRef, registerTrigger, triggerElementRef];
    const props = [localInteractionProps.getReferenceProps(), hoverProps ?? EMPTY_OBJECT, rootTriggerProps, {
      "aria-haspopup": "menu",
      id: thisTriggerId,
      onMouseDown: (event) => {
        if (store.select("open")) {
          return;
        }
        allowMouseUpTriggerTimeout.start(200, () => {
          store.context.allowMouseUpTriggerRef.current = true;
        });
        const doc = ownerDocument(event.currentTarget);
        doc.addEventListener("mouseup", handleDocumentMouseUp, {
          once: true
        });
      }
    }, isInMenubar ? {
      role: "menuitem"
    } : {}, mixedToggleHandlers, elementProps, getButtonProps];
    const preFocusGuardRef = React98.useRef(null);
    const handlePreFocusGuardFocus = useStableCallback((event) => {
      ReactDOM5.flushSync(() => {
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.focusOut, event.nativeEvent, event.currentTarget));
      });
      const previousTabbable = getTabbableBeforeElement(preFocusGuardRef.current);
      previousTabbable?.focus();
    });
    const handleFocusTargetFocus = useStableCallback((event) => {
      const currentPositionerElement = store.select("positionerElement");
      if (currentPositionerElement && isOutsideEvent(event, currentPositionerElement)) {
        store.context.beforeContentFocusGuardRef.current?.focus();
      } else {
        ReactDOM5.flushSync(() => {
          store.setOpen(false, createChangeEventDetails(reason_parts_exports.focusOut, event.nativeEvent, event.currentTarget));
        });
        let nextTabbable = getTabbableAfterElement(store.context.triggerFocusTargetRef.current || triggerElementRef.current);
        while (nextTabbable !== null && contains(currentPositionerElement, nextTabbable)) {
          const prevTabbable = nextTabbable;
          nextTabbable = getNextTabbable(nextTabbable);
          if (nextTabbable === prevTabbable) {
            break;
          }
        }
        nextTabbable?.focus();
      }
    });
    const element = useRenderElement("button", componentProps, {
      enabled: !isInMenubar,
      stateAttributesMapping: pressableTriggerOpenStateMapping,
      state,
      ref,
      props
    });
    if (isInMenubar) {
      return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(CompositeItem, {
        tag: "button",
        render,
        className,
        state,
        refs: ref,
        props,
        stateAttributesMapping: pressableTriggerOpenStateMapping
      });
    }
    if (isOpenedByThisTrigger) {
      return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)(React98.Fragment, {
        children: [/* @__PURE__ */ (0, import_jsx_runtime25.jsx)(FocusGuard, {
          ref: preFocusGuardRef,
          onFocus: handlePreFocusGuardFocus
        }, `${thisTriggerId}-pre-focus-guard`), /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(React98.Fragment, {
          children: element
        }, thisTriggerId), /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(FocusGuard, {
          ref: store.context.triggerFocusTargetRef,
          onFocus: handleFocusTargetFocus
        }, `${thisTriggerId}-post-focus-guard`)]
      });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(React98.Fragment, {
      children: element
    }, thisTriggerId);
  });
  if (true) MenuTrigger.displayName = "MenuTrigger";
  function useStickIfOpen(open, openReason) {
    const stickIfOpenTimeout = useTimeout();
    const [stickIfOpen, setStickIfOpen] = React98.useState(false);
    useIsoLayoutEffect(() => {
      if (open && openReason === "trigger-hover") {
        setStickIfOpen(true);
        stickIfOpenTimeout.start(PATIENT_CLICK_THRESHOLD, () => {
          setStickIfOpen(false);
        });
      } else if (!open) {
        stickIfOpenTimeout.clear();
        setStickIfOpen(false);
      }
    }, [open, openReason, stickIfOpenTimeout]);
    return stickIfOpen;
  }
  function useMenuParent() {
    const contextMenuContext = useContextMenuRootContext(true);
    const parentContext = useMenuRootContext(true);
    const menubarContext = useMenubarContext(true);
    const parent = React98.useMemo(() => {
      if (menubarContext) {
        return {
          type: "menubar",
          context: menubarContext
        };
      }
      if (contextMenuContext && !parentContext) {
        return {
          type: "context-menu",
          context: contextMenuContext
        };
      }
      return {
        type: void 0
      };
    }, [contextMenuContext, parentContext, menubarContext]);
    return parent;
  }

  // node_modules/@base-ui/react/esm/menu/viewport/MenuViewport.js
  init_define_import_meta_env();
  var React102 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/usePopupViewport.js
  init_define_import_meta_env();
  var React101 = __toESM(require_react_shim(), 1);
  var ReactDOM6 = __toESM(require_react_dom_shim(), 1);

  // node_modules/@base-ui/utils/esm/usePreviousValue.js
  init_define_import_meta_env();
  var React99 = __toESM(require_react_shim(), 1);
  function usePreviousValue(value) {
    const [state, setState] = React99.useState({
      current: value,
      previous: null
    });
    if (value !== state.current) {
      setState({
        current: value,
        previous: state.current
      });
    }
    return state.previous;
  }

  // node_modules/@base-ui/react/esm/utils/usePopupAutoResize.js
  init_define_import_meta_env();
  var React100 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/getCssDimensions.js
  init_define_import_meta_env();
  function getCssDimensions2(element) {
    const css = getComputedStyle2(element);
    let width = parseFloat(css.width) || 0;
    let height = parseFloat(css.height) || 0;
    const hasOffset = isHTMLElement(element);
    const offsetWidth = hasOffset ? element.offsetWidth : width;
    const offsetHeight = hasOffset ? element.offsetHeight : height;
    const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
    if (shouldFallback) {
      width = offsetWidth;
      height = offsetHeight;
    }
    return {
      width,
      height
    };
  }

  // node_modules/@base-ui/react/esm/utils/usePopupAutoResize.js
  var DEFAULT_ENABLED = () => true;
  function usePopupAutoResize(parameters) {
    const {
      popupElement,
      positionerElement,
      content,
      mounted,
      enabled = DEFAULT_ENABLED,
      onMeasureLayout: onMeasureLayoutParam,
      onMeasureLayoutComplete: onMeasureLayoutCompleteParam,
      side,
      direction
    } = parameters;
    const runOnceAnimationsFinish = useAnimationsFinished(popupElement, true, false);
    const animationFrame = useAnimationFrame();
    const committedDimensionsRef = React100.useRef(null);
    const liveDimensionsRef = React100.useRef(null);
    const isInitialRenderRef = React100.useRef(true);
    const restoreAnchoringStylesRef = React100.useRef(NOOP);
    const onMeasureLayout = useStableCallback(onMeasureLayoutParam);
    const onMeasureLayoutComplete = useStableCallback(onMeasureLayoutCompleteParam);
    const anchoringStyles = React100.useMemo(() => {
      let isOriginSide = side === "top";
      let isPhysicalLeft = side === "left";
      if (direction === "rtl") {
        isOriginSide = isOriginSide || side === "inline-end";
        isPhysicalLeft = isPhysicalLeft || side === "inline-end";
      } else {
        isOriginSide = isOriginSide || side === "inline-start";
        isPhysicalLeft = isPhysicalLeft || side === "inline-start";
      }
      return isOriginSide ? {
        position: "absolute",
        [side === "top" ? "bottom" : "top"]: "0",
        [isPhysicalLeft ? "right" : "left"]: "0"
      } : EMPTY_OBJECT;
    }, [side, direction]);
    useIsoLayoutEffect(() => {
      if (!mounted || !enabled() || typeof ResizeObserver !== "function") {
        restoreAnchoringStylesRef.current = NOOP;
        isInitialRenderRef.current = true;
        committedDimensionsRef.current = null;
        liveDimensionsRef.current = null;
        return void 0;
      }
      if (!popupElement || !positionerElement) {
        return void 0;
      }
      restoreAnchoringStylesRef.current = applyElementStyles(popupElement, anchoringStyles);
      const observer = new ResizeObserver((entries) => {
        const entry = entries[0];
        if (entry) {
          liveDimensionsRef.current = {
            width: Math.ceil(entry.borderBoxSize[0].inlineSize),
            height: Math.ceil(entry.borderBoxSize[0].blockSize)
          };
        }
      });
      observer.observe(popupElement);
      setPopupCssSize(popupElement, "auto");
      const restorePopupPosition = overrideElementStyle(popupElement, "position", "static");
      const restorePopupTransform = overrideElementStyle(popupElement, "transform", "none");
      const restorePopupScale = overrideElementStyle(popupElement, "scale", "1");
      const restorePositionerAvailableSize = applyElementStyles(positionerElement, {
        "--available-width": "max-content",
        "--available-height": "max-content"
      });
      function restoreMeasurementOverrides() {
        restorePopupPosition();
        restorePopupTransform();
        restorePositionerAvailableSize();
      }
      function restoreMeasurementOverridesIncludingScale() {
        restoreMeasurementOverrides();
        restorePopupScale();
      }
      onMeasureLayout?.();
      if (isInitialRenderRef.current || committedDimensionsRef.current === null) {
        setPositionerCssSize(positionerElement, "max-content");
        const dimensions = getCssDimensions2(popupElement);
        committedDimensionsRef.current = dimensions;
        setPositionerCssSize(positionerElement, dimensions);
        restoreMeasurementOverridesIncludingScale();
        onMeasureLayoutComplete?.(null, dimensions);
        isInitialRenderRef.current = false;
        return () => {
          observer.disconnect();
          restoreAnchoringStylesRef.current();
          restoreAnchoringStylesRef.current = NOOP;
        };
      }
      setPopupCssSize(popupElement, "auto");
      setPositionerCssSize(positionerElement, "max-content");
      const previousDimensions = committedDimensionsRef.current ?? liveDimensionsRef.current;
      const newDimensions = getCssDimensions2(popupElement);
      committedDimensionsRef.current = newDimensions;
      if (!previousDimensions) {
        setPositionerCssSize(positionerElement, newDimensions);
        restoreMeasurementOverridesIncludingScale();
        onMeasureLayoutComplete?.(null, newDimensions);
        return () => {
          observer.disconnect();
          animationFrame.cancel();
          restoreAnchoringStylesRef.current();
          restoreAnchoringStylesRef.current = NOOP;
        };
      }
      setPopupCssSize(popupElement, previousDimensions);
      restoreMeasurementOverridesIncludingScale();
      onMeasureLayoutComplete?.(previousDimensions, newDimensions);
      setPositionerCssSize(positionerElement, newDimensions);
      const abortController = new AbortController();
      animationFrame.request(() => {
        setPopupCssSize(popupElement, newDimensions);
        runOnceAnimationsFinish(() => {
          popupElement.style.setProperty("--popup-width", "auto");
          popupElement.style.setProperty("--popup-height", "auto");
        }, abortController.signal);
      });
      return () => {
        observer.disconnect();
        abortController.abort();
        animationFrame.cancel();
        restoreAnchoringStylesRef.current();
        restoreAnchoringStylesRef.current = NOOP;
      };
    }, [content, popupElement, positionerElement, runOnceAnimationsFinish, animationFrame, enabled, mounted, onMeasureLayout, onMeasureLayoutComplete, anchoringStyles]);
  }
  function overrideElementStyle(element, property, value) {
    const originalValue = element.style.getPropertyValue(property);
    element.style.setProperty(property, value);
    return () => {
      element.style.setProperty(property, originalValue);
    };
  }
  function applyElementStyles(element, styles) {
    const restorers = [];
    for (const [key, value] of Object.entries(styles)) {
      restorers.push(overrideElementStyle(element, key, value));
    }
    return restorers.length ? () => {
      restorers.forEach((restore) => restore());
    } : NOOP;
  }
  function setPopupCssSize(popupElement, size4) {
    const width = size4 === "auto" ? "auto" : `${size4.width}px`;
    const height = size4 === "auto" ? "auto" : `${size4.height}px`;
    popupElement.style.setProperty("--popup-width", width);
    popupElement.style.setProperty("--popup-height", height);
  }
  function setPositionerCssSize(positionerElement, size4) {
    const width = size4 === "max-content" ? "max-content" : `${size4.width}px`;
    const height = size4 === "max-content" ? "max-content" : `${size4.height}px`;
    positionerElement.style.setProperty("--positioner-width", width);
    positionerElement.style.setProperty("--positioner-height", height);
  }

  // node_modules/@base-ui/react/esm/direction-provider/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/direction-provider/index.parts.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/usePopupViewport.js
  var import_jsx_runtime26 = __toESM(require_react_shim(), 1);
  function usePopupViewport(parameters) {
    const {
      store,
      side,
      cssVars,
      children
    } = parameters;
    const direction = useDirection();
    const activeTrigger = store.useState("activeTriggerElement");
    const activeTriggerId = store.useState("activeTriggerId");
    const open = store.useState("open");
    const payload = store.useState("payload");
    const mounted = store.useState("mounted");
    const popupElement = store.useState("popupElement");
    const positionerElement = store.useState("positionerElement");
    const previousActiveTrigger = usePreviousValue(open ? activeTrigger : null);
    const currentContentKey = usePopupContentKey(activeTriggerId, payload);
    const capturedNodeRef = React101.useRef(null);
    const [previousContentNode, setPreviousContentNode] = React101.useState(null);
    const [newTriggerOffset, setNewTriggerOffset] = React101.useState(null);
    const currentContainerRef = React101.useRef(null);
    const previousContainerRef = React101.useRef(null);
    const onAnimationsFinished = useAnimationsFinished(currentContainerRef, true, false);
    const cleanupFrame = useAnimationFrame();
    const [previousContentDimensions, setPreviousContentDimensions] = React101.useState(null);
    const [showStartingStyleAttribute, setShowStartingStyleAttribute] = React101.useState(false);
    useIsoLayoutEffect(() => {
      store.set("hasViewport", true);
      return () => {
        store.set("hasViewport", false);
      };
    }, [store]);
    const handleMeasureLayout = useStableCallback(() => {
      currentContainerRef.current?.style.setProperty("animation", "none");
      currentContainerRef.current?.style.setProperty("transition", "none");
      previousContainerRef.current?.style.setProperty("display", "none");
    });
    const handleMeasureLayoutComplete = useStableCallback((previousDimensions) => {
      currentContainerRef.current?.style.removeProperty("animation");
      currentContainerRef.current?.style.removeProperty("transition");
      previousContainerRef.current?.style.removeProperty("display");
      if (previousDimensions) {
        setPreviousContentDimensions(previousDimensions);
      }
    });
    const lastHandledTriggerRef = React101.useRef(null);
    useIsoLayoutEffect(() => {
      if (activeTrigger && previousActiveTrigger && activeTrigger !== previousActiveTrigger && lastHandledTriggerRef.current !== activeTrigger && capturedNodeRef.current) {
        setPreviousContentNode(capturedNodeRef.current);
        setShowStartingStyleAttribute(true);
        const offset4 = calculateRelativePosition(previousActiveTrigger, activeTrigger);
        setNewTriggerOffset(offset4);
        cleanupFrame.request(() => {
          ReactDOM6.flushSync(() => {
            setShowStartingStyleAttribute(false);
          });
          onAnimationsFinished(() => {
            setPreviousContentNode(null);
            setPreviousContentDimensions(null);
            capturedNodeRef.current = null;
          });
        });
        lastHandledTriggerRef.current = activeTrigger;
      }
    }, [activeTrigger, previousActiveTrigger, previousContentNode, onAnimationsFinished, cleanupFrame]);
    useIsoLayoutEffect(() => {
      const source = currentContainerRef.current;
      if (!source) {
        return;
      }
      const wrapper = document.createElement("div");
      for (const child of Array.from(source.childNodes)) {
        wrapper.appendChild(child.cloneNode(true));
      }
      capturedNodeRef.current = wrapper;
    });
    const isTransitioning = previousContentNode != null;
    let childrenToRender;
    if (!isTransitioning) {
      childrenToRender = /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", {
        "data-current": true,
        ref: currentContainerRef,
        children
      }, currentContentKey);
    } else {
      childrenToRender = /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)(React101.Fragment, {
        children: [/* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", {
          "data-previous": true,
          inert: inertValue(true),
          ref: previousContainerRef,
          style: {
            ...previousContentDimensions ? {
              [cssVars.popupWidth]: `${previousContentDimensions.width}px`,
              [cssVars.popupHeight]: `${previousContentDimensions.height}px`
            } : null,
            position: "absolute"
          },
          "data-ending-style": showStartingStyleAttribute ? void 0 : ""
        }, "previous"), /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", {
          "data-current": true,
          ref: currentContainerRef,
          "data-starting-style": showStartingStyleAttribute ? "" : void 0,
          children
        }, currentContentKey)]
      });
    }
    useIsoLayoutEffect(() => {
      const container = previousContainerRef.current;
      if (!container || !previousContentNode) {
        return;
      }
      container.replaceChildren(...Array.from(previousContentNode.childNodes));
    }, [previousContentNode]);
    usePopupAutoResize({
      popupElement,
      positionerElement,
      mounted,
      content: payload,
      onMeasureLayout: handleMeasureLayout,
      onMeasureLayoutComplete: handleMeasureLayoutComplete,
      side,
      direction
    });
    const state = {
      activationDirection: getActivationDirection(newTriggerOffset),
      transitioning: isTransitioning
    };
    return {
      children: childrenToRender,
      state
    };
  }
  function getActivationDirection(offset4) {
    if (!offset4) {
      return void 0;
    }
    return `${getValueWithTolerance(offset4.horizontal, 5, "right", "left")} ${getValueWithTolerance(offset4.vertical, 5, "down", "up")}`;
  }
  function getValueWithTolerance(value, tolerance, positiveLabel, negativeLabel) {
    if (value > tolerance) {
      return positiveLabel;
    }
    if (value < -tolerance) {
      return negativeLabel;
    }
    return "";
  }
  function calculateRelativePosition(from, to) {
    const fromRect = from.getBoundingClientRect();
    const toRect = to.getBoundingClientRect();
    const fromCenter = {
      x: fromRect.left + fromRect.width / 2,
      y: fromRect.top + fromRect.height / 2
    };
    const toCenter = {
      x: toRect.left + toRect.width / 2,
      y: toRect.top + toRect.height / 2
    };
    return {
      horizontal: toCenter.x - fromCenter.x,
      vertical: toCenter.y - fromCenter.y
    };
  }
  function usePopupContentKey(activeTriggerId, payload) {
    const [contentKey, setContentKey] = React101.useState(0);
    const previousActiveTriggerIdRef = React101.useRef(activeTriggerId);
    const previousPayloadRef = React101.useRef(payload);
    const pendingPayloadUpdateRef = React101.useRef(false);
    useIsoLayoutEffect(() => {
      const previousActiveTriggerId = previousActiveTriggerIdRef.current;
      const previousPayload = previousPayloadRef.current;
      const triggerIdChanged = activeTriggerId !== previousActiveTriggerId;
      const payloadChanged = payload !== previousPayload;
      if (triggerIdChanged) {
        setContentKey((value) => value + 1);
        pendingPayloadUpdateRef.current = !payloadChanged;
      } else if (pendingPayloadUpdateRef.current && payloadChanged) {
        setContentKey((value) => value + 1);
        pendingPayloadUpdateRef.current = false;
      }
      previousActiveTriggerIdRef.current = activeTriggerId;
      previousPayloadRef.current = payload;
    }, [activeTriggerId, payload]);
    return `${activeTriggerId ?? "current"}-${contentKey}`;
  }

  // node_modules/@base-ui/react/esm/menu/viewport/MenuViewportCssVars.js
  init_define_import_meta_env();
  var MenuViewportCssVars = /* @__PURE__ */ (function(MenuViewportCssVars2) {
    MenuViewportCssVars2["popupWidth"] = "--popup-width";
    MenuViewportCssVars2["popupHeight"] = "--popup-height";
    return MenuViewportCssVars2;
  })({});

  // node_modules/@base-ui/react/esm/menu/viewport/MenuViewport.js
  var stateAttributesMapping7 = {
    activationDirection: (value) => value ? {
      "data-activation-direction": value
    } : null
  };
  var MenuViewport = /* @__PURE__ */ React102.forwardRef(function MenuViewport2(componentProps, forwardedRef) {
    const {
      render,
      className,
      children,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useMenuRootContext();
    const {
      side
    } = useMenuPositionerContext();
    const instantType = store.useState("instantType");
    const {
      children: childrenToRender,
      state: viewportState
    } = usePopupViewport({
      store,
      side,
      cssVars: MenuViewportCssVars,
      children
    });
    const state = {
      activationDirection: viewportState.activationDirection,
      transitioning: viewportState.transitioning,
      instant: instantType
    };
    return useRenderElement("div", componentProps, {
      state,
      ref: forwardedRef,
      props: [elementProps, {
        children: childrenToRender
      }],
      stateAttributesMapping: stateAttributesMapping7
    });
  });
  if (true) MenuViewport.displayName = "MenuViewport";

  // node_modules/@base-ui/react/esm/separator/Separator.js
  init_define_import_meta_env();
  var React103 = __toESM(require_react_shim(), 1);
  var Separator = /* @__PURE__ */ React103.forwardRef(function SeparatorComponent(componentProps, forwardedRef) {
    const {
      className,
      render,
      orientation = "horizontal",
      ...elementProps
    } = componentProps;
    const state = {
      orientation
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: forwardedRef,
      props: [{
        role: "separator",
        "aria-orientation": orientation
      }, elementProps]
    });
    return element;
  });
  if (true) Separator.displayName = "Separator";

  // node_modules/@base-ui/react/esm/menu/submenu-trigger/MenuSubmenuTrigger.js
  init_define_import_meta_env();
  var React104 = __toESM(require_react_shim(), 1);
  var MenuSubmenuTrigger = /* @__PURE__ */ React104.forwardRef(function SubmenuTriggerComponent(componentProps, forwardedRef) {
    const {
      render,
      className,
      label,
      id: idProp,
      nativeButton = false,
      openOnHover = true,
      delay = 100,
      closeDelay = 0,
      disabled: disabledProp = false,
      ...elementProps
    } = componentProps;
    const listItem = useCompositeListItem();
    const menuPositionerContext = useMenuPositionerContext();
    const {
      store
    } = useMenuRootContext();
    const thisTriggerId = useBaseUiId(idProp);
    const open = store.useState("open");
    const floatingRootContext = store.useState("floatingRootContext");
    const floatingTreeRoot = store.useState("floatingTreeRoot");
    const baseRegisterTrigger = useTriggerRegistration(thisTriggerId, store);
    const registerTrigger = React104.useCallback((element2) => {
      const cleanup = baseRegisterTrigger(element2);
      if (element2 !== null && store.select("open") && store.select("activeTriggerId") == null) {
        store.update({
          activeTriggerId: thisTriggerId,
          activeTriggerElement: element2,
          closeDelay
        });
      }
      return cleanup;
    }, [baseRegisterTrigger, closeDelay, store, thisTriggerId]);
    const triggerElementRef = React104.useRef(null);
    const handleTriggerElementRef = React104.useCallback((el) => {
      triggerElementRef.current = el;
      store.set("activeTriggerElement", el);
    }, [store]);
    const submenuRootContext = useMenuSubmenuRootContext();
    if (!submenuRootContext?.parentMenu) {
      throw new Error(true ? "Base UI: <Menu.SubmenuTrigger> must be placed in <Menu.SubmenuRoot>." : formatErrorMessage_default(37));
    }
    store.useSyncedValue("closeDelay", closeDelay);
    const parentMenuStore = submenuRootContext.parentMenu;
    const itemProps = parentMenuStore.useState("itemProps");
    const highlighted = parentMenuStore.useState("isActive", listItem.index);
    const itemMetadata = React104.useMemo(() => ({
      type: "submenu-trigger",
      setActive() {
        parentMenuStore.set("activeIndex", listItem.index);
      }
    }), [parentMenuStore, listItem.index]);
    const rootDisabled = store.useState("disabled");
    const disabled2 = disabledProp || rootDisabled;
    const {
      getItemProps,
      itemRef
    } = useMenuItem({
      closeOnClick: false,
      disabled: disabled2,
      highlighted,
      id: thisTriggerId,
      store,
      typingRef: parentMenuStore.context.typingRef,
      nativeButton,
      itemMetadata,
      nodeId: menuPositionerContext?.nodeId
    });
    const hoverEnabled = store.useState("hoverEnabled");
    const allowMouseEnter = parentMenuStore.useState("allowMouseEnter");
    const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
      enabled: hoverEnabled && openOnHover && !disabled2,
      handleClose: safePolygon({
        blockPointerEvents: true
      }),
      mouseOnly: true,
      move: true,
      restMs: delay,
      delay: allowMouseEnter ? {
        open: delay,
        close: closeDelay
      } : 0,
      triggerElementRef,
      externalTree: floatingTreeRoot
    });
    const click = useClick(floatingRootContext, {
      enabled: !disabled2,
      event: "mousedown",
      toggle: !openOnHover,
      ignoreMouse: openOnHover,
      stickIfOpen: false
    });
    const localInteractionProps = useInteractions([click]);
    const rootTriggerProps = store.useState("triggerProps", true);
    delete rootTriggerProps.id;
    const state = {
      disabled: disabled2,
      highlighted,
      open
    };
    const element = useRenderElement("div", componentProps, {
      state,
      stateAttributesMapping: triggerOpenStateMapping,
      props: [localInteractionProps.getReferenceProps(), hoverProps, rootTriggerProps, itemProps, {
        tabIndex: open || highlighted ? 0 : -1,
        onBlur() {
          if (highlighted) {
            parentMenuStore.set("activeIndex", null);
          }
        }
      }, elementProps, getItemProps],
      ref: [forwardedRef, listItem.ref, itemRef, registerTrigger, handleTriggerElementRef]
    });
    return element;
  });
  if (true) MenuSubmenuTrigger.displayName = "MenuSubmenuTrigger";

  // node_modules/@base-ui/react/esm/menu/store/MenuHandle.js
  init_define_import_meta_env();
  var MenuHandle = class {
    /**
     * Internal store holding the menu's state.
     * @internal
     */
    constructor() {
      this.store = new MenuStore();
    }
    /**
     * Opens the menu and associates it with the trigger with the given id.
     * The trigger must be a Menu.Trigger component with this handle passed as a prop.
     *
     * @param triggerId ID of the trigger to associate with the menu.
     */
    open(triggerId) {
      const triggerElement = triggerId ? this.store.context.triggerElements.getById(triggerId) : void 0;
      if (triggerId && !triggerElement) {
        throw new Error(true ? `Base UI: MenuHandle.open: No trigger found with id "${triggerId}".` : formatErrorMessage_default(83, triggerId));
      }
      this.store.setOpen(true, createChangeEventDetails("imperative-action", void 0, triggerElement));
    }
    /**
     * Closes the menu.
     */
    close() {
      this.store.setOpen(false, createChangeEventDetails("imperative-action", void 0, void 0));
    }
    /**
     * Indicates whether the menu is currently open.
     */
    get isOpen() {
      return this.store.state.open;
    }
  };
  function createMenuHandle() {
    return new MenuHandle();
  }

  // src/components/ui/dropdown-menu.tsx
  var import_jsx_runtime27 = __toESM(require_react_shim(), 1);
  function DropdownMenu({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.Root, { "data-slot": "dropdown-menu", ...props });
  }
  function DropdownMenuPortal({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.Portal, { "data-slot": "dropdown-menu-portal", ...props });
  }
  function DropdownMenuTrigger({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.Trigger, { "data-slot": "dropdown-menu-trigger", ...props });
  }
  function DropdownMenuContent({
    align = "start",
    alignOffset = 0,
    side = "bottom",
    sideOffset = 4,
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      index_parts_exports3.Positioner,
      {
        className: "isolate z-50 outline-none",
        align,
        alignOffset,
        side,
        sideOffset,
        children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
          index_parts_exports3.Popup,
          {
            "data-slot": "dropdown-menu-content",
            className: cn("z-50 max-h-(--available-height) w-(--anchor-width) min-w-32 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:overflow-hidden data-closed:fade-out-0 data-closed:zoom-out-95", className),
            ...props
          }
        )
      }
    ) });
  }
  function DropdownMenuGroup({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.Group, { "data-slot": "dropdown-menu-group", ...props });
  }
  function DropdownMenuLabel({
    className,
    inset,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      index_parts_exports3.GroupLabel,
      {
        "data-slot": "dropdown-menu-label",
        "data-inset": inset,
        className: cn(
          "px-1.5 py-1 text-xs font-medium text-muted-foreground data-inset:pl-7",
          className
        ),
        ...props
      }
    );
  }
  function DropdownMenuItem({
    className,
    inset,
    variant = "default",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      index_parts_exports3.Item,
      {
        "data-slot": "dropdown-menu-item",
        "data-inset": inset,
        "data-variant": variant,
        className: cn(
          "group/dropdown-menu-item relative flex cursor-default items-center gap-1.5 rounded-md px-1.5 py-1 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[variant=destructive]:*:[svg]:text-destructive",
          className
        ),
        ...props
      }
    );
  }
  function DropdownMenuSub({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.SubmenuRoot, { "data-slot": "dropdown-menu-sub", ...props });
  }
  function DropdownMenuSubTrigger({
    className,
    inset,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(
      index_parts_exports3.SubmenuTrigger,
      {
        "data-slot": "dropdown-menu-sub-trigger",
        "data-inset": inset,
        className: cn(
          "flex cursor-default items-center gap-1.5 rounded-md px-1.5 py-1 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7 data-popup-open:bg-accent data-popup-open:text-accent-foreground data-open:bg-accent data-open:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(ChevronRight, { className: "ml-auto" })
        ]
      }
    );
  }
  function DropdownMenuSubContent({
    align = "start",
    alignOffset = -3,
    side = "right",
    sideOffset = 0,
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      DropdownMenuContent,
      {
        "data-slot": "dropdown-menu-sub-content",
        className: cn("w-auto min-w-[96px] rounded-lg bg-popover p-1 text-popover-foreground shadow-lg ring-1 ring-foreground/10 duration-100 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
        align,
        alignOffset,
        side,
        sideOffset,
        ...props
      }
    );
  }
  function DropdownMenuCheckboxItem({
    className,
    children,
    checked,
    inset,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(
      index_parts_exports3.CheckboxItem,
      {
        "data-slot": "dropdown-menu-checkbox-item",
        "data-inset": inset,
        className: cn(
          "relative flex cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-7 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        checked,
        ...props,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
            "span",
            {
              className: "pointer-events-none absolute right-2 flex items-center justify-center",
              "data-slot": "dropdown-menu-checkbox-item-indicator",
              children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.CheckboxItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                Check,
                {}
              ) })
            }
          ),
          children
        ]
      }
    );
  }
  function DropdownMenuRadioGroup({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      index_parts_exports3.RadioGroup,
      {
        "data-slot": "dropdown-menu-radio-group",
        ...props
      }
    );
  }
  function DropdownMenuRadioItem({
    className,
    children,
    inset,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(
      index_parts_exports3.RadioItem,
      {
        "data-slot": "dropdown-menu-radio-item",
        "data-inset": inset,
        className: cn(
          "relative flex cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-7 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        ...props,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
            "span",
            {
              className: "pointer-events-none absolute right-2 flex items-center justify-center",
              "data-slot": "dropdown-menu-radio-item-indicator",
              children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(index_parts_exports3.RadioItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                Check,
                {}
              ) })
            }
          ),
          children
        ]
      }
    );
  }
  function DropdownMenuSeparator({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      index_parts_exports3.Separator,
      {
        "data-slot": "dropdown-menu-separator",
        className: cn("-mx-1 my-1 h-px bg-border", className),
        ...props
      }
    );
  }
  function DropdownMenuShortcut({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      "span",
      {
        "data-slot": "dropdown-menu-shortcut",
        className: cn(
          "ml-auto text-xs tracking-widest text-muted-foreground group-focus/dropdown-menu-item:text-accent-foreground",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/input.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/input/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/input/Input.js
  init_define_import_meta_env();
  var React121 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/field/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/field/index.parts.js
  var index_parts_exports4 = {};
  __export(index_parts_exports4, {
    Control: () => FieldControl,
    Description: () => FieldDescription,
    Error: () => FieldError,
    Item: () => FieldItem,
    Label: () => FieldLabel,
    Root: () => FieldRoot,
    Validity: () => FieldValidity
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/field/root/FieldRoot.js
  init_define_import_meta_env();
  var React111 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/field/root/FieldRootContext.js
  init_define_import_meta_env();
  var React105 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/field/utils/constants.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/field/control/FieldControlDataAttributes.js
  init_define_import_meta_env();
  var FieldControlDataAttributes = /* @__PURE__ */ (function(FieldControlDataAttributes2) {
    FieldControlDataAttributes2["disabled"] = "data-disabled";
    FieldControlDataAttributes2["valid"] = "data-valid";
    FieldControlDataAttributes2["invalid"] = "data-invalid";
    FieldControlDataAttributes2["touched"] = "data-touched";
    FieldControlDataAttributes2["dirty"] = "data-dirty";
    FieldControlDataAttributes2["filled"] = "data-filled";
    FieldControlDataAttributes2["focused"] = "data-focused";
    return FieldControlDataAttributes2;
  })({});

  // node_modules/@base-ui/react/esm/field/utils/constants.js
  var DEFAULT_VALIDITY_STATE = {
    badInput: false,
    customError: false,
    patternMismatch: false,
    rangeOverflow: false,
    rangeUnderflow: false,
    stepMismatch: false,
    tooLong: false,
    tooShort: false,
    typeMismatch: false,
    valid: null,
    valueMissing: false
  };
  var DEFAULT_FIELD_STATE_ATTRIBUTES = {
    valid: null,
    touched: false,
    dirty: false,
    filled: false,
    focused: false
  };
  var DEFAULT_FIELD_ROOT_STATE = {
    disabled: false,
    ...DEFAULT_FIELD_STATE_ATTRIBUTES
  };
  var fieldValidityMapping = {
    valid(value) {
      if (value === null) {
        return null;
      }
      if (value) {
        return {
          [FieldControlDataAttributes.valid]: ""
        };
      }
      return {
        [FieldControlDataAttributes.invalid]: ""
      };
    }
  };

  // node_modules/@base-ui/react/esm/field/root/FieldRootContext.js
  var FieldRootContext = /* @__PURE__ */ React105.createContext({
    invalid: void 0,
    name: void 0,
    validityData: {
      state: DEFAULT_VALIDITY_STATE,
      errors: [],
      error: "",
      value: "",
      initialValue: null
    },
    setValidityData: NOOP,
    disabled: void 0,
    touched: DEFAULT_FIELD_STATE_ATTRIBUTES.touched,
    setTouched: NOOP,
    dirty: DEFAULT_FIELD_STATE_ATTRIBUTES.dirty,
    setDirty: NOOP,
    filled: DEFAULT_FIELD_STATE_ATTRIBUTES.filled,
    setFilled: NOOP,
    focused: DEFAULT_FIELD_STATE_ATTRIBUTES.focused,
    setFocused: NOOP,
    validate: () => null,
    validationMode: "onSubmit",
    validationDebounceTime: 0,
    shouldValidateOnChange: () => false,
    state: DEFAULT_FIELD_ROOT_STATE,
    markedDirtyRef: {
      current: false
    },
    validation: {
      getValidationProps: (props = EMPTY_OBJECT) => props,
      getInputValidationProps: (props = EMPTY_OBJECT) => props,
      inputRef: {
        current: null
      },
      commit: async () => {
      }
    }
  });
  if (true) FieldRootContext.displayName = "FieldRootContext";
  function useFieldRootContext(optional = true) {
    const context = React105.useContext(FieldRootContext);
    if (context.setValidityData === NOOP && !optional) {
      throw new Error(true ? "Base UI: FieldRootContext is missing. Field parts must be placed within <Field.Root>." : formatErrorMessage_default(28));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/fieldset/root/FieldsetRootContext.js
  init_define_import_meta_env();
  var React106 = __toESM(require_react_shim(), 1);
  var FieldsetRootContext = /* @__PURE__ */ React106.createContext({
    legendId: void 0,
    setLegendId: () => {
    },
    disabled: void 0
  });
  if (true) FieldsetRootContext.displayName = "FieldsetRootContext";
  function useFieldsetRootContext(optional = false) {
    const context = React106.useContext(FieldsetRootContext);
    if (!context && !optional) {
      throw new Error(true ? "Base UI: FieldsetRootContext is missing. Fieldset parts must be placed within <Fieldset.Root>." : formatErrorMessage_default(86));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/form/FormContext.js
  init_define_import_meta_env();
  var React107 = __toESM(require_react_shim(), 1);
  var FormContext = /* @__PURE__ */ React107.createContext({
    formRef: {
      current: {
        fields: /* @__PURE__ */ new Map()
      }
    },
    errors: {},
    clearErrors: NOOP,
    validationMode: "onSubmit",
    submitAttemptedRef: {
      current: false
    }
  });
  if (true) FormContext.displayName = "FormContext";
  function useFormContext() {
    return React107.useContext(FormContext);
  }

  // node_modules/@base-ui/react/esm/labelable-provider/LabelableProvider.js
  init_define_import_meta_env();
  var React109 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js
  init_define_import_meta_env();
  var React108 = __toESM(require_react_shim(), 1);
  var LabelableContext = /* @__PURE__ */ React108.createContext({
    controlId: void 0,
    registerControlId: NOOP,
    labelId: void 0,
    setLabelId: NOOP,
    messageIds: [],
    setMessageIds: NOOP,
    getDescriptionProps: (externalProps) => externalProps
  });
  if (true) LabelableContext.displayName = "LabelableContext";
  function useLabelableContext() {
    return React108.useContext(LabelableContext);
  }

  // node_modules/@base-ui/react/esm/labelable-provider/LabelableProvider.js
  var import_jsx_runtime28 = __toESM(require_react_shim(), 1);
  var LabelableProvider = function LabelableProvider2(props) {
    const defaultId = useBaseUiId();
    const initialControlId = props.controlId === void 0 ? defaultId : props.controlId;
    const [controlId, setControlIdState] = React109.useState(initialControlId);
    const [labelId, setLabelId] = React109.useState(props.labelId);
    const [messageIds, setMessageIds] = React109.useState([]);
    const registrationsRef = useRefWithInit(() => /* @__PURE__ */ new Map());
    const {
      messageIds: parentMessageIds
    } = useLabelableContext();
    const registerControlId = useStableCallback((source, nextId) => {
      const registrations = registrationsRef.current;
      if (nextId === void 0) {
        registrations.delete(source);
        return;
      }
      registrations.set(source, nextId);
      setControlIdState((prev) => {
        if (registrations.size === 0) {
          return void 0;
        }
        let nextControlId;
        for (const id of registrations.values()) {
          if (prev !== void 0 && id === prev) {
            return prev;
          }
          if (nextControlId === void 0) {
            nextControlId = id;
          }
        }
        return nextControlId;
      });
    });
    const getDescriptionProps = React109.useCallback((externalProps) => {
      return mergeProps({
        "aria-describedby": parentMessageIds.concat(messageIds).join(" ") || void 0
      }, externalProps);
    }, [parentMessageIds, messageIds]);
    const contextValue = React109.useMemo(() => ({
      controlId,
      registerControlId,
      labelId,
      setLabelId,
      messageIds,
      setMessageIds,
      getDescriptionProps
    }), [controlId, registerControlId, labelId, setLabelId, messageIds, setMessageIds, getDescriptionProps]);
    return /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(LabelableContext.Provider, {
      value: contextValue,
      children: props.children
    });
  };
  if (true) LabelableProvider.displayName = "LabelableProvider";

  // node_modules/@base-ui/react/esm/field/root/useFieldValidation.js
  init_define_import_meta_env();
  var React110 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/field/utils/getCombinedFieldValidityData.js
  init_define_import_meta_env();
  function getCombinedFieldValidityData(validityData, invalid) {
    return {
      ...validityData,
      state: {
        ...validityData.state,
        valid: !invalid && validityData.state.valid
      }
    };
  }

  // node_modules/@base-ui/react/esm/field/root/useFieldValidation.js
  var validityKeys = Object.keys(DEFAULT_VALIDITY_STATE);
  function isOnlyValueMissing(state) {
    if (!state || state.valid || !state.valueMissing) {
      return false;
    }
    let onlyValueMissing = false;
    for (const key of validityKeys) {
      if (key === "valid") {
        continue;
      }
      if (key === "valueMissing") {
        onlyValueMissing = state[key];
      }
      if (state[key]) {
        onlyValueMissing = false;
      }
    }
    return onlyValueMissing;
  }
  function useFieldValidation(params) {
    const {
      formRef,
      clearErrors
    } = useFormContext();
    const {
      setValidityData,
      validate,
      validityData,
      validationDebounceTime,
      invalid,
      markedDirtyRef,
      state,
      name,
      shouldValidateOnChange
    } = params;
    const {
      controlId,
      getDescriptionProps
    } = useLabelableContext();
    const timeout = useTimeout();
    const inputRef = React110.useRef(null);
    const commit = useStableCallback(async (value, revalidate = false) => {
      const element = inputRef.current;
      if (!element) {
        return;
      }
      if (revalidate) {
        if (state.valid !== false) {
          return;
        }
        const currentNativeValidity = element.validity;
        if (!currentNativeValidity.valueMissing) {
          const nextValidityData2 = {
            value,
            state: {
              ...DEFAULT_VALIDITY_STATE,
              valid: true
            },
            error: "",
            errors: [],
            initialValue: validityData.initialValue
          };
          element.setCustomValidity("");
          if (controlId) {
            const currentFieldData = formRef.current.fields.get(controlId);
            if (currentFieldData) {
              formRef.current.fields.set(controlId, {
                ...currentFieldData,
                ...getCombinedFieldValidityData(nextValidityData2, false)
                // invalid = false
              });
            }
          }
          setValidityData(nextValidityData2);
          return;
        }
        const currentNativeValidityObject = validityKeys.reduce((acc, key) => {
          acc[key] = currentNativeValidity[key];
          return acc;
        }, {});
        if (!currentNativeValidityObject.valid && !isOnlyValueMissing(currentNativeValidityObject)) {
          return;
        }
      }
      function getState(el) {
        const computedState = validityKeys.reduce((acc, key) => {
          acc[key] = el.validity[key];
          return acc;
        }, {});
        let hasOnlyValueMissingError = false;
        for (const key of validityKeys) {
          if (key === "valid") {
            continue;
          }
          if (key === "valueMissing" && computedState[key]) {
            hasOnlyValueMissingError = true;
          } else if (computedState[key]) {
            return computedState;
          }
        }
        if (hasOnlyValueMissingError && !markedDirtyRef.current) {
          computedState.valid = true;
          computedState.valueMissing = false;
        }
        return computedState;
      }
      timeout.clear();
      let result = null;
      let validationErrors = [];
      const nextState = getState(element);
      let defaultValidationMessage;
      const validateOnChange = shouldValidateOnChange();
      if (element.validationMessage && !validateOnChange) {
        defaultValidationMessage = element.validationMessage;
        validationErrors = [element.validationMessage];
      } else {
        const formValues = Array.from(formRef.current.fields.values()).reduce((acc, field) => {
          if (field.name) {
            acc[field.name] = field.getValue();
          }
          return acc;
        }, {});
        const resultOrPromise = validate(value, formValues);
        if (typeof resultOrPromise === "object" && resultOrPromise !== null && "then" in resultOrPromise) {
          result = await resultOrPromise;
        } else {
          result = resultOrPromise;
        }
        if (result !== null) {
          nextState.valid = false;
          nextState.customError = true;
          if (Array.isArray(result)) {
            validationErrors = result;
            element.setCustomValidity(result.join("\n"));
          } else if (result) {
            validationErrors = [result];
            element.setCustomValidity(result);
          }
        } else if (validateOnChange) {
          element.setCustomValidity("");
          nextState.customError = false;
          if (element.validationMessage) {
            defaultValidationMessage = element.validationMessage;
            validationErrors = [element.validationMessage];
          } else if (element.validity.valid && !nextState.valid) {
            nextState.valid = true;
          }
        }
      }
      const nextValidityData = {
        value,
        state: nextState,
        error: defaultValidationMessage ?? (Array.isArray(result) ? result[0] : result ?? ""),
        errors: validationErrors,
        initialValue: validityData.initialValue
      };
      if (controlId) {
        const currentFieldData = formRef.current.fields.get(controlId);
        if (currentFieldData) {
          formRef.current.fields.set(controlId, {
            ...currentFieldData,
            // Keep Form-level errors part of overall field validity for submit blocking/focus logic.
            ...getCombinedFieldValidityData(nextValidityData, invalid)
          });
        }
      }
      setValidityData(nextValidityData);
    });
    const getValidationProps = React110.useCallback((externalProps = {}) => mergeProps(getDescriptionProps, state.valid === false ? {
      "aria-invalid": true
    } : EMPTY_OBJECT, externalProps), [getDescriptionProps, state.valid]);
    const getInputValidationProps = React110.useCallback((externalProps = {}) => mergeProps({
      onChange(event) {
        if (event.nativeEvent.defaultPrevented) {
          return;
        }
        clearErrors(name);
        if (!shouldValidateOnChange()) {
          commit(event.currentTarget.value, true);
          return;
        }
        const element = event.currentTarget;
        if (element.value === "") {
          commit(element.value);
          return;
        }
        timeout.clear();
        if (validationDebounceTime) {
          timeout.start(validationDebounceTime, () => {
            commit(element.value);
          });
        } else {
          commit(element.value);
        }
      }
    }, getValidationProps(externalProps)), [getValidationProps, clearErrors, name, timeout, commit, validationDebounceTime, shouldValidateOnChange]);
    return React110.useMemo(() => ({
      getValidationProps,
      getInputValidationProps,
      inputRef,
      commit
    }), [getValidationProps, getInputValidationProps, commit]);
  }

  // node_modules/@base-ui/react/esm/field/root/FieldRoot.js
  var import_jsx_runtime29 = __toESM(require_react_shim(), 1);
  var FieldRootInner = /* @__PURE__ */ React111.forwardRef(function FieldRootInner2(componentProps, forwardedRef) {
    const {
      errors,
      validationMode: formValidationMode,
      submitAttemptedRef
    } = useFormContext();
    const {
      render,
      className,
      validate: validateProp,
      validationDebounceTime = 0,
      validationMode = formValidationMode,
      name,
      disabled: disabledProp = false,
      invalid: invalidProp,
      dirty: dirtyProp,
      touched: touchedProp,
      actionsRef,
      ...elementProps
    } = componentProps;
    const {
      disabled: disabledFieldset
    } = useFieldsetRootContext();
    const validate = useStableCallback(validateProp || (() => null));
    const disabled2 = disabledFieldset || disabledProp;
    const [touchedState, setTouchedUnwrapped] = React111.useState(false);
    const [dirtyState, setDirtyUnwrapped] = React111.useState(false);
    const [filled, setFilled] = React111.useState(false);
    const [focused, setFocused] = React111.useState(false);
    const dirty = dirtyProp ?? dirtyState;
    const touched = touchedProp ?? touchedState;
    const markedDirtyRef = React111.useRef(false);
    const setDirty = useStableCallback((value) => {
      if (dirtyProp !== void 0) {
        return;
      }
      if (value) {
        markedDirtyRef.current = true;
      }
      setDirtyUnwrapped(value);
    });
    const setTouched = useStableCallback((value) => {
      if (touchedProp !== void 0) {
        return;
      }
      setTouchedUnwrapped(value);
    });
    const shouldValidateOnChange = useStableCallback(() => validationMode === "onChange" || validationMode === "onSubmit" && submitAttemptedRef.current);
    const hasFormError = !!name && Object.hasOwn(errors, name) && errors[name] !== void 0;
    const invalid = invalidProp === true || hasFormError;
    const [validityData, setValidityData] = React111.useState({
      state: DEFAULT_VALIDITY_STATE,
      error: "",
      errors: [],
      value: null,
      initialValue: null
    });
    const valid = !invalid && validityData.state.valid;
    const state = React111.useMemo(() => ({
      disabled: disabled2,
      touched,
      dirty,
      valid,
      filled,
      focused
    }), [disabled2, touched, dirty, valid, filled, focused]);
    const validation = useFieldValidation({
      setValidityData,
      validate,
      validityData,
      validationDebounceTime,
      invalid,
      markedDirtyRef,
      state,
      name,
      shouldValidateOnChange
    });
    const handleImperativeValidate = React111.useCallback(() => {
      markedDirtyRef.current = true;
      validation.commit(validityData.value);
    }, [validation, validityData]);
    React111.useImperativeHandle(actionsRef, () => ({
      validate: handleImperativeValidate
    }), [handleImperativeValidate]);
    const contextValue = React111.useMemo(() => ({
      invalid,
      name,
      validityData,
      setValidityData,
      disabled: disabled2,
      touched,
      setTouched,
      dirty,
      setDirty,
      filled,
      setFilled,
      focused,
      setFocused,
      validate,
      validationMode,
      validationDebounceTime,
      shouldValidateOnChange,
      state,
      markedDirtyRef,
      validation
    }), [invalid, name, validityData, disabled2, touched, setTouched, dirty, setDirty, filled, setFilled, focused, setFocused, validate, validationMode, validationDebounceTime, shouldValidateOnChange, state, validation]);
    const element = useRenderElement("div", componentProps, {
      ref: forwardedRef,
      state,
      props: elementProps,
      stateAttributesMapping: fieldValidityMapping
    });
    return /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(FieldRootContext.Provider, {
      value: contextValue,
      children: element
    });
  });
  if (true) FieldRootInner.displayName = "FieldRootInner";
  var FieldRoot = /* @__PURE__ */ React111.forwardRef(function FieldRoot2(componentProps, forwardedRef) {
    return /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(LabelableProvider, {
      children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(FieldRootInner, {
        ...componentProps,
        ref: forwardedRef
      })
    });
  });
  if (true) FieldRoot.displayName = "FieldRoot";

  // node_modules/@base-ui/react/esm/field/label/FieldLabel.js
  init_define_import_meta_env();
  var React112 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/labelable-provider/useLabel.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/useRegisteredLabelId.js
  init_define_import_meta_env();
  function useRegisteredLabelId(idProp, setLabelId) {
    const id = useBaseUiId(idProp);
    useIsoLayoutEffect(() => {
      setLabelId(id);
      return () => {
        setLabelId(void 0);
      };
    }, [id, setLabelId]);
    return id;
  }

  // node_modules/@base-ui/react/esm/labelable-provider/useLabel.js
  function useLabel(params = {}) {
    const {
      id: idProp,
      fallbackControlId,
      native = false,
      setLabelId: setLabelIdProp,
      focusControl: focusControlProp
    } = params;
    const {
      controlId: contextControlId,
      setLabelId: setContextLabelId
    } = useLabelableContext();
    const syncLabelId = useStableCallback((nextLabelId) => {
      setContextLabelId(nextLabelId);
      setLabelIdProp?.(nextLabelId);
    });
    const id = useRegisteredLabelId(idProp, syncLabelId);
    const resolvedControlId = contextControlId ?? fallbackControlId;
    function focusControl(event) {
      if (focusControlProp) {
        focusControlProp(event, resolvedControlId);
        return;
      }
      if (!resolvedControlId) {
        return;
      }
      const controlElement = ownerDocument(event.currentTarget).getElementById(resolvedControlId);
      if (isHTMLElement(controlElement)) {
        focusElementWithVisible(controlElement);
      }
    }
    function handleInteraction(event) {
      const target = getTarget(event.nativeEvent);
      if (target?.closest("button,input,select,textarea")) {
        return;
      }
      if (!event.defaultPrevented && event.detail > 1) {
        event.preventDefault();
      }
      if (native) {
        return;
      }
      focusControl(event);
    }
    return native ? {
      id,
      htmlFor: resolvedControlId ?? void 0,
      onMouseDown: handleInteraction
    } : {
      id,
      onClick: handleInteraction,
      onPointerDown(event) {
        event.preventDefault();
      }
    };
  }
  function focusElementWithVisible(element) {
    element.focus({
      // Available from Chrome 144+ (January 2026).
      // Safari and Firefox already support it.
      // @ts-expect-error not available in types yet
      focusVisible: true
    });
  }

  // node_modules/@base-ui/react/esm/field/label/FieldLabel.js
  var FieldLabel = /* @__PURE__ */ React112.forwardRef(function FieldLabel2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      nativeLabel = true,
      ...elementProps
    } = componentProps;
    const fieldRootContext = useFieldRootContext(false);
    const {
      labelId
    } = useLabelableContext();
    const labelRef = React112.useRef(null);
    const labelProps = useLabel({
      id: labelId ?? idProp,
      native: nativeLabel
    });
    if (true) {
      React112.useEffect(() => {
        if (!labelRef.current) {
          return;
        }
        const isLabelTag = labelRef.current.tagName === "LABEL";
        if (nativeLabel) {
          if (!isLabelTag) {
            const ownerStackMessage = SafeReact.captureOwnerStack?.() || "";
            const message = "<Field.Label> expected a <label> element because the `nativeLabel` prop is true. Rendering a non-<label> disables native label association, so `htmlFor` will not work. Use a real <label> in the `render` prop, or set `nativeLabel` to `false`.";
            error(`${message}${ownerStackMessage}`);
          }
        } else if (isLabelTag) {
          const ownerStackMessage = SafeReact.captureOwnerStack?.() || "";
          const message = "<Field.Label> expected a non-<label> element because the `nativeLabel` prop is false. Rendering a <label> assumes native label behavior while Base UI treats it as non-native, which can cause unexpected pointer behavior. Use a non-<label> in the `render` prop, or set `nativeLabel` to `true`.";
          error(`${message}${ownerStackMessage}`);
        }
      }, [nativeLabel]);
    }
    const element = useRenderElement("label", componentProps, {
      ref: [forwardedRef, labelRef],
      state: fieldRootContext.state,
      props: [labelProps, elementProps],
      stateAttributesMapping: fieldValidityMapping
    });
    return element;
  });
  if (true) FieldLabel.displayName = "FieldLabel";

  // node_modules/@base-ui/react/esm/field/error/FieldError.js
  init_define_import_meta_env();
  var React113 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime30 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping8 = {
    ...fieldValidityMapping,
    ...transitionStatusMapping
  };
  var FieldError = /* @__PURE__ */ React113.forwardRef(function FieldError2(componentProps, forwardedRef) {
    const {
      render,
      id: idProp,
      className,
      match,
      ...elementProps
    } = componentProps;
    const id = useBaseUiId(idProp);
    const {
      validityData,
      state: fieldState,
      name
    } = useFieldRootContext(false);
    const {
      setMessageIds
    } = useLabelableContext();
    const {
      errors
    } = useFormContext();
    const formError = name ? errors[name] : null;
    let rendered = false;
    if (formError || match === true) {
      rendered = true;
    } else if (match) {
      rendered = Boolean(validityData.state[match]);
    } else {
      rendered = validityData.state.valid === false;
    }
    const {
      mounted,
      transitionStatus,
      setMounted
    } = useTransitionStatus(rendered);
    useIsoLayoutEffect(() => {
      if (!rendered || !id) {
        return void 0;
      }
      setMessageIds((v) => v.concat(id));
      return () => {
        setMessageIds((v) => v.filter((item) => item !== id));
      };
    }, [rendered, id, setMessageIds]);
    const errorRef = React113.useRef(null);
    const [lastRenderedMessage, setLastRenderedMessage] = React113.useState(null);
    const [lastRenderedMessageKey, setLastRenderedMessageKey] = React113.useState(null);
    const errorMessage = formError || (validityData.errors.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("ul", {
      children: validityData.errors.map((message) => /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("li", {
        children: message
      }, message))
    }) : validityData.error);
    let errorKey = validityData.error;
    if (formError != null) {
      errorKey = Array.isArray(formError) ? JSON.stringify(formError) : formError;
    } else if (validityData.errors.length > 1) {
      errorKey = JSON.stringify(validityData.errors);
    }
    if (rendered && errorKey !== lastRenderedMessageKey) {
      setLastRenderedMessageKey(errorKey);
      setLastRenderedMessage(errorMessage);
    }
    useOpenChangeComplete({
      open: rendered,
      ref: errorRef,
      onComplete() {
        if (!rendered) {
          setMounted(false);
        }
      }
    });
    const state = {
      ...fieldState,
      transitionStatus
    };
    const element = useRenderElement("div", componentProps, {
      ref: [forwardedRef, errorRef],
      state,
      props: [{
        id,
        children: rendered ? errorMessage : lastRenderedMessage
      }, elementProps],
      stateAttributesMapping: stateAttributesMapping8,
      enabled: mounted
    });
    if (!mounted) {
      return null;
    }
    return element;
  });
  if (true) FieldError.displayName = "FieldError";

  // node_modules/@base-ui/react/esm/field/description/FieldDescription.js
  init_define_import_meta_env();
  var React114 = __toESM(require_react_shim(), 1);
  var FieldDescription = /* @__PURE__ */ React114.forwardRef(function FieldDescription2(componentProps, forwardedRef) {
    const {
      render,
      id: idProp,
      className,
      ...elementProps
    } = componentProps;
    const id = useBaseUiId(idProp);
    const fieldRootContext = useFieldRootContext(false);
    const {
      setMessageIds
    } = useLabelableContext();
    useIsoLayoutEffect(() => {
      if (!id) {
        return void 0;
      }
      setMessageIds((v) => v.concat(id));
      return () => {
        setMessageIds((v) => v.filter((item) => item !== id));
      };
    }, [id, setMessageIds]);
    const element = useRenderElement("p", componentProps, {
      ref: forwardedRef,
      state: fieldRootContext.state,
      props: [{
        id
      }, elementProps],
      stateAttributesMapping: fieldValidityMapping
    });
    return element;
  });
  if (true) FieldDescription.displayName = "FieldDescription";

  // node_modules/@base-ui/react/esm/field/control/FieldControl.js
  init_define_import_meta_env();
  var React116 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/labelable-provider/useLabelableId.js
  init_define_import_meta_env();
  var React115 = __toESM(require_react_shim(), 1);
  function useLabelableId(params = {}) {
    const {
      id,
      implicit = false,
      controlRef
    } = params;
    const {
      controlId,
      registerControlId
    } = useLabelableContext();
    const defaultId = useBaseUiId(id);
    const controlIdForEffect = implicit ? controlId : void 0;
    const controlSourceRef = useRefWithInit(() => /* @__PURE__ */ Symbol("labelable-control"));
    const hasRegisteredRef = React115.useRef(false);
    const hadExplicitIdRef = React115.useRef(id != null);
    const unregisterControlId = useStableCallback(() => {
      if (!hasRegisteredRef.current || registerControlId === NOOP) {
        return;
      }
      hasRegisteredRef.current = false;
      registerControlId(controlSourceRef.current, void 0);
    });
    useIsoLayoutEffect(() => {
      if (registerControlId === NOOP) {
        return void 0;
      }
      let nextId;
      if (implicit) {
        const elem = controlRef?.current;
        if (isElement(elem) && elem.closest("label") != null) {
          nextId = id ?? null;
        } else {
          nextId = controlIdForEffect ?? defaultId;
        }
      } else if (id != null) {
        hadExplicitIdRef.current = true;
        nextId = id;
      } else if (hadExplicitIdRef.current) {
        nextId = defaultId;
      } else {
        unregisterControlId();
        return void 0;
      }
      if (nextId === void 0) {
        unregisterControlId();
        return void 0;
      }
      hasRegisteredRef.current = true;
      registerControlId(controlSourceRef.current, nextId);
      return void 0;
    }, [id, controlRef, controlIdForEffect, registerControlId, implicit, defaultId, controlSourceRef, unregisterControlId]);
    React115.useEffect(() => {
      return unregisterControlId;
    }, [unregisterControlId]);
    return controlId ?? defaultId;
  }

  // node_modules/@base-ui/react/esm/field/useField.js
  init_define_import_meta_env();
  var ReactDOM7 = __toESM(require_react_dom_shim(), 1);
  function useField(params) {
    const {
      enabled = true,
      value,
      id,
      name,
      controlRef,
      commit
    } = params;
    const {
      formRef
    } = useFormContext();
    const {
      invalid,
      markedDirtyRef,
      validityData,
      setValidityData
    } = useFieldRootContext();
    const getValue = useStableCallback(params.getValue);
    useIsoLayoutEffect(() => {
      if (!enabled) {
        return;
      }
      let initialValue = value;
      if (initialValue === void 0) {
        initialValue = getValue();
      }
      if (validityData.initialValue === null && initialValue !== null) {
        setValidityData((prev) => ({
          ...prev,
          initialValue
        }));
      }
    }, [enabled, setValidityData, value, validityData.initialValue, getValue]);
    useIsoLayoutEffect(() => {
      if (!enabled || !id) {
        return;
      }
      formRef.current.fields.set(id, {
        getValue,
        name,
        controlRef,
        validityData: getCombinedFieldValidityData(validityData, invalid),
        validate(flushSync9 = true) {
          let nextValue = value;
          if (nextValue === void 0) {
            nextValue = getValue();
          }
          markedDirtyRef.current = true;
          if (!flushSync9) {
            commit(nextValue);
          } else {
            ReactDOM7.flushSync(() => commit(nextValue));
          }
        }
      });
    }, [commit, controlRef, enabled, formRef, getValue, id, invalid, markedDirtyRef, name, validityData, value]);
    useIsoLayoutEffect(() => {
      const fields = formRef.current.fields;
      return () => {
        if (id) {
          fields.delete(id);
        }
      };
    }, [formRef, id]);
  }

  // node_modules/@base-ui/react/esm/field/control/FieldControl.js
  var FieldControl = /* @__PURE__ */ React116.forwardRef(function FieldControl2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      name: nameProp,
      value: valueProp,
      disabled: disabledProp = false,
      onValueChange,
      defaultValue,
      autoFocus = false,
      ...elementProps
    } = componentProps;
    const {
      state: fieldState,
      name: fieldName,
      disabled: fieldDisabled,
      setTouched,
      setDirty,
      validityData,
      setFocused,
      setFilled,
      validationMode,
      validation
    } = useFieldRootContext();
    const disabled2 = fieldDisabled || disabledProp;
    const name = fieldName ?? nameProp;
    const state = {
      ...fieldState,
      disabled: disabled2
    };
    const {
      labelId
    } = useLabelableContext();
    const id = useLabelableId({
      id: idProp
    });
    useIsoLayoutEffect(() => {
      const hasExternalValue = valueProp != null;
      if (validation.inputRef.current?.value || hasExternalValue && valueProp !== "") {
        setFilled(true);
      } else if (hasExternalValue && valueProp === "") {
        setFilled(false);
      }
    }, [validation.inputRef, setFilled, valueProp]);
    const inputRef = React116.useRef(null);
    useIsoLayoutEffect(() => {
      if (autoFocus && inputRef.current === activeElement(ownerDocument(inputRef.current))) {
        setFocused(true);
      }
    }, [autoFocus, setFocused]);
    const [valueUnwrapped] = useControlled({
      controlled: valueProp,
      default: defaultValue,
      name: "FieldControl",
      state: "value"
    });
    const isControlled = valueProp !== void 0;
    const value = isControlled ? valueUnwrapped : void 0;
    useField({
      id,
      name,
      commit: validation.commit,
      value,
      getValue: () => validation.inputRef.current?.value,
      controlRef: validation.inputRef
    });
    const element = useRenderElement("input", componentProps, {
      ref: [forwardedRef, inputRef],
      state,
      props: [{
        id,
        disabled: disabled2,
        name,
        ref: validation.inputRef,
        "aria-labelledby": labelId,
        autoFocus,
        ...isControlled ? {
          value
        } : {
          defaultValue
        },
        onChange(event) {
          const inputValue = event.currentTarget.value;
          onValueChange?.(inputValue, createChangeEventDetails(reason_parts_exports.none, event.nativeEvent));
          setDirty(inputValue !== validityData.initialValue);
          setFilled(inputValue !== "");
        },
        onFocus() {
          setFocused(true);
        },
        onBlur(event) {
          setTouched(true);
          setFocused(false);
          if (validationMode === "onBlur") {
            validation.commit(event.currentTarget.value);
          }
        },
        onKeyDown(event) {
          if (event.currentTarget.tagName === "INPUT" && event.key === "Enter") {
            setTouched(true);
            validation.commit(event.currentTarget.value);
          }
        }
      }, validation.getInputValidationProps(), elementProps],
      stateAttributesMapping: fieldValidityMapping
    });
    return element;
  });
  if (true) FieldControl.displayName = "FieldControl";

  // node_modules/@base-ui/react/esm/field/validity/FieldValidity.js
  init_define_import_meta_env();
  var React117 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime31 = __toESM(require_react_shim(), 1);
  var FieldValidity = function FieldValidity2(props) {
    const {
      children
    } = props;
    const {
      validityData,
      invalid
    } = useFieldRootContext(false);
    const combinedFieldValidityData = React117.useMemo(() => getCombinedFieldValidityData(validityData, invalid), [validityData, invalid]);
    const isInvalid = combinedFieldValidityData.state.valid === false;
    const {
      transitionStatus
    } = useTransitionStatus(isInvalid);
    const fieldValidityState = React117.useMemo(() => {
      return {
        ...combinedFieldValidityData,
        validity: combinedFieldValidityData.state,
        transitionStatus
      };
    }, [combinedFieldValidityData, transitionStatus]);
    return /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(React117.Fragment, {
      children: children(fieldValidityState)
    });
  };
  if (true) FieldValidity.displayName = "FieldValidity";

  // node_modules/@base-ui/react/esm/field/item/FieldItem.js
  init_define_import_meta_env();
  var React120 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/field/item/FieldItemContext.js
  init_define_import_meta_env();
  var React118 = __toESM(require_react_shim(), 1);
  var FieldItemContext = /* @__PURE__ */ React118.createContext({
    disabled: false
  });
  if (true) FieldItemContext.displayName = "FieldItemContext";

  // node_modules/@base-ui/react/esm/checkbox-group/CheckboxGroupContext.js
  init_define_import_meta_env();
  var React119 = __toESM(require_react_shim(), 1);
  var CheckboxGroupContext = /* @__PURE__ */ React119.createContext(void 0);
  if (true) CheckboxGroupContext.displayName = "CheckboxGroupContext";
  function useCheckboxGroupContext(optional = true) {
    const context = React119.useContext(CheckboxGroupContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: CheckboxGroupContext is missing. CheckboxGroup parts must be placed within <CheckboxGroup>." : formatErrorMessage_default(3));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/field/item/FieldItem.js
  var import_jsx_runtime32 = __toESM(require_react_shim(), 1);
  var FieldItem = /* @__PURE__ */ React120.forwardRef(function FieldItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      disabled: disabledProp = false,
      ...elementProps
    } = componentProps;
    const {
      state,
      disabled: rootDisabled
    } = useFieldRootContext(false);
    const disabled2 = rootDisabled || disabledProp;
    const checkboxGroupContext = useCheckboxGroupContext();
    const parentId = checkboxGroupContext?.parent.id;
    const hasParentCheckbox = checkboxGroupContext?.allValues !== void 0;
    const controlId = hasParentCheckbox ? parentId : void 0;
    const fieldItemContext = React120.useMemo(() => ({
      disabled: disabled2
    }), [disabled2]);
    const element = useRenderElement("div", componentProps, {
      ref: forwardedRef,
      state,
      props: elementProps,
      stateAttributesMapping: fieldValidityMapping
    });
    return /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(LabelableProvider, {
      controlId,
      children: /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(FieldItemContext.Provider, {
        value: fieldItemContext,
        children: element
      })
    });
  });
  if (true) FieldItem.displayName = "FieldItem";

  // node_modules/@base-ui/react/esm/input/Input.js
  var import_jsx_runtime33 = __toESM(require_react_shim(), 1);
  var Input = /* @__PURE__ */ React121.forwardRef(function Input2(props, forwardedRef) {
    return /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(index_parts_exports4.Control, {
      ref: forwardedRef,
      ...props
    });
  });
  if (true) Input.displayName = "Input";

  // src/components/ui/input.tsx
  var import_jsx_runtime34 = __toESM(require_react_shim(), 1);
  function Input3({ className, type, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(
      Input,
      {
        type,
        "data-slot": "input",
        className: cn(
          "h-8 w-full min-w-0 rounded-lg border border-input bg-transparent px-2.5 py-1 text-base transition-colors outline-none file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 md:text-sm dark:bg-input/30 dark:disabled:bg-input/80 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/label.tsx
  init_define_import_meta_env();
  var import_jsx_runtime35 = __toESM(require_react_shim(), 1);
  function Label({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(
      "label",
      {
        "data-slot": "label",
        className: cn(
          "flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/select.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/select/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/select/index.parts.js
  var index_parts_exports5 = {};
  __export(index_parts_exports5, {
    Arrow: () => SelectArrow,
    Backdrop: () => SelectBackdrop,
    Group: () => SelectGroup,
    GroupLabel: () => SelectGroupLabel,
    Icon: () => SelectIcon,
    Item: () => SelectItem,
    ItemIndicator: () => SelectItemIndicator,
    ItemText: () => SelectItemText,
    Label: () => SelectLabel,
    List: () => SelectList,
    Popup: () => SelectPopup,
    Portal: () => SelectPortal,
    Positioner: () => SelectPositioner,
    Root: () => SelectRoot,
    ScrollDownArrow: () => SelectScrollDownArrow,
    ScrollUpArrow: () => SelectScrollUpArrow,
    Separator: () => Separator,
    Trigger: () => SelectTrigger,
    Value: () => SelectValue
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/select/root/SelectRoot.js
  init_define_import_meta_env();
  var React124 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/root/SelectRootContext.js
  init_define_import_meta_env();
  var React122 = __toESM(require_react_shim(), 1);
  var SelectRootContext = /* @__PURE__ */ React122.createContext(null);
  if (true) SelectRootContext.displayName = "SelectRootContext";
  var SelectFloatingContext = /* @__PURE__ */ React122.createContext(null);
  if (true) SelectFloatingContext.displayName = "SelectFloatingContext";
  function useSelectRootContext() {
    const context = React122.useContext(SelectRootContext);
    if (context === null) {
      throw new Error(true ? "Base UI: SelectRootContext is missing. Select parts must be placed within <Select.Root>." : formatErrorMessage_default(60));
    }
    return context;
  }
  function useSelectFloatingContext() {
    const context = React122.useContext(SelectFloatingContext);
    if (context === null) {
      throw new Error(true ? "Base UI: SelectFloatingContext is missing. Select parts must be placed within <Select.Root>." : formatErrorMessage_default(61));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/select/store.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/utils/itemEquality.js
  init_define_import_meta_env();
  var defaultItemEquality = (itemValue, selectedValue) => Object.is(itemValue, selectedValue);
  function compareItemEquality(itemValue, selectedValue, comparer) {
    if (itemValue == null || selectedValue == null) {
      return Object.is(itemValue, selectedValue);
    }
    return comparer(itemValue, selectedValue);
  }
  function selectedValueIncludes(selectedValues, itemValue, comparer) {
    if (!selectedValues || selectedValues.length === 0) {
      return false;
    }
    return selectedValues.some((selectedValue) => {
      if (selectedValue === void 0) {
        return false;
      }
      return compareItemEquality(itemValue, selectedValue, comparer);
    });
  }
  function findItemIndex(itemValues, selectedValue, comparer) {
    if (!itemValues || itemValues.length === 0) {
      return -1;
    }
    return itemValues.findIndex((itemValue) => {
      if (itemValue === void 0) {
        return false;
      }
      return compareItemEquality(itemValue, selectedValue, comparer);
    });
  }
  function removeItem(selectedValues, itemValue, comparer) {
    return selectedValues.filter((selectedValue) => !compareItemEquality(itemValue, selectedValue, comparer));
  }

  // node_modules/@base-ui/react/esm/utils/resolveValueLabel.js
  init_define_import_meta_env();
  var React123 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/serializeValue.js
  init_define_import_meta_env();
  function serializeValue(value) {
    if (value == null) {
      return "";
    }
    if (typeof value === "string") {
      return value;
    }
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }

  // node_modules/@base-ui/react/esm/utils/resolveValueLabel.js
  var import_jsx_runtime36 = __toESM(require_react_shim(), 1);
  function isGroupedItems(items) {
    return items != null && items.length > 0 && typeof items[0] === "object" && items[0] != null && "items" in items[0];
  }
  function hasNullItemLabel(items) {
    if (!Array.isArray(items)) {
      return items != null && "null" in items;
    }
    const arrayItems = items;
    if (isGroupedItems(arrayItems)) {
      for (const group of arrayItems) {
        for (const item of group.items) {
          if (item && item.value == null && item.label != null) {
            return true;
          }
        }
      }
      return false;
    }
    for (const item of arrayItems) {
      if (item && item.value == null && item.label != null) {
        return true;
      }
    }
    return false;
  }
  function stringifyAsLabel(item, itemToStringLabel) {
    if (itemToStringLabel && item != null) {
      return itemToStringLabel(item) ?? "";
    }
    if (item && typeof item === "object") {
      if ("label" in item && item.label != null) {
        return String(item.label);
      }
      if ("value" in item) {
        return String(item.value);
      }
    }
    return serializeValue(item);
  }
  function stringifyAsValue(item, itemToStringValue) {
    if (itemToStringValue && item != null) {
      return itemToStringValue(item) ?? "";
    }
    if (item && typeof item === "object" && "value" in item && "label" in item) {
      return serializeValue(item.value);
    }
    return serializeValue(item);
  }
  function resolveSelectedLabel(value, items, itemToStringLabel) {
    function fallback() {
      return stringifyAsLabel(value, itemToStringLabel);
    }
    if (itemToStringLabel && value != null) {
      return itemToStringLabel(value);
    }
    if (value && typeof value === "object" && "label" in value && value.label != null) {
      return value.label;
    }
    if (items && !Array.isArray(items)) {
      return items[value] ?? fallback();
    }
    if (Array.isArray(items)) {
      const arrayItems = items;
      const flatItems = isGroupedItems(arrayItems) ? arrayItems.flatMap((group) => group.items) : arrayItems;
      if (value == null || typeof value !== "object") {
        const match = flatItems.find((item) => item.value === value);
        if (match && match.label != null) {
          return match.label;
        }
        return fallback();
      }
      if ("value" in value) {
        const match = flatItems.find((item) => item && item.value === value.value);
        if (match && match.label != null) {
          return match.label;
        }
      }
    }
    return fallback();
  }
  function resolveMultipleLabels(values, items, itemToStringLabel) {
    return values.reduce((acc, value, index2) => {
      if (index2 > 0) {
        acc.push(", ");
      }
      acc.push(/* @__PURE__ */ (0, import_jsx_runtime36.jsx)(React123.Fragment, {
        children: resolveSelectedLabel(value, items, itemToStringLabel)
      }, index2));
      return acc;
    }, []);
  }

  // node_modules/@base-ui/react/esm/select/store.js
  var selectors4 = {
    id: createSelector2((state) => state.id),
    labelId: createSelector2((state) => state.labelId),
    modal: createSelector2((state) => state.modal),
    multiple: createSelector2((state) => state.multiple),
    items: createSelector2((state) => state.items),
    itemToStringLabel: createSelector2((state) => state.itemToStringLabel),
    itemToStringValue: createSelector2((state) => state.itemToStringValue),
    isItemEqualToValue: createSelector2((state) => state.isItemEqualToValue),
    value: createSelector2((state) => state.value),
    hasSelectedValue: createSelector2((state) => {
      const {
        value,
        multiple,
        itemToStringValue
      } = state;
      if (value == null) {
        return false;
      }
      if (multiple && Array.isArray(value)) {
        return value.length > 0;
      }
      return stringifyAsValue(value, itemToStringValue) !== "";
    }),
    hasNullItemLabel: createSelector2((state, enabled) => {
      return enabled ? hasNullItemLabel(state.items) : false;
    }),
    open: createSelector2((state) => state.open),
    mounted: createSelector2((state) => state.mounted),
    forceMount: createSelector2((state) => state.forceMount),
    transitionStatus: createSelector2((state) => state.transitionStatus),
    openMethod: createSelector2((state) => state.openMethod),
    activeIndex: createSelector2((state) => state.activeIndex),
    selectedIndex: createSelector2((state) => state.selectedIndex),
    isActive: createSelector2((state, index2) => state.activeIndex === index2),
    isSelected: createSelector2((state, index2, itemValue) => {
      const comparer = state.isItemEqualToValue;
      const storeValue = state.value;
      if (state.multiple) {
        return Array.isArray(storeValue) && storeValue.some((selectedItem) => compareItemEquality(itemValue, selectedItem, comparer));
      }
      if (state.selectedIndex === index2 && state.selectedIndex !== null) {
        return true;
      }
      return compareItemEquality(itemValue, storeValue, comparer);
    }),
    isSelectedByFocus: createSelector2((state, index2) => {
      return state.selectedIndex === index2;
    }),
    popupProps: createSelector2((state) => state.popupProps),
    triggerProps: createSelector2((state) => state.triggerProps),
    triggerElement: createSelector2((state) => state.triggerElement),
    positionerElement: createSelector2((state) => state.positionerElement),
    listElement: createSelector2((state) => state.listElement),
    scrollUpArrowVisible: createSelector2((state) => state.scrollUpArrowVisible),
    scrollDownArrowVisible: createSelector2((state) => state.scrollDownArrowVisible),
    hasScrollArrows: createSelector2((state) => state.hasScrollArrows)
  };

  // node_modules/@base-ui/react/esm/select/root/SelectRoot.js
  var import_jsx_runtime37 = __toESM(require_react_shim(), 1);
  function SelectRoot(props) {
    const {
      id,
      value: valueProp,
      defaultValue = null,
      onValueChange,
      open: openProp,
      defaultOpen = false,
      onOpenChange,
      name: nameProp,
      autoComplete,
      disabled: disabledProp = false,
      readOnly = false,
      required = false,
      modal = true,
      actionsRef,
      inputRef,
      onOpenChangeComplete,
      items,
      multiple = false,
      itemToStringLabel,
      itemToStringValue,
      isItemEqualToValue = defaultItemEquality,
      highlightItemOnHover = true,
      children
    } = props;
    const {
      clearErrors
    } = useFormContext();
    const {
      setDirty,
      setTouched,
      setFocused,
      shouldValidateOnChange,
      validityData,
      setFilled,
      name: fieldName,
      disabled: fieldDisabled,
      validation,
      validationMode
    } = useFieldRootContext();
    const generatedId = useLabelableId({
      id
    });
    const disabled2 = fieldDisabled || disabledProp;
    const name = fieldName ?? nameProp;
    const [value, setValueUnwrapped] = useControlled({
      controlled: valueProp,
      default: multiple ? defaultValue ?? EMPTY_ARRAY : defaultValue,
      name: "Select",
      state: "value"
    });
    const [open, setOpenUnwrapped] = useControlled({
      controlled: openProp,
      default: defaultOpen,
      name: "Select",
      state: "open"
    });
    const listRef = React124.useRef([]);
    const labelsRef = React124.useRef([]);
    const popupRef = React124.useRef(null);
    const scrollHandlerRef = React124.useRef(null);
    const scrollArrowsMountedCountRef = React124.useRef(0);
    const valueRef = React124.useRef(null);
    const valuesRef = React124.useRef([]);
    const typingRef = React124.useRef(false);
    const keyboardActiveRef = React124.useRef(false);
    const selectedItemTextRef = React124.useRef(null);
    const selectionRef = React124.useRef({
      allowSelectedMouseUp: false,
      allowUnselectedMouseUp: false
    });
    const alignItemWithTriggerActiveRef = React124.useRef(false);
    const {
      mounted,
      setMounted,
      transitionStatus
    } = useTransitionStatus(open);
    const {
      openMethod,
      triggerProps: interactionTypeProps
    } = useOpenInteractionType(open);
    const store = useRefWithInit(() => new Store({
      id: generatedId,
      labelId: void 0,
      modal,
      multiple,
      itemToStringLabel,
      itemToStringValue,
      isItemEqualToValue,
      value,
      open,
      mounted,
      transitionStatus,
      items,
      forceMount: false,
      openMethod: null,
      activeIndex: null,
      selectedIndex: null,
      popupProps: {},
      triggerProps: {},
      triggerElement: null,
      positionerElement: null,
      listElement: null,
      scrollUpArrowVisible: false,
      scrollDownArrowVisible: false,
      hasScrollArrows: false
    })).current;
    const activeIndex = useStore(store, selectors4.activeIndex);
    const selectedIndex = useStore(store, selectors4.selectedIndex);
    const triggerElement = useStore(store, selectors4.triggerElement);
    const positionerElement = useStore(store, selectors4.positionerElement);
    const serializedValue = React124.useMemo(() => {
      if (multiple && Array.isArray(value) && value.length === 0) {
        return "";
      }
      return stringifyAsValue(value, itemToStringValue);
    }, [multiple, value, itemToStringValue]);
    const fieldStringValue = React124.useMemo(() => {
      if (multiple && Array.isArray(value)) {
        return value.map((currentValue) => stringifyAsValue(currentValue, itemToStringValue));
      }
      return stringifyAsValue(value, itemToStringValue);
    }, [multiple, value, itemToStringValue]);
    const controlRef = useValueAsRef(store.state.triggerElement);
    useField({
      id: generatedId,
      commit: validation.commit,
      value,
      controlRef,
      name,
      getValue: () => fieldStringValue
    });
    const initialValueRef = React124.useRef(value);
    useIsoLayoutEffect(() => {
      if (value !== initialValueRef.current) {
        store.set("forceMount", true);
      }
    }, [store, value]);
    useIsoLayoutEffect(() => {
      setFilled(multiple ? Array.isArray(value) && value.length > 0 : value != null);
    }, [multiple, value, setFilled]);
    useIsoLayoutEffect(function syncSelectedIndex() {
      if (open) {
        return;
      }
      const registry = valuesRef.current;
      if (multiple) {
        const currentValue = Array.isArray(value) ? value : [];
        if (currentValue.length === 0) {
          store.set("selectedIndex", null);
          return;
        }
        const lastValue = currentValue[currentValue.length - 1];
        const lastIndex = findItemIndex(registry, lastValue, isItemEqualToValue);
        store.set("selectedIndex", lastIndex === -1 ? null : lastIndex);
        return;
      }
      const index2 = findItemIndex(registry, value, isItemEqualToValue);
      store.set("selectedIndex", index2 === -1 ? null : index2);
    }, [multiple, open, value, valuesRef, isItemEqualToValue, store]);
    useValueChanged(value, () => {
      clearErrors(name);
      setDirty(value !== validityData.initialValue);
      if (shouldValidateOnChange()) {
        validation.commit(value);
      } else {
        validation.commit(value, true);
      }
    });
    const setOpen = useStableCallback((nextOpen, eventDetails) => {
      onOpenChange?.(nextOpen, eventDetails);
      if (eventDetails.isCanceled) {
        return;
      }
      setOpenUnwrapped(nextOpen);
      if (!nextOpen && (eventDetails.reason === reason_parts_exports.focusOut || eventDetails.reason === reason_parts_exports.outsidePress)) {
        setTouched(true);
        setFocused(false);
        if (validationMode === "onBlur") {
          validation.commit(value);
        }
      }
      if (!nextOpen && store.state.activeIndex !== null) {
        const activeOption = listRef.current[store.state.activeIndex];
        queueMicrotask(() => {
          activeOption?.setAttribute("tabindex", "-1");
        });
      }
    });
    const handleUnmount = useStableCallback(() => {
      setMounted(false);
      store.set("activeIndex", null);
      onOpenChangeComplete?.(false);
    });
    useOpenChangeComplete({
      enabled: !actionsRef,
      open,
      ref: popupRef,
      onComplete() {
        if (!open) {
          handleUnmount();
        }
      }
    });
    React124.useImperativeHandle(actionsRef, () => ({
      unmount: handleUnmount
    }), [handleUnmount]);
    const setValue = useStableCallback((nextValue, eventDetails) => {
      onValueChange?.(nextValue, eventDetails);
      if (eventDetails.isCanceled) {
        return;
      }
      setValueUnwrapped(nextValue);
    });
    const handleScrollArrowVisibility = useStableCallback(() => {
      const scroller = store.state.listElement || popupRef.current;
      if (!scroller) {
        return;
      }
      const viewportTop = scroller.scrollTop;
      const viewportBottom = scroller.scrollTop + scroller.clientHeight;
      const shouldShowUp = viewportTop > 1;
      const shouldShowDown = viewportBottom < scroller.scrollHeight - 1;
      if (store.state.scrollUpArrowVisible !== shouldShowUp) {
        store.set("scrollUpArrowVisible", shouldShowUp);
      }
      if (store.state.scrollDownArrowVisible !== shouldShowDown) {
        store.set("scrollDownArrowVisible", shouldShowDown);
      }
    });
    const floatingContext = useFloatingRootContext({
      open,
      onOpenChange: setOpen,
      elements: {
        reference: triggerElement,
        floating: positionerElement
      }
    });
    const click = useClick(floatingContext, {
      enabled: !readOnly && !disabled2,
      event: "mousedown"
    });
    const dismiss = useDismiss(floatingContext, {
      bubbles: false
    });
    const listNavigation2 = useListNavigation(floatingContext, {
      enabled: !readOnly && !disabled2,
      listRef,
      activeIndex,
      selectedIndex,
      disabledIndices: EMPTY_ARRAY,
      onNavigate(nextActiveIndex) {
        if (nextActiveIndex === null && !open) {
          return;
        }
        store.set("activeIndex", nextActiveIndex);
      },
      // Implement our own listeners since `onPointerLeave` on each option fires while scrolling with
      // the `alignItemWithTrigger=true`, causing a performance issue on Chrome.
      focusItemOnHover: false
    });
    const typeahead = useTypeahead(floatingContext, {
      enabled: !readOnly && !disabled2 && (open || !multiple),
      listRef: labelsRef,
      activeIndex,
      selectedIndex,
      onMatch(index2) {
        if (open) {
          store.set("activeIndex", index2);
        } else {
          setValue(valuesRef.current[index2], createChangeEventDetails("none"));
        }
      },
      onTypingChange(typing) {
        typingRef.current = typing;
      }
    });
    const {
      getReferenceProps,
      getFloatingProps,
      getItemProps
    } = useInteractions([click, dismiss, listNavigation2, typeahead]);
    const mergedTriggerProps = React124.useMemo(() => {
      return mergeProps(getReferenceProps(), interactionTypeProps, generatedId ? {
        id: generatedId
      } : EMPTY_OBJECT);
    }, [getReferenceProps, interactionTypeProps, generatedId]);
    useOnFirstRender(() => {
      store.update({
        popupProps: getFloatingProps(),
        triggerProps: mergedTriggerProps
      });
    });
    useIsoLayoutEffect(() => {
      store.update({
        id: generatedId,
        modal,
        multiple,
        value,
        open,
        mounted,
        transitionStatus,
        popupProps: getFloatingProps(),
        triggerProps: mergedTriggerProps,
        items,
        itemToStringLabel,
        itemToStringValue,
        isItemEqualToValue,
        openMethod
      });
    }, [store, generatedId, modal, multiple, value, open, mounted, transitionStatus, getFloatingProps, mergedTriggerProps, items, itemToStringLabel, itemToStringValue, isItemEqualToValue, openMethod]);
    const contextValue = React124.useMemo(() => ({
      store,
      name,
      required,
      disabled: disabled2,
      readOnly,
      multiple,
      itemToStringLabel,
      itemToStringValue,
      highlightItemOnHover,
      setValue,
      setOpen,
      listRef,
      popupRef,
      scrollHandlerRef,
      handleScrollArrowVisibility,
      scrollArrowsMountedCountRef,
      getItemProps,
      events: floatingContext.context.events,
      valueRef,
      valuesRef,
      labelsRef,
      typingRef,
      selectionRef,
      selectedItemTextRef,
      validation,
      onOpenChangeComplete,
      keyboardActiveRef,
      alignItemWithTriggerActiveRef,
      initialValueRef
    }), [store, name, required, disabled2, readOnly, multiple, itemToStringLabel, itemToStringValue, highlightItemOnHover, setValue, setOpen, getItemProps, floatingContext.context.events, validation, onOpenChangeComplete, handleScrollArrowVisibility]);
    const ref = useMergedRefs(inputRef, validation.inputRef);
    const hasMultipleSelection = multiple && Array.isArray(value) && value.length > 0;
    const hiddenInputName = multiple ? void 0 : name;
    const hiddenInputs = React124.useMemo(() => {
      if (!multiple || !Array.isArray(value) || !name) {
        return null;
      }
      return value.map((v) => {
        const currentSerializedValue = stringifyAsValue(v, itemToStringValue);
        return /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("input", {
          type: "hidden",
          name,
          value: currentSerializedValue
        }, currentSerializedValue);
      });
    }, [multiple, value, name, itemToStringValue]);
    return /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(SelectRootContext.Provider, {
      value: contextValue,
      children: /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)(SelectFloatingContext.Provider, {
        value: floatingContext,
        children: [children, /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("input", {
          ...validation.getInputValidationProps({
            onFocus() {
              store.state.triggerElement?.focus({
                // Supported in Chrome from 144 (January 2026)
                // @ts-expect-error - focusVisible is not yet in the lib.dom.d.ts
                focusVisible: true
              });
            },
            // Handle browser autofill.
            onChange(event) {
              if (event.nativeEvent.defaultPrevented) {
                return;
              }
              const nextValue = event.target.value;
              const details = createChangeEventDetails(reason_parts_exports.none, event.nativeEvent);
              function handleChange() {
                if (multiple) {
                  return;
                }
                const matchingValue = valuesRef.current.find((v) => {
                  const candidate = stringifyAsValue(v, itemToStringValue);
                  if (candidate.toLowerCase() === nextValue.toLowerCase()) {
                    return true;
                  }
                  return false;
                });
                if (matchingValue != null) {
                  setDirty(matchingValue !== validityData.initialValue);
                  setValue(matchingValue, details);
                  if (shouldValidateOnChange()) {
                    validation.commit(matchingValue);
                  }
                }
              }
              store.set("forceMount", true);
              queueMicrotask(handleChange);
            }
          }),
          id: generatedId && hiddenInputName == null ? `${generatedId}-hidden-input` : void 0,
          name: hiddenInputName,
          autoComplete,
          value: serializedValue,
          disabled: disabled2,
          required: required && !hasMultipleSelection,
          readOnly,
          ref,
          style: name ? visuallyHiddenInput : visuallyHidden,
          tabIndex: -1,
          "aria-hidden": true
        }), hiddenInputs]
      })
    });
  }

  // node_modules/@base-ui/react/esm/select/label/SelectLabel.js
  init_define_import_meta_env();
  var React125 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/utils/resolveAriaLabelledBy.js
  init_define_import_meta_env();
  function getDefaultLabelId(id) {
    return id == null ? void 0 : `${id}-label`;
  }
  function resolveAriaLabelledBy(fieldLabelId, localLabelId) {
    return fieldLabelId ?? localLabelId;
  }

  // node_modules/@base-ui/react/esm/select/label/SelectLabel.js
  var SelectLabel = /* @__PURE__ */ React125.forwardRef(function SelectLabel2(componentProps, forwardedRef) {
    const {
      render,
      className,
      ...elementProps
    } = componentProps;
    const elementPropsWithoutId = elementProps;
    delete elementPropsWithoutId.id;
    const fieldRootContext = useFieldRootContext();
    const {
      store
    } = useSelectRootContext();
    const triggerElement = useStore(store, selectors4.triggerElement);
    const rootId = useStore(store, selectors4.id);
    const defaultLabelId = getDefaultLabelId(rootId);
    const labelProps = useLabel({
      id: defaultLabelId,
      fallbackControlId: triggerElement?.id ?? rootId,
      setLabelId(nextLabelId) {
        store.set("labelId", nextLabelId);
      }
    });
    return useRenderElement("div", componentProps, {
      ref: forwardedRef,
      state: fieldRootContext.state,
      props: [labelProps, elementProps],
      stateAttributesMapping: fieldValidityMapping
    });
  });
  if (true) SelectLabel.displayName = "SelectLabel";

  // node_modules/@base-ui/react/esm/select/trigger/SelectTrigger.js
  init_define_import_meta_env();
  var React126 = __toESM(require_react_shim(), 1);
  var BOUNDARY_OFFSET2 = 2;
  var SELECTED_DELAY = 400;
  var UNSELECTED_DELAY = 200;
  var stateAttributesMapping9 = {
    ...pressableTriggerOpenStateMapping,
    ...fieldValidityMapping,
    value: () => null
  };
  var SelectTrigger = /* @__PURE__ */ React126.forwardRef(function SelectTrigger2(componentProps, forwardedRef) {
    const {
      render,
      className,
      id: idProp,
      disabled: disabledProp = false,
      nativeButton = true,
      ...elementProps
    } = componentProps;
    const {
      setTouched,
      setFocused,
      validationMode,
      state: fieldState,
      disabled: fieldDisabled
    } = useFieldRootContext();
    const {
      labelId: fieldLabelId
    } = useLabelableContext();
    const {
      store,
      setOpen,
      selectionRef,
      validation,
      readOnly,
      required,
      alignItemWithTriggerActiveRef,
      disabled: selectDisabled,
      keyboardActiveRef
    } = useSelectRootContext();
    const disabled2 = fieldDisabled || selectDisabled || disabledProp;
    const open = useStore(store, selectors4.open);
    const value = useStore(store, selectors4.value);
    const triggerProps = useStore(store, selectors4.triggerProps);
    const positionerElement = useStore(store, selectors4.positionerElement);
    const listElement = useStore(store, selectors4.listElement);
    const rootId = useStore(store, selectors4.id);
    const selectLabelId = useStore(store, selectors4.labelId);
    const hasSelectedValue = useStore(store, selectors4.hasSelectedValue);
    const shouldCheckNullItemLabel = !hasSelectedValue && open;
    const hasNullItemLabel2 = useStore(store, selectors4.hasNullItemLabel, shouldCheckNullItemLabel);
    const id = idProp ?? rootId;
    const ariaLabelledBy = resolveAriaLabelledBy(fieldLabelId, selectLabelId);
    useLabelableId({
      id
    });
    const positionerRef = useValueAsRef(positionerElement);
    const triggerRef = React126.useRef(null);
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      native: nativeButton
    });
    const setTriggerElement = useStableCallback((element) => {
      store.set("triggerElement", element);
    });
    const mergedRef = useMergedRefs(forwardedRef, triggerRef, buttonRef, setTriggerElement);
    const timeoutFocus = useTimeout();
    const timeoutMouseDown = useTimeout();
    const selectedDelayTimeout = useTimeout();
    const unselectedDelayTimeout = useTimeout();
    React126.useEffect(() => {
      if (open) {
        const hasSelectedItemInList = hasSelectedValue || hasNullItemLabel2;
        const shouldDelayUnselectedMouseUpLonger = !hasSelectedItemInList;
        if (shouldDelayUnselectedMouseUpLonger) {
          selectedDelayTimeout.start(SELECTED_DELAY, () => {
            selectionRef.current.allowUnselectedMouseUp = true;
            selectionRef.current.allowSelectedMouseUp = true;
          });
        } else {
          unselectedDelayTimeout.start(UNSELECTED_DELAY, () => {
            selectionRef.current.allowUnselectedMouseUp = true;
            selectedDelayTimeout.start(UNSELECTED_DELAY, () => {
              selectionRef.current.allowSelectedMouseUp = true;
            });
          });
        }
        return () => {
          selectedDelayTimeout.clear();
          unselectedDelayTimeout.clear();
        };
      }
      selectionRef.current = {
        allowSelectedMouseUp: false,
        allowUnselectedMouseUp: false
      };
      timeoutMouseDown.clear();
      return void 0;
    }, [open, hasSelectedValue, hasNullItemLabel2, selectionRef, timeoutMouseDown, selectedDelayTimeout, unselectedDelayTimeout]);
    const ariaControlsId = React126.useMemo(() => {
      return listElement?.id ?? getFloatingFocusElement(positionerElement)?.id;
    }, [listElement, positionerElement]);
    const props = mergeProps(triggerProps, {
      id,
      role: "combobox",
      "aria-expanded": open ? "true" : "false",
      "aria-haspopup": "listbox",
      "aria-controls": open ? ariaControlsId : void 0,
      "aria-labelledby": ariaLabelledBy,
      "aria-readonly": readOnly || void 0,
      "aria-required": required || void 0,
      tabIndex: disabled2 ? -1 : 0,
      ref: mergedRef,
      onFocus(event) {
        setFocused(true);
        if (open && alignItemWithTriggerActiveRef.current) {
          setOpen(false, createChangeEventDetails(reason_parts_exports.none, event.nativeEvent));
        }
        timeoutFocus.start(0, () => {
          store.set("forceMount", true);
        });
      },
      onBlur(event) {
        if (contains(positionerElement, event.relatedTarget)) {
          return;
        }
        setTouched(true);
        setFocused(false);
        if (validationMode === "onBlur") {
          validation.commit(value);
        }
      },
      onPointerMove() {
        keyboardActiveRef.current = false;
      },
      onKeyDown() {
        keyboardActiveRef.current = true;
      },
      onMouseDown(event) {
        if (open) {
          return;
        }
        const doc = ownerDocument(event.currentTarget);
        function handleMouseUp(mouseEvent) {
          if (!triggerRef.current) {
            return;
          }
          const mouseUpTarget = mouseEvent.target;
          if (contains(triggerRef.current, mouseUpTarget) || contains(positionerRef.current, mouseUpTarget) || mouseUpTarget === triggerRef.current) {
            return;
          }
          const bounds = getPseudoElementBounds(triggerRef.current);
          if (mouseEvent.clientX >= bounds.left - BOUNDARY_OFFSET2 && mouseEvent.clientX <= bounds.right + BOUNDARY_OFFSET2 && mouseEvent.clientY >= bounds.top - BOUNDARY_OFFSET2 && mouseEvent.clientY <= bounds.bottom + BOUNDARY_OFFSET2) {
            return;
          }
          setOpen(false, createChangeEventDetails(reason_parts_exports.cancelOpen, mouseEvent));
        }
        timeoutMouseDown.start(0, () => {
          doc.addEventListener("mouseup", handleMouseUp, {
            once: true
          });
        });
      }
    }, validation.getValidationProps, elementProps, getButtonProps);
    props.role = "combobox";
    const state = {
      ...fieldState,
      open,
      disabled: disabled2,
      value,
      readOnly,
      placeholder: !hasSelectedValue
    };
    return useRenderElement("button", componentProps, {
      ref: [forwardedRef, triggerRef],
      state,
      stateAttributesMapping: stateAttributesMapping9,
      props
    });
  });
  if (true) SelectTrigger.displayName = "SelectTrigger";

  // node_modules/@base-ui/react/esm/select/value/SelectValue.js
  init_define_import_meta_env();
  var React127 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping10 = {
    value: () => null
  };
  var SelectValue = /* @__PURE__ */ React127.forwardRef(function SelectValue2(componentProps, forwardedRef) {
    const {
      className,
      render,
      children: childrenProp,
      placeholder,
      ...elementProps
    } = componentProps;
    const {
      store,
      valueRef
    } = useSelectRootContext();
    const value = useStore(store, selectors4.value);
    const items = useStore(store, selectors4.items);
    const itemToStringLabel = useStore(store, selectors4.itemToStringLabel);
    const hasSelectedValue = useStore(store, selectors4.hasSelectedValue);
    const shouldCheckNullItemLabel = !hasSelectedValue && placeholder != null && childrenProp == null;
    const hasNullLabel = useStore(store, selectors4.hasNullItemLabel, shouldCheckNullItemLabel);
    const state = {
      value,
      placeholder: !hasSelectedValue
    };
    let children = null;
    if (typeof childrenProp === "function") {
      children = childrenProp(value);
    } else if (childrenProp != null) {
      children = childrenProp;
    } else if (!hasSelectedValue && placeholder != null && !hasNullLabel) {
      children = placeholder;
    } else if (Array.isArray(value)) {
      children = resolveMultipleLabels(value, items, itemToStringLabel);
    } else {
      children = resolveSelectedLabel(value, items, itemToStringLabel);
    }
    const element = useRenderElement("span", componentProps, {
      state,
      ref: [forwardedRef, valueRef],
      props: [{
        children
      }, elementProps],
      stateAttributesMapping: stateAttributesMapping10
    });
    return element;
  });
  if (true) SelectValue.displayName = "SelectValue";

  // node_modules/@base-ui/react/esm/select/icon/SelectIcon.js
  init_define_import_meta_env();
  var React128 = __toESM(require_react_shim(), 1);
  var SelectIcon = /* @__PURE__ */ React128.forwardRef(function SelectIcon2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useSelectRootContext();
    const open = useStore(store, selectors4.open);
    const state = {
      open
    };
    const element = useRenderElement("span", componentProps, {
      state,
      ref: forwardedRef,
      props: [{
        "aria-hidden": true,
        children: "\u25BC"
      }, elementProps],
      stateAttributesMapping: triggerOpenStateMapping
    });
    return element;
  });
  if (true) SelectIcon.displayName = "SelectIcon";

  // node_modules/@base-ui/react/esm/select/portal/SelectPortal.js
  init_define_import_meta_env();
  var React130 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/portal/SelectPortalContext.js
  init_define_import_meta_env();
  var React129 = __toESM(require_react_shim(), 1);
  var SelectPortalContext = /* @__PURE__ */ React129.createContext(void 0);
  if (true) SelectPortalContext.displayName = "SelectPortalContext";

  // node_modules/@base-ui/react/esm/select/portal/SelectPortal.js
  var import_jsx_runtime38 = __toESM(require_react_shim(), 1);
  var SelectPortal = /* @__PURE__ */ React130.forwardRef(function SelectPortal2(portalProps, forwardedRef) {
    const {
      store
    } = useSelectRootContext();
    const mounted = useStore(store, selectors4.mounted);
    const forceMount = useStore(store, selectors4.forceMount);
    const shouldRender = mounted || forceMount;
    if (!shouldRender) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(SelectPortalContext.Provider, {
      value: true,
      children: /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(FloatingPortal, {
        ref: forwardedRef,
        ...portalProps
      })
    });
  });
  if (true) SelectPortal.displayName = "SelectPortal";

  // node_modules/@base-ui/react/esm/select/backdrop/SelectBackdrop.js
  init_define_import_meta_env();
  var React131 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping11 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var SelectBackdrop = /* @__PURE__ */ React131.forwardRef(function SelectBackdrop2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useSelectRootContext();
    const open = useStore(store, selectors4.open);
    const mounted = useStore(store, selectors4.mounted);
    const transitionStatus = useStore(store, selectors4.transitionStatus);
    const state = {
      open,
      transitionStatus
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: forwardedRef,
      props: [{
        role: "presentation",
        hidden: !mounted,
        style: {
          userSelect: "none",
          WebkitUserSelect: "none"
        }
      }, elementProps],
      stateAttributesMapping: stateAttributesMapping11
    });
    return element;
  });
  if (true) SelectBackdrop.displayName = "SelectBackdrop";

  // node_modules/@base-ui/react/esm/select/positioner/SelectPositioner.js
  init_define_import_meta_env();
  var React133 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/positioner/SelectPositionerContext.js
  init_define_import_meta_env();
  var React132 = __toESM(require_react_shim(), 1);
  var SelectPositionerContext = /* @__PURE__ */ React132.createContext(void 0);
  if (true) SelectPositionerContext.displayName = "SelectPositionerContext";
  function useSelectPositionerContext() {
    const context = React132.useContext(SelectPositionerContext);
    if (!context) {
      throw new Error(true ? "Base UI: SelectPositionerContext is missing. SelectPositioner parts must be placed within <Select.Positioner>." : formatErrorMessage_default(59));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/select/popup/utils.js
  init_define_import_meta_env();
  function clearStyles(element, originalStyles) {
    if (element) {
      Object.assign(element.style, originalStyles);
    }
  }
  var LIST_FUNCTIONAL_STYLES = {
    position: "relative",
    maxHeight: "100%",
    overflowX: "hidden",
    overflowY: "auto"
  };

  // node_modules/@base-ui/react/esm/select/positioner/SelectPositioner.js
  var import_jsx_runtime39 = __toESM(require_react_shim(), 1);
  var FIXED = {
    position: "fixed"
  };
  var SelectPositioner = /* @__PURE__ */ React133.forwardRef(function SelectPositioner2(componentProps, forwardedRef) {
    const {
      anchor,
      positionMethod = "absolute",
      className,
      render,
      side = "bottom",
      align = "center",
      sideOffset = 0,
      alignOffset = 0,
      collisionBoundary = "clipping-ancestors",
      collisionPadding,
      arrowPadding = 5,
      sticky = false,
      disableAnchorTracking,
      alignItemWithTrigger = true,
      collisionAvoidance = DROPDOWN_COLLISION_AVOIDANCE,
      ...elementProps
    } = componentProps;
    const {
      store,
      listRef,
      labelsRef,
      alignItemWithTriggerActiveRef,
      selectedItemTextRef,
      valuesRef,
      initialValueRef,
      popupRef,
      setValue
    } = useSelectRootContext();
    const floatingRootContext = useSelectFloatingContext();
    const open = useStore(store, selectors4.open);
    const mounted = useStore(store, selectors4.mounted);
    const modal = useStore(store, selectors4.modal);
    const value = useStore(store, selectors4.value);
    const openMethod = useStore(store, selectors4.openMethod);
    const positionerElement = useStore(store, selectors4.positionerElement);
    const triggerElement = useStore(store, selectors4.triggerElement);
    const isItemEqualToValue = useStore(store, selectors4.isItemEqualToValue);
    const transitionStatus = useStore(store, selectors4.transitionStatus);
    const scrollUpArrowRef = React133.useRef(null);
    const scrollDownArrowRef = React133.useRef(null);
    const [controlledAlignItemWithTrigger, setControlledAlignItemWithTrigger] = React133.useState(alignItemWithTrigger);
    const alignItemWithTriggerActive = mounted && controlledAlignItemWithTrigger && openMethod !== "touch";
    if (!mounted && controlledAlignItemWithTrigger !== alignItemWithTrigger) {
      setControlledAlignItemWithTrigger(alignItemWithTrigger);
    }
    useIsoLayoutEffect(() => {
      if (!mounted) {
        if (selectors4.scrollUpArrowVisible(store.state)) {
          store.set("scrollUpArrowVisible", false);
        }
        if (selectors4.scrollDownArrowVisible(store.state)) {
          store.set("scrollDownArrowVisible", false);
        }
      }
    }, [store, mounted]);
    React133.useImperativeHandle(alignItemWithTriggerActiveRef, () => alignItemWithTriggerActive);
    useScrollLock((alignItemWithTriggerActive || modal) && open && openMethod !== "touch", triggerElement);
    const positioning = useAnchorPositioning({
      anchor,
      floatingRootContext,
      positionMethod,
      mounted,
      side,
      sideOffset,
      align,
      alignOffset,
      arrowPadding,
      collisionBoundary,
      collisionPadding,
      sticky,
      disableAnchorTracking: disableAnchorTracking ?? alignItemWithTriggerActive,
      collisionAvoidance,
      keepMounted: true
    });
    const renderedSide = alignItemWithTriggerActive ? "none" : positioning.side;
    const positionerStyles = alignItemWithTriggerActive ? FIXED : positioning.positionerStyles;
    const defaultProps = React133.useMemo(() => {
      const hiddenStyles = {};
      if (!open) {
        hiddenStyles.pointerEvents = "none";
      }
      return {
        role: "presentation",
        hidden: !mounted,
        style: {
          ...positionerStyles,
          ...hiddenStyles
        }
      };
    }, [open, mounted, positionerStyles]);
    const state = {
      open,
      side: renderedSide,
      align: positioning.align,
      anchorHidden: positioning.anchorHidden
    };
    const setPositionerElement = useStableCallback((element2) => {
      store.set("positionerElement", element2);
    });
    const element = useRenderElement("div", componentProps, {
      ref: [forwardedRef, setPositionerElement],
      state,
      stateAttributesMapping: popupStateMapping,
      props: [defaultProps, getDisabledMountTransitionStyles(transitionStatus), elementProps]
    });
    const prevMapSizeRef = React133.useRef(0);
    const onMapChange = useStableCallback((map) => {
      if (map.size === 0 && prevMapSizeRef.current === 0) {
        return;
      }
      if (valuesRef.current.length === 0) {
        return;
      }
      const prevSize = prevMapSizeRef.current;
      prevMapSizeRef.current = map.size;
      if (map.size === prevSize) {
        return;
      }
      const eventDetails = createChangeEventDetails(reason_parts_exports.none);
      if (prevSize !== 0 && !store.state.multiple && value !== null) {
        const selectedValueIndex = findItemIndex(valuesRef.current, value, isItemEqualToValue);
        if (selectedValueIndex === -1) {
          const initialSelectedValue = initialValueRef.current;
          const hasInitial = initialSelectedValue != null && findItemIndex(valuesRef.current, initialSelectedValue, isItemEqualToValue) !== -1;
          const nextValue = hasInitial ? initialSelectedValue : null;
          setValue(nextValue, eventDetails);
          if (nextValue === null) {
            store.set("selectedIndex", null);
            selectedItemTextRef.current = null;
          }
        }
      }
      if (prevSize !== 0 && store.state.multiple && Array.isArray(value)) {
        const hasVisibleItem = (selectedItemValue) => findItemIndex(valuesRef.current, selectedItemValue, isItemEqualToValue) !== -1;
        const nextValue = value.filter((selectedItemValue) => hasVisibleItem(selectedItemValue));
        if (nextValue.length !== value.length || nextValue.some((selectedItemValue) => !selectedValueIncludes(value, selectedItemValue, isItemEqualToValue))) {
          setValue(nextValue, eventDetails);
          if (nextValue.length === 0) {
            store.set("selectedIndex", null);
            selectedItemTextRef.current = null;
          }
        }
      }
      if (open && alignItemWithTriggerActive) {
        store.update({
          scrollUpArrowVisible: false,
          scrollDownArrowVisible: false
        });
        const stylesToClear = {
          height: ""
        };
        clearStyles(positionerElement, stylesToClear);
        clearStyles(popupRef.current, stylesToClear);
      }
    });
    const contextValue = React133.useMemo(() => ({
      ...positioning,
      side: renderedSide,
      alignItemWithTriggerActive,
      setControlledAlignItemWithTrigger,
      scrollUpArrowRef,
      scrollDownArrowRef
    }), [positioning, renderedSide, alignItemWithTriggerActive, setControlledAlignItemWithTrigger]);
    return /* @__PURE__ */ (0, import_jsx_runtime39.jsx)(CompositeList, {
      elementsRef: listRef,
      labelsRef,
      onMapChange,
      children: /* @__PURE__ */ (0, import_jsx_runtime39.jsxs)(SelectPositionerContext.Provider, {
        value: contextValue,
        children: [mounted && modal && /* @__PURE__ */ (0, import_jsx_runtime39.jsx)(InternalBackdrop, {
          inert: inertValue(!open),
          cutout: triggerElement
        }), element]
      })
    });
  });
  if (true) SelectPositioner.displayName = "SelectPositioner";

  // node_modules/@base-ui/react/esm/select/popup/SelectPopup.js
  init_define_import_meta_env();
  var React135 = __toESM(require_react_shim(), 1);
  var ReactDOM8 = __toESM(require_react_dom_shim(), 1);

  // node_modules/@base-ui/utils/esm/isMouseWithinBounds.js
  init_define_import_meta_env();
  function isMouseWithinBounds(event) {
    const targetRect = event.currentTarget.getBoundingClientRect();
    const isWithinBounds = targetRect.top + 1 <= event.clientY && event.clientY <= targetRect.bottom - 1 && targetRect.left + 1 <= event.clientX && event.clientX <= targetRect.right - 1;
    return isWithinBounds;
  }

  // node_modules/@base-ui/react/esm/utils/styles.js
  init_define_import_meta_env();
  var import_jsx_runtime40 = __toESM(require_react_shim(), 1);
  var DISABLE_SCROLLBAR_CLASS_NAME = "base-ui-disable-scrollbar";
  var styleDisableScrollbar = {
    className: DISABLE_SCROLLBAR_CLASS_NAME,
    getElement(nonce) {
      return /* @__PURE__ */ (0, import_jsx_runtime40.jsx)("style", {
        nonce,
        href: DISABLE_SCROLLBAR_CLASS_NAME,
        precedence: "base-ui:low",
        children: `.${DISABLE_SCROLLBAR_CLASS_NAME}{scrollbar-width:none}.${DISABLE_SCROLLBAR_CLASS_NAME}::-webkit-scrollbar{display:none}`
      });
    }
  };
  if (true) styleDisableScrollbar.getElement.displayName = "styleDisableScrollbar.getElement";

  // node_modules/@base-ui/react/esm/utils/clamp.js
  init_define_import_meta_env();
  function clamp2(val, min2 = Number.MIN_SAFE_INTEGER, max2 = Number.MAX_SAFE_INTEGER) {
    return Math.max(min2, Math.min(val, max2));
  }

  // node_modules/@base-ui/react/esm/csp-provider/CSPContext.js
  init_define_import_meta_env();
  var React134 = __toESM(require_react_shim(), 1);
  var CSPContext = /* @__PURE__ */ React134.createContext(void 0);
  if (true) CSPContext.displayName = "CSPContext";
  var DEFAULT_CSP_CONTEXT_VALUE = {
    disableStyleElements: false
  };
  function useCSPContext() {
    return React134.useContext(CSPContext) ?? DEFAULT_CSP_CONTEXT_VALUE;
  }

  // node_modules/@base-ui/react/esm/select/popup/SelectPopup.js
  var import_jsx_runtime41 = __toESM(require_react_shim(), 1);
  var SCROLL_EPS_PX = 1;
  var stateAttributesMapping12 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var SelectPopup = /* @__PURE__ */ React135.forwardRef(function SelectPopup2(componentProps, forwardedRef) {
    const {
      render,
      className,
      finalFocus,
      ...elementProps
    } = componentProps;
    const {
      store,
      popupRef,
      onOpenChangeComplete,
      setOpen,
      valueRef,
      selectedItemTextRef,
      keyboardActiveRef,
      multiple,
      handleScrollArrowVisibility,
      scrollHandlerRef,
      highlightItemOnHover
    } = useSelectRootContext();
    const {
      side,
      align,
      alignItemWithTriggerActive,
      setControlledAlignItemWithTrigger,
      scrollDownArrowRef,
      scrollUpArrowRef
    } = useSelectPositionerContext();
    const insideToolbar = useToolbarRootContext(true) != null;
    const floatingRootContext = useSelectFloatingContext();
    const {
      nonce,
      disableStyleElements
    } = useCSPContext();
    const highlightTimeout = useTimeout();
    const id = useStore(store, selectors4.id);
    const open = useStore(store, selectors4.open);
    const mounted = useStore(store, selectors4.mounted);
    const popupProps = useStore(store, selectors4.popupProps);
    const transitionStatus = useStore(store, selectors4.transitionStatus);
    const triggerElement = useStore(store, selectors4.triggerElement);
    const positionerElement = useStore(store, selectors4.positionerElement);
    const listElement = useStore(store, selectors4.listElement);
    const initialHeightRef = React135.useRef(0);
    const reachedMaxHeightRef = React135.useRef(false);
    const maxHeightRef = React135.useRef(0);
    const initialPlacedRef = React135.useRef(false);
    const originalPositionerStylesRef = React135.useRef({});
    const scrollArrowFrame = useAnimationFrame();
    const handleScroll = useStableCallback((scroller) => {
      if (!positionerElement || !popupRef.current || !initialPlacedRef.current) {
        return;
      }
      if (reachedMaxHeightRef.current || !alignItemWithTriggerActive) {
        handleScrollArrowVisibility();
        return;
      }
      const isTopPositioned = positionerElement.style.top === "0px";
      const isBottomPositioned = positionerElement.style.bottom === "0px";
      const currentHeight = positionerElement.getBoundingClientRect().height;
      const doc = ownerDocument(positionerElement);
      const positionerStyles = getComputedStyle(positionerElement);
      const marginTop = parseFloat(positionerStyles.marginTop);
      const marginBottom = parseFloat(positionerStyles.marginBottom);
      const maxPopupHeight = getMaxPopupHeight(getComputedStyle(popupRef.current));
      const maxAvailableHeight = Math.min(doc.documentElement.clientHeight - marginTop - marginBottom, maxPopupHeight);
      const scrollTop = scroller.scrollTop;
      const maxScrollTop = getMaxScrollTop(scroller);
      let nextPositionerHeight = 0;
      let nextScrollTop = null;
      let setReachedMax = false;
      let scrollToMax = false;
      const setHeight = (height) => {
        positionerElement.style.height = `${height}px`;
      };
      const handleSmallDiff = (diff, targetScrollTop) => {
        const heightDelta = clamp2(diff, 0, maxAvailableHeight - currentHeight);
        if (heightDelta > 0) {
          setHeight(currentHeight + heightDelta);
        }
        scroller.scrollTop = targetScrollTop;
        if (maxAvailableHeight - (currentHeight + heightDelta) <= SCROLL_EPS_PX) {
          reachedMaxHeightRef.current = true;
        }
        handleScrollArrowVisibility();
      };
      if (isTopPositioned) {
        const diff = maxScrollTop - scrollTop;
        const idealHeight = currentHeight + diff;
        const nextHeight = Math.min(idealHeight, maxAvailableHeight);
        nextPositionerHeight = nextHeight;
        if (diff <= SCROLL_EPS_PX) {
          handleSmallDiff(diff, maxScrollTop);
          return;
        }
        if (maxAvailableHeight - nextHeight > SCROLL_EPS_PX) {
          scrollToMax = true;
        } else {
          setReachedMax = true;
        }
      } else if (isBottomPositioned) {
        const diff = scrollTop;
        const idealHeight = currentHeight + diff;
        const nextHeight = Math.min(idealHeight, maxAvailableHeight);
        const overshoot = idealHeight - maxAvailableHeight;
        nextPositionerHeight = nextHeight;
        if (diff <= SCROLL_EPS_PX) {
          handleSmallDiff(diff, 0);
          return;
        }
        if (maxAvailableHeight - nextHeight > SCROLL_EPS_PX) {
          nextScrollTop = 0;
        } else {
          setReachedMax = true;
          if (scrollTop < maxScrollTop) {
            nextScrollTop = scrollTop - (diff - overshoot);
          }
        }
      }
      nextPositionerHeight = Math.ceil(nextPositionerHeight);
      if (nextPositionerHeight !== 0) {
        setHeight(nextPositionerHeight);
      }
      if (scrollToMax || nextScrollTop != null) {
        const nextMaxScrollTop = getMaxScrollTop(scroller);
        const target = scrollToMax ? nextMaxScrollTop : clamp2(nextScrollTop, 0, nextMaxScrollTop);
        if (Math.abs(scroller.scrollTop - target) > SCROLL_EPS_PX) {
          scroller.scrollTop = target;
        }
      }
      if (setReachedMax || nextPositionerHeight >= maxAvailableHeight - SCROLL_EPS_PX) {
        reachedMaxHeightRef.current = true;
      }
      handleScrollArrowVisibility();
    });
    React135.useImperativeHandle(scrollHandlerRef, () => handleScroll, [handleScroll]);
    useOpenChangeComplete({
      open,
      ref: popupRef,
      onComplete() {
        if (open) {
          onOpenChangeComplete?.(true);
        }
      }
    });
    const state = {
      open,
      transitionStatus,
      side,
      align
    };
    useIsoLayoutEffect(() => {
      if (!positionerElement || !popupRef.current || Object.keys(originalPositionerStylesRef.current).length) {
        return;
      }
      originalPositionerStylesRef.current = {
        top: positionerElement.style.top || "0",
        left: positionerElement.style.left || "0",
        right: positionerElement.style.right,
        height: positionerElement.style.height,
        bottom: positionerElement.style.bottom,
        minHeight: positionerElement.style.minHeight,
        maxHeight: positionerElement.style.maxHeight,
        marginTop: positionerElement.style.marginTop,
        marginBottom: positionerElement.style.marginBottom
      };
    }, [popupRef, positionerElement]);
    useIsoLayoutEffect(() => {
      if (open || alignItemWithTriggerActive) {
        return;
      }
      initialPlacedRef.current = false;
      reachedMaxHeightRef.current = false;
      initialHeightRef.current = 0;
      maxHeightRef.current = 0;
      clearStyles(positionerElement, originalPositionerStylesRef.current);
    }, [open, alignItemWithTriggerActive, positionerElement, popupRef]);
    useIsoLayoutEffect(() => {
      const popupElement = popupRef.current;
      if (!open || !triggerElement || !positionerElement || !popupElement || store.state.transitionStatus === "ending") {
        return;
      }
      if (!alignItemWithTriggerActive) {
        initialPlacedRef.current = true;
        scrollArrowFrame.request(handleScrollArrowVisibility);
        popupElement.style.removeProperty("--transform-origin");
        return;
      }
      queueMicrotask(() => {
        const restoreTransformStyles = unsetTransformStyles(popupElement);
        popupElement.style.removeProperty("--transform-origin");
        try {
          const positionerStyles = getComputedStyle(positionerElement);
          const popupStyles = getComputedStyle(popupElement);
          const doc = ownerDocument(triggerElement);
          const win = getWindow(positionerElement);
          const scale = getScale2(triggerElement);
          const triggerRect = normalizeRect(triggerElement.getBoundingClientRect(), scale);
          const positionerRect = normalizeRect(positionerElement.getBoundingClientRect(), scale);
          const triggerX = triggerRect.left;
          const triggerHeight = triggerRect.height;
          const scroller = listElement || popupElement;
          const scrollHeight = scroller.scrollHeight;
          const borderBottom = parseFloat(popupStyles.borderBottomWidth);
          const marginTop = parseFloat(positionerStyles.marginTop) || 10;
          const marginBottom = parseFloat(positionerStyles.marginBottom) || 10;
          const minHeight = parseFloat(positionerStyles.minHeight) || 100;
          const maxPopupHeight = getMaxPopupHeight(popupStyles);
          const paddingLeft = 5;
          const paddingRight = 5;
          const triggerCollisionThreshold = 20;
          const viewportHeight = doc.documentElement.clientHeight - marginTop - marginBottom;
          const viewportWidth = doc.documentElement.clientWidth;
          const availableSpaceBeneathTrigger = viewportHeight - triggerRect.bottom + triggerHeight;
          const textElement = selectedItemTextRef.current;
          const valueElement = valueRef.current;
          let textRect;
          let offsetX = 0;
          let offsetY = 0;
          if (textElement && valueElement) {
            const valueRect = normalizeRect(valueElement.getBoundingClientRect(), scale);
            textRect = normalizeRect(textElement.getBoundingClientRect(), scale);
            const valueLeftFromTriggerLeft = valueRect.left - triggerX;
            const textLeftFromPositionerLeft = textRect.left - positionerRect.left;
            const valueCenterFromPositionerTop = valueRect.top - triggerRect.top + valueRect.height / 2;
            const textCenterFromTriggerTop = textRect.top - positionerRect.top + textRect.height / 2;
            offsetX = valueLeftFromTriggerLeft - textLeftFromPositionerLeft;
            offsetY = textCenterFromTriggerTop - valueCenterFromPositionerTop;
          }
          const idealHeight = availableSpaceBeneathTrigger + offsetY + marginBottom + borderBottom;
          let height = Math.min(viewportHeight, idealHeight);
          const maxHeight = viewportHeight - marginTop - marginBottom;
          const scrollTop = idealHeight - height;
          const left = Math.max(paddingLeft, triggerX + offsetX);
          const maxRight = viewportWidth - paddingRight;
          const rightOverflow = Math.max(0, left + positionerRect.width - maxRight);
          positionerElement.style.left = `${left - rightOverflow}px`;
          positionerElement.style.height = `${height}px`;
          positionerElement.style.maxHeight = "auto";
          positionerElement.style.marginTop = `${marginTop}px`;
          positionerElement.style.marginBottom = `${marginBottom}px`;
          popupElement.style.height = "100%";
          const maxScrollTop = getMaxScrollTop(scroller);
          const isTopPositioned = scrollTop >= maxScrollTop - SCROLL_EPS_PX;
          if (isTopPositioned) {
            height = Math.min(viewportHeight, positionerRect.height) - (scrollTop - maxScrollTop);
          }
          const fallbackToAlignPopupToTrigger = triggerRect.top < triggerCollisionThreshold || triggerRect.bottom > viewportHeight - triggerCollisionThreshold || Math.ceil(height) + SCROLL_EPS_PX < Math.min(scrollHeight, minHeight);
          const isPinchZoomed = (win.visualViewport?.scale ?? 1) !== 1 && isWebKit2;
          if (fallbackToAlignPopupToTrigger || isPinchZoomed) {
            initialPlacedRef.current = true;
            clearStyles(positionerElement, originalPositionerStylesRef.current);
            ReactDOM8.flushSync(() => setControlledAlignItemWithTrigger(false));
            return;
          }
          if (isTopPositioned) {
            const topOffset = Math.max(0, viewportHeight - idealHeight);
            positionerElement.style.top = positionerRect.height >= maxHeight ? "0" : `${topOffset}px`;
            positionerElement.style.height = `${height}px`;
            scroller.scrollTop = getMaxScrollTop(scroller);
            initialHeightRef.current = Math.max(minHeight, height);
          } else {
            positionerElement.style.bottom = "0";
            initialHeightRef.current = Math.max(minHeight, height);
            scroller.scrollTop = scrollTop;
          }
          if (textRect) {
            const popupTop = positionerRect.top;
            const popupHeight = positionerRect.height;
            const textCenterY = textRect.top + textRect.height / 2;
            const transformOriginY = popupHeight > 0 ? (textCenterY - popupTop) / popupHeight * 100 : 50;
            const clampedY = clamp2(transformOriginY, 0, 100);
            popupElement.style.setProperty("--transform-origin", `50% ${clampedY}%`);
          }
          if (initialHeightRef.current === viewportHeight || height >= maxPopupHeight) {
            reachedMaxHeightRef.current = true;
          }
          handleScrollArrowVisibility();
          setTimeout(() => {
            initialPlacedRef.current = true;
          });
        } finally {
          restoreTransformStyles();
        }
      });
    }, [store, open, positionerElement, triggerElement, valueRef, selectedItemTextRef, popupRef, handleScrollArrowVisibility, alignItemWithTriggerActive, setControlledAlignItemWithTrigger, scrollArrowFrame, scrollDownArrowRef, scrollUpArrowRef, listElement]);
    React135.useEffect(() => {
      if (!alignItemWithTriggerActive || !positionerElement || !open) {
        return void 0;
      }
      const win = getWindow(positionerElement);
      function handleResize(event) {
        setOpen(false, createChangeEventDetails(reason_parts_exports.windowResize, event));
      }
      win.addEventListener("resize", handleResize);
      return () => {
        win.removeEventListener("resize", handleResize);
      };
    }, [setOpen, alignItemWithTriggerActive, positionerElement, open]);
    const defaultProps = {
      ...listElement ? {
        role: "presentation",
        "aria-orientation": void 0
      } : {
        role: "listbox",
        "aria-multiselectable": multiple || void 0,
        id: `${id}-list`
      },
      onKeyDown(event) {
        keyboardActiveRef.current = true;
        if (insideToolbar && COMPOSITE_KEYS.has(event.key)) {
          event.stopPropagation();
        }
      },
      onMouseMove() {
        keyboardActiveRef.current = false;
      },
      onPointerLeave(event) {
        if (!highlightItemOnHover || isMouseWithinBounds(event) || event.pointerType === "touch") {
          return;
        }
        const popup = event.currentTarget;
        highlightTimeout.start(0, () => {
          store.set("activeIndex", null);
          popup.focus({
            preventScroll: true
          });
        });
      },
      onScroll(event) {
        if (listElement) {
          return;
        }
        handleScroll(event.currentTarget);
      },
      ...alignItemWithTriggerActive && {
        style: listElement ? {
          height: "100%"
        } : LIST_FUNCTIONAL_STYLES
      }
    };
    const element = useRenderElement("div", componentProps, {
      ref: [forwardedRef, popupRef],
      state,
      stateAttributesMapping: stateAttributesMapping12,
      props: [popupProps, defaultProps, getDisabledMountTransitionStyles(transitionStatus), {
        className: !listElement && alignItemWithTriggerActive ? styleDisableScrollbar.className : void 0
      }, elementProps]
    });
    return /* @__PURE__ */ (0, import_jsx_runtime41.jsxs)(React135.Fragment, {
      children: [!disableStyleElements && styleDisableScrollbar.getElement(nonce), /* @__PURE__ */ (0, import_jsx_runtime41.jsx)(FloatingFocusManager, {
        context: floatingRootContext,
        modal: false,
        disabled: !mounted,
        returnFocus: finalFocus,
        restoreFocus: true,
        children: element
      })]
    });
  });
  if (true) SelectPopup.displayName = "SelectPopup";
  function getMaxPopupHeight(popupStyles) {
    const maxHeightStyle = popupStyles.maxHeight || "";
    return maxHeightStyle.endsWith("px") ? parseFloat(maxHeightStyle) || Infinity : Infinity;
  }
  function getMaxScrollTop(scroller) {
    return Math.max(0, scroller.scrollHeight - scroller.clientHeight);
  }
  function getScale2(element) {
    return platform2.getScale(element);
  }
  function normalizeRect(rect, scale) {
    return rectToClientRect({
      x: rect.x / scale.x,
      y: rect.y / scale.y,
      width: rect.width / scale.x,
      height: rect.height / scale.y
    });
  }
  var TRANSFORM_STYLE_RESETS = [["transform", "none"], ["scale", "1"], ["translate", "0 0"]];
  function unsetTransformStyles(popupElement) {
    const {
      style
    } = popupElement;
    const originalStyles = {};
    for (const [property, value] of TRANSFORM_STYLE_RESETS) {
      originalStyles[property] = style.getPropertyValue(property);
      style.setProperty(property, value, "important");
    }
    return () => {
      for (const [property] of TRANSFORM_STYLE_RESETS) {
        const originalValue = originalStyles[property];
        if (originalValue) {
          style.setProperty(property, originalValue);
        } else {
          style.removeProperty(property);
        }
      }
    };
  }

  // node_modules/@base-ui/react/esm/select/list/SelectList.js
  init_define_import_meta_env();
  var React136 = __toESM(require_react_shim(), 1);
  var SelectList = /* @__PURE__ */ React136.forwardRef(function SelectList2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store,
      scrollHandlerRef
    } = useSelectRootContext();
    const {
      alignItemWithTriggerActive
    } = useSelectPositionerContext();
    const hasScrollArrows = useStore(store, selectors4.hasScrollArrows);
    const openMethod = useStore(store, selectors4.openMethod);
    const multiple = useStore(store, selectors4.multiple);
    const id = useStore(store, selectors4.id);
    const defaultProps = {
      id: `${id}-list`,
      role: "listbox",
      "aria-multiselectable": multiple || void 0,
      onScroll(event) {
        scrollHandlerRef.current?.(event.currentTarget);
      },
      ...alignItemWithTriggerActive && {
        style: LIST_FUNCTIONAL_STYLES
      },
      className: hasScrollArrows && openMethod !== "touch" ? styleDisableScrollbar.className : void 0
    };
    const setListElement = useStableCallback((element) => {
      store.set("listElement", element);
    });
    return useRenderElement("div", componentProps, {
      ref: [forwardedRef, setListElement],
      props: [defaultProps, elementProps]
    });
  });
  if (true) SelectList.displayName = "SelectList";

  // node_modules/@base-ui/react/esm/select/item/SelectItem.js
  init_define_import_meta_env();
  var React138 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/item/SelectItemContext.js
  init_define_import_meta_env();
  var React137 = __toESM(require_react_shim(), 1);
  var SelectItemContext = /* @__PURE__ */ React137.createContext(void 0);
  if (true) SelectItemContext.displayName = "SelectItemContext";
  function useSelectItemContext() {
    const context = React137.useContext(SelectItemContext);
    if (!context) {
      throw new Error(true ? "Base UI: SelectItemContext is missing. SelectItem parts must be placed within <Select.Item>." : formatErrorMessage_default(57));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/select/item/SelectItem.js
  var import_jsx_runtime42 = __toESM(require_react_shim(), 1);
  var SelectItem = /* @__PURE__ */ React138.memo(/* @__PURE__ */ React138.forwardRef(function SelectItem2(componentProps, forwardedRef) {
    const {
      render,
      className,
      value: itemValue = null,
      label,
      disabled: disabled2 = false,
      nativeButton = false,
      ...elementProps
    } = componentProps;
    const textRef = React138.useRef(null);
    const listItem = useCompositeListItem({
      label,
      textRef,
      indexGuessBehavior: IndexGuessBehavior.GuessFromOrder
    });
    const {
      store,
      getItemProps,
      setOpen,
      setValue,
      selectionRef,
      typingRef,
      valuesRef,
      keyboardActiveRef,
      multiple,
      highlightItemOnHover
    } = useSelectRootContext();
    const highlightTimeout = useTimeout();
    const highlighted = useStore(store, selectors4.isActive, listItem.index);
    const selected = useStore(store, selectors4.isSelected, listItem.index, itemValue);
    const selectedByFocus = useStore(store, selectors4.isSelectedByFocus, listItem.index);
    const isItemEqualToValue = useStore(store, selectors4.isItemEqualToValue);
    const index2 = listItem.index;
    const hasRegistered = index2 !== -1;
    const itemRef = React138.useRef(null);
    const indexRef = useValueAsRef(index2);
    useIsoLayoutEffect(() => {
      if (!hasRegistered) {
        return void 0;
      }
      const values = valuesRef.current;
      values[index2] = itemValue;
      return () => {
        delete values[index2];
      };
    }, [hasRegistered, index2, itemValue, valuesRef]);
    useIsoLayoutEffect(() => {
      if (!hasRegistered) {
        return void 0;
      }
      const selectedValue = store.state.value;
      let selectedCandidate = selectedValue;
      if (multiple && Array.isArray(selectedValue) && selectedValue.length > 0) {
        selectedCandidate = selectedValue[selectedValue.length - 1];
      }
      if (selectedCandidate !== void 0 && compareItemEquality(itemValue, selectedCandidate, isItemEqualToValue)) {
        store.set("selectedIndex", index2);
      }
      return void 0;
    }, [hasRegistered, index2, multiple, isItemEqualToValue, store, itemValue]);
    const state = {
      disabled: disabled2,
      selected,
      highlighted
    };
    const rootProps = getItemProps({
      active: highlighted,
      selected
    });
    rootProps.onFocus = void 0;
    rootProps.id = void 0;
    const lastKeyRef = React138.useRef(null);
    const pointerTypeRef = React138.useRef("mouse");
    const didPointerDownRef = React138.useRef(false);
    const {
      getButtonProps,
      buttonRef
    } = useButton({
      disabled: disabled2,
      focusableWhenDisabled: true,
      native: nativeButton,
      composite: true
    });
    function commitSelection(event) {
      const selectedValue = store.state.value;
      if (multiple) {
        const currentValue = Array.isArray(selectedValue) ? selectedValue : [];
        const nextValue = selected ? removeItem(currentValue, itemValue, isItemEqualToValue) : [...currentValue, itemValue];
        setValue(nextValue, createChangeEventDetails(reason_parts_exports.itemPress, event));
      } else {
        setValue(itemValue, createChangeEventDetails(reason_parts_exports.itemPress, event));
        setOpen(false, createChangeEventDetails(reason_parts_exports.itemPress, event));
      }
    }
    const defaultProps = {
      role: "option",
      "aria-selected": selected,
      tabIndex: highlighted ? 0 : -1,
      onFocus() {
        store.set("activeIndex", index2);
      },
      onMouseEnter() {
        if (!keyboardActiveRef.current && store.state.selectedIndex === null && highlightItemOnHover) {
          store.set("activeIndex", index2);
        }
      },
      onMouseMove() {
        if (highlightItemOnHover) {
          store.set("activeIndex", index2);
        }
      },
      onMouseLeave(event) {
        if (!highlightItemOnHover || keyboardActiveRef.current || isMouseWithinBounds(event)) {
          return;
        }
        highlightTimeout.start(0, () => {
          if (store.state.activeIndex === index2) {
            store.set("activeIndex", null);
          }
        });
      },
      onTouchStart() {
        selectionRef.current = {
          allowSelectedMouseUp: false,
          allowUnselectedMouseUp: false
        };
      },
      onKeyDown(event) {
        lastKeyRef.current = event.key;
        store.set("activeIndex", index2);
        if (event.key === " " && typingRef.current) {
          event.preventDefault();
        }
      },
      onClick(event) {
        didPointerDownRef.current = false;
        if (event.type === "keydown" && lastKeyRef.current === null) {
          return;
        }
        if (disabled2 || event.type === "keydown" && lastKeyRef.current === " " && typingRef.current || pointerTypeRef.current !== "touch" && !highlighted) {
          return;
        }
        lastKeyRef.current = null;
        commitSelection(event.nativeEvent);
      },
      onPointerEnter(event) {
        pointerTypeRef.current = event.pointerType;
      },
      onPointerDown(event) {
        pointerTypeRef.current = event.pointerType;
        didPointerDownRef.current = true;
      },
      onMouseUp() {
        if (disabled2) {
          return;
        }
        if (didPointerDownRef.current) {
          didPointerDownRef.current = false;
          return;
        }
        const disallowSelectedMouseUp = !selectionRef.current.allowSelectedMouseUp && selected;
        const disallowUnselectedMouseUp = !selectionRef.current.allowUnselectedMouseUp && !selected;
        if (disallowSelectedMouseUp || disallowUnselectedMouseUp || pointerTypeRef.current !== "touch" && !highlighted) {
          return;
        }
        itemRef.current?.click();
      }
    };
    const element = useRenderElement("div", componentProps, {
      ref: [buttonRef, forwardedRef, listItem.ref, itemRef],
      state,
      props: [rootProps, defaultProps, elementProps, getButtonProps]
    });
    const contextValue = React138.useMemo(() => ({
      selected,
      indexRef,
      textRef,
      selectedByFocus,
      hasRegistered
    }), [selected, indexRef, textRef, selectedByFocus, hasRegistered]);
    return /* @__PURE__ */ (0, import_jsx_runtime42.jsx)(SelectItemContext.Provider, {
      value: contextValue,
      children: element
    });
  }));
  if (true) SelectItem.displayName = "SelectItem";

  // node_modules/@base-ui/react/esm/select/item-indicator/SelectItemIndicator.js
  init_define_import_meta_env();
  var React139 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime43 = __toESM(require_react_shim(), 1);
  var SelectItemIndicator = /* @__PURE__ */ React139.forwardRef(function SelectItemIndicator2(componentProps, forwardedRef) {
    const keepMounted = componentProps.keepMounted ?? false;
    const {
      selected
    } = useSelectItemContext();
    const shouldRender = keepMounted || selected;
    if (!shouldRender) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime43.jsx)(Inner, {
      ...componentProps,
      ref: forwardedRef
    });
  });
  if (true) SelectItemIndicator.displayName = "SelectItemIndicator";
  var Inner = /* @__PURE__ */ React139.memo(/* @__PURE__ */ React139.forwardRef((componentProps, forwardedRef) => {
    const {
      render,
      className,
      keepMounted,
      ...elementProps
    } = componentProps;
    const {
      selected
    } = useSelectItemContext();
    const indicatorRef = React139.useRef(null);
    const {
      transitionStatus,
      setMounted
    } = useTransitionStatus(selected);
    const state = {
      selected,
      transitionStatus
    };
    const element = useRenderElement("span", componentProps, {
      ref: [forwardedRef, indicatorRef],
      state,
      props: [{
        "aria-hidden": true,
        children: "\u2714\uFE0F"
      }, elementProps],
      stateAttributesMapping: transitionStatusMapping
    });
    useOpenChangeComplete({
      open: selected,
      ref: indicatorRef,
      onComplete() {
        if (!selected) {
          setMounted(false);
        }
      }
    });
    return element;
  }));
  if (true) Inner.displayName = "Inner";

  // node_modules/@base-ui/react/esm/select/item-text/SelectItemText.js
  init_define_import_meta_env();
  var React140 = __toESM(require_react_shim(), 1);
  var SelectItemText = /* @__PURE__ */ React140.memo(/* @__PURE__ */ React140.forwardRef(function SelectItemText2(componentProps, forwardedRef) {
    const {
      indexRef,
      textRef,
      selectedByFocus,
      hasRegistered
    } = useSelectItemContext();
    const {
      selectedItemTextRef
    } = useSelectRootContext();
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const localRef = React140.useCallback((node) => {
      if (!node || !hasRegistered) {
        return;
      }
      const hasNoSelectedItemText = selectedItemTextRef.current === null || !selectedItemTextRef.current.isConnected;
      if (selectedByFocus || hasNoSelectedItemText && indexRef.current === 0) {
        selectedItemTextRef.current = node;
      }
    }, [selectedItemTextRef, indexRef, selectedByFocus, hasRegistered]);
    const element = useRenderElement("div", componentProps, {
      ref: [localRef, forwardedRef, textRef],
      props: elementProps
    });
    return element;
  }));
  if (true) SelectItemText.displayName = "SelectItemText";

  // node_modules/@base-ui/react/esm/select/arrow/SelectArrow.js
  init_define_import_meta_env();
  var React141 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping13 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var SelectArrow = /* @__PURE__ */ React141.forwardRef(function SelectArrow2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      store
    } = useSelectRootContext();
    const {
      side,
      align,
      arrowRef,
      arrowStyles,
      arrowUncentered,
      alignItemWithTriggerActive
    } = useSelectPositionerContext();
    const open = useStore(store, selectors4.open, true);
    const state = {
      open,
      side,
      align,
      uncentered: arrowUncentered
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: [arrowRef, forwardedRef],
      props: [{
        style: arrowStyles,
        "aria-hidden": true
      }, elementProps],
      stateAttributesMapping: stateAttributesMapping13
    });
    if (alignItemWithTriggerActive) {
      return null;
    }
    return element;
  });
  if (true) SelectArrow.displayName = "SelectArrow";

  // node_modules/@base-ui/react/esm/select/scroll-down-arrow/SelectScrollDownArrow.js
  init_define_import_meta_env();
  var React143 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/scroll-arrow/SelectScrollArrow.js
  init_define_import_meta_env();
  var React142 = __toESM(require_react_shim(), 1);
  var SelectScrollArrow = /* @__PURE__ */ React142.forwardRef(function SelectScrollArrow2(componentProps, forwardedRef) {
    const {
      render,
      className,
      direction,
      keepMounted = false,
      ...elementProps
    } = componentProps;
    const {
      store,
      popupRef,
      listRef,
      handleScrollArrowVisibility,
      scrollArrowsMountedCountRef
    } = useSelectRootContext();
    const {
      side,
      scrollDownArrowRef,
      scrollUpArrowRef
    } = useSelectPositionerContext();
    const visibleSelector = direction === "up" ? selectors4.scrollUpArrowVisible : selectors4.scrollDownArrowVisible;
    const stateVisible = useStore(store, visibleSelector);
    const openMethod = useStore(store, selectors4.openMethod);
    const visible = stateVisible && openMethod !== "touch";
    const timeout = useTimeout();
    const scrollArrowRef = direction === "up" ? scrollUpArrowRef : scrollDownArrowRef;
    const {
      transitionStatus,
      setMounted
    } = useTransitionStatus(visible);
    useIsoLayoutEffect(() => {
      scrollArrowsMountedCountRef.current += 1;
      if (!store.state.hasScrollArrows) {
        store.set("hasScrollArrows", true);
      }
      return () => {
        scrollArrowsMountedCountRef.current = Math.max(0, scrollArrowsMountedCountRef.current - 1);
        if (scrollArrowsMountedCountRef.current === 0 && store.state.hasScrollArrows) {
          store.set("hasScrollArrows", false);
        }
      };
    }, [store, scrollArrowsMountedCountRef]);
    useOpenChangeComplete({
      open: visible,
      ref: scrollArrowRef,
      onComplete() {
        if (!visible) {
          setMounted(false);
        }
      }
    });
    const state = {
      direction,
      visible,
      side,
      transitionStatus
    };
    const defaultProps = {
      "aria-hidden": true,
      children: direction === "up" ? "\u25B2" : "\u25BC",
      style: {
        position: "absolute"
      },
      onMouseMove(event) {
        if (event.movementX === 0 && event.movementY === 0 || timeout.isStarted()) {
          return;
        }
        store.set("activeIndex", null);
        function scrollNextItem() {
          const scroller = store.state.listElement ?? popupRef.current;
          if (!scroller) {
            return;
          }
          store.set("activeIndex", null);
          handleScrollArrowVisibility();
          const isScrolledToTop = scroller.scrollTop === 0;
          const isScrolledToBottom = Math.round(scroller.scrollTop + scroller.clientHeight) >= scroller.scrollHeight;
          const list = listRef.current;
          if (list.length === 0) {
            if (direction === "up") {
              store.set("scrollUpArrowVisible", !isScrolledToTop);
            } else {
              store.set("scrollDownArrowVisible", !isScrolledToBottom);
            }
          }
          if (direction === "up" && isScrolledToTop || direction === "down" && isScrolledToBottom) {
            timeout.clear();
            return;
          }
          if ((store.state.listElement || popupRef.current) && listRef.current && listRef.current.length > 0) {
            const items = listRef.current;
            const scrollArrowHeight = scrollArrowRef.current?.offsetHeight || 0;
            if (direction === "up") {
              let firstVisibleIndex = 0;
              const scrollTop = scroller.scrollTop + scrollArrowHeight;
              for (let i = 0; i < items.length; i += 1) {
                const item = items[i];
                if (item) {
                  const itemTop = item.offsetTop;
                  if (itemTop >= scrollTop) {
                    firstVisibleIndex = i;
                    break;
                  }
                }
              }
              const targetIndex = Math.max(0, firstVisibleIndex - 1);
              if (targetIndex < firstVisibleIndex) {
                const targetItem = items[targetIndex];
                if (targetItem) {
                  scroller.scrollTop = Math.max(0, targetItem.offsetTop - scrollArrowHeight);
                }
              } else {
                scroller.scrollTop = 0;
              }
            } else {
              let lastVisibleIndex = items.length - 1;
              const scrollBottom = scroller.scrollTop + scroller.clientHeight - scrollArrowHeight;
              for (let i = 0; i < items.length; i += 1) {
                const item = items[i];
                if (item) {
                  const itemBottom = item.offsetTop + item.offsetHeight;
                  if (itemBottom > scrollBottom) {
                    lastVisibleIndex = Math.max(0, i - 1);
                    break;
                  }
                }
              }
              const targetIndex = Math.min(items.length - 1, lastVisibleIndex + 1);
              if (targetIndex > lastVisibleIndex) {
                const targetItem = items[targetIndex];
                if (targetItem) {
                  scroller.scrollTop = targetItem.offsetTop + targetItem.offsetHeight - scroller.clientHeight + scrollArrowHeight;
                }
              } else {
                scroller.scrollTop = scroller.scrollHeight - scroller.clientHeight;
              }
            }
          }
          timeout.start(40, scrollNextItem);
        }
        timeout.start(40, scrollNextItem);
      },
      onMouseLeave() {
        timeout.clear();
      }
    };
    const element = useRenderElement("div", componentProps, {
      ref: [forwardedRef, scrollArrowRef],
      state,
      props: [defaultProps, elementProps]
    });
    const shouldRender = visible || keepMounted;
    if (!shouldRender) {
      return null;
    }
    return element;
  });
  if (true) SelectScrollArrow.displayName = "SelectScrollArrow";

  // node_modules/@base-ui/react/esm/select/scroll-down-arrow/SelectScrollDownArrow.js
  var import_jsx_runtime44 = __toESM(require_react_shim(), 1);
  var SelectScrollDownArrow = /* @__PURE__ */ React143.forwardRef(function SelectScrollDownArrow2(props, forwardedRef) {
    return /* @__PURE__ */ (0, import_jsx_runtime44.jsx)(SelectScrollArrow, {
      ...props,
      ref: forwardedRef,
      direction: "down"
    });
  });
  if (true) SelectScrollDownArrow.displayName = "SelectScrollDownArrow";

  // node_modules/@base-ui/react/esm/select/scroll-up-arrow/SelectScrollUpArrow.js
  init_define_import_meta_env();
  var React144 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime45 = __toESM(require_react_shim(), 1);
  var SelectScrollUpArrow = /* @__PURE__ */ React144.forwardRef(function SelectScrollUpArrow2(props, forwardedRef) {
    return /* @__PURE__ */ (0, import_jsx_runtime45.jsx)(SelectScrollArrow, {
      ...props,
      ref: forwardedRef,
      direction: "up"
    });
  });
  if (true) SelectScrollUpArrow.displayName = "SelectScrollUpArrow";

  // node_modules/@base-ui/react/esm/select/group/SelectGroup.js
  init_define_import_meta_env();
  var React146 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/select/group/SelectGroupContext.js
  init_define_import_meta_env();
  var React145 = __toESM(require_react_shim(), 1);
  var SelectGroupContext = /* @__PURE__ */ React145.createContext(void 0);
  if (true) SelectGroupContext.displayName = "SelectGroupContext";
  function useSelectGroupContext() {
    const context = React145.useContext(SelectGroupContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: SelectGroupContext is missing. SelectGroup parts must be placed within <Select.Group>." : formatErrorMessage_default(56));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/select/group/SelectGroup.js
  var import_jsx_runtime46 = __toESM(require_react_shim(), 1);
  var SelectGroup = /* @__PURE__ */ React146.forwardRef(function SelectGroup2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const [labelId, setLabelId] = React146.useState();
    const contextValue = React146.useMemo(() => ({
      labelId,
      setLabelId
    }), [labelId, setLabelId]);
    const element = useRenderElement("div", componentProps, {
      ref: forwardedRef,
      props: [{
        role: "group",
        "aria-labelledby": labelId
      }, elementProps]
    });
    return /* @__PURE__ */ (0, import_jsx_runtime46.jsx)(SelectGroupContext.Provider, {
      value: contextValue,
      children: element
    });
  });
  if (true) SelectGroup.displayName = "SelectGroup";

  // node_modules/@base-ui/react/esm/select/group-label/SelectGroupLabel.js
  init_define_import_meta_env();
  var React147 = __toESM(require_react_shim(), 1);
  var SelectGroupLabel = /* @__PURE__ */ React147.forwardRef(function SelectGroupLabel2(componentProps, forwardedRef) {
    const {
      className,
      render,
      id: idProp,
      ...elementProps
    } = componentProps;
    const {
      setLabelId
    } = useSelectGroupContext();
    const id = useBaseUiId(idProp);
    useIsoLayoutEffect(() => {
      setLabelId(id);
    }, [id, setLabelId]);
    const element = useRenderElement("div", componentProps, {
      ref: forwardedRef,
      props: [{
        id
      }, elementProps]
    });
    return element;
  });
  if (true) SelectGroupLabel.displayName = "SelectGroupLabel";

  // src/components/ui/select.tsx
  var import_jsx_runtime47 = __toESM(require_react_shim(), 1);
  var Select = index_parts_exports5.Root;
  function SelectGroup3({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.Group,
      {
        "data-slot": "select-group",
        className: cn("scroll-my-1 p-1", className),
        ...props
      }
    );
  }
  function SelectValue3({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.Value,
      {
        "data-slot": "select-value",
        className: cn("flex flex-1 text-left", className),
        ...props
      }
    );
  }
  function SelectTrigger3({
    className,
    size: size4 = "default",
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsxs)(
      index_parts_exports5.Trigger,
      {
        "data-slot": "select-trigger",
        "data-size": size4,
        className: cn(
          "flex w-fit items-center justify-between gap-1.5 rounded-lg border border-input bg-transparent py-2 pr-2 pl-2.5 text-sm whitespace-nowrap transition-colors outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 data-placeholder:text-muted-foreground data-[size=default]:h-8 data-[size=sm]:h-7 data-[size=sm]:rounded-[min(var(--radius-md),10px)] *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center *:data-[slot=select-value]:gap-1.5 dark:bg-input/30 dark:hover:bg-input/50 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
            index_parts_exports5.Icon,
            {
              render: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(ChevronDown, { className: "pointer-events-none size-4 text-muted-foreground" })
            }
          )
        ]
      }
    );
  }
  function SelectContent({
    className,
    children,
    side = "bottom",
    sideOffset = 4,
    align = "center",
    alignOffset = 0,
    alignItemWithTrigger = true,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(index_parts_exports5.Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.Positioner,
      {
        side,
        sideOffset,
        align,
        alignOffset,
        alignItemWithTrigger,
        className: "isolate z-50",
        children: /* @__PURE__ */ (0, import_jsx_runtime47.jsxs)(
          index_parts_exports5.Popup,
          {
            "data-slot": "select-content",
            "data-align-trigger": alignItemWithTrigger,
            className: cn("relative isolate z-50 max-h-(--available-height) w-(--anchor-width) min-w-36 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 data-[align-trigger=true]:animate-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
            ...props,
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(SelectScrollUpButton, {}),
              /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(index_parts_exports5.List, { children }),
              /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(SelectScrollDownButton, {})
            ]
          }
        )
      }
    ) });
  }
  function SelectLabel3({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.GroupLabel,
      {
        "data-slot": "select-label",
        className: cn("px-1.5 py-1 text-xs text-muted-foreground", className),
        ...props
      }
    );
  }
  function SelectItem3({
    className,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsxs)(
      index_parts_exports5.Item,
      {
        "data-slot": "select-item",
        className: cn(
          "relative flex w-full cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2",
          className
        ),
        ...props,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(index_parts_exports5.ItemText, { className: "flex flex-1 shrink-0 gap-2 whitespace-nowrap", children }),
          /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
            index_parts_exports5.ItemIndicator,
            {
              render: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)("span", { className: "pointer-events-none absolute right-2 flex size-4 items-center justify-center" }),
              children: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(Check, { className: "pointer-events-none" })
            }
          )
        ]
      }
    );
  }
  function SelectSeparator({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.Separator,
      {
        "data-slot": "select-separator",
        className: cn("pointer-events-none -mx-1 my-1 h-px bg-border", className),
        ...props
      }
    );
  }
  function SelectScrollUpButton({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.ScrollUpArrow,
      {
        "data-slot": "select-scroll-up-button",
        className: cn(
          "top-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        ...props,
        children: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
          ChevronUp,
          {}
        )
      }
    );
  }
  function SelectScrollDownButton({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
      index_parts_exports5.ScrollDownArrow,
      {
        "data-slot": "select-scroll-down-button",
        className: cn(
          "bottom-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
          className
        ),
        ...props,
        children: /* @__PURE__ */ (0, import_jsx_runtime47.jsx)(
          ChevronDown,
          {}
        )
      }
    );
  }

  // src/components/ui/separator.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/separator/index.js
  init_define_import_meta_env();

  // src/components/ui/separator.tsx
  var import_jsx_runtime48 = __toESM(require_react_shim(), 1);
  function Separator2({
    className,
    orientation = "horizontal",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime48.jsx)(
      Separator,
      {
        "data-slot": "separator",
        orientation,
        className: cn(
          "shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch",
          className
        ),
        ...props
      }
    );
  }

  // src/components/ui/sheet.tsx
  init_define_import_meta_env();
  var import_jsx_runtime49 = __toESM(require_react_shim(), 1);
  function Sheet({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(index_parts_exports2.Root, { "data-slot": "sheet", ...props });
  }
  function SheetTrigger({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(index_parts_exports2.Trigger, { "data-slot": "sheet-trigger", ...props });
  }
  function SheetClose({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(index_parts_exports2.Close, { "data-slot": "sheet-close", ...props });
  }
  function SheetPortal({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(index_parts_exports2.Portal, { "data-slot": "sheet-portal", ...props });
  }
  function SheetOverlay({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
      index_parts_exports2.Backdrop,
      {
        "data-slot": "sheet-overlay",
        className: cn(
          "fixed inset-0 z-50 bg-black/10 transition-opacity duration-150 data-ending-style:opacity-0 data-starting-style:opacity-0 supports-backdrop-filter:backdrop-blur-xs",
          className
        ),
        ...props
      }
    );
  }
  function SheetContent({
    className,
    children,
    side = "right",
    showCloseButton = true,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)(SheetPortal, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(SheetOverlay, {}),
      /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)(
        index_parts_exports2.Popup,
        {
          "data-slot": "sheet-content",
          "data-side": side,
          className: cn(
            "fixed z-50 flex flex-col gap-4 bg-background bg-clip-padding text-sm shadow-lg transition duration-200 ease-in-out data-ending-style:opacity-0 data-starting-style:opacity-0 data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=bottom]:data-ending-style:translate-y-[2.5rem] data-[side=bottom]:data-starting-style:translate-y-[2.5rem] data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:h-full data-[side=left]:w-3/4 data-[side=left]:border-r data-[side=left]:data-ending-style:translate-x-[-2.5rem] data-[side=left]:data-starting-style:translate-x-[-2.5rem] data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:h-full data-[side=right]:w-3/4 data-[side=right]:border-l data-[side=right]:data-ending-style:translate-x-[2.5rem] data-[side=right]:data-starting-style:translate-x-[2.5rem] data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-[side=top]:data-ending-style:translate-y-[-2.5rem] data-[side=top]:data-starting-style:translate-y-[-2.5rem] data-[side=left]:sm:max-w-sm data-[side=right]:sm:max-w-sm",
            className
          ),
          ...props,
          children: [
            children,
            showCloseButton && /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)(
              index_parts_exports2.Close,
              {
                "data-slot": "sheet-close",
                render: /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
                  Button3,
                  {
                    variant: "ghost",
                    className: "absolute top-3 right-3",
                    size: "icon-sm"
                  }
                ),
                children: [
                  /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
                    X,
                    {}
                  ),
                  /* @__PURE__ */ (0, import_jsx_runtime49.jsx)("span", { className: "sr-only", children: "Close" })
                ]
              }
            )
          ]
        }
      )
    ] });
  }
  function SheetHeader({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
      "div",
      {
        "data-slot": "sheet-header",
        className: cn("flex flex-col gap-0.5 p-4", className),
        ...props
      }
    );
  }
  function SheetFooter({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
      "div",
      {
        "data-slot": "sheet-footer",
        className: cn("mt-auto flex flex-col gap-2 p-4", className),
        ...props
      }
    );
  }
  function SheetTitle({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
      index_parts_exports2.Title,
      {
        "data-slot": "sheet-title",
        className: cn("text-base font-medium text-foreground", className),
        ...props
      }
    );
  }
  function SheetDescription({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(
      index_parts_exports2.Description,
      {
        "data-slot": "sheet-description",
        className: cn("text-sm text-muted-foreground", className),
        ...props
      }
    );
  }

  // src/components/ui/sidebar.tsx
  init_define_import_meta_env();
  var React163 = __toESM(require_react_shim(), 1);

  // src/hooks/use-mobile.ts
  init_define_import_meta_env();
  var React148 = __toESM(require_react_shim());
  var MOBILE_BREAKPOINT = 768;
  function useIsMobile() {
    const [isMobile, setIsMobile] = React148.useState(void 0);
    React148.useEffect(() => {
      const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
      const onChange = () => {
        setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
      };
      mql.addEventListener("change", onChange);
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
      return () => mql.removeEventListener("change", onChange);
    }, []);
    return !!isMobile;
  }

  // src/components/ui/skeleton.tsx
  init_define_import_meta_env();
  var import_jsx_runtime50 = __toESM(require_react_shim(), 1);
  function Skeleton({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime50.jsx)(
      "div",
      {
        "data-slot": "skeleton",
        className: cn("animate-pulse rounded-md bg-muted", className),
        ...props
      }
    );
  }

  // src/components/ui/tooltip.tsx
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/tooltip/index.js
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/tooltip/index.parts.js
  var index_parts_exports6 = {};
  __export(index_parts_exports6, {
    Arrow: () => TooltipArrow,
    Handle: () => TooltipHandle,
    Popup: () => TooltipPopup,
    Portal: () => TooltipPortal,
    Positioner: () => TooltipPositioner,
    Provider: () => TooltipProvider,
    Root: () => TooltipRoot,
    Trigger: () => TooltipTrigger,
    Viewport: () => TooltipViewport,
    createHandle: () => createTooltipHandle
  });
  init_define_import_meta_env();

  // node_modules/@base-ui/react/esm/tooltip/root/TooltipRoot.js
  init_define_import_meta_env();
  var React151 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/tooltip/root/TooltipRootContext.js
  init_define_import_meta_env();
  var React149 = __toESM(require_react_shim(), 1);
  var TooltipRootContext = /* @__PURE__ */ React149.createContext(void 0);
  if (true) TooltipRootContext.displayName = "TooltipRootContext";
  function useTooltipRootContext(optional) {
    const context = React149.useContext(TooltipRootContext);
    if (context === void 0 && !optional) {
      throw new Error(true ? "Base UI: TooltipRootContext is missing. Tooltip parts must be placed within <Tooltip.Root>." : formatErrorMessage_default(72));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/tooltip/store/TooltipStore.js
  init_define_import_meta_env();
  var React150 = __toESM(require_react_shim(), 1);
  var ReactDOM9 = __toESM(require_react_dom_shim(), 1);
  var selectors5 = {
    ...popupStoreSelectors,
    disabled: createSelector2((state) => state.disabled),
    instantType: createSelector2((state) => state.instantType),
    isInstantPhase: createSelector2((state) => state.isInstantPhase),
    trackCursorAxis: createSelector2((state) => state.trackCursorAxis),
    disableHoverablePopup: createSelector2((state) => state.disableHoverablePopup),
    lastOpenChangeReason: createSelector2((state) => state.openChangeReason),
    closeOnClick: createSelector2((state) => state.closeOnClick),
    closeDelay: createSelector2((state) => state.closeDelay),
    hasViewport: createSelector2((state) => state.hasViewport)
  };
  var TooltipStore = class _TooltipStore extends ReactStore {
    constructor(initialState) {
      super({
        ...createInitialState3(),
        ...initialState
      }, {
        popupRef: /* @__PURE__ */ React150.createRef(),
        onOpenChange: void 0,
        onOpenChangeComplete: void 0,
        triggerElements: new PopupTriggerMap()
      }, selectors5);
      __publicField(this, "setOpen", (nextOpen, eventDetails) => {
        const reason = eventDetails.reason;
        const isHover = reason === reason_parts_exports.triggerHover;
        const isFocusOpen = nextOpen && reason === reason_parts_exports.triggerFocus;
        const isDismissClose = !nextOpen && (reason === reason_parts_exports.triggerPress || reason === reason_parts_exports.escapeKey);
        eventDetails.preventUnmountOnClose = () => {
          this.set("preventUnmountingOnClose", true);
        };
        this.context.onOpenChange?.(nextOpen, eventDetails);
        if (eventDetails.isCanceled) {
          return;
        }
        const changeState = () => {
          const updatedState = {
            open: nextOpen,
            openChangeReason: reason
          };
          if (isFocusOpen) {
            updatedState.instantType = "focus";
          } else if (isDismissClose) {
            updatedState.instantType = "dismiss";
          } else if (reason === reason_parts_exports.triggerHover) {
            updatedState.instantType = void 0;
          }
          const newTriggerId = eventDetails.trigger?.id ?? null;
          if (newTriggerId || nextOpen) {
            updatedState.activeTriggerId = newTriggerId;
            updatedState.activeTriggerElement = eventDetails.trigger ?? null;
          }
          this.update(updatedState);
        };
        if (isHover) {
          ReactDOM9.flushSync(changeState);
        } else {
          changeState();
        }
      });
    }
    static useStore(externalStore, initialState) {
      const internalStore = useRefWithInit(() => {
        return new _TooltipStore(initialState);
      }).current;
      const store = externalStore ?? internalStore;
      const floatingRootContext = useSyncedFloatingRootContext({
        popupStore: store,
        onOpenChange: store.setOpen
      });
      store.state.floatingRootContext = floatingRootContext;
      return store;
    }
  };
  function createInitialState3() {
    return {
      ...createInitialPopupStoreState(),
      disabled: false,
      instantType: void 0,
      isInstantPhase: false,
      trackCursorAxis: "none",
      disableHoverablePopup: false,
      openChangeReason: null,
      closeOnClick: true,
      closeDelay: 0,
      hasViewport: false
    };
  }

  // node_modules/@base-ui/react/esm/tooltip/root/TooltipRoot.js
  var import_jsx_runtime51 = __toESM(require_react_shim(), 1);
  var TooltipRoot = fastComponent(function TooltipRoot2(props) {
    const {
      disabled: disabled2 = false,
      defaultOpen = false,
      open: openProp,
      disableHoverablePopup = false,
      trackCursorAxis = "none",
      actionsRef,
      onOpenChange,
      onOpenChangeComplete,
      handle,
      triggerId: triggerIdProp,
      defaultTriggerId: defaultTriggerIdProp = null,
      children
    } = props;
    const store = TooltipStore.useStore(handle?.store, {
      open: defaultOpen,
      openProp,
      activeTriggerId: defaultTriggerIdProp,
      triggerIdProp
    });
    useOnFirstRender(() => {
      if (openProp === void 0 && store.state.open === false && defaultOpen === true) {
        store.update({
          open: true,
          activeTriggerId: defaultTriggerIdProp
        });
      }
    });
    store.useControlledProp("openProp", openProp);
    store.useControlledProp("triggerIdProp", triggerIdProp);
    store.useContextCallback("onOpenChange", onOpenChange);
    store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
    const openState = store.useState("open");
    const open = !disabled2 && openState;
    const activeTriggerId = store.useState("activeTriggerId");
    const payload = store.useState("payload");
    store.useSyncedValues({
      trackCursorAxis,
      disableHoverablePopup
    });
    useIsoLayoutEffect(() => {
      if (openState && disabled2) {
        store.setOpen(false, createChangeEventDetails(reason_parts_exports.disabled));
      }
    }, [openState, disabled2, store]);
    store.useSyncedValue("disabled", disabled2);
    useImplicitActiveTrigger(store);
    const {
      forceUnmount,
      transitionStatus
    } = useOpenStateTransitions(open, store);
    const isInstantPhase = store.useState("isInstantPhase");
    const instantType = store.useState("instantType");
    const lastOpenChangeReason = store.useState("lastOpenChangeReason");
    const previousInstantTypeRef = React151.useRef(null);
    useIsoLayoutEffect(() => {
      if (transitionStatus === "ending" && lastOpenChangeReason === reason_parts_exports.none || transitionStatus !== "ending" && isInstantPhase) {
        if (instantType !== "delay") {
          previousInstantTypeRef.current = instantType;
        }
        store.set("instantType", "delay");
      } else if (previousInstantTypeRef.current !== null) {
        store.set("instantType", previousInstantTypeRef.current);
        previousInstantTypeRef.current = null;
      }
    }, [transitionStatus, isInstantPhase, lastOpenChangeReason, instantType, store]);
    useIsoLayoutEffect(() => {
      if (open) {
        if (activeTriggerId == null) {
          store.set("payload", void 0);
        }
      }
    }, [store, activeTriggerId, open]);
    const handleImperativeClose = React151.useCallback(() => {
      store.setOpen(false, createTooltipEventDetails(store, reason_parts_exports.imperativeAction));
    }, [store]);
    React151.useImperativeHandle(actionsRef, () => ({
      unmount: forceUnmount,
      close: handleImperativeClose
    }), [forceUnmount, handleImperativeClose]);
    const floatingRootContext = store.useState("floatingRootContext");
    const dismiss = useDismiss(floatingRootContext, {
      enabled: !disabled2,
      referencePress: () => store.select("closeOnClick")
    });
    const clientPoint = useClientPoint(floatingRootContext, {
      enabled: !disabled2 && trackCursorAxis !== "none",
      axis: trackCursorAxis === "none" ? void 0 : trackCursorAxis
    });
    const {
      getReferenceProps,
      getFloatingProps,
      getTriggerProps
    } = useInteractions([dismiss, clientPoint]);
    const activeTriggerProps = React151.useMemo(() => getReferenceProps(), [getReferenceProps]);
    const inactiveTriggerProps = React151.useMemo(() => getTriggerProps(), [getTriggerProps]);
    const popupProps = React151.useMemo(() => getFloatingProps(), [getFloatingProps]);
    store.useSyncedValues({
      activeTriggerProps,
      inactiveTriggerProps,
      popupProps
    });
    return /* @__PURE__ */ (0, import_jsx_runtime51.jsx)(TooltipRootContext.Provider, {
      value: store,
      children: typeof children === "function" ? children({
        payload
      }) : children
    });
  });
  if (true) TooltipRoot.displayName = "TooltipRoot";
  function createTooltipEventDetails(store, reason) {
    const details = createChangeEventDetails(reason);
    details.preventUnmountOnClose = () => {
      store.set("preventUnmountingOnClose", true);
    };
    return details;
  }

  // node_modules/@base-ui/react/esm/tooltip/trigger/TooltipTrigger.js
  init_define_import_meta_env();
  var React153 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/tooltip/provider/TooltipProviderContext.js
  init_define_import_meta_env();
  var React152 = __toESM(require_react_shim(), 1);
  var TooltipProviderContext = /* @__PURE__ */ React152.createContext(void 0);
  if (true) TooltipProviderContext.displayName = "TooltipProviderContext";
  function useTooltipProviderContext() {
    return React152.useContext(TooltipProviderContext);
  }

  // node_modules/@base-ui/react/esm/tooltip/trigger/TooltipTriggerDataAttributes.js
  init_define_import_meta_env();
  var TooltipTriggerDataAttributes = (function(TooltipTriggerDataAttributes2) {
    TooltipTriggerDataAttributes2[TooltipTriggerDataAttributes2["popupOpen"] = CommonTriggerDataAttributes.popupOpen] = "popupOpen";
    TooltipTriggerDataAttributes2["triggerDisabled"] = "data-trigger-disabled";
    return TooltipTriggerDataAttributes2;
  })({});

  // node_modules/@base-ui/react/esm/tooltip/utils/constants.js
  init_define_import_meta_env();
  var OPEN_DELAY = 600;

  // node_modules/@base-ui/react/esm/tooltip/trigger/TooltipTrigger.js
  var TooltipTrigger = fastComponentRef(function TooltipTrigger2(componentProps, forwardedRef) {
    const {
      className,
      render,
      handle,
      payload,
      disabled: disabledProp,
      delay,
      closeOnClick = true,
      closeDelay,
      id: idProp,
      ...elementProps
    } = componentProps;
    const rootContext = useTooltipRootContext(true);
    const store = handle?.store ?? rootContext;
    if (!store) {
      throw new Error(true ? "Base UI: <Tooltip.Trigger> must be either used within a <Tooltip.Root> component or provided with a handle." : formatErrorMessage_default(82));
    }
    const thisTriggerId = useBaseUiId(idProp);
    const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
    const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
    const floatingRootContext = store.useState("floatingRootContext");
    const triggerElementRef = React153.useRef(null);
    const delayWithDefault = delay ?? OPEN_DELAY;
    const closeDelayWithDefault = closeDelay ?? 0;
    const {
      registerTrigger,
      isMountedByThisTrigger
    } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
      payload,
      closeOnClick,
      closeDelay: closeDelayWithDefault
    });
    const providerContext = useTooltipProviderContext();
    const {
      delayRef,
      isInstantPhase,
      hasProvider
    } = useDelayGroup(floatingRootContext, {
      open: isOpenedByThisTrigger
    });
    store.useSyncedValue("isInstantPhase", isInstantPhase);
    const rootDisabled = store.useState("disabled");
    const disabled2 = disabledProp ?? rootDisabled;
    const trackCursorAxis = store.useState("trackCursorAxis");
    const disableHoverablePopup = store.useState("disableHoverablePopup");
    const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
      enabled: !disabled2,
      mouseOnly: true,
      move: false,
      handleClose: !disableHoverablePopup && trackCursorAxis !== "both" ? safePolygon() : null,
      restMs() {
        const providerDelay = providerContext?.delay;
        const groupOpenValue = typeof delayRef.current === "object" ? delayRef.current.open : void 0;
        let computedRestMs = delayWithDefault;
        if (hasProvider) {
          if (groupOpenValue !== 0) {
            computedRestMs = delay ?? providerDelay ?? delayWithDefault;
          } else {
            computedRestMs = 0;
          }
        }
        return computedRestMs;
      },
      delay() {
        const closeValue = typeof delayRef.current === "object" ? delayRef.current.close : void 0;
        let computedCloseDelay = closeDelayWithDefault;
        if (closeDelay == null && hasProvider) {
          computedCloseDelay = closeValue;
        }
        return {
          close: computedCloseDelay
        };
      },
      triggerElementRef,
      isActiveTrigger: isTriggerActive
    });
    const focusProps = useFocus(floatingRootContext, {
      enabled: !disabled2
    }).reference;
    const state = {
      open: isOpenedByThisTrigger
    };
    const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
    const element = useRenderElement("button", componentProps, {
      state,
      ref: [forwardedRef, registerTrigger, triggerElementRef],
      props: [hoverProps, focusProps, rootTriggerProps, {
        onPointerDown() {
          store.set("closeOnClick", closeOnClick);
        },
        id: thisTriggerId,
        [TooltipTriggerDataAttributes.triggerDisabled]: disabled2 ? "" : void 0
      }, elementProps],
      stateAttributesMapping: triggerOpenStateMapping
    });
    return element;
  });
  if (true) TooltipTrigger.displayName = "TooltipTrigger";

  // node_modules/@base-ui/react/esm/tooltip/portal/TooltipPortal.js
  init_define_import_meta_env();
  var React156 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/tooltip/portal/TooltipPortalContext.js
  init_define_import_meta_env();
  var React154 = __toESM(require_react_shim(), 1);
  var TooltipPortalContext = /* @__PURE__ */ React154.createContext(void 0);
  if (true) TooltipPortalContext.displayName = "TooltipPortalContext";
  function useTooltipPortalContext() {
    const value = React154.useContext(TooltipPortalContext);
    if (value === void 0) {
      throw new Error(true ? "Base UI: <Tooltip.Portal> is missing." : formatErrorMessage_default(70));
    }
    return value;
  }

  // node_modules/@base-ui/react/esm/utils/FloatingPortalLite.js
  init_define_import_meta_env();
  var React155 = __toESM(require_react_shim(), 1);
  var ReactDOM10 = __toESM(require_react_dom_shim(), 1);
  var import_jsx_runtime52 = __toESM(require_react_shim(), 1);
  var FloatingPortalLite = /* @__PURE__ */ React155.forwardRef(function FloatingPortalLite2(componentProps, forwardedRef) {
    const {
      children,
      container,
      className,
      render,
      ...elementProps
    } = componentProps;
    const {
      portalNode,
      portalSubtree
    } = useFloatingPortalNode({
      container,
      ref: forwardedRef,
      componentProps,
      elementProps
    });
    if (!portalSubtree && !portalNode) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime52.jsxs)(React155.Fragment, {
      children: [portalSubtree, portalNode && /* @__PURE__ */ ReactDOM10.createPortal(children, portalNode)]
    });
  });
  if (true) FloatingPortalLite.displayName = "FloatingPortalLite";

  // node_modules/@base-ui/react/esm/tooltip/portal/TooltipPortal.js
  var import_jsx_runtime53 = __toESM(require_react_shim(), 1);
  var TooltipPortal = /* @__PURE__ */ React156.forwardRef(function TooltipPortal2(props, forwardedRef) {
    const {
      keepMounted = false,
      ...portalProps
    } = props;
    const store = useTooltipRootContext();
    const mounted = store.useState("mounted");
    const shouldRender = mounted || keepMounted;
    if (!shouldRender) {
      return null;
    }
    return /* @__PURE__ */ (0, import_jsx_runtime53.jsx)(TooltipPortalContext.Provider, {
      value: keepMounted,
      children: /* @__PURE__ */ (0, import_jsx_runtime53.jsx)(FloatingPortalLite, {
        ref: forwardedRef,
        ...portalProps
      })
    });
  });
  if (true) TooltipPortal.displayName = "TooltipPortal";

  // node_modules/@base-ui/react/esm/tooltip/positioner/TooltipPositioner.js
  init_define_import_meta_env();
  var React158 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/tooltip/positioner/TooltipPositionerContext.js
  init_define_import_meta_env();
  var React157 = __toESM(require_react_shim(), 1);
  var TooltipPositionerContext = /* @__PURE__ */ React157.createContext(void 0);
  if (true) TooltipPositionerContext.displayName = "TooltipPositionerContext";
  function useTooltipPositionerContext() {
    const context = React157.useContext(TooltipPositionerContext);
    if (context === void 0) {
      throw new Error(true ? "Base UI: TooltipPositionerContext is missing. TooltipPositioner parts must be placed within <Tooltip.Positioner>." : formatErrorMessage_default(71));
    }
    return context;
  }

  // node_modules/@base-ui/react/esm/tooltip/positioner/TooltipPositioner.js
  var import_jsx_runtime54 = __toESM(require_react_shim(), 1);
  var TooltipPositioner = /* @__PURE__ */ React158.forwardRef(function TooltipPositioner2(componentProps, forwardedRef) {
    const {
      render,
      className,
      anchor,
      positionMethod = "absolute",
      side = "top",
      align = "center",
      sideOffset = 0,
      alignOffset = 0,
      collisionBoundary = "clipping-ancestors",
      collisionPadding = 5,
      arrowPadding = 5,
      sticky = false,
      disableAnchorTracking = false,
      collisionAvoidance = POPUP_COLLISION_AVOIDANCE,
      ...elementProps
    } = componentProps;
    const store = useTooltipRootContext();
    const keepMounted = useTooltipPortalContext();
    const open = store.useState("open");
    const mounted = store.useState("mounted");
    const trackCursorAxis = store.useState("trackCursorAxis");
    const disableHoverablePopup = store.useState("disableHoverablePopup");
    const floatingRootContext = store.useState("floatingRootContext");
    const instantType = store.useState("instantType");
    const transitionStatus = store.useState("transitionStatus");
    const hasViewport = store.useState("hasViewport");
    const positioning = useAnchorPositioning({
      anchor,
      positionMethod,
      floatingRootContext,
      mounted,
      side,
      sideOffset,
      align,
      alignOffset,
      collisionBoundary,
      collisionPadding,
      sticky,
      arrowPadding,
      disableAnchorTracking,
      keepMounted,
      collisionAvoidance,
      adaptiveOrigin: hasViewport ? adaptiveOrigin : void 0
    });
    const defaultProps = React158.useMemo(() => {
      const hiddenStyles = {};
      if (!open || trackCursorAxis === "both" || disableHoverablePopup) {
        hiddenStyles.pointerEvents = "none";
      }
      return {
        role: "presentation",
        hidden: !mounted,
        style: {
          ...positioning.positionerStyles,
          ...hiddenStyles
        }
      };
    }, [open, trackCursorAxis, disableHoverablePopup, mounted, positioning.positionerStyles]);
    const state = React158.useMemo(() => ({
      open,
      side: positioning.side,
      align: positioning.align,
      anchorHidden: positioning.anchorHidden,
      instant: trackCursorAxis !== "none" ? "tracking-cursor" : instantType
    }), [open, positioning.side, positioning.align, positioning.anchorHidden, trackCursorAxis, instantType]);
    const contextValue = React158.useMemo(() => ({
      ...state,
      arrowRef: positioning.arrowRef,
      arrowStyles: positioning.arrowStyles,
      arrowUncentered: positioning.arrowUncentered
    }), [state, positioning.arrowRef, positioning.arrowStyles, positioning.arrowUncentered]);
    const element = useRenderElement("div", componentProps, {
      state,
      props: [defaultProps, getDisabledMountTransitionStyles(transitionStatus), elementProps],
      ref: [forwardedRef, store.useStateSetter("positionerElement")],
      stateAttributesMapping: popupStateMapping
    });
    return /* @__PURE__ */ (0, import_jsx_runtime54.jsx)(TooltipPositionerContext.Provider, {
      value: contextValue,
      children: element
    });
  });
  if (true) TooltipPositioner.displayName = "TooltipPositioner";

  // node_modules/@base-ui/react/esm/tooltip/popup/TooltipPopup.js
  init_define_import_meta_env();
  var React159 = __toESM(require_react_shim(), 1);
  var stateAttributesMapping14 = {
    ...popupStateMapping,
    ...transitionStatusMapping
  };
  var TooltipPopup = /* @__PURE__ */ React159.forwardRef(function TooltipPopup2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const store = useTooltipRootContext();
    const {
      side,
      align
    } = useTooltipPositionerContext();
    const open = store.useState("open");
    const instantType = store.useState("instantType");
    const transitionStatus = store.useState("transitionStatus");
    const popupProps = store.useState("popupProps");
    const floatingContext = store.useState("floatingRootContext");
    useOpenChangeComplete({
      open,
      ref: store.context.popupRef,
      onComplete() {
        if (open) {
          store.context.onOpenChangeComplete?.(true);
        }
      }
    });
    const disabled2 = store.useState("disabled");
    const closeDelay = store.useState("closeDelay");
    useHoverFloatingInteraction(floatingContext, {
      enabled: !disabled2,
      closeDelay
    });
    const state = {
      open,
      side,
      align,
      instant: instantType,
      transitionStatus
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: [forwardedRef, store.context.popupRef, store.useStateSetter("popupElement")],
      props: [popupProps, getDisabledMountTransitionStyles(transitionStatus), elementProps],
      stateAttributesMapping: stateAttributesMapping14
    });
    return element;
  });
  if (true) TooltipPopup.displayName = "TooltipPopup";

  // node_modules/@base-ui/react/esm/tooltip/arrow/TooltipArrow.js
  init_define_import_meta_env();
  var React160 = __toESM(require_react_shim(), 1);
  var TooltipArrow = /* @__PURE__ */ React160.forwardRef(function TooltipArrow2(componentProps, forwardedRef) {
    const {
      className,
      render,
      ...elementProps
    } = componentProps;
    const store = useTooltipRootContext();
    const instantType = store.useState("instantType");
    const {
      open,
      arrowRef,
      side,
      align,
      arrowUncentered,
      arrowStyles
    } = useTooltipPositionerContext();
    const state = {
      open,
      side,
      align,
      uncentered: arrowUncentered,
      instant: instantType
    };
    const element = useRenderElement("div", componentProps, {
      state,
      ref: [forwardedRef, arrowRef],
      props: [{
        style: arrowStyles,
        "aria-hidden": true
      }, elementProps],
      stateAttributesMapping: popupStateMapping
    });
    return element;
  });
  if (true) TooltipArrow.displayName = "TooltipArrow";

  // node_modules/@base-ui/react/esm/tooltip/provider/TooltipProvider.js
  init_define_import_meta_env();
  var React161 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime55 = __toESM(require_react_shim(), 1);
  var TooltipProvider = function TooltipProvider2(props) {
    const {
      delay,
      closeDelay,
      timeout = 400
    } = props;
    const contextValue = React161.useMemo(() => ({
      delay,
      closeDelay
    }), [delay, closeDelay]);
    const delayValue = React161.useMemo(() => ({
      open: delay,
      close: closeDelay
    }), [delay, closeDelay]);
    return /* @__PURE__ */ (0, import_jsx_runtime55.jsx)(TooltipProviderContext.Provider, {
      value: contextValue,
      children: /* @__PURE__ */ (0, import_jsx_runtime55.jsx)(FloatingDelayGroup, {
        delay: delayValue,
        timeoutMs: timeout,
        children: props.children
      })
    });
  };
  if (true) TooltipProvider.displayName = "TooltipProvider";

  // node_modules/@base-ui/react/esm/tooltip/viewport/TooltipViewport.js
  init_define_import_meta_env();
  var React162 = __toESM(require_react_shim(), 1);

  // node_modules/@base-ui/react/esm/tooltip/viewport/TooltipViewportCssVars.js
  init_define_import_meta_env();
  var TooltipViewportCssVars = /* @__PURE__ */ (function(TooltipViewportCssVars2) {
    TooltipViewportCssVars2["popupWidth"] = "--popup-width";
    TooltipViewportCssVars2["popupHeight"] = "--popup-height";
    return TooltipViewportCssVars2;
  })({});

  // node_modules/@base-ui/react/esm/tooltip/viewport/TooltipViewport.js
  var stateAttributesMapping15 = {
    activationDirection: (value) => value ? {
      "data-activation-direction": value
    } : null
  };
  var TooltipViewport = /* @__PURE__ */ React162.forwardRef(function TooltipViewport2(componentProps, forwardedRef) {
    const {
      render,
      className,
      children,
      ...elementProps
    } = componentProps;
    const store = useTooltipRootContext();
    const positioner = useTooltipPositionerContext();
    const instantType = store.useState("instantType");
    const {
      children: childrenToRender,
      state: viewportState
    } = usePopupViewport({
      store,
      side: positioner.side,
      cssVars: TooltipViewportCssVars,
      children
    });
    const state = {
      activationDirection: viewportState.activationDirection,
      transitioning: viewportState.transitioning,
      instant: instantType
    };
    return useRenderElement("div", componentProps, {
      state,
      ref: forwardedRef,
      props: [elementProps, {
        children: childrenToRender
      }],
      stateAttributesMapping: stateAttributesMapping15
    });
  });
  if (true) TooltipViewport.displayName = "TooltipViewport";

  // node_modules/@base-ui/react/esm/tooltip/store/TooltipHandle.js
  init_define_import_meta_env();
  var TooltipHandle = class {
    /**
     * Internal store holding the tooltip state.
     * @internal
     */
    constructor() {
      this.store = new TooltipStore();
    }
    /**
     * Opens the tooltip and associates it with the trigger with the given ID.
     * The trigger must be a Tooltip.Trigger component with this handle passed as a prop.
     *
     * This method should only be called in an event handler or an effect (not during rendering).
     *
     * @param triggerId ID of the trigger to associate with the tooltip.
     */
    open(triggerId) {
      const triggerElement = triggerId ? this.store.context.triggerElements.getById(triggerId) : void 0;
      if (triggerId && !triggerElement) {
        throw new Error(true ? `Base UI: TooltipHandle.open: No trigger found with id "${triggerId}".` : formatErrorMessage_default(81, triggerId));
      }
      this.store.setOpen(true, createChangeEventDetails(reason_parts_exports.imperativeAction, void 0, triggerElement));
    }
    /**
     * Closes the tooltip.
     */
    close() {
      this.store.setOpen(false, createChangeEventDetails(reason_parts_exports.imperativeAction, void 0, void 0));
    }
    /**
     * Indicates whether the tooltip is currently open.
     */
    get isOpen() {
      return this.store.state.open;
    }
  };
  function createTooltipHandle() {
    return new TooltipHandle();
  }

  // src/components/ui/tooltip.tsx
  var import_jsx_runtime56 = __toESM(require_react_shim(), 1);
  function TooltipProvider3({
    delay = 0,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(
      index_parts_exports6.Provider,
      {
        "data-slot": "tooltip-provider",
        delay,
        ...props
      }
    );
  }
  function Tooltip({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(index_parts_exports6.Root, { "data-slot": "tooltip", ...props });
  }
  function TooltipTrigger3({ ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(index_parts_exports6.Trigger, { "data-slot": "tooltip-trigger", ...props });
  }
  function TooltipContent({
    className,
    side = "top",
    sideOffset = 4,
    align = "center",
    alignOffset = 0,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(index_parts_exports6.Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(
      index_parts_exports6.Positioner,
      {
        align,
        alignOffset,
        side,
        sideOffset,
        className: "isolate z-50",
        children: /* @__PURE__ */ (0, import_jsx_runtime56.jsxs)(
          index_parts_exports6.Popup,
          {
            "data-slot": "tooltip-content",
            className: cn(
              "z-50 inline-flex w-fit max-w-xs origin-(--transform-origin) items-center gap-1.5 rounded-md bg-foreground px-3 py-1.5 text-xs text-background has-data-[slot=kbd]:pr-1.5 data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 **:data-[slot=kbd]:relative **:data-[slot=kbd]:isolate **:data-[slot=kbd]:z-50 **:data-[slot=kbd]:rounded-sm data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",
              className
            ),
            ...props,
            children: [
              children,
              /* @__PURE__ */ (0, import_jsx_runtime56.jsx)(index_parts_exports6.Arrow, { className: "z-50 size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground data-[side=bottom]:top-1 data-[side=inline-end]:top-1/2! data-[side=inline-end]:-left-1 data-[side=inline-end]:-translate-y-1/2 data-[side=inline-start]:top-1/2! data-[side=inline-start]:-right-1 data-[side=inline-start]:-translate-y-1/2 data-[side=left]:top-1/2! data-[side=left]:-right-1 data-[side=left]:-translate-y-1/2 data-[side=right]:top-1/2! data-[side=right]:-left-1 data-[side=right]:-translate-y-1/2 data-[side=top]:-bottom-2.5" })
            ]
          }
        )
      }
    ) });
  }

  // src/components/ui/sidebar.tsx
  var import_jsx_runtime57 = __toESM(require_react_shim(), 1);
  var SIDEBAR_COOKIE_NAME = "sidebar_state";
  var SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
  var SIDEBAR_WIDTH = "16rem";
  var SIDEBAR_WIDTH_MOBILE = "18rem";
  var SIDEBAR_WIDTH_ICON = "3rem";
  var SIDEBAR_KEYBOARD_SHORTCUT = "b";
  var SidebarContext = React163.createContext(null);
  function useSidebar() {
    const context = React163.useContext(SidebarContext);
    if (!context) {
      throw new Error("useSidebar must be used within a SidebarProvider.");
    }
    return context;
  }
  function SidebarProvider({
    defaultOpen = true,
    open: openProp,
    onOpenChange: setOpenProp,
    className,
    style,
    children,
    ...props
  }) {
    const isMobile = useIsMobile();
    const [openMobile, setOpenMobile] = React163.useState(false);
    const [_open, _setOpen] = React163.useState(defaultOpen);
    const open = openProp ?? _open;
    const setOpen = React163.useCallback(
      (value) => {
        const openState = typeof value === "function" ? value(open) : value;
        if (setOpenProp) {
          setOpenProp(openState);
        } else {
          _setOpen(openState);
        }
        document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
      },
      [setOpenProp, open]
    );
    const toggleSidebar = React163.useCallback(() => {
      return isMobile ? setOpenMobile((open2) => !open2) : setOpen((open2) => !open2);
    }, [isMobile, setOpen, setOpenMobile]);
    React163.useEffect(() => {
      const handleKeyDown = (event) => {
        if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          toggleSidebar();
        }
      };
      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }, [toggleSidebar]);
    const state = open ? "expanded" : "collapsed";
    const contextValue = React163.useMemo(
      () => ({
        state,
        open,
        setOpen,
        isMobile,
        openMobile,
        setOpenMobile,
        toggleSidebar
      }),
      [state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSidebar]
    );
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(SidebarContext.Provider, { value: contextValue, children: /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-wrapper",
        style: {
          "--sidebar-width": SIDEBAR_WIDTH,
          "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
          ...style
        },
        className: cn(
          "group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar",
          className
        ),
        ...props,
        children
      }
    ) });
  }
  function Sidebar({
    side = "left",
    variant = "sidebar",
    collapsible = "offcanvas",
    className,
    children,
    dir,
    ...props
  }) {
    const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
    if (collapsible === "none") {
      return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
        "div",
        {
          "data-slot": "sidebar",
          className: cn(
            "flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground",
            className
          ),
          ...props,
          children
        }
      );
    }
    if (isMobile) {
      return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(Sheet, { open: openMobile, onOpenChange: setOpenMobile, ...props, children: /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(
        SheetContent,
        {
          dir,
          "data-sidebar": "sidebar",
          "data-slot": "sidebar",
          "data-mobile": "true",
          className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
          style: {
            "--sidebar-width": SIDEBAR_WIDTH_MOBILE
          },
          side,
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(SheetHeader, { className: "sr-only", children: [
              /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(SheetTitle, { children: "Sidebar" }),
              /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(SheetDescription, { children: "Displays the mobile sidebar." })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime57.jsx)("div", { className: "flex h-full w-full flex-col", children })
          ]
        }
      ) });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(
      "div",
      {
        className: "group peer hidden text-sidebar-foreground md:block",
        "data-state": state,
        "data-collapsible": state === "collapsed" ? collapsible : "",
        "data-variant": variant,
        "data-side": side,
        "data-slot": "sidebar",
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
            "div",
            {
              "data-slot": "sidebar-gap",
              className: cn(
                "relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear",
                "group-data-[collapsible=offcanvas]:w-0",
                "group-data-[side=right]:rotate-180",
                variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)"
              )
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
            "div",
            {
              "data-slot": "sidebar-container",
              "data-side": side,
              className: cn(
                "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex",
                // Adjust the padding for floating and inset variants.
                variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
                className
              ),
              ...props,
              children: /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
                "div",
                {
                  "data-sidebar": "sidebar",
                  "data-slot": "sidebar-inner",
                  className: "flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:shadow-sm group-data-[variant=floating]:ring-1 group-data-[variant=floating]:ring-sidebar-border",
                  children
                }
              )
            }
          )
        ]
      }
    );
  }
  function SidebarTrigger({
    className,
    onClick,
    ...props
  }) {
    const { toggleSidebar } = useSidebar();
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(
      Button3,
      {
        "data-sidebar": "trigger",
        "data-slot": "sidebar-trigger",
        variant: "ghost",
        size: "icon-sm",
        className: cn(className),
        onClick: (event) => {
          onClick?.(event);
          toggleSidebar();
        },
        ...props,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(PanelLeft, {}),
          /* @__PURE__ */ (0, import_jsx_runtime57.jsx)("span", { className: "sr-only", children: "Toggle Sidebar" })
        ]
      }
    );
  }
  function SidebarRail({ className, ...props }) {
    const { toggleSidebar } = useSidebar();
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "button",
      {
        "data-sidebar": "rail",
        "data-slot": "sidebar-rail",
        "aria-label": "Toggle Sidebar",
        tabIndex: -1,
        onClick: toggleSidebar,
        title: "Toggle Sidebar",
        className: cn(
          "absolute inset-y-0 z-20 hidden w-4 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:start-1/2 after:w-[2px] hover:after:bg-sidebar-border sm:flex ltr:-translate-x-1/2 rtl:-translate-x-1/2",
          "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize",
          "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
          "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar",
          "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
          "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
          className
        ),
        ...props
      }
    );
  }
  function SidebarInset({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "main",
      {
        "data-slot": "sidebar-inset",
        className: cn(
          // min-w-0 is load-bearing: a flex item defaults to min-width:auto, so it
          // refuses to shrink below its widest child. One long log line or a wide
          // table then stretches this pane past the viewport, the page grows a
          // horizontal scrollbar, and scrolling right slides the content under the
          // fixed sidebar. Content that overflows should scroll inside its own box.
          "relative flex w-full min-w-0 flex-1 flex-col bg-background md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2",
          className
        ),
        ...props
      }
    );
  }
  function SidebarInput({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      Input3,
      {
        "data-slot": "sidebar-input",
        "data-sidebar": "input",
        className: cn("h-8 w-full bg-background shadow-none", className),
        ...props
      }
    );
  }
  function SidebarHeader({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-header",
        "data-sidebar": "header",
        className: cn("flex flex-col gap-2 p-2", className),
        ...props
      }
    );
  }
  function SidebarFooter({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-footer",
        "data-sidebar": "footer",
        className: cn("flex flex-col gap-2 p-2", className),
        ...props
      }
    );
  }
  function SidebarSeparator({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      Separator2,
      {
        "data-slot": "sidebar-separator",
        "data-sidebar": "separator",
        className: cn("mx-2 w-auto bg-sidebar-border", className),
        ...props
      }
    );
  }
  function SidebarContent({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-content",
        "data-sidebar": "content",
        className: cn(
          "no-scrollbar flex min-h-0 flex-1 flex-col gap-0 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
          className
        ),
        ...props
      }
    );
  }
  function SidebarGroup({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-group",
        "data-sidebar": "group",
        className: cn("relative flex w-full min-w-0 flex-col p-2", className),
        ...props
      }
    );
  }
  function SidebarGroupLabel({
    className,
    render,
    ...props
  }) {
    return useRender({
      defaultTagName: "div",
      props: mergeProps(
        {
          className: cn(
            "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
            className
          )
        },
        props
      ),
      render,
      state: {
        slot: "sidebar-group-label",
        sidebar: "group-label"
      }
    });
  }
  function SidebarGroupAction({
    className,
    render,
    ...props
  }) {
    return useRender({
      defaultTagName: "button",
      props: mergeProps(
        {
          className: cn(
            "absolute top-3.5 right-3 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0",
            className
          )
        },
        props
      ),
      render,
      state: {
        slot: "sidebar-group-action",
        sidebar: "group-action"
      }
    });
  }
  function SidebarGroupContent({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-group-content",
        "data-sidebar": "group-content",
        className: cn("w-full text-sm", className),
        ...props
      }
    );
  }
  function SidebarMenu({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "ul",
      {
        "data-slot": "sidebar-menu",
        "data-sidebar": "menu",
        className: cn("flex w-full min-w-0 flex-col gap-0", className),
        ...props
      }
    );
  }
  function SidebarMenuItem({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "li",
      {
        "data-slot": "sidebar-menu-item",
        "data-sidebar": "menu-item",
        className: cn("group/menu-item relative", className),
        ...props
      }
    );
  }
  var sidebarMenuButtonVariants = cva(
    "peer/menu-button group/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm ring-sidebar-ring outline-hidden transition-[width,height,padding] group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-open:hover:bg-sidebar-accent data-open:hover:text-sidebar-accent-foreground data-active:bg-sidebar-accent data-active:font-medium data-active:text-sidebar-accent-foreground [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate",
    {
      variants: {
        variant: {
          default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
          outline: "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]"
        },
        size: {
          default: "h-8 text-sm",
          sm: "h-7 text-xs",
          lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
        }
      },
      defaultVariants: {
        variant: "default",
        size: "default"
      }
    }
  );
  function SidebarMenuButton({
    render,
    isActive = false,
    variant = "default",
    size: size4 = "default",
    tooltip,
    className,
    ...props
  }) {
    const { isMobile, state } = useSidebar();
    const comp = useRender({
      defaultTagName: "button",
      props: mergeProps(
        {
          className: cn(sidebarMenuButtonVariants({ variant, size: size4 }), className)
        },
        props
      ),
      render: !tooltip ? render : /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(TooltipTrigger3, { render }),
      state: {
        slot: "sidebar-menu-button",
        sidebar: "menu-button",
        size: size4,
        active: isActive
      }
    });
    if (!tooltip) {
      return comp;
    }
    if (typeof tooltip === "string") {
      tooltip = {
        children: tooltip
      };
    }
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(Tooltip, { children: [
      comp,
      /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
        TooltipContent,
        {
          side: "right",
          align: "center",
          hidden: state !== "collapsed" || isMobile,
          ...tooltip
        }
      )
    ] });
  }
  function SidebarMenuAction({
    className,
    render,
    showOnHover = false,
    ...props
  }) {
    return useRender({
      defaultTagName: "button",
      props: mergeProps(
        {
          className: cn(
            "absolute top-1.5 right-1 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0",
            showOnHover && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 peer-data-active/menu-button:text-sidebar-accent-foreground aria-expanded:opacity-100 md:opacity-0",
            className
          )
        },
        props
      ),
      render,
      state: {
        slot: "sidebar-menu-action",
        sidebar: "menu-action"
      }
    });
  }
  function SidebarMenuBadge({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "div",
      {
        "data-slot": "sidebar-menu-badge",
        "data-sidebar": "menu-badge",
        className: cn(
          "pointer-events-none absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium text-sidebar-foreground tabular-nums select-none group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 peer-data-active/menu-button:text-sidebar-accent-foreground",
          className
        ),
        ...props
      }
    );
  }
  function SidebarMenuSkeleton({
    className,
    showIcon = false,
    ...props
  }) {
    const [width] = React163.useState(() => {
      return `${Math.floor(Math.random() * 40) + 50}%`;
    });
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)(
      "div",
      {
        "data-slot": "sidebar-menu-skeleton",
        "data-sidebar": "menu-skeleton",
        className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
        ...props,
        children: [
          showIcon && /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
            Skeleton,
            {
              className: "size-4 rounded-md",
              "data-sidebar": "menu-skeleton-icon"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
            Skeleton,
            {
              className: "h-4 max-w-(--skeleton-width) flex-1",
              "data-sidebar": "menu-skeleton-text",
              style: {
                "--skeleton-width": width
              }
            }
          )
        ]
      }
    );
  }
  function SidebarMenuSub({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "ul",
      {
        "data-slot": "sidebar-menu-sub",
        "data-sidebar": "menu-sub",
        className: cn(
          "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5 group-data-[collapsible=icon]:hidden",
          className
        ),
        ...props
      }
    );
  }
  function SidebarMenuSubItem({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(
      "li",
      {
        "data-slot": "sidebar-menu-sub-item",
        "data-sidebar": "menu-sub-item",
        className: cn("group/menu-sub-item relative", className),
        ...props
      }
    );
  }
  function SidebarMenuSubButton({
    render,
    size: size4 = "md",
    isActive = false,
    className,
    ...props
  }) {
    return useRender({
      defaultTagName: "a",
      props: mergeProps(
        {
          className: cn(
            "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground ring-sidebar-ring outline-hidden group-data-[collapsible=icon]:hidden hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[size=md]:text-sm data-[size=sm]:text-xs data-active:bg-sidebar-accent data-active:text-sidebar-accent-foreground [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
            className
          )
        },
        props
      ),
      render,
      state: {
        slot: "sidebar-menu-sub-button",
        sidebar: "menu-sub-button",
        size: size4,
        active: isActive
      }
    });
  }

  // src/components/ui/table.tsx
  init_define_import_meta_env();
  var import_jsx_runtime58 = __toESM(require_react_shim(), 1);
  function Table({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "div",
      {
        "data-slot": "table-container",
        className: "relative w-full overflow-x-auto",
        children: /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
          "table",
          {
            "data-slot": "table",
            className: cn("w-full caption-bottom text-sm", className),
            ...props
          }
        )
      }
    );
  }
  function TableHeader({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "thead",
      {
        "data-slot": "table-header",
        className: cn("[&_tr]:border-b", className),
        ...props
      }
    );
  }
  function TableBody({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "tbody",
      {
        "data-slot": "table-body",
        className: cn("[&_tr:last-child]:border-0", className),
        ...props
      }
    );
  }
  function TableFooter({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "tfoot",
      {
        "data-slot": "table-footer",
        className: cn(
          "border-t bg-muted/50 font-medium [&>tr]:last:border-b-0",
          className
        ),
        ...props
      }
    );
  }
  function TableRow({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "tr",
      {
        "data-slot": "table-row",
        className: cn(
          "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
          className
        ),
        ...props
      }
    );
  }
  function TableHead({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "th",
      {
        "data-slot": "table-head",
        className: cn(
          "h-10 px-2 text-left align-middle font-medium whitespace-nowrap text-foreground [&:has([role=checkbox])]:pr-0",
          className
        ),
        ...props
      }
    );
  }
  function TableCell({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "td",
      {
        "data-slot": "table-cell",
        className: cn(
          "p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0",
          className
        ),
        ...props
      }
    );
  }
  function TableCaption({
    className,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime58.jsx)(
      "caption",
      {
        "data-slot": "table-caption",
        className: cn("mt-4 text-sm text-muted-foreground", className),
        ...props
      }
    );
  }

  // src/components/ui/textarea.tsx
  init_define_import_meta_env();
  var import_jsx_runtime59 = __toESM(require_react_shim(), 1);
  function Textarea({ className, ...props }) {
    return /* @__PURE__ */ (0, import_jsx_runtime59.jsx)(
      "textarea",
      {
        "data-slot": "textarea",
        className: cn(
          "flex field-sizing-content min-h-16 w-full rounded-lg border border-input bg-transparent px-2.5 py-2 text-base transition-colors outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 md:text-sm dark:bg-input/30 dark:disabled:bg-input/80 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40",
          className
        ),
        ...props
      }
    );
  }
  return __toCommonJS(ds_entry_exports);
})();
/*! Bundled license information:

use-sync-external-store/cjs/use-sync-external-store-shim.development.js:
  (**
   * @license React
   * use-sync-external-store-shim.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js:
  (**
   * @license React
   * use-sync-external-store-shim/with-selector.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

tabbable/dist/index.esm.js:
  (*!
  * tabbable 6.4.0
  * @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
  *)

lucide-react/dist/esm/shared/src/utils/mergeClasses.js:
lucide-react/dist/esm/shared/src/utils/toKebabCase.js:
lucide-react/dist/esm/shared/src/utils/toCamelCase.js:
lucide-react/dist/esm/shared/src/utils/toPascalCase.js:
lucide-react/dist/esm/defaultAttributes.js:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.js:
lucide-react/dist/esm/Icon.js:
lucide-react/dist/esm/createLucideIcon.js:
lucide-react/dist/esm/icons/check.js:
lucide-react/dist/esm/icons/chevron-down.js:
lucide-react/dist/esm/icons/chevron-right.js:
lucide-react/dist/esm/icons/chevron-up.js:
lucide-react/dist/esm/icons/panel-left.js:
lucide-react/dist/esm/icons/x.js:
lucide-react/dist/esm/lucide-react.js:
  (**
   * @license lucide-react v0.577.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
window.CacDS=CacDS.__dsMainNs?Object.assign({},CacDS,CacDS.__dsMainNs,{__dsMainNs:undefined}):CacDS;
