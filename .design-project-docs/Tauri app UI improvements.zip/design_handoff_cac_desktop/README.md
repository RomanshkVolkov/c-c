# Handoff: rediseño del escritorio cac

## Qué es esto

El rebranding visual (tema oscuro grafito + cian, tema claro) y los cambios de
navegación del escritorio Tauri: sidebar agrupado con árbol de espacios, chats y
DMs separados por organización, DevTools en una sola pantalla, "Mi trabajo" como
entrada por defecto y detalle de tarea a pantalla completa.

> **Paquetes aparte, posteriores a este** — cada uno con su documento y su
> prototipo, implementables por separado y en cualquier orden:
>
> - **Salas de voz:** [`voz-salas.md`](voz-salas.md) · `Cac Voice Rooms.dc.html`
> - **Documentación por proyecto:** [`docs-proyecto.md`](docs-proyecto.md) · `Cac Project Docs.dc.html`

## Sobre los archivos de este paquete

`Cac Desktop Flow.dc.html` es una **referencia de diseño escrita en HTML**: un
prototipo navegable que muestra el aspecto y el comportamiento buscados. No es
código para copiar. El trabajo es reproducir ese diseño **en el codebase actual**
(React + Vite + Tailwind v4 + shadcn + zustand + Tauri), con sus patrones ya
establecidos.

Ábrelo en un navegador para navegarlo: todo lo que se describe abajo funciona
ahí (arrastrar, crear, filtrar, cambiar de tema con el prop `theme`).

## Fidelidad

**Alta.** Colores, tipografías, tamaños y espaciados son finales. La estructura de
cada pantalla es final. Los datos son de ejemplo.

## Regla que manda sobre todo lo demás

**No se toca la capa de API ni la autenticación.** Casi todo el rediseño es
visual sobre lo que ya existe: reutiliza los stores, los endpoints y los tipos
actuales. Donde el diseño pide algo que hoy no existe, está listado abajo en
"Endpoints que faltan" — nada de eso se inventa en el cliente.

---

## Orden de PRs sugerido

1. **Tokens.** Reemplazar el bloque de variables de `src/index.css` por
   `tokens.css` de este paquete. Un archivo, sin tocar componentes. Aquí cae el
   80% del rebranding porque la app ya usa `bg-background`, `text-muted-foreground`,
   `border`, `bg-sidebar`.
2. **Sidebar.** `AppSidebar.tsx`: agrupar en Work / Talk / Tools / Plataforma,
   árbol de espacios con acciones en fila, candado de orden, dropdown por fila.
3. **Tasks.** `Tasks.tsx`: "Mi trabajo" como vista por defecto, filtros como
   chips, composer de nueva tarea en línea, detalle a pantalla completa.
4. **DevTools.** Unificar `ImageTool`, `RequestClient` y `CryptoTools` bajo una
   ruta con rail de herramientas.
5. **Chat y DMs.** Sacar `ChatPanel` de Tasks a pantalla propia; DMs al mismo
   nivel.
6. **Notificaciones y ⌘K.** Panel de notificaciones y paleta de comandos.

Cada PR es independiente: si se para en el 1, la app ya se ve nueva.

---

## Tokens

Todo está en `tokens.css`. Los nombres de variable **no cambian**, así que ningún
componente shadcn necesita edición.

Lo que cambia respecto a hoy:

| Variable | Antes (oscuro) | Ahora (oscuro) |
| --- | --- | --- |
| `--background` | `#081225` navy | `#101013` grafito |
| `--card` | `#111F3A` | `#17171B` |
| `--muted` | `#0D1930` | `#131317` |
| `--muted-foreground` | `#8B99B0` azulado | `#9A9AA4` neutro |
| `--accent` | `#162747` | `#212128` |
| `--border` | `#223454` | `#2B2B33` |
| `--sidebar` | `#07101F` | `#0A0A0D` |
| `--sidebar-border` | `#1C2C49` | `#23232A` |
| `--destructive` | `#FB7185` | `#FB7185` (igual) |
| `--primary` | `#20D9E8` | `#20D9E8` (igual) |

El cian se mantiene; lo que se va es el azul del fondo. El tema claro se queda
casi igual: solo `--accent` (`#f2f4f6`) y `--border` (`#e8eaee`) se neutralizan.

**Tema por defecto: oscuro.** `theme.store.ts` ya resuelve la clase `.dark`; solo
hay que cambiar el valor inicial.

### Tipografía

Ya vendorizada en el proyecto, no se añade nada:

- Interfaz: **Inter Variable**. 13px base, 12.5px en filas de árbol, 11.5px en
  metadatos, 19px en títulos de pantalla (peso 650), 21px en título de tarea.
- Monoespaciada: **Iosevka Term Slab**, para folios (`portento-89`), IDs, JSON,
  métodos HTTP, atajos de teclado y tamaños. Nunca para texto corrido.

### Otras constantes

- Radios: filas y chips `6–8px`; tarjetas y diálogos `10–13px`; `--radius` sigue en `0.625rem`.
- Alturas: fila de árbol 30px, chip 26px, botón `sm` 32px, barra de título 38px, cabecera de contenido 46px.
- Sidebar 250px; panel de contexto derecho 250–300px; rail de herramientas 200px (46px colapsado).
- Sombra de menús y diálogos: `0 18px 44px rgba(0,0,0,.5)` y `0 28px 70px rgba(0,0,0,.55)`.
- Semántica de color: vence hoy/ayer y urgente en `--destructive`; alta en `--warning`; normal en `--info`; baja y sin fecha en `--muted-foreground`; hecho en `--success`. Lo visible para el cliente siempre en `--warning`.

---

## Mapa pantalla → archivo

| Pantalla del prototipo | Archivo del codebase | Qué cambia |
| --- | --- | --- |
| Barra de título + buscador ⌘K | `components/AppLayout.tsx` | Buscador centrado que abre la paleta; campana con contador |
| Sidebar | `components/AppSidebar.tsx` | Reescritura de la estructura: grupos Work / Talk / Tools / Plataforma; árbol con `+`, `⋯`, candado y arrastre; pie con versión y estado |
| Menú de cuenta (pie del sidebar) | `components/AppSidebar.tsx` + `ChangePassword.tsx`, `ConnectMcpDialog.tsx`, `NotificationsPanel.tsx` | Solo visual; los tres diálogos ya existen y se conservan |
| Mi trabajo (lista / tablero / calendario) | `pages/Tasks.tsx` | Vista por defecto sin espacio seleccionado; pestañas Asignadas / Creadas / Siguiendo / De clientes / Todas; filtros como chips; agrupar por espacio |
| Composer de nueva tarea | `pages/Tasks.tsx` | Fila en línea sobre la lista, con destino, prioridad, fecha, responsable y visibilidad |
| Detalle de tarea | `pages/Tasks.tsx` (panel derecho hoy) | A pantalla completa con panel lateral de propiedades; folio y visibilidad arriba |
| Canales | `components/ChatPanel.tsx` | Deja de ser panel dentro de Tasks: pantalla propia con lista de canales por organización |
| Directos | `components/DMSwitcher.tsx` | Sale del switcher a entrada propia del sidebar |
| Notificaciones | `components/NotificationsPanel.tsx` | Panel anclado a la campana, agrupado por tipo, con "marcar todo leído"; sin botón de prueba |
| DevTools · Imagen | `pages/ImageTool.tsx` | Ajustes en una fila, chips de formato, aviso cuando el resultado crece |
| DevTools · Requests | `pages/RequestClient.tsx` | Igual de estructura; ámbito del request visible y punto de cambios sin guardar |
| DevTools · Tokens (antes Crypto) | `pages/CryptoTools.tsx` | Renombrada; secciones como chips; JWT coloreado por partes y `exp` en lenguaje humano |
| Organización | `pages/OrganizationSettings.tsx`, `pages/Users.tsx`, `pages/Invitations.tsx` | Una pantalla con pestañas: Identidad, Miembros, Invitaciones, Integraciones |
| Invitaciones para ti | `pages/Invitations.tsx` | Pantalla propia accesible desde el selector de organización |
| Paleta ⌘K | nuevo | Crear tarea / folder / lista / espacio e ir a un espacio |
| Modo invitado | `pages/ImageTool.tsx` + `ProtectedRoute` | Arranca en DevTools; el resto del producto no aparece |

Pantallas que **no** cambian de estructura y solo heredan el tema: `Dashboard`,
`Notes`, `Diagnostics`, `ServerManage`, `ServerStats`, `StackSecrets`, `Login`.

---

## Comportamiento que hay que reproducir

### Árbol de espacios

- `+` y `⋯` **siempre visibles** en cada fila (hoy son `opacity-0 group-hover`, invisibles y sin acceso por teclado).
- Crear **sin modal**: el `+` inserta una fila editable en su sitio. `Enter` crea y deja lista la siguiente hermana, `Tab` crea y anida dentro, `Esc` cancela. Sustituye a `prompt()` de `PromptDialog`.
- Renombrar en línea, en la misma fila, con el texto seleccionado.
- **Folders anidados**: un folder puede contener otro. Hoy el modelo es espacio → folder → lista, plano.
- **Candado** en la cabecera de Espacios, cerrado por defecto: sin él no hay asas ni arrastre.
- Arrastre con zonas: borde superior = antes, centro de un folder = dentro, borde inferior = después. El folder arrastra su contenido y se atenúa completo, con contador "moviendo N". Arrastrar a otro espacio se marca en rojo y no hace nada: para eso está "Mover a otro espacio…".
- `⋯` abre un dropdown flotante (no una tira en línea): nuevo folder, nueva lista, ordenar A–Z, renombrar, duplicar, mover a otro espacio, borrar.

### Tasks

- Sin espacio seleccionado se ve **Mi trabajo**: todas las tareas abiertas agrupadas por espacio. Elegir un espacio o una lista en el árbol **filtra** esa misma vista, no navega a otra pantalla.
- El filtro de estado oculta las cerradas por defecto.
- El composer crea y se queda abierto para la siguiente.

### Notificaciones

- El panel crece con el contenido hasta el borde inferior y ahí scrollea; cabecera y pie fijos.
- Cada notificación navega a su origen (tarjeta, canal, servidor).

---

## Endpoints

### Se reciclan tal cual

Todo el rediseño de Tasks, Chat, DMs, Organización, Invitaciones, Colecciones,
Reports y MCP corre sobre lo que ya existe:

- `/api/v1/task-spaces/`, `/task-spaces/:id`, `/task-spaces/:id/folders`, `/task-spaces/:id/lists`, `/task-spaces/:id/chat`
- `/api/v1/task-folders/:id`, `/api/v1/task-lists/:id`, `/task-lists/:id/board`, `/task-lists/:id/tasks`
- `/api/v1/tasks/:id`, `/tasks/:id/comments`, `/tasks/:id/attachments`, `/tasks/:id/move`
- `/api/v1/dm/`, `/dm/:id/messages`, `/dm/:id/read`
- `/api/v1/organizations/...`, `/api/v1/invitations/...`, `/api/v1/users/...`
- `/api/v1/report-projects/...`, `/api/v1/reports/...`
- `/api/v1/collections/...`, `/api/v1/notes/...`, `/api/v1/docs/...`

### Faltan para lo nuevo

| Necesidad | Hoy | Propuesta |
| --- | --- | --- |
| Reordenar el árbol arrastrando | `POST /task-spaces/:id/move?dir=up\|down` y `/task-folders/:id/move?dir=` — solo un paso arriba/abajo, y las listas no tienen endpoint de movimiento | `PUT /api/v1/task-spaces/:id/tree` con un lote de `{id, kind, parentId, position}`, igual que `PUT /api/v1/notes/tree` que ya existe |
| Folders anidados | El modelo asume folder hijo directo del espacio | `parentFolderId` en `task-folders` |
| Mover una lista o folder a otro espacio | No existe | `POST /api/v1/task-lists/:id/move-to-space` y `/task-folders/:id/move-to-space` |
| Duplicar folder con su contenido | No existe | `POST /api/v1/task-folders/:id/duplicate` |
| Mi trabajo | `GET /api/v1/tasks/?orgId&limit` sin filtros de persona | Parámetros `assignee=me`, `creator=me`, `watcher=me`, `status=open`, `dueFrom`, `dueTo`, `groupBy=space` |
| Vista de calendario | — | Se resuelve con `dueFrom` / `dueTo` del punto anterior |
| Seguir una tarea | No hay concepto de watcher | `POST /api/v1/tasks/:id/watch` y `DELETE` |
| Feed de notificaciones | `notifications.store.ts` es **local**: solo registra lo que llegó por SSE mientras la app estuvo abierta | `GET /api/v1/notifications?orgId`, `POST /notifications/read`, `POST /notifications/read-all` |
| Preferencias de notificación | No existen | `GET` y `PATCH /api/v1/notifications/preferences` |
| Buscador ⌘K global | Solo `/users/search` y `/notes/search` | `GET /api/v1/search?q=&orgId=` sobre tareas, mensajes, notas y personas |

Nota sobre notificaciones: hoy el badge de no leídas solo puede reflejar lo que
pasó con la app abierta. Esa es la queja que arrastramos de Slack, y no se
arregla en el cliente: hace falta el feed persistente.

---

## Archivos de este paquete

- `Cac Desktop Flow.dc.html` — el prototipo navegable. Ábrelo en un navegador.
- `Cac Desktop Redesign.dc.html` — las exploraciones iniciales (tres navegaciones distintas). Contexto, no destino.
- `tokens.css` — el bloque de variables listo para pegar en `src/index.css`.
- `_ds/` — fuentes y bundle del design system que usa el prototipo. **No hace falta copiarlo al proyecto**: las fuentes ya están vendorizadas en `src/assets/fonts`.
